-- Run as the V3 DB administrator only. No password belongs in this file.
-- This resolves the previously observed 1370 for sys.ML_GENERATE only.
-- A later failure must be diagnosed; this is not proof all GenAI grants are sufficient.
GRANT EXECUTE ON FUNCTION sys.ML_GENERATE
TO 'olvn_v3_app'@'10.0.0.0/255.255.255.0';
