<?php
declare(strict_types=1);
require __DIR__ . '/runtime.php';
try {
    if (($argv[1] ?? '') === '--reuse') {
        $old = new App\Infrastructure\Console\PackageFileReader();
        $host = json_decode($old->read('/etc/olvn-v3/runtime/connection.json', 4096, true), true, 16, JSON_THROW_ON_ERROR)['host'];
        $secret = json_decode($old->read('/etc/olvn-v3/runtime/database.json', 16384, true), true, 16, JSON_THROW_ON_ERROR);
        $password = $secret['password'];
        if ($secret['username'] !== 'olvn_v3_app') {
            throw new RuntimeException('Unexpected existing username.');
        }
        $mode = $argv[2] ?? '';
    } else {
        $host = $argv[1] ?? '';
        $mode = $argv[2] ?? '';
        $password = stream_get_contents(STDIN, 4097);
    }
    if (!filter_var($host, FILTER_VALIDATE_IP, FILTER_FLAG_IPV4) || !str_starts_with($host, '10.0.1.')
        || !in_array($mode, ['bundled', 'database'], true) || !is_string($password)
        || $password === '' || strlen($password) > 4096 || strpbrk($password, "\r\n\0") !== false) {
        throw new RuntimeException('Invalid setup input.');
    }
    if (file_exists(V3Runtime::CONFIG) || is_link(V3Runtime::CONFIG)) {
        throw new RuntimeException('Configuration exists; refusing to overwrite it.');
    }
    $c = ['host'=>$host, 'database'=>'olvn_v3', 'username'=>'olvn_v3_app', 'password'=>$password, 'catalogMode'=>$mode];
    V3Runtime::database($c); // Validate before saving; never save a mistyped password.
    umask(0077);
    $fp = fopen(V3Runtime::CONFIG, 'xb');
    $bytes = json_encode($c, JSON_THROW_ON_ERROR);
    if ($fp === false || fwrite($fp, $bytes) !== strlen($bytes)) {
        throw new RuntimeException('Configuration write failed.');
    }
    fclose($fp);
    echo "PASS: credentials verified and saved privately.\n";
} catch (Throwable $e) {
    fwrite(STDERR, V3Runtime::error($e) . "\n");
    exit(1);
}
