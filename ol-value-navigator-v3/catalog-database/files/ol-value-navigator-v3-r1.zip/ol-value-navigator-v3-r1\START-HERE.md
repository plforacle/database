# Oracle Linux Value Navigator V3: Installation Package R1

This ZIP includes Shawn's reviewed application and production PHP libraries. You do not install or run Composer on OCI.

This is a private rehearsal candidate for your existing **ol-value-navigator-3-app** instance and **olvn_v3** database from Labs 1 and 2. It is not a fully verified release. The unresolved application-account GenAI error must still pass the included test on HeatWave.

## Download, unzip, install, test

Upload `ol-value-navigator-v3-r1.zip` to your chosen Object Storage bucket. Download it to the V3 compute instance using your approved Object Storage download method. If you use a pre-authenticated request, treat its URL as a secret and give it a short expiry. Do not share the URL in chat or source control.

From your SSH session on **ol-value-navigator-3-app**, in the directory containing the ZIP:

```bash
unzip ol-value-navigator-v3-r1.zip
cd ol-value-navigator-v3-r1
sudo bash install.sh
sudo bash /opt/olvn-v3/package-r1/test.sh
```

Use a new extraction directory if this folder already exists. Compare the downloaded ZIP's SHA256 with the supplied sidecar before extracting. The installer also checks its internal file manifest.

The installer reuses and verifies the V3 application credentials already configured during Lab 3. If they are absent, it prompts for the private database IP and password. No credentials are included in this ZIP. A mistyped password fails the connection check before a new credential file is saved.

It checks PHP dependencies, then installs to `/opt/olvn-v3/package-r1`. It leaves `/opt/olvn-v3/app`, existing credentials, database records, Version 1, and the port-80 greeting untouched. It adds a loopback-only Apache listener on port 8009. Do not open port 8009 in OCI or the firewall.

The existing server must already have PHP 8.3, the extensions from Lab 3, Apache/PHP-FPM, and SELinux management tools. This package does not provision infrastructure, migrate the schema, create database accounts, or install operating-system packages.

## One catalog choice

The installer asks you to type one of these values:

* `bundled`: use Shawn's complete built-in catalog included in this ZIP. Comparison records and their catalog snapshots still go into MySQL HeatWave. Catalog changes come with a new tested ZIP. The database package channel is not activated or changed.
* `database`: use Shawn's existing database publish/activate workflow. This requires an active catalog. Your generation-zero channel is not yet ready for this option. The installer stops before enabling Apache if the catalog cannot load.

Bundled mode is recommended for a simple private workshop rehearsal. It is an explicit choice, not a fallback if database catalog checks fail. This ZIP does not remove either implementation from Shawn's source.

## Open the application

On your Windows computer, open PowerShell and use the same SSH key that worked in Lab 3:

```powershell
$V3Key = 'C:\REPLACE\WITH\YOUR\V3-PRIVATE-KEY.key'
ssh -i $V3Key -o ExitOnForwardFailure=yes -N -L 127.0.0.1:8080:127.0.0.1:8009 opc@158.101.119.245
```

Keep that window open. Browse to **http://127.0.0.1:8080/demo/coverage**. Use `/demo/coverage/new` for the newer scenario editor and `/demo` for the AI-assisted input workflow. They are separate upstream workflows, not a newly integrated screen.

If another tunnel uses local port 8080, stop that tunnel or use 8081 on the left side and in your browser address. Stop the tunnel with Ctrl+C when finished.

## What a passing test means

The test checks PHP extensions, both catalog profiles, independently calculated synthetic legacy totals, an unknown-SKU block, restricted database access, GenAI, HTTP routes, and private-file boundaries. Any failure makes the script exit with a failure status.

After those checks, use invented data to save a comparison, reopen its saved URL, confirm it, and export its presentation. Test an import and verify its reviewed quantities and prices. Compare displayed totals with hand calculations. These browser and persistence checks are still required; the automated smoke test does not claim to cover them.

There is no real multiuser login in this candidate. All requests use the existing shared demo identity. Keep it private and use no customer data. Installing this ZIP does not establish user isolation, commercial price approval, or five-year support in the newer 12/36-month scenario workflow.

Database TLS is required, but certificate identity is not verified in this rehearsal. The browser uses loopback HTTP through encrypted SSH, not a public HTTPS endpoint.

## If a check fails

Read the failing stage and database error number. Permission errors also identify the denied routine when the server provides one. Do not grant broad administrator permissions.

`genai-grant.sql` contains only the function-specific grant already applied during your rehearsal. It is not a claim that the remaining GenAI failure is solved. If the same test still fails, capture its new error and diagnose that exact routine or service issue.

The installer intentionally refuses to overwrite an existing package or private configuration. A partial install is preserved for diagnosis; do not repeatedly rerun setup or delete broad directories. Use the installed test script to inspect a completed installation.

If this package must be disabled, move only `/etc/httpd/conf.d/olvn-v3-package.conf` to a backup location outside `conf.d`, check `sudo httpd -t`, and reload Apache only if syntax is valid. This stops the new listener without deleting application files or database records.

## Provenance and maintenance

Upstream: Shawn's local `olvalnav` repository, commit `d419d24d035cabc68b219b9e98be23cd05770742`. Application source is copied unchanged; the package adds a separate entry point and deployment helpers. Dependencies follow its unmodified Composer lock file. Third-party license files remain in `app/vendor`.

Use the ZIP as a deployment artifact, not as a substitute for team-owned source and release maintenance. See `BUILD-REPORT.md` for actual validation and limitations.
