#!/usr/bin/env bash
# First install on Perside's existing V3 server. No OCI provisioning or schema changes.
set -euo pipefail
trap 'echo "STOP: setup failed at line $LINENO. Prior V3 installation and database were not deleted." >&2' ERR
[[ $EUID -eq 0 ]] || { echo "Run: sudo bash install.sh"; exit 1; }
[[ $(hostname -s) == ol-value-navigator-3-app ]] || { echo "This installer is restricted to ol-value-navigator-3-app."; exit 1; }
SOURCE=$(cd -- "$(dirname -- "$0")" && pwd -P)
TARGET=/opt/olvn-v3/package-r2
CONFIG=/etc/olvn-v3-package
[[ ! -e "$TARGET" && ! -L "$TARGET" ]] || { echo "Package already installed. Run: sudo bash $TARGET/test.sh"; exit 1; }
[[ ! -e "$CONFIG" && ! -L "$CONFIG" ]] || { echo "Private configuration directory exists. Inspect before retrying."; exit 1; }
[[ ! -e /etc/httpd/conf.d/olvn-v3-package.conf ]] || { echo "Package Apache configuration already exists."; exit 1; }
for tool in php runuser semanage restorecon sha256sum curl httpd ss; do command -v "$tool" >/dev/null || { echo "Missing prerequisite: $tool. Complete Lab 1 and PHP extensions first."; exit 1; }; done
(cd "$SOURCE" && sha256sum --quiet -c SHA256SUMS)
php "$SOURCE/offline-test.php"
php -r 'if (!function_exists("posix_geteuid")) { fwrite(STDERR,"Install php-process first.\n"); exit(1); }'
[[ -z $(ss -H -ltn 'sport = :8009') ]] || { echo "Port 8009 is in use. Nothing changed."; exit 1; }
semanage port -l | awk '$1=="http_port_t" {print}' | grep -qw 8009 || { echo "SELinux does not list port 8009 for HTTP. Nothing changed."; exit 1; }
MODE=bundled
echo "Using the catalog bundled with this ZIP. HeatWave remains the database."
echo "Existing database catalog publication records will not be changed."
install -d -m 0755 /opt/olvn-v3 "$TARGET"
cp -R -- "$SOURCE/." "$TARGET/"
chown -R root:root "$TARGET"
find "$TARGET" -type d -exec chmod 0755 {} +
find "$TARGET" -type f -exec chmod 0644 {} +
install -d -o apache -g apache -m 0700 "$CONFIG"
install -d -o apache -g apache -m 0700 "$TARGET/app/var/private/coverage"
if [[ -f /etc/olvn-v3/runtime/database.json && -f /etc/olvn-v3/runtime/connection.json ]]; then
    echo "Reusing the existing V3 application credentials, with a connection check."
    runuser -u apache -- php "$TARGET/configure.php" --reuse "$MODE"
else
    read -r -p "V3 private DB IP: " DB_IP </dev/tty
    read -r -s -p "Application password: " APP_PASSWORD </dev/tty
    printf '\n'
    printf '%s' "$APP_PASSWORD" | runuser -u apache -- php "$TARGET/configure.php" "$DB_IP" "$MODE"
    unset APP_PASSWORD
fi
semanage fcontext -a -t httpd_sys_content_t '/opt/olvn-v3/package-r2(/.*)?'
semanage fcontext -a -t httpd_sys_rw_content_t '/opt/olvn-v3/package-r2/app/var/private(/.*)?'
semanage fcontext -a -t httpd_sys_content_t '/etc/olvn-v3-package(/.*)?'
restorecon -R "$TARGET" "$CONFIG"
runuser -u apache -- php "$TARGET/check.php"
install -m 0644 "$TARGET/apache.conf" /etc/httpd/conf.d/olvn-v3-package.conf
if ! httpd -t; then
    mv -- /etc/httpd/conf.d/olvn-v3-package.conf "$TARGET/apache.conf.failed"
    echo "Apache syntax failed. New configuration moved aside; existing service not reloaded."
    exit 1
fi
systemctl reload httpd
echo "INSTALLED. Next: sudo bash /opt/olvn-v3/package-r2/test.sh"
echo "No public endpoint was opened. See START-HERE.md for the SSH tunnel."
