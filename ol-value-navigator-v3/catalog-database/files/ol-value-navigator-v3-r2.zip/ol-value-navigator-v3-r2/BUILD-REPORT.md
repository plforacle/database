# V3 R2 Build Report

Date: September 16, 2026.

Status: **Private rehearsal candidate, not an end-to-end verified release.**

## Contents and provenance

* Source commit: `d419d24d035cabc68b219b9e98be23cd05770742` from Shawn's `olvalnav` repository.
* The original `app`, `config`, `resources`, public assets, Composer declarations and lock file are unchanged. A separate `package-index.php` entry point and deployment helpers are added.
* Production libraries were installed from the unchanged lock file with scripts and plugins disabled. Development-only packages were removed from the isolated build before packaging. Composer itself, development tools, tests, private configuration and credentials are not bundled.
* PHP 8.3.33 was downloaded from the official PHP distribution and its SHA256 was verified. This portable build tool is not included in the deployment ZIP and did not replace the user's installed PHP.
* Composer's downloaded tool checksum was verified against its official SHA256.
* The installer is specific to the existing V3 hostname and Lab 2 schema. It does not provision OCI or modify Version 1.

## Passed locally

* Production Composer platform requirements under Windows PHP 8.3.33.
* Composer production dependency audit: no reported advisories or abandoned packages at build time.
* Syntax lint for the five added PHP files and Bash parsing for the installer and test script.
* Offline test: both complete catalog profiles load, with 103 legacy and 106 scenario entries.
* Independent synthetic legacy arithmetic: ten source units at invented USD 150 versus ten target units at invented USD 60 produces USD 1,500 versus USD 600 annually, USD 900 savings and 60 percent. Three-year totals are USD 4,500 versus USD 1,800; five-year totals are USD 7,500 versus USD 3,000.
* Unknown SKU remains blocked rather than ready.
* Slim rendered `/health/live`, `/demo`, `/demo/coverage`, and `/demo/coverage/new` with HTTP 200 using the bundled catalog and an in-memory SQLite connection. These checks do not exercise Apache, MySQL or saved records.

## Full upstream suite did not pass

The full unit suite ran locally on Windows PHP 8.3.33: 853 tests, 20,140 assertions, 37 errors, 15 failures, 6 warnings and 1 skipped test. It is not a full passing test result.

Observed failures include Linux permission and symlink expectations, platform-dependent console line endings, repository/process verification, and presentation archive finalization. These require a compatible Linux test environment and investigation before release approval. No upstream source was changed to suppress or bypass failing tests.

The initial run also lacked the local SQLite driver; that build-environment omission was corrected before the results above were recorded.

## Not verified here

* Installation under Oracle Linux, SELinux rules, Apache/PHP-FPM execution, and private-file HTTP denial.
* Live MySQL HeatWave persistence, user-owned data isolation, imports, and presentation export.
* Application-account GenAI: the user reported another failure after the function grant. The underlying new error remains unresolved. The included check reports a bounded driver error and denied routine when available. It must not print credentials or falsely report PASS.
* Real login is not implemented. Shared demo identity remains. Newer scenario periods remain 12 and 36 months.
* Catalog prices are not approved commercial quotes. Bundled mode uses the upstream fixed catalog explicitly; it does not publish a database package or imply commercial approval.

## Operational boundaries

R2 automatically selects the user-approved bundled catalog. No catalog selection prompt or database catalog publication is required. MySQL HeatWave remains the application database in both modes. The new package uses a separate directory and private loopback listener, leaving the earlier candidate and database records intact.

Database encryption is required, but certificate identity is not verified. Public HTTPS and real authentication are not provided. Use synthetic data through an SSH tunnel only.

No OCI commands, migrations, grants, deployments, or remote server tests were run by the assistant while building this package.

## R2 changes

R2 changes only the deployment helpers, installation path and instructions. It selects bundled mode automatically, verifies the package manifest before executing its PHP checks, and uses `/opt/olvn-v3/package-r2`. R1 remains unchanged. This is a first-install package, not an automatic upgrade from an installed R1.

The full upstream suite results above are retained from the R1 build against the same unchanged source and dependency lock. They were not rerun for R2. R2's final archive requires its own syntax, integrity, offline calculation and page-rendering checks; those do not establish Linux or HeatWave integration success.

