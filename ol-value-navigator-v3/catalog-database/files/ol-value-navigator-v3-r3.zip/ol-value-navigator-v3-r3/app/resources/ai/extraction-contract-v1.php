<?php

declare(strict_types=1);

return [
    'contractVersion' => 'heatwave-extraction-v1',
    'promptTemplateVersion' => 'heatwave-prompt-v1',
    'maximumLines' => 100,
    'maximumLineBytes' => 32_768,
    'maximumIntegerDigits' => 15,
    'maximumFractionalDigits' => 4,
];
