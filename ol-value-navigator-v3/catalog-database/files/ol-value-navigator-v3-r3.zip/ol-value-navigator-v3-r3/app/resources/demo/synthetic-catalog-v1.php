<?php

declare(strict_types=1);

return [
    'catalogVersionId' => '00000000-0000-4000-8000-000000000901',
    'label' => 'SYNTHETIC DEMO CATALOG — NOT ORACLE PRICING',
    'skus' => [
        [
            'sku' => 'SYN-RHEL-BASE',
            'description' => 'Synthetic source subscription',
            'unit' => 'SYSTEM',
            'annualUsdPrice' => '100.00',
        ],
        [
            'sku' => 'SYN-OL-BASE',
            'description' => 'Synthetic governed option',
            'unit' => 'SYSTEM',
            'annualUsdPrice' => '60.00',
        ],
    ],
    'aliases' => [],
    'mappings' => [
        [
            'sourceSku' => 'SYN-RHEL-BASE',
            'optionSku' => 'SYN-OL-BASE',
            'rationale' => 'Synthetic demonstration mapping only',
        ],
    ],
];
