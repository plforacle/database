<?php

declare(strict_types=1);

$subject = getenv('OLVN_DEMO_REPRESENTATIVE_SUBJECT');
if ($subject === false || trim($subject) === '') {
    throw \App\Domain\Shared\DomainViolation::because('Synthetic representative subject is required.');
}
$modelIdentifier = getenv('HEATWAVE_MODEL_ID');
if ($modelIdentifier === false || trim($modelIdentifier) === '' || strlen($modelIdentifier) > 255) {
    throw \App\Domain\Shared\DomainViolation::because('HeatWave model identifier is required.');
}
$databaseDsn = getenv('OLVN_DATABASE_DSN');
if ($databaseDsn === false || trim($databaseDsn) === '') {
    throw \App\Domain\Shared\DomainViolation::because('Database DSN is required.');
}
$databaseUserSecretPath = getenv('OLVN_DATABASE_USER_SECRET_PATH');
if ($databaseUserSecretPath === false || trim($databaseUserSecretPath) === '') {
    throw \App\Domain\Shared\DomainViolation::because('Database user secret path is required.');
}
$environment = getenv('OLVN_ENVIRONMENT');

return [
    'environment' => $environment === false || trim($environment) === '' ? 'production' : trim($environment),
    'demoRepresentativeSubject' => trim($subject),
    'heatWaveModelIdentifier' => trim($modelIdentifier),
    'databaseDsn' => trim($databaseDsn),
    'databaseUserSecretPath' => trim($databaseUserSecretPath),
];
