<?php

declare(strict_types=1);

use App\Bootstrap;

require __DIR__ . '/../vendor/autoload.php';

/** @var array<string, mixed> $settings */
$settings = require __DIR__ . '/../config/app.php';

Bootstrap::app($settings, Bootstrap::database($settings))->run();
