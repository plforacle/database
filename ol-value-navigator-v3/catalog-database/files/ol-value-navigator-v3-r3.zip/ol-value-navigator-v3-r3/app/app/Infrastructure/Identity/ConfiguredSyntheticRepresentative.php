<?php

declare(strict_types=1);

namespace App\Infrastructure\Identity;

use App\Application\Identity\RepresentativeContext;
use App\Domain\Shared\Actor;
use App\Domain\Shared\DomainViolation;

final readonly class ConfiguredSyntheticRepresentative implements RepresentativeContext
{
    public function __construct(private string $subject)
    {
        if (trim($subject) === '') {
            throw DomainViolation::because('Synthetic representative subject is required.');
        }
    }

    public function current(): Actor
    {
        return Actor::representative(trim($this->subject));
    }
}
