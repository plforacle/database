<?php

declare(strict_types=1);

namespace App\Infrastructure\Identity;

use App\Application\Package\PackagePublisherPrincipal;
use App\Domain\Shared\DomainViolation;
use PDO;
use PDOException;

final readonly class PdoPackagePublisherPrincipal implements PackagePublisherPrincipal
{
    /** @param array<mixed> $allowedAccounts */
    public function __construct(private PDO $pdo, private array $allowedAccounts)
    {
        if (!array_is_list($allowedAccounts) || $allowedAccounts === []) {
            throw DomainViolation::because('Package publisher authorization is unavailable.');
        }
        foreach ($allowedAccounts as $account) {
            if (!is_string($account) || preg_match('/\A[A-Za-z0-9_.-]{1,32}@[A-Za-z0-9_.:%-]{1,255}\z/D', $account) !== 1
                || strtolower(explode('@', $account)[0]) === 'root') {
                throw DomainViolation::because('Package publisher authorization is unavailable.');
            }
        }
    }

    public function authenticatedIdentifier(): string
    {
        try {
            $statement = $this->pdo->query('SELECT CURRENT_USER()');
            $account = $statement === false ? false : $statement->fetchColumn();
        } catch (PDOException) {
            throw DomainViolation::because('Package publisher authentication failed.');
        }
        if (!is_string($account) || !in_array($account, $this->allowedAccounts, true)) {
            throw DomainViolation::because('Package publisher is not authorized.');
        }
        return $account;
    }
}
