<?php

declare(strict_types=1);

namespace App\Infrastructure\Catalog;

interface CatalogWorkbookReader
{
    /**
     * @param array<string, mixed> $manifest
     * @return array{cells: array<string, array{value: string|null, formula: string|null}>, tables: array<string, list<array<string, string|null>>>}
     */
    public function read(string $path, array $manifest): array;
}
