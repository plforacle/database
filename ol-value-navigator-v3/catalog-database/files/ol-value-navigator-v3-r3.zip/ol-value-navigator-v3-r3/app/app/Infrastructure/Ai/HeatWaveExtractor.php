<?php

declare(strict_types=1);

namespace App\Infrastructure\Ai;

use App\Application\Extraction\ExtractionContract;
use App\Application\Extraction\Extractor;
use App\Application\Extraction\HeatWaveGenerateClient;
use App\Application\Extraction\InvalidExtractionResponse;
use App\Domain\Extraction\ExtractionEvidence;
use App\Domain\Extraction\ExtractionResult;
use App\Domain\Shared\DomainViolation;
use App\Domain\Shared\RedactedSourceText;
use App\Domain\Shared\RequestId;
use JsonException;

final readonly class HeatWaveExtractor implements Extractor
{
    private ExtractionContract $contract;

    public function __construct(private HeatWaveGenerateClient $client, private string $modelIdentifier)
    {
        if (trim($modelIdentifier) === '' || strlen($modelIdentifier) > 255) {
            throw DomainViolation::because('The HeatWave model identifier is required.');
        }
        $this->contract = new ExtractionContract();
    }

    public function extract(RedactedSourceText $source, RequestId $requestId): ExtractionResult
    {
        $template = file_get_contents(dirname(__DIR__, 3) . '/resources/ai/heatwave-extraction-prompt-v1.txt');
        if (!is_string($template)) {
            throw InvalidExtractionResponse::because('the prompt template is unavailable.');
        }
        $outer = $this->client->generate($template . "\n" . $source->value(), $this->modelIdentifier);
        try {
            $decoded = json_decode($outer, true, 512, JSON_THROW_ON_ERROR);
        } catch (JsonException) {
            throw InvalidExtractionResponse::because('outer HeatWave JSON is malformed.');
        }
        if (!is_array($decoded) || array_is_list($decoded) || array_diff(array_keys($decoded), ['text', 'error']) !== [] || !array_key_exists('text', $decoded) || !is_string($decoded['text']) || array_key_exists('error', $decoded) && $decoded['error'] !== null) {
            throw InvalidExtractionResponse::because('outer HeatWave JSON has an unsupported shape.');
        }

        return new ExtractionResult(
            ExtractionEvidence::ai($this->modelIdentifier, $this->contract->contractVersion(), $this->contract->promptTemplateVersion(), hash('sha256', $outer)),
            $this->contract->validate($source, $decoded['text']),
        );
    }
}
