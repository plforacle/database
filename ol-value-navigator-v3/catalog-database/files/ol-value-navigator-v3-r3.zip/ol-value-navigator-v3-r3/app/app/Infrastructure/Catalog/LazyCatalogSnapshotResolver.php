<?php

declare(strict_types=1);

namespace App\Infrastructure\Catalog;

use App\Application\Package\CatalogSnapshotResolver;
use App\Domain\Package\CatalogSnapshot;
use App\Domain\Shared\DomainViolation;
use Closure;

/** One application instance only; historical requests never invoke the factory. */
final class LazyCatalogSnapshotResolver implements CatalogSnapshotResolver
{
    private ?CatalogSnapshotResolver $resolver = null;

    /** @param Closure():CatalogSnapshotResolver $factory */
    public function __construct(private readonly Closure $factory)
    {
    }

    public function resolve(string $profileId): CatalogSnapshot
    {
        return $this->resolver()->resolve($profileId);
    }

    public function resolveForConfirmation(string $profileId): CatalogSnapshot
    {
        return $this->resolver()->resolveForConfirmation($profileId);
    }

    private function resolver(): CatalogSnapshotResolver
    {
        try {
            return $this->resolver ??= ($this->factory)();
        } catch (\RuntimeException|\InvalidArgumentException $error) {
            throw DomainViolation::because('The selected catalog is unavailable. Review cannot proceed.');
        }
    }
}
