<?php

declare(strict_types=1);

namespace App\Infrastructure\Persistence;

use App\Application\Package\CatalogPackageValidator;
use App\Application\Package\PackageEnvelopeDecoder;
use App\Domain\Package\CatalogPackageContract;
use App\Domain\Package\CatalogSnapshot;
use App\Domain\Package\StrictJsonObjectDecoder;
use App\Domain\Shared\DomainViolation;
use PDO;

/** Internal attachment access. CoverageStore authorizes ownership before calling read. */
final readonly class CoverageRevisionPackageStore
{
    public function __construct(private PDO $pdo)
    {
    }

    public function insert(string $revisionId, CatalogSnapshot $snapshot): void
    {
        $envelope = $snapshot->package()->envelope();
        $manifest = $envelope->manifestJson();
        $mapping = $envelope->member('mappings')->json();
        $price = $envelope->member('prices')->json();
        $this->bounds($manifest, $mapping, $price);
        $this->pdo->prepare('INSERT INTO coverage_revision_package (revision_id,context_json,manifest_bytes,mapping_bytes,price_bytes) VALUES (?,?,?,?,?)')->execute([
            $revisionId, json_encode($snapshot->context(), JSON_THROW_ON_ERROR), $manifest, $mapping, $price,
        ]);
    }

    public function read(string $revisionId): ?CatalogSnapshot
    {
        // Limit bytes before transferring even an administratively corrupted row.
        $query = $this->pdo->prepare('SELECT context_json, IF(OCTET_LENGTH(manifest_bytes) <= 65536,manifest_bytes,NULL) AS manifest_bytes, IF(OCTET_LENGTH(mapping_bytes) <= 8388608,mapping_bytes,NULL) AS mapping_bytes, IF(OCTET_LENGTH(price_bytes) <= 8388608,price_bytes,NULL) AS price_bytes FROM coverage_revision_package WHERE revision_id=?');
        $query->execute([$revisionId]);
        $row = $query->fetch(PDO::FETCH_ASSOC);
        if ($row === false) {
            return null;
        }
        if (!is_string($row['manifest_bytes']) || !is_string($row['mapping_bytes']) || !is_string($row['price_bytes']) || !is_string($row['context_json'])) {
            throw DomainViolation::because('Saved catalog attachment exceeds its byte bounds.');
        }
        $this->bounds($row['manifest_bytes'], $row['mapping_bytes'], $row['price_bytes']);
        $context = get_object_vars(StrictJsonObjectDecoder::decode($row['context_json'], 8192));
        if (!is_string($context['profileId'] ?? null) || !is_string($context['channel'] ?? null) || !is_int($context['generation'] ?? null)) {
            throw DomainViolation::because('Saved catalog context is invalid.');
        }
        $envelope = (new PackageEnvelopeDecoder(CatalogPackageContract::PROFILES, CatalogPackageContract::MEMBER_SCHEMAS))->decode($row['manifest_bytes'], $row['mapping_bytes'], $row['price_bytes']);
        $package = (new CatalogPackageValidator())->validate($envelope);
        $snapshot = new CatalogSnapshot($package, $context['profileId'], $context['channel'], $context['generation']);
        $expected = $snapshot->context();
        ksort($expected);
        ksort($context);
        if ($context !== $expected) {
            throw DomainViolation::because('Saved catalog context disagrees with its retained package.');
        }
        return $snapshot;
    }

    private function bounds(string $manifest, string $mapping, string $price): void
    {
        if ($manifest === '' || strlen($manifest) > 65536 || $mapping === '' || strlen($mapping) > 8388608 || $price === '' || strlen($price) > 8388608) {
            throw DomainViolation::because('Saved catalog attachment exceeds its byte bounds.');
        }
    }
}
