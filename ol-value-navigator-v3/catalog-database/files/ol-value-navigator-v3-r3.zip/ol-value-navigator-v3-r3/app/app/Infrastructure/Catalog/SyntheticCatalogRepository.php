<?php

declare(strict_types=1);

namespace App\Infrastructure\Catalog;

use App\Domain\Catalog\CatalogRepository;
use App\Domain\Shared\CatalogVersionId;
use App\Domain\Shared\DomainViolation;

final readonly class SyntheticCatalogRepository implements CatalogRepository
{
    /** @var array<string, array{sku: string, description: string, unit: string, annualUsdPrice: string}> */
    private array $skusBySku;

    /** @var list<array{alias: string, governedSku: string}> */
    private array $aliases;

    /** @var array<string, list<array{sku: string, description: string, unit: string, annualUsdPrice: string, rationale: string}>> */
    private array $optionsBySourceSku;

    public function __construct()
    {
        $fixture = SyntheticCatalogFixture::load();
        $this->catalogVersionId = CatalogVersionId::fromString($fixture['catalogVersionId']);
        $this->skusBySku = $this->indexSkus($fixture['skus']);
        $this->aliases = $this->validateAliases($fixture['aliases']);
        $this->optionsBySourceSku = $this->indexMappings($fixture['mappings']);
    }

    private CatalogVersionId $catalogVersionId;

    /**
     * @param list<mixed> $skus
     * @return array<string, array{sku: string, description: string, unit: string, annualUsdPrice: string}>
     */
    private function indexSkus(array $skus): array
    {
        $indexed = [];
        foreach ($skus as $sku) {
            if (!is_array($sku) || array_keys($sku) !== ['sku', 'description', 'unit', 'annualUsdPrice']) {
                throw DomainViolation::because('Synthetic catalog fixture is invalid.');
            }

            $skuIdentifier = $sku['sku'] ?? null;
            $description = $sku['description'] ?? null;
            $unit = $sku['unit'] ?? null;
            $annualUsdPrice = $sku['annualUsdPrice'] ?? null;
            if (!is_string($skuIdentifier) || trim($skuIdentifier) === ''
                || !is_string($description) || trim($description) === ''
                || !is_string($unit) || trim($unit) === ''
                || !is_string($annualUsdPrice) || trim($annualUsdPrice) === '') {
                throw DomainViolation::because('Synthetic catalog fixture is invalid.');
            }

            if (isset($indexed[$skuIdentifier])) {
                throw DomainViolation::because('Synthetic catalog fixture is invalid.');
            }

            $indexed[$skuIdentifier] = [
                'sku' => $skuIdentifier,
                'description' => $description,
                'unit' => $unit,
                'annualUsdPrice' => $annualUsdPrice,
            ];
        }

        return $indexed;
    }

    /**
     * @param list<mixed> $aliases
     * @return list<array{alias: string, governedSku: string}>
     */
    private function validateAliases(array $aliases): array
    {
        $validated = [];
        foreach ($aliases as $alias) {
            if (!is_array($alias) || array_keys($alias) !== ['alias', 'governedSku']) {
                throw DomainViolation::because('Synthetic catalog fixture is invalid.');
            }

            $aliasValue = $alias['alias'] ?? null;
            $governedSku = $alias['governedSku'] ?? null;
            if (!is_string($aliasValue) || trim($aliasValue) === ''
                || !is_string($governedSku) || !isset($this->skusBySku[$governedSku])) {
                throw DomainViolation::because('Synthetic catalog fixture is invalid.');
            }

            $validated[] = ['alias' => $aliasValue, 'governedSku' => $governedSku];
        }

        return $validated;
    }

    /**
     * @param list<mixed> $mappings
     * @return array<string, list<array{sku: string, description: string, unit: string, annualUsdPrice: string, rationale: string}>>
     */
    private function indexMappings(array $mappings): array
    {
        $indexed = [];
        foreach ($mappings as $mapping) {
            if (!is_array($mapping) || array_keys($mapping) !== ['sourceSku', 'optionSku', 'rationale']) {
                throw DomainViolation::because('Synthetic catalog fixture is invalid.');
            }

            $sourceSku = $mapping['sourceSku'] ?? null;
            $optionSku = $mapping['optionSku'] ?? null;
            $rationale = $mapping['rationale'] ?? null;
            if (!is_string($sourceSku) || !is_string($optionSku) || !is_string($rationale)
                || trim($rationale) === '' || !isset($this->skusBySku[$sourceSku]) || !isset($this->skusBySku[$optionSku])) {
                throw DomainViolation::because('Synthetic catalog fixture is invalid.');
            }

            $option = $this->skusBySku[$optionSku];
            $indexed[$sourceSku][] = [
                'sku' => $option['sku'],
                'description' => $option['description'],
                'unit' => $option['unit'],
                'annualUsdPrice' => $option['annualUsdPrice'],
                'rationale' => $rationale,
            ];
        }

        return $indexed;
    }

    /**
     * @return array{sku: string, description: string, unit: string, annualUsdPrice: string|null}|null
     */
    public function findSku(CatalogVersionId $catalogVersionId, string $governedSku): ?array
    {
        if (!$this->isCurrentVersion($catalogVersionId) || !isset($this->skusBySku[$governedSku])) {
            return null;
        }

        return $this->skusBySku[$governedSku];
    }

    /**
     * @return list<array{alias: string, governedSku: string}>
     */
    public function aliasesForVersion(CatalogVersionId $catalogVersionId): array
    {
        return $this->isCurrentVersion($catalogVersionId) ? $this->aliases : [];
    }

    /**
     * @return list<array{sku: string, description: string, unit: string, annualUsdPrice: string, rationale: string}>
     */
    public function eligibleOptions(CatalogVersionId $catalogVersionId, string $sourceSku): array
    {
        if (!$this->isCurrentVersion($catalogVersionId)) {
            return [];
        }

        return $this->optionsBySourceSku[$sourceSku] ?? [];
    }

    private function isCurrentVersion(CatalogVersionId $catalogVersionId): bool
    {
        return (string) $catalogVersionId === (string) $this->catalogVersionId;
    }
}
