<?php

declare(strict_types=1);

namespace App\Infrastructure\Catalog;

use App\Domain\Shared\DomainViolation;

final class SyntheticCatalogFixture
{
    /** @var array{catalogVersionId: string, label: string, skus: list<array{sku: string, description: string, unit: string, annualUsdPrice: string}>, aliases: list<array{alias: string, governedSku: string}>, mappings: list<array{sourceSku: string, optionSku: string, rationale: string}>} */
    private const APPROVED_FACTS = [
        'catalogVersionId' => '00000000-0000-4000-8000-000000000901',
        'label' => 'SYNTHETIC DEMO CATALOG — NOT ORACLE PRICING',
        'skus' => [
            [
                'sku' => 'SYN-RHEL-BASE',
                'description' => 'Synthetic source subscription',
                'unit' => 'SYSTEM',
                'annualUsdPrice' => '100.00',
            ],
            [
                'sku' => 'SYN-OL-BASE',
                'description' => 'Synthetic governed option',
                'unit' => 'SYSTEM',
                'annualUsdPrice' => '60.00',
            ],
        ],
        'aliases' => [],
        'mappings' => [
            [
                'sourceSku' => 'SYN-RHEL-BASE',
                'optionSku' => 'SYN-OL-BASE',
                'rationale' => 'Synthetic demonstration mapping only',
            ],
        ],
    ];

    /**
     * @return array{catalogVersionId: string, label: string, skus: list<array{sku: string, description: string, unit: string, annualUsdPrice: string}>, aliases: list<array{alias: string, governedSku: string}>, mappings: list<array{sourceSku: string, optionSku: string, rationale: string}>}
     */
    public static function load(): array
    {
        $fixture = require dirname(__DIR__, 3) . '/resources/demo/synthetic-catalog-v1.php';
        if (!is_array($fixture)) {
            throw DomainViolation::because('Synthetic catalog fixture is invalid.');
        }

        return self::validate($fixture);
    }

    /**
     * @param array<mixed> $fixture
     * @return array{catalogVersionId: string, label: string, skus: list<array{sku: string, description: string, unit: string, annualUsdPrice: string}>, aliases: list<array{alias: string, governedSku: string}>, mappings: list<array{sourceSku: string, optionSku: string, rationale: string}>}
     */
    public static function validate(array $fixture): array
    {
        $skus = $fixture['skus'] ?? null;
        if (!is_array($skus)) {
            throw DomainViolation::because('Synthetic catalog fixture is invalid.');
        }

        foreach ($skus as $sku) {
            $price = is_array($sku) ? ($sku['annualUsdPrice'] ?? null) : null;
            if (!is_string($price) || !self::isBoundedDecimalPrice($price)) {
                throw DomainViolation::because('Synthetic catalog fixture is invalid.');
            }
        }

        if ($fixture !== self::APPROVED_FACTS) {
            throw DomainViolation::because('Synthetic catalog fixture is invalid.');
        }

        return self::APPROVED_FACTS;
    }

    private static function isBoundedDecimalPrice(string $price): bool
    {
        return preg_match('/^(?:0|[1-9][0-9]{0,14})(?:\.[0-9]{1,4})?$/D', $price) === 1;
    }
}
