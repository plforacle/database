<?php

declare(strict_types=1);

namespace App\Infrastructure\Console;

use App\Application\Catalog\ActivateCatalog;
use App\Domain\Shared\CatalogVersionId;
use App\Domain\Shared\DomainViolation;

final readonly class CatalogActivateCommand
{
    public function __construct(private ActivateCatalog $activateCatalog)
    {
    }

    /** @param list<string> $arguments */
    public function run(array $arguments): int
    {
        $options = $this->options($arguments);
        $catalogVersion = $options['catalog-version'] ?? null;
        $evidenceReference = $options['evidence-reference'] ?? null;
        if ($catalogVersion === null || $evidenceReference === null) {
            throw DomainViolation::because('Usage: catalog:activate --catalog-version=<uuid> --evidence-reference=<reference>');
        }
        $this->activateCatalog->execute(
            CatalogVersionId::fromString($catalogVersion),
            $evidenceReference,
        );
        echo json_encode([
            'catalog_version_id' => $catalogVersion,
            'catalog_status' => 'APPROVED',
            'activation' => 'PERFORMED',
        ], JSON_THROW_ON_ERROR | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . PHP_EOL;

        return 0;
    }

    /**
     * @param list<string> $arguments
     * @return array<string, string>
     */
    private function options(array $arguments): array
    {
        $options = [];
        foreach ($arguments as $argument) {
            if (preg_match('/^--([a-z0-9-]+)=(.*)$/', $argument, $matches) !== 1) {
                throw DomainViolation::because(sprintf('Unknown catalog activation argument "%s".', $argument));
            }
            if (!in_array($matches[1], ['catalog-version', 'evidence-reference'], true)) {
                throw DomainViolation::because(sprintf('Unknown catalog activation argument "%s".', $argument));
            }
            $options[$matches[1]] = $matches[2];
        }

        return $options;
    }
}
