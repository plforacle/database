<?php

declare(strict_types=1);

namespace App\Infrastructure\Catalog;

use App\Domain\Shared\DomainViolation;
use Brick\Math\BigDecimal;
use Brick\Math\RoundingMode;
use DOMDocument;
use DOMElement;
use DOMXPath;
use ZipArchive;

final class WorkbookReader implements CatalogWorkbookReader
{
    private const MAIN_NAMESPACE = 'http://schemas.openxmlformats.org/spreadsheetml/2006/main';
    private const RELATIONSHIP_NAMESPACE = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships';
    private const PACKAGE_RELATIONSHIP_NAMESPACE = 'http://schemas.openxmlformats.org/package/2006/relationships';
    private const CONTENT_TYPE_NAMESPACE = 'http://schemas.openxmlformats.org/package/2006/content-types';
    private const MAX_ZIP_ENTRIES = 256;
    private const MAX_PART_BYTES = 4 * 1024 * 1024;
    private const MAX_TOTAL_BYTES = 16 * 1024 * 1024;
    private const MAX_XML_BYTES = 1024 * 1024;
    private const MAX_COMPRESSION_RATIO = 100;
    private const ALLOWED_RELATIONSHIP_TYPES = [
        'http://schemas.microsoft.com/office/2017/10/relationships/person',
        'http://schemas.microsoft.com/office/2017/10/relationships/threadedComment',
        'http://schemas.openxmlformats.org/officeDocument/2006/relationships/chart',
        'http://schemas.openxmlformats.org/officeDocument/2006/relationships/comments',
        'http://schemas.openxmlformats.org/officeDocument/2006/relationships/custom-properties',
        'http://schemas.openxmlformats.org/officeDocument/2006/relationships/drawing',
        'http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties',
        'http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument',
        'http://schemas.openxmlformats.org/officeDocument/2006/relationships/sharedStrings',
        'http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles',
        'http://schemas.openxmlformats.org/officeDocument/2006/relationships/table',
        'http://schemas.openxmlformats.org/officeDocument/2006/relationships/theme',
        'http://schemas.openxmlformats.org/officeDocument/2006/relationships/vmlDrawing',
        'http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet',
        'http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties',
    ];
    private const ALLOWED_CONTENT_TYPES = [
        'application/vnd.ms-excel.person+xml',
        'application/vnd.ms-excel.threadedcomments+xml',
        'application/vnd.openxmlformats-officedocument.drawing+xml',
        'application/vnd.openxmlformats-officedocument.drawingml.chart+xml',
        'application/vnd.openxmlformats-officedocument.extended-properties+xml',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.comments+xml',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sharedStrings+xml',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.table+xml',
        'application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml',
        'application/vnd.openxmlformats-officedocument.theme+xml',
        'application/vnd.openxmlformats-officedocument.vmlDrawing',
        'application/vnd.openxmlformats-package.core-properties+xml',
        'application/vnd.openxmlformats-package.relationships+xml',
        'application/xml',
    ];

    /**
     * @param array<string, mixed> $manifest
     * @return array{cells: array<string, array{value: string|null, formula: string|null}>, tables: array<string, list<array<string, string|null>>>}
     */
    public function read(string $path, array $manifest): array
    {
        $zip = new ZipArchive();
        if ($zip->open($path) !== true) {
            throw DomainViolation::because('Workbook is not a readable XLSX package.');
        }

        try {
            $this->validatePackage($zip);
            $worksheets = $this->worksheetParts($zip);
            $expectedWorksheets = $manifest['approved_worksheets'] ?? null;
            if (!is_array($expectedWorksheets) || array_keys($worksheets) !== array_values($expectedWorksheets)) {
                throw DomainViolation::because('Workbook worksheets do not match the fixed import manifest.');
            }

            $sharedStrings = $this->sharedStrings($zip);
            $requested = $this->requestedCells($manifest);
            $cells = [];
            foreach ($requested as $worksheet => $references) {
                $part = $worksheets[$worksheet] ?? null;
                if (!is_string($part)) {
                    throw DomainViolation::because(sprintf('Required worksheet "%s" is missing.', $worksheet));
                }

                foreach ($this->readCells($this->part($zip, $part), $references, $sharedStrings) as $reference => $cell) {
                    $cells[$worksheet . '!' . $reference] = $cell;
                }
            }

            return [
                'cells' => $cells,
                'tables' => $this->tables($manifest, $cells),
            ];
        } finally {
            $zip->close();
        }
    }

    private function validatePackage(ZipArchive $zip): void
    {
        if ($zip->numFiles > self::MAX_ZIP_ENTRIES) {
            throw DomainViolation::because('Workbook package exceeds the safe ZIP entry limit.');
        }

        $totalBytes = 0;
        $seen = [];
        for ($index = 0; $index < $zip->numFiles; ++$index) {
            $name = $zip->getNameIndex($index);
            $stats = $zip->statIndex($index);
            if (!is_string($name) || !is_array($stats)) {
                throw DomainViolation::because('Workbook package structure is malformed.');
            }
            if ($name === '' || str_starts_with($name, '/') || str_contains($name, '\\') || str_contains($name, "\0")) {
                throw DomainViolation::because('Workbook package contains an unsafe part path.');
            }
            $segments = explode('/', rtrim($name, '/'));
            if (in_array('.', $segments, true) || in_array('..', $segments, true) || isset($seen[$name])) {
                throw DomainViolation::because('Workbook package contains an unsafe part path.');
            }
            $seen[$name] = true;

            $size = $stats['size'];
            $compressedSize = $stats['comp_size'];
            if ($size < 0 || $compressedSize < 0) {
                throw DomainViolation::because('Workbook package structure is malformed.');
            }
            if ($size > self::MAX_PART_BYTES) {
                throw DomainViolation::because('Workbook package part exceeds the safe uncompressed-size limit.');
            }
            $totalBytes += $size;
            if ($totalBytes > self::MAX_TOTAL_BYTES) {
                throw DomainViolation::because('Workbook package exceeds the safe total uncompressed-size limit.');
            }
            if ($size >= 64 * 1024 && ($compressedSize === 0 || $size / $compressedSize > self::MAX_COMPRESSION_RATIO)) {
                throw DomainViolation::because('Workbook package part exceeds the safe compression ratio.');
            }
            if (preg_match('~(?:vbaProject\.bin|macrosheets?/|externalLinks/|activeX/|embeddings/)~i', $name) === 1) {
                throw DomainViolation::because('Workbook contains executable or externally linked content.');
            }
        }

        $this->validateContentTypes($zip);
        $this->validateRelationships($zip);
    }

    private function validateContentTypes(ZipArchive $zip): void
    {
        $document = $this->document($this->part($zip, '[Content_Types].xml'));
        $xpath = new DOMXPath($document);
        $xpath->registerNamespace('c', self::CONTENT_TYPE_NAMESPACE);
        $workbookType = null;
        $xmlDefaultType = null;
        $defaults = [];
        $overrides = [];
        foreach ($xpath->query('/c:Types/c:Default | /c:Types/c:Override') ?: [] as $contentType) {
            if (!$contentType instanceof DOMElement) {
                continue;
            }
            $value = $contentType->getAttribute('ContentType');
            if ($value === '') {
                throw DomainViolation::because('Workbook package content types are malformed.');
            }
            if (!in_array($value, self::ALLOWED_CONTENT_TYPES, true)) {
                throw DomainViolation::because('Workbook contains an unsafe package content type.');
            }
            $extension = null;
            $partName = null;
            if ($contentType->localName === 'Default') {
                $extension = strtolower($contentType->getAttribute('Extension'));
                if ($extension === '') {
                    throw DomainViolation::because('Workbook package content types are malformed.');
                }
                $defaults[$extension] = $value;
            } else {
                $partName = $contentType->getAttribute('PartName');
                if (!str_starts_with($partName, '/') || $partName === '/') {
                    throw DomainViolation::because('Workbook package content types are malformed.');
                }
                $overrides[$partName] = $value;
            }
            if ($partName === '/xl/workbook.xml') {
                $workbookType = $value;
            }
            if ($contentType->localName === 'Default' && $extension === 'xml') {
                $xmlDefaultType = $value;
            }
        }
        if (($workbookType ?? $xmlDefaultType) !== 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml') {
            throw DomainViolation::because('Workbook package does not declare a macro-free XLSX workbook.');
        }

        for ($index = 0; $index < $zip->numFiles; ++$index) {
            $name = $zip->getNameIndex($index);
            if (!is_string($name) || $name === '[Content_Types].xml' || str_ends_with($name, '/')) {
                continue;
            }
            $extension = strtolower(pathinfo($name, PATHINFO_EXTENSION));
            $resolvedType = $overrides['/' . $name] ?? $defaults[$extension] ?? null;
            if (!is_string($resolvedType)) {
                throw DomainViolation::because('Workbook package part is not declared by [Content_Types].xml.');
            }
        }
    }

    private function validateRelationships(ZipArchive $zip): void
    {
        for ($index = 0; $index < $zip->numFiles; ++$index) {
            $name = $zip->getNameIndex($index);
            if (!is_string($name) || !str_ends_with($name, '.rels')) {
                continue;
            }
            $document = $this->document($this->part($zip, $name));
            $xpath = new DOMXPath($document);
            $xpath->registerNamespace('r', self::PACKAGE_RELATIONSHIP_NAMESPACE);
            foreach ($xpath->query('/r:Relationships/r:Relationship') ?: [] as $relationship) {
                if (!$relationship instanceof DOMElement) {
                    continue;
                }
                $type = $relationship->getAttribute('Type');
                $target = $relationship->getAttribute('Target');
                $targetMode = $relationship->getAttribute('TargetMode');
                if ($type === '' || $target === '') {
                    throw DomainViolation::because('Workbook package relationships are malformed.');
                }
                $resolvedTarget = $this->resolvedRelationshipTarget($name, $target);
                if (strcasecmp($targetMode, 'External') === 0
                    || ($targetMode !== '' && strcasecmp($targetMode, 'Internal') !== 0)
                    || !in_array($type, self::ALLOWED_RELATIONSHIP_TYPES, true)
                    || preg_match('~^[a-z][a-z0-9+.-]*:|^//~i', $target) === 1
                    || $resolvedTarget === null
                    || $zip->locateName($resolvedTarget) === false
                ) {
                    throw DomainViolation::because('Workbook contains an unsafe package relationship.');
                }
            }
        }
    }

    private function resolvedRelationshipTarget(string $relationshipPart, string $target): ?string
    {
        $target = str_replace('\\', '/', $target);
        if (str_starts_with($target, '/')) {
            $candidate = ltrim($target, '/');
        } else {
            if ($relationshipPart === '_rels/.rels') {
                $base = '';
            } elseif (preg_match('~^(.*)/_rels/([^/]+)\.rels$~', $relationshipPart, $matches) === 1) {
                $base = $matches[1];
            } else {
                return null;
            }
            $candidate = ($base === '' ? '' : $base . '/') . $target;
        }

        $normalized = [];
        foreach (explode('/', $candidate) as $segment) {
            if ($segment === '' || $segment === '.') {
                continue;
            }
            if ($segment === '..') {
                if ($normalized === []) {
                    return null;
                }
                array_pop($normalized);
                continue;
            }
            $normalized[] = $segment;
        }

        return $normalized === [] ? null : implode('/', $normalized);
    }

    /**
     * @return array<string, string>
     */
    private function worksheetParts(ZipArchive $zip): array
    {
        $workbook = $this->document($this->part($zip, 'xl/workbook.xml'));
        $relationships = $this->document($this->part($zip, 'xl/_rels/workbook.xml.rels'));
        $relationshipXPath = new DOMXPath($relationships);
        $relationshipXPath->registerNamespace('r', self::PACKAGE_RELATIONSHIP_NAMESPACE);
        $targets = [];
        foreach ($relationshipXPath->query('/r:Relationships/r:Relationship') ?: [] as $relationship) {
            if ($relationship instanceof DOMElement) {
                $type = $relationship->getAttribute('Type');
                if ($type !== 'http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet') {
                    continue;
                }
                $targets[$relationship->getAttribute('Id')] = $relationship->getAttribute('Target');
            }
        }

        $workbookXPath = new DOMXPath($workbook);
        $workbookXPath->registerNamespace('x', self::MAIN_NAMESPACE);
        $worksheets = [];
        foreach ($workbookXPath->query('/x:workbook/x:sheets/x:sheet') ?: [] as $sheet) {
            if (!$sheet instanceof DOMElement) {
                continue;
            }
            $relationshipId = $sheet->getAttributeNS(self::RELATIONSHIP_NAMESPACE, 'id');
            $target = $targets[$relationshipId] ?? null;
            if (!is_string($target) || $target === '') {
                throw DomainViolation::because('Workbook worksheet relationship is incomplete.');
            }
            $worksheets[$sheet->getAttribute('name')] = $this->normalizeWorksheetTarget($target);
        }

        return $worksheets;
    }

    private function normalizeWorksheetTarget(string $target): string
    {
        $target = str_replace('\\', '/', $target);
        if (str_starts_with($target, '/')) {
            return ltrim($target, '/');
        }

        return 'xl/' . ltrim($target, '/');
    }

    /**
     * @return list<string>
     */
    private function sharedStrings(ZipArchive $zip): array
    {
        $xml = $zip->getFromName('xl/sharedStrings.xml');
        if ($xml === false) {
            return [];
        }

        $document = $this->document($xml);
        $xpath = new DOMXPath($document);
        $xpath->registerNamespace('x', self::MAIN_NAMESPACE);
        $strings = [];
        foreach ($xpath->query('/x:sst/x:si') ?: [] as $item) {
            if ($item instanceof \DOMNode) {
                $strings[] = $item->textContent;
            }
        }

        return $strings;
    }

    /**
     * @param array<string, mixed> $manifest
     * @return array<string, list<string>>
     */
    private function requestedCells(array $manifest): array
    {
        $requested = [];
        foreach ($manifest['tables'] ?? [] as $definition) {
            if (!is_array($definition)) {
                continue;
            }
            $worksheet = (string) ($definition['worksheet'] ?? '');
            $headerRow = (int) ($definition['header_row'] ?? 0);
            $firstDataRow = (int) ($definition['first_data_row'] ?? 0);
            $lastDataRow = (int) ($definition['last_data_row'] ?? 0);
            foreach ($definition['columns'] ?? [] as $column => $_columnDefinition) {
                $requested[$worksheet][] = $column . $headerRow;
                for ($row = $firstDataRow; $row <= $lastDataRow; ++$row) {
                    $requested[$worksheet][] = $column . $row;
                }
            }
        }
        foreach (['values', 'formulas'] as $controlType) {
            foreach ($manifest['controls'][$controlType] ?? [] as $qualifiedReference => $_expected) {
                [$worksheet, $reference] = explode('!', (string) $qualifiedReference, 2);
                $requested[$worksheet][] = $reference;
            }
        }

        foreach ($requested as &$references) {
            $references = array_values(array_unique($references));
        }

        return $requested;
    }

    /**
     * @param list<string> $requestedReferences
     * @param list<string> $sharedStrings
     * @return array<string, array{value: string|null, formula: string|null}>
     */
    private function readCells(string $xml, array $requestedReferences, array $sharedStrings): array
    {
        $requested = array_fill_keys($requestedReferences, true);
        $document = $this->document($xml);
        $xpath = new DOMXPath($document);
        $xpath->registerNamespace('x', self::MAIN_NAMESPACE);
        $cells = [];
        foreach ($xpath->query('/x:worksheet/x:sheetData/x:row/x:c') ?: [] as $cell) {
            if (!$cell instanceof DOMElement) {
                continue;
            }
            $reference = $cell->getAttribute('r');
            if (!isset($requested[$reference])) {
                continue;
            }
            $formulaNodes = $xpath->query('x:f', $cell);
            if ($formulaNodes === false) {
                throw DomainViolation::because('Workbook formula cell is malformed.');
            }
            $formulaNode = $formulaNodes->item(0);
            $formula = $formulaNode instanceof \DOMNode ? '=' . $formulaNode->textContent : null;
            $value = null;
            if ($formula === null) {
                $type = $cell->getAttribute('t');
                $valueNodes = $xpath->query($type === 'inlineStr' ? 'x:is' : 'x:v', $cell);
                if ($valueNodes === false) {
                    throw DomainViolation::because('Workbook value cell is malformed.');
                }
                $valueNode = $valueNodes->item(0);
                if ($valueNode instanceof \DOMNode) {
                    $value = $valueNode->textContent;
                    if ($type === 's') {
                        $sharedIndex = filter_var($value, FILTER_VALIDATE_INT);
                        if ($sharedIndex === false || !isset($sharedStrings[$sharedIndex])) {
                            throw DomainViolation::because('Workbook shared-string reference is invalid.');
                        }
                        $value = $sharedStrings[$sharedIndex];
                    }
                }
            }
            $cells[$reference] = ['value' => $value, 'formula' => $formula];
        }

        foreach ($requestedReferences as $reference) {
            $cells[$reference] ??= ['value' => null, 'formula' => null];
        }

        return $cells;
    }

    /**
     * @param array<string, mixed> $manifest
     * @param array<string, array{value: string|null, formula: string|null}> $cells
     * @return array<string, list<array<string, string|null>>>
     */
    private function tables(array $manifest, array $cells): array
    {
        $tables = [];
        foreach ($manifest['tables'] ?? [] as $key => $definition) {
            if (!is_array($definition)) {
                continue;
            }
            $worksheet = (string) $definition['worksheet'];
            $headerRow = (int) $definition['header_row'];
            foreach ($definition['columns'] as $column => $columnDefinition) {
                $headerCell = $cells[$worksheet . '!' . $column . $headerRow] ?? ['value' => null, 'formula' => null];
                if ($headerCell['formula'] !== null || $headerCell['value'] !== $columnDefinition['header']) {
                    throw DomainViolation::because(sprintf('%s header "%s" does not match the fixed import manifest.', $worksheet, $columnDefinition['header']));
                }
            }

            $rows = [];
            for ($rowNumber = (int) $definition['first_data_row']; $rowNumber <= (int) $definition['last_data_row']; ++$rowNumber) {
                $row = ['_worksheet_row' => (string) $rowNumber];
                foreach ($definition['columns'] as $column => $columnDefinition) {
                    $cell = $cells[$worksheet . '!' . $column . $rowNumber] ?? ['value' => null, 'formula' => null];
                    if ($cell['formula'] !== null) {
                        throw DomainViolation::because(sprintf('Mapped catalog cell %s!%s%d must not contain a formula.', $worksheet, $column, $rowNumber));
                    }
                    $row[$columnDefinition['field']] = $this->normalize($cell['value'], $columnDefinition['type'] ?? 'string');
                }
                if (($row[$definition['primary_field']] ?? null) !== null) {
                    $rows[] = $row;
                }
            }
            $tables[(string) $key] = $rows;
        }

        return $tables;
    }

    private function normalize(?string $value, string $type): ?string
    {
        if ($value === null || $value === '') {
            return null;
        }
        if ($type === 'decimal') {
            if (preg_match('/^-?\d+(?:\.\d+)?$/', $value) !== 1) {
                throw DomainViolation::because('Catalog price must be a fixed-precision decimal value.');
            }
            try {
                return (string) BigDecimal::of($value)->toScale(4, RoundingMode::UNNECESSARY);
            } catch (\Throwable) {
                throw DomainViolation::because('Catalog price must have no more than four decimal places.');
            }
        }
        if ($type === 'date') {
            if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $value) === 1) {
                return $value;
            }
            if (preg_match('/^(\d+)(?:\.\d+)?$/', $value, $matches) !== 1) {
                throw DomainViolation::because('Catalog date must be an Excel serial date or YYYY-MM-DD.');
            }
            $serial = (int) $matches[1];
            if ($serial < 1) {
                throw DomainViolation::because('Catalog date must be a positive Excel serial date.');
            }

            return (new \DateTimeImmutable('1899-12-30', new \DateTimeZone('UTC')))
                ->modify('+' . $serial . ' days')
                ->format('Y-m-d');
        }

        return $value;
    }

    private function part(ZipArchive $zip, string $name): string
    {
        $content = $zip->getFromName($name);
        if ($content === false) {
            throw DomainViolation::because(sprintf('Workbook package part "%s" is missing.', $name));
        }

        if (strlen($content) > self::MAX_PART_BYTES) {
            throw DomainViolation::because('Workbook package part exceeds the safe uncompressed-size limit.');
        }

        return $content;
    }

    private function document(string $xml): DOMDocument
    {
        if (strlen($xml) > self::MAX_XML_BYTES) {
            throw DomainViolation::because('Workbook XML part exceeds the safe size limit.');
        }
        if (preg_match('/<!\s*(?:DOCTYPE|ENTITY)\b/i', $xml) === 1) {
            throw DomainViolation::because('Workbook XML must not contain DTD or entity declarations.');
        }
        $document = new DOMDocument();
        $previous = libxml_use_internal_errors(true);
        try {
            if (!$document->loadXML($xml, LIBXML_NONET | LIBXML_COMPACT)) {
                throw DomainViolation::because('Workbook XML is malformed.');
            }
        } finally {
            libxml_clear_errors();
            libxml_use_internal_errors($previous);
        }

        return $document;
    }
}
