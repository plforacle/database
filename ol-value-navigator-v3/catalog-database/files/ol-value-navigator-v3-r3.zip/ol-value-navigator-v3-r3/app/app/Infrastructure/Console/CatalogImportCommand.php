<?php

declare(strict_types=1);

namespace App\Infrastructure\Console;

use App\Application\Catalog\StageCatalog;
use App\Domain\Shared\Actor;
use App\Domain\Shared\DomainViolation;
use PDO;

final readonly class CatalogImportCommand
{
    public function __construct(
        private StageCatalog $stageCatalog,
        private PDO $pdo,
        private string $actorIdentifier,
    ) {
    }

    /** @param list<string> $arguments */
    public function run(array $arguments): int
    {
        $options = $this->options($arguments);
        $workbook = $options['workbook'] ?? null;
        $sha256 = $options['sha256'] ?? null;
        if ($workbook === null || $sha256 === null) {
            throw DomainViolation::because('Usage: catalog:stage --workbook=<path> --sha256=<approved-sha256>');
        }
        $id = $this->stageCatalog->execute($workbook, $sha256, Actor::catalogImporter($this->actorIdentifier));
        $statement = $this->pdo->prepare(
            'SELECT version.status, reconciliation.report FROM catalog_version AS version INNER JOIN catalog_reconciliation AS reconciliation ON reconciliation.catalog_version_id = version.id WHERE version.id = ?',
        );
        $statement->execute([(string) $id]);
        $row = $statement->fetch(PDO::FETCH_ASSOC);
        if (!is_array($row)) {
            throw DomainViolation::because('Staged catalog version could not be read back.');
        }
        $report = json_decode((string) ($row['report'] ?? ''), true, flags: JSON_THROW_ON_ERROR);
        echo json_encode([
            'catalog_version_id' => (string) $id,
            'catalog_status' => $row['status'],
            'reconciliation' => $report,
            'activation' => 'NOT_PERFORMED',
        ], JSON_THROW_ON_ERROR | JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES) . PHP_EOL;

        return 0;
    }

    /**
     * @param list<string> $arguments
     * @return array<string, string>
     */
    private function options(array $arguments): array
    {
        $options = [];
        foreach ($arguments as $argument) {
            if (preg_match('/^--([a-z0-9-]+)=(.*)$/', $argument, $matches) !== 1) {
                throw DomainViolation::because(sprintf('Unknown catalog staging argument "%s".', $argument));
            }
            $options[$matches[1]] = $matches[2];
        }

        return $options;
    }
}
