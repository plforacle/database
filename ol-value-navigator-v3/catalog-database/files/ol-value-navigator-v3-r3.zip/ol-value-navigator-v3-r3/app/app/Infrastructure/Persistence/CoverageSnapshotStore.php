<?php

declare(strict_types=1);

namespace App\Infrastructure\Persistence;

use App\Domain\Shared\Actor;
use App\Domain\Shared\DomainViolation;
use Psr\Http\Message\UploadedFileInterface;

/** Private local evidence bytes, scoped to the fixed authorized demo representative. */
final readonly class CoverageSnapshotStore
{
    public function __construct(private string $root = __DIR__ . '/../../../var/private/coverage')
    {
    }

    /** @return array{id:string,filename:string,sha256:string} */
    public function retain(Actor $actor, UploadedFileInterface $upload): array
    {
        $this->authorize($actor);
        if ($upload->getError() !== UPLOAD_ERR_OK || ($upload->getSize() ?? 8388609) > 8388608) {
            throw DomainViolation::because('Select a source file of at most 8 MB.');
        }
        $filename = basename(str_replace('\\', '/', $upload->getClientFilename() ?? 'source'));
        if (preg_match('/^[^\x00-\x1f]{1,180}\.(csv|tsv|xlsx|png|jpg|jpeg)$/iD', $filename) !== 1) {
            throw DomainViolation::because('Select a CSV, TSV, XLSX, PNG or JPEG source.');
        }
        $directory = $this->directory($actor);
        if (!is_dir($directory) && !mkdir($directory, 0700, true) && !is_dir($directory)) {
            throw DomainViolation::because('Private source storage is unavailable.');
        }
        chmod($directory, 0700);
        $id = bin2hex(random_bytes(16));
        $path = $directory . '/' . $id;
        $source = $upload->getStream();
        $source->rewind();
        $bytes = $source->read(8388609);
        if (strlen($bytes) > 8388608 || $bytes === '') {
            throw DomainViolation::because('The source is empty or exceeds 8 MB.');
        }
        $handle = fopen($path, 'x');
        if ($handle === false) {
            throw DomainViolation::because('Cannot preserve the private source.');
        }
        try {
            chmod($path, 0600);
            if (fwrite($handle, $bytes) !== strlen($bytes)) {
                throw DomainViolation::because('Cannot preserve the complete source.');
            }
        } finally {
            fclose($handle);
        }
        return ['id' => $id, 'filename' => $filename, 'sha256' => hash('sha256', $bytes)];
    }

    public function path(Actor $actor, string $id): string
    {
        $this->authorize($actor);
        if (preg_match('/^[a-f0-9]{32}$/D', $id) !== 1 || !is_file($this->directory($actor) . '/' . $id)) {
            throw DomainViolation::because('The private source is unavailable.');
        }
        return $this->directory($actor) . '/' . $id;
    }

    /** @param array<string,mixed> $preview */
    public function savePreview(Actor $actor, string $id, array $preview): void
    {
        $path = $this->path($actor, $id);
        if (is_file($path . '.json')) {
            throw DomainViolation::because('Source review snapshots are immutable; create a new review revision.');
        }
        $encoded = json_encode($preview, JSON_THROW_ON_ERROR);
        if (file_put_contents($path . '.json', $encoded, LOCK_EX) === false) {
            throw DomainViolation::because('Cannot save the source review.');
        }
        chmod($path . '.json', 0600);
    }

    /** @param array<string,mixed> $preview
     * @return array<string,mixed>
     */
    public function revisePreview(Actor $actor, string $id, array $preview): array
    {
        $source = $this->path($actor, $id);
        $newId = bin2hex(random_bytes(16));
        $target = $this->directory($actor) . '/' . $newId;
        if (!copy($source, $target)) {
            throw DomainViolation::because('Cannot preserve a new source-review revision.');
        }
        chmod($target, 0600);
        $preview['id'] = $newId;
        $this->savePreview($actor, $newId, $preview);
        return $preview;
    }

    /** @return list<string> */
    public function hashes(Actor $actor): array
    {
        $this->authorize($actor);
        $files = glob($this->directory($actor) . '/*.json') ?: [];
        $hashes = [];
        foreach (array_slice($files, -100) as $file) {
            $bytes = file_get_contents($file);
            $data = is_string($bytes) ? json_decode($bytes, true) : null;
            if (is_array($data) && is_string($data['sha256'] ?? null)) {
                $hashes[] = $data['sha256'];
            }
        }
        return array_values(array_unique($hashes));
    }

    /** @return array<string,mixed> */
    public function preview(Actor $actor, string $id): array
    {
        $path = $this->path($actor, $id);
        $bytes = @file_get_contents($path . '.json');
        $preview = is_string($bytes) ? json_decode($bytes, true, 32, JSON_THROW_ON_ERROR) : null;
        if (!is_array($preview) || array_is_list($preview) || ($preview['sha256'] ?? null) !== hash_file('sha256', $path)) {
            throw DomainViolation::because('The source review is unavailable or its preserved bytes differ.');
        }
        return $preview;
    }

    private function directory(Actor $actor): string
    {
        return $this->root . '/' . hash('sha256', $actor->identifier());
    }

    private function authorize(Actor $actor): void
    {
        if (!$actor->canConfirmAnalysis()) {
            throw DomainViolation::because('Representative access is required.');
        }
    }
}
