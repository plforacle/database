<?php

declare(strict_types=1);

namespace App\Infrastructure\Presentation;

use App\Application\Presentation\PresentationDocument;
use RuntimeException;
use ZipArchive;

/** Writes a prepared document as editable OOXML without business-profile policy. */
final class PptxWriter
{
    private const A = 'http://schemas.openxmlformats.org/drawingml/2006/main';
    private const P = 'http://schemas.openxmlformats.org/presentationml/2006/main';
    private const R = 'http://schemas.openxmlformats.org/officeDocument/2006/relationships';
    private int $shapeId = 1;

    public function write(PresentationDocument $document): string
    {
        $this->shapeId = 1;
        $data = $document->toArray();
        $slides = [];
        foreach ($data['slides'] as $slide) {
            $content = '';
            foreach ($slide as $operation) {
                $content .= $operation['kind'] === 'text'
                    ? $this->box($operation['text'], $operation['x'], $operation['y'], $operation['w'], $operation['h'], $operation['size'], $operation['bold'], $operation['color'])
                    : $this->table($operation['rows'], $operation['x'], $operation['y'], $operation['widths'], $operation['rowHeight'], $operation['size']);
            }
            $slides[] = $content;
        }
        return $this->package($slides, ['notes' => $data['notes'], 'disclosure' => $data['disclosure']]);
    }

    private function box(string $text, float $x, float $y, float $w, float $h, int $size, bool $bold = false, string $color = '282923', bool $notesBody = false): string
    {
        $id = ++$this->shapeId;
        $paragraphs = $this->paragraphs($text, $size, $bold, $color);
        return '<p:sp><p:nvSpPr><p:cNvPr id="' . $id . '" name="Text ' . $id . '"/><p:cNvSpPr txBox="1"/><p:nvPr>' . ($notesBody ? '<p:ph type="body" idx="1"/>' : '') . '</p:nvPr></p:nvSpPr>'
            . '<p:spPr><a:xfrm><a:off x="' . $this->emu($x) . '" y="' . $this->emu($y) . '"/><a:ext cx="' . $this->emu($w) . '" cy="' . $this->emu($h) . '"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom><a:noFill/></p:spPr>'
            . '<p:txBody><a:bodyPr wrap="square" lIns="0" rIns="0" tIns="0" bIns="0"/><a:lstStyle/>' . $paragraphs . '</p:txBody></p:sp>';
    }

    private function paragraphs(string $text, int $size, bool $bold = false, string $color = '282923'): string
    {
        $xml = '';
        foreach (explode("\n", $text) as $line) {
            $xml .= '<a:p><a:pPr/><a:r><a:rPr lang="en-US" sz="' . ($size * 100) . '" b="' . ($bold ? '1' : '0') . '"><a:solidFill><a:srgbClr val="' . $color . '"/></a:solidFill><a:latin typeface="Arial"/></a:rPr><a:t xml:space="preserve">' . $this->xml($line) . '</a:t></a:r><a:endParaRPr lang="en-US" sz="' . ($size * 100) . '"/></a:p>';
        }
        return $xml;
    }

    /** @param list<list<string>> $rows
     * @param list<float> $widths
     */
    private function table(array $rows, float $x, float $y, array $widths, float $rowHeight, int $size): string
    {
        $id = ++$this->shapeId;
        $xml = '<p:graphicFrame><p:nvGraphicFramePr><p:cNvPr id="' . $id . '" name="Comparison table"/><p:cNvGraphicFramePr/><p:nvPr/></p:nvGraphicFramePr><p:xfrm><a:off x="' . $this->emu($x) . '" y="' . $this->emu($y) . '"/><a:ext cx="' . $this->emu(array_sum($widths)) . '" cy="' . $this->emu(count($rows) * $rowHeight) . '"/></p:xfrm><a:graphic><a:graphicData uri="' . 'http://schemas.openxmlformats.org/drawingml/2006/table"><a:tbl><a:tblPr firstRow="1" bandRow="0"/><a:tblGrid>';
        foreach ($widths as $width) {
            $xml .= '<a:gridCol w="' . $this->emu($width) . '"/>';
        }
        $xml .= '</a:tblGrid>';
        foreach ($rows as $index => $row) {
            $xml .= '<a:tr h="' . $this->emu($rowHeight) . '">';
            foreach ($row as $cell) {
                $xml .= '<a:tc><a:txBody><a:bodyPr/><a:lstStyle/>' . $this->paragraphs($cell, $size, $index === 0, $index === 0 ? 'FFFFFF' : '282923') . '</a:txBody><a:tcPr marL="100000" marR="100000" marT="65000" marB="50000"><a:solidFill><a:srgbClr val="' . ($index === 0 ? '384239' : ($index % 2 === 0 ? 'EEEAE1' : 'F8F5EF')) . '"/></a:solidFill></a:tcPr></a:tc>';
            }
            $xml .= '</a:tr>';
        }
        return $xml . '</a:tbl></a:graphicData></a:graphic></p:graphicFrame>';
    }

    private function emu(float $inches): int
    {
        return (int) round($inches * 914400);
    }

    private function xml(string $text): string
    {
        return htmlspecialchars($text, ENT_QUOTES | ENT_XML1, 'UTF-8');
    }

    /** @param list<string> $slides
     * @param array{notes:list<string>,disclosure:string} $data
     */
    private function package(array $slides, array $data): string
    {
        // tmpfile uses the runtime's configured temporary directory and closes on every exit.
        $stream = tmpfile();
        if ($stream === false) {
            throw new RuntimeException('Cannot allocate presentation output.');
        }
        try {
            $path = stream_get_meta_data($stream)['uri'] ?? throw new RuntimeException('Temporary output has no path.');
            $zip = new ZipArchive();
            if ($zip->open($path, ZipArchive::OVERWRITE) !== true) {
                throw new RuntimeException('Cannot open presentation archive.');
            }
            $parts = $this->parts($slides, $data);
            foreach ($parts as $name => $xml) {
                if (!$zip->addFromString($name, '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>' . $xml)) {
                    $zip->close();
                    throw new RuntimeException('Cannot write presentation archive.');
                }
            }
            if (!$zip->close()) {
                throw new RuntimeException('Cannot finalize presentation archive.');
            }
            $bytes = file_get_contents($path);
            if ($bytes === false) {
                throw new RuntimeException('Cannot read presentation output.');
            }
            return $bytes;
        } finally {
            fclose($stream);
        }
    }

    /** @param list<string> $slides
     * @param array{notes:list<string>,disclosure:string} $data
     * @return array<string,string>
     */
    private function parts(array $slides, array $data): array
    {
        $parts = [];
        $overrides = '';
        $ids = '';
        $presentationRels = [['slideMaster', 'slideMasters/slideMaster1.xml'], ['notesMaster', 'notesMasters/notesMaster1.xml']];
        foreach ($slides as $index => $content) {
            $number = $index + 1;
            $ids .= '<p:sldId id="' . (256 + $index) . '" r:id="rId' . ($index + 3) . '"/>';
            $presentationRels[] = ['slide', 'slides/slide' . $number . '.xml'];
            $content .= $this->box($data['disclosure'], .6, 7.05, 11.6, .32, 10);
            $content .= $this->box((string) $number, 12.4, 7.03, .35, .3, 11);
            $parts['ppt/slides/slide' . $number . '.xml'] = '<p:sld xmlns:a="' . self::A . '" xmlns:r="' . self::R . '" xmlns:p="' . self::P . '"><p:cSld><p:bg><p:bgPr><a:solidFill><a:srgbClr val="F8F5EF"/></a:solidFill><a:effectLst/></p:bgPr></p:bg>' . $this->tree($content) . '</p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sld>';
            $parts['ppt/slides/_rels/slide' . $number . '.xml.rels'] = $this->rels([['slideLayout', '../slideLayouts/slideLayout1.xml'], ['notesSlide', '../notesSlides/notesSlide' . $number . '.xml']]);
            $notes = $data['notes'][$index];
            $parts['ppt/notesSlides/notesSlide' . $number . '.xml'] = '<p:notes xmlns:a="' . self::A . '" xmlns:r="' . self::R . '" xmlns:p="' . self::P . '"><p:cSld>' . $this->tree($this->box($notes, .5, 1, 6, 8, 11, notesBody: true)) . '</p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:notes>';
            $parts['ppt/notesSlides/_rels/notesSlide' . $number . '.xml.rels'] = $this->rels([['notesMaster', '../notesMasters/notesMaster1.xml'], ['slide', '../slides/slide' . $number . '.xml']]);
            $overrides .= $this->override('/ppt/slides/slide' . $number . '.xml', 'slide') . $this->override('/ppt/notesSlides/notesSlide' . $number . '.xml', 'notesSlide');
        }
        $parts['_rels/.rels'] = $this->rels([['officeDocument', 'ppt/presentation.xml']]);
        $parts['ppt/_rels/presentation.xml.rels'] = $this->rels($presentationRels);
        $parts['ppt/presentation.xml'] = '<p:presentation xmlns:a="' . self::A . '" xmlns:r="' . self::R . '" xmlns:p="' . self::P . '"><p:sldMasterIdLst><p:sldMasterId id="2147483648" r:id="rId1"/></p:sldMasterIdLst><p:notesMasterIdLst><p:notesMasterId r:id="rId2"/></p:notesMasterIdLst><p:sldIdLst>' . $ids . '</p:sldIdLst><p:sldSz cx="12192000" cy="6858000"/><p:notesSz cx="6858000" cy="9144000"/></p:presentation>';
        $map = '<p:clrMap accent1="accent1" accent2="accent2" accent3="accent3" accent4="accent4" accent5="accent5" accent6="accent6" bg1="lt1" bg2="lt2" folHlink="folHlink" hlink="hlink" tx1="dk1" tx2="dk2"/>';
        $parts['ppt/slideMasters/slideMaster1.xml'] = '<p:sldMaster xmlns:a="' . self::A . '" xmlns:r="' . self::R . '" xmlns:p="' . self::P . '"><p:cSld>' . $this->tree('') . '</p:cSld>' . $map . '<p:sldLayoutIdLst><p:sldLayoutId id="2147483649" r:id="rId1"/></p:sldLayoutIdLst><p:txStyles/></p:sldMaster>';
        $parts['ppt/slideMasters/_rels/slideMaster1.xml.rels'] = $this->rels([['slideLayout', '../slideLayouts/slideLayout1.xml'], ['theme', '../theme/theme1.xml']]);
        $parts['ppt/slideLayouts/slideLayout1.xml'] = '<p:sldLayout xmlns:a="' . self::A . '" xmlns:r="' . self::R . '" xmlns:p="' . self::P . '" type="blank" preserve="1"><p:cSld name="Blank">' . $this->tree('') . '</p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sldLayout>';
        $parts['ppt/slideLayouts/_rels/slideLayout1.xml.rels'] = $this->rels([['slideMaster', '../slideMasters/slideMaster1.xml']]);
        $parts['ppt/notesMasters/notesMaster1.xml'] = '<p:notesMaster xmlns:a="' . self::A . '" xmlns:r="' . self::R . '" xmlns:p="' . self::P . '"><p:cSld>' . $this->tree('') . '</p:cSld>' . $map . '<p:notesStyle/></p:notesMaster>';
        $parts['ppt/notesMasters/_rels/notesMaster1.xml.rels'] = $this->rels([['theme', '../theme/notesTheme.xml']]);
        $colors = '';
        foreach (['dk1' => '282923', 'lt1' => 'FFFFFF', 'dk2' => '384239', 'lt2' => 'F8F5EF', 'accent1' => 'B84032', 'accent2' => '384239', 'accent3' => '8B6A47', 'accent4' => '657C72', 'accent5' => 'BEA57A', 'accent6' => '6E6B63', 'hlink' => '0563C1', 'folHlink' => '954F72'] as $key => $color) {
            $colors .= '<a:' . $key . '><a:srgbClr val="' . $color . '"/></a:' . $key . '>';
        }
        $font = '<a:latin typeface="Arial"/><a:ea typeface=""/><a:cs typeface=""/>';
        $parts['ppt/theme/theme1.xml'] = '<a:theme xmlns:a="' . self::A . '" name="Customer comparison"><a:themeElements><a:clrScheme name="Warm neutral">' . $colors . '</a:clrScheme><a:fontScheme name="Arial"><a:majorFont>' . $font . '</a:majorFont><a:minorFont>' . $font . '</a:minorFont></a:fontScheme><a:fmtScheme name="Simple"><a:fillStyleLst>' . str_repeat('<a:solidFill><a:schemeClr val="phClr"/></a:solidFill>', 3) . '</a:fillStyleLst><a:lnStyleLst>' . str_repeat('<a:ln w="9525"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill><a:prstDash val="solid"/></a:ln>', 3) . '</a:lnStyleLst><a:effectStyleLst>' . str_repeat('<a:effectStyle><a:effectLst/></a:effectStyle>', 3) . '</a:effectStyleLst><a:bgFillStyleLst>' . str_repeat('<a:solidFill><a:schemeClr val="phClr"/></a:solidFill>', 3) . '</a:bgFillStyleLst></a:fmtScheme></a:themeElements></a:theme>';
        // PowerPoint repairs decks when slide and notes masters share a theme part.
        // Preserve the theme content while giving the notes master its own part.
        $parts['ppt/theme/notesTheme.xml'] = $parts['ppt/theme/theme1.xml'];
        foreach (['presentation' => 'presentation.main', 'slideMasters/slideMaster1' => 'slideMaster', 'slideLayouts/slideLayout1' => 'slideLayout', 'notesMasters/notesMaster1' => 'notesMaster'] as $name => $type) {
            $overrides .= $this->override('/ppt/' . $name . '.xml', $type);
        }
        $parts['[Content_Types].xml'] = '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/>' . $overrides . '<Override PartName="/ppt/theme/theme1.xml" ContentType="application/vnd.openxmlformats-officedocument.theme+xml"/><Override PartName="/ppt/theme/notesTheme.xml" ContentType="application/vnd.openxmlformats-officedocument.theme+xml"/></Types>';
        return $parts;
    }

    private function tree(string $content): string
    {
        return '<p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr>' . $content . '</p:spTree>';
    }

    /** @param list<array{string,string}> $relationships */
    private function rels(array $relationships): string
    {
        $xml = '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">';
        foreach ($relationships as $index => [$type, $target]) {
            $xml .= '<Relationship Id="rId' . ($index + 1) . '" Type="' . self::R . '/' . $type . '" Target="' . $this->xml($target) . '"/>';
        }
        return $xml . '</Relationships>';
    }

    private function override(string $path, string $type): string
    {
        return '<Override PartName="' . $path . '" ContentType="application/vnd.openxmlformats-officedocument.presentationml.' . $type . '+xml"/>';
    }
}
