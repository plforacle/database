<?php

declare(strict_types=1);

namespace App\Infrastructure\Console;

use App\Domain\Shared\DomainViolation;

/** Read local regular files once, preserving their exact bytes. */
final class PackageFileReader
{
    public function read(string $path, int $maximumBytes, bool $protected = false): string
    {
        if ($path === '' || str_contains($path, '://') || str_contains($path, "\0") || $maximumBytes < 1) {
            throw DomainViolation::because('Package input file is invalid.');
        }
        clearstatcache(true, $path);
        $before = @lstat($path);
        if ($before === false || !$this->safe($before, $maximumBytes, $protected)) {
            throw DomainViolation::because('Package input file is unavailable or unsafe.');
        }
        $handle = @fopen($path, 'rb');
        if ($handle === false) {
            throw DomainViolation::because('Package input file cannot be opened.');
        }
        try {
            $opened = fstat($handle);
            if ($opened === false || !$this->same($before, $opened) || !$this->safe($opened, $maximumBytes, $protected)) {
                throw DomainViolation::because('Package input file changed during opening.');
            }
            $bytes = stream_get_contents($handle, $maximumBytes + 1);
            $after = fstat($handle);
            clearstatcache(true, $path);
            $named = @lstat($path);
            if (!is_string($bytes) || strlen($bytes) !== $before['size'] || $after === false || $named === false
                || !$this->same($before, $after) || !$this->same($before, $named)) {
                throw DomainViolation::because('Package input file changed during reading.');
            }
            return $bytes;
        } finally {
            fclose($handle);
        }
    }

    /** @param array<string|int,int> $stat */
    private function safe(array $stat, int $maximumBytes, bool $protected): bool
    {
        return ($stat['mode'] & 0170000) === 0100000 && $stat['size'] > 0 && $stat['size'] <= $maximumBytes
            && (!$protected || (function_exists('posix_geteuid') && $stat['uid'] === posix_geteuid() && ($stat['mode'] & 0077) === 0));
    }

    /** @param array<string|int,int> $left
     * @param array<string|int,int> $right
     */
    private function same(array $left, array $right): bool
    {
        foreach (['dev', 'ino', 'mode', 'uid', 'gid', 'size', 'mtime', 'ctime'] as $field) {
            if ($left[$field] !== $right[$field]) {
                return false;
            }
        }
        return true;
    }
}
