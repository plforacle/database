<?php

declare(strict_types=1);

namespace App\Infrastructure\Console;

use App\Application\Package\ActivatePackage;
use App\Application\Package\PublishPackage;
use App\Domain\Package\StrictJsonObjectDecoder;
use App\Domain\Shared\DomainViolation;
use App\Infrastructure\Persistence\PdoPackageRepository;
use Closure;
use Throwable;

final readonly class PackageCommand
{
    private Closure $output;
    private Closure $error;

    /** @param null|Closure(string):void $output
     * @param null|Closure(string):void $error
     */
    public function __construct(
        private PackageConnectionFactory $connections,
        private PackageFileReader $files,
        private PackageBaselineWriter $baseline,
        ?Closure $output = null,
        ?Closure $error = null,
    ) {
        $this->output = $output ?? static function (string $text): void {
            if (@fwrite(STDOUT, $text) !== strlen($text)) {
                throw DomainViolation::because('Package receipt output failed.');
            }
        };
        $this->error = $error ?? static function (string $text): void {
            @fwrite(STDERR, $text);
        };
    }

    /** @param list<string> $arguments */
    public function run(string $name, array $arguments): int
    {
        $stage = 'invalid_arguments';
        try {
            $options = $this->options($name, $arguments);
            if ($name === 'package:baseline') {
                $stage = 'authoring_failed';
                $receipt = $this->baseline->write($options['output-dir']);
            } elseif ($name === 'package:status') {
                $stage = 'authentication_failed';
                $pdo = $this->connections->runtime();
                $stage = 'status_failed';
                $receipt = ['outcome' => 'status', ...(new PdoPackageRepository($pdo))->status()];
            } else {
                $stage = 'authentication_failed';
                ['pdo' => $pdo, 'principal' => $principal] = $this->connections->publisher();
                if ($name === 'package:publish') {
                    $stage = 'invalid_file';
                    $manifest = $this->files->read($options['manifest'], 64 * 1024);
                    $mappings = $this->files->read($options['mappings'], 8 * 1024 * 1024);
                    $prices = $this->files->read($options['prices'], 8 * 1024 * 1024);
                    $acceptance = $this->files->read($options['acceptance'], 4 * 1024 * 1024);
                    $stage = 'publication_failed';
                    $receipt = (new PublishPackage($pdo, $principal))->execute($manifest, $mappings, $prices, $acceptance, $options['evidence-reference']);
                } else {
                    $stage = 'transition_failed';
                    $service = new ActivatePackage($pdo, $principal);
                    $method = $name === 'package:rollback' ? 'rollback' : 'execute';
                    $receipt = $service->$method($options['release'], (int) $options['expected-generation'], $options['reason'], $options['evidence-reference']);
                }
            }
            $stage = 'receipt_failed';
            $encoded = json_encode($receipt, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES) . PHP_EOL;
            if (strlen($encoded) > 4096) {
                throw DomainViolation::because('Package receipt exceeds the output bound.');
            }
            ($this->output)($encoded);
            return 0;
        } catch (Throwable) {
            ($this->error)(json_encode(['outcome' => 'rejected', 'error' => $stage], JSON_THROW_ON_ERROR) . PHP_EOL);
            return 1;
        }
    }

    /** @param list<string> $arguments
     * @return array<string,string>
     */
    private function options(string $name, array $arguments): array
    {
        $required = match ($name) {
            'package:baseline' => ['output-dir'],
            'package:status' => [],
            'package:publish' => ['manifest', 'mappings', 'prices', 'acceptance', 'evidence-reference'],
            'package:activate', 'package:rollback' => ['release', 'expected-generation', 'reason', 'evidence-reference'],
            default => throw DomainViolation::because('Unknown package command.'),
        };
        $options = [];
        foreach ($arguments as $argument) {
            if (strlen($argument) > 8192 || preg_match('/\A--([a-z-]+)=(.*)\z/sD', $argument, $matches) !== 1
                || !in_array($matches[1], $required, true) || isset($options[$matches[1]]) || trim($matches[2]) === '') {
                throw DomainViolation::because('Invalid package command arguments.');
            }
            $options[$matches[1]] = $matches[2];
        }
        if (count($options) !== count($required)) {
            throw DomainViolation::because('Required package command arguments are missing.');
        }
        foreach (['reason', 'evidence-reference'] as $field) {
            if (isset($options[$field])) {
                if (preg_match('//u', $options[$field]) !== 1) {
                    throw DomainViolation::because('Invalid UTF-8 package reference.');
                }
                PdoPackageRepository::evidenceReference($options[$field]);
            }
        }
        if (isset($options['release'])) {
            StrictJsonObjectDecoder::identifier($options['release']);
            PdoPackageRepository::generation($options['expected-generation'] ?? null);
        }
        return $options;
    }
}
