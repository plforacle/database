<?php

declare(strict_types=1);

namespace App\Infrastructure\Catalog;

use App\Domain\Package\CatalogPackageContract;
use App\Domain\Package\CatalogRecordShape;
use App\Domain\Package\PackageEnvelope;
use App\Domain\Package\SemanticCatalogPackage;
use JsonException;
use App\Domain\Shared\DomainViolation;

/** Pure authoring support from explicitly captured arrays; never a runtime fallback. */
final class BaselineCatalogPackageBuilder
{
    /** @param array<string,mixed> $profiles
     * @param list<string> $evidenceReferences
     * @return array{manifest:string,mappings:string,prices:string}
     */
    public function build(string $releaseId, string $mappingId, string $priceId, array $profiles, array $evidenceReferences): array
    {
        CatalogRecordShape::check(array_diff_key($profiles, CatalogPackageContract::PROFILES) === [] && array_diff_key(CatalogPackageContract::PROFILES, $profiles) === [], 'builder profiles', 'complete supported profiles required');
        $mappingProfiles = $priceProfiles = [];
        foreach ($profiles as $profileId => $profile) {
            $profile = self::fields($profile, ['entries', 'offerings', 'scenarioPrices', 'applicability']);
            $mappings = ['entries' => [], 'offerings' => []];
            $prices = ['entries' => [], 'offerings' => [], 'scenarioPrices' => []];
            $profile = [
                'entries' => self::capturedMap($profile['entries']),
                'offerings' => self::capturedMap($profile['offerings']),
                'scenarioPrices' => self::capturedMap($profile['scenarioPrices']),
                'applicability' => self::capturedMap($profile['applicability']),
            ];
            foreach ($profile['entries'] as $id => $entry) {
                $entry = self::fields($entry, [...CatalogPackageContract::ENTRY_MAPPING_REQUIRED, ...CatalogPackageContract::ENTRY_PRICE_FIELDS, 'readiness', 'provenance'], CatalogPackageContract::ENTRY_MAPPING_OPTIONAL);
                $scope = in_array($entry['readiness'], ['EXCLUDED', 'NO_EQUIVALENT'], true) ? $entry['readiness'] : 'IN_SCOPE';
                $evidence = ['kind' => 'LEGACY_MIXED', 'text' => $entry['provenance']];
                $mappings['entries'][$id] = ['scopeState' => $scope, 'catalogFields' => self::pick($entry, [...CatalogPackageContract::ENTRY_MAPPING_REQUIRED, ...CatalogPackageContract::ENTRY_MAPPING_OPTIONAL]), 'evidence' => $evidence];
                $prices['entries'][$id] = ['priceReadiness' => $scope === 'IN_SCOPE' ? $entry['readiness'] : 'NOT_ADOPTED', 'metric' => $entry['unit'], 'periodBasis' => $entry['term'] === 'ANNUAL' ? 'ANNUAL_UNIT_RATE' : 'UNKNOWN', 'catalogFields' => self::pick($entry, CatalogPackageContract::ENTRY_PRICE_FIELDS), 'evidence' => $evidence];
            }
            foreach ($profile['offerings'] as $id => $offering) {
                $offering = self::fields($offering, [...CatalogPackageContract::OFFERING_MAPPING_FIELDS, ...CatalogPackageContract::OFFERING_PRICE_REQUIRED, 'provenance'], CatalogPackageContract::OFFERING_PRICE_OPTIONAL);
                $evidence = ['kind' => 'LEGACY_MIXED', 'text' => $offering['provenance']];
                $mappings['offerings'][$id] = ['catalogFields' => self::pick($offering, CatalogPackageContract::OFFERING_MAPPING_FIELDS), 'evidence' => $evidence];
                $prices['offerings'][$id] = ['metric' => $offering['unit'], 'periodBasis' => 'ANNUAL_UNIT_RATE', 'catalogFields' => self::pick($offering, [...CatalogPackageContract::OFFERING_PRICE_REQUIRED, ...CatalogPackageContract::OFFERING_PRICE_OPTIONAL]), 'evidence' => $evidence];
            }
            CatalogRecordShape::check(array_diff_key($profile['scenarioPrices'], $profile['applicability']) === [] && array_diff_key($profile['applicability'], $profile['scenarioPrices']) === [], 'builder applicability', 'explicit price applicability required');
            foreach ($profile['scenarioPrices'] as $id => $price) {
                $prices['scenarioPrices'][$id] = ['record' => self::fields($price, CatalogPackageContract::PRICE_FIELDS), 'applicableSkus' => $profile['applicability'][$id]];
            }
            $mappingProfiles[$profileId] = array_map(static fn (array $map): object => (object) $map, $mappings);
            $priceProfiles[$profileId] = array_map(static fn (array $map): object => (object) $map, $prices);
        }
        try {
            $mappings = json_encode(['schemaVersion' => 'olvn-mappings-1', 'memberId' => $mappingId, 'profiles' => $mappingProfiles], JSON_THROW_ON_ERROR);
            $prices = json_encode(['schemaVersion' => 'olvn-prices-1', 'memberId' => $priceId, 'profiles' => $priceProfiles], JSON_THROW_ON_ERROR);
            $manifest = json_encode(['schemaVersion' => 'olvn-release-envelope-1', 'releaseId' => $releaseId, 'profiles' => CatalogPackageContract::PROFILES, 'members' => ['mappings' => ['memberId' => $mappingId, 'schemaVersion' => 'olvn-mappings-1', 'sha256' => hash('sha256', $mappings)], 'prices' => ['memberId' => $priceId, 'schemaVersion' => 'olvn-prices-1', 'sha256' => hash('sha256', $prices)]], 'evidenceReferences' => $evidenceReferences], JSON_THROW_ON_ERROR);
        } catch (JsonException) {
            throw DomainViolation::because('Catalog captured arrays cannot be encoded as package JSON.');
        }
        SemanticCatalogPackage::fromEnvelope(PackageEnvelope::fromJson($manifest, $mappings, $prices, CatalogPackageContract::PROFILES, CatalogPackageContract::MEMBER_SCHEMAS));
        return ['manifest' => $manifest, 'mappings' => $mappings, 'prices' => $prices];
    }

    /** @return array<string,mixed> */
    private static function capturedMap(mixed $value): array
    {
        CatalogRecordShape::check(is_array($value), 'builder profile', 'captured arrays required');
        /** @var array<string,mixed> $value */
        return $value;
    }

    /** @param list<string> $required
     * @param list<string> $optional
     * @return array<string,mixed>
     */
    private static function fields(mixed $value, array $required, array $optional = []): array
    {
        CatalogRecordShape::check(is_array($value), 'builder record', 'captured array required');
        /** @var array<string,mixed> $value */
        return CatalogRecordShape::record((object) $value, $required, $optional, 'builder record');
    }

    /** @param array<string,mixed> $record
     * @param list<string> $keys
     * @return array<string,mixed>
     */
    private static function pick(array $record, array $keys): array
    {
        return array_intersect_key($record, array_flip($keys));
    }
}
