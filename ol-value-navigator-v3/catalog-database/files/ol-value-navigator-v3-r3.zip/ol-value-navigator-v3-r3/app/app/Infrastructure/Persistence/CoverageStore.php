<?php

declare(strict_types=1);

namespace App\Infrastructure\Persistence;

use App\Application\Package\CatalogSnapshotResolver;
use App\Domain\Coverage\CoverageEvaluator;
use App\Domain\Coverage\CoverageInput;
use App\Domain\Package\CatalogSnapshot;
use App\Domain\Shared\Actor;
use App\Domain\Shared\DomainViolation;
use PDO;
use Ramsey\Uuid\Uuid;

/** @phpstan-import-type Context from CatalogSnapshot */
final readonly class CoverageStore
{
    public function __construct(private PDO $pdo, private CatalogSnapshotResolver $catalogs)
    {
    }

    /** @param array<string,mixed> $input
     * @return array{comparisonId:string,revisionId:string,state:string,catalogVersion:string,ruleVersion:string,catalogContext:Context|null,confirmedAt:?string,synthetic:bool,customer:array<string,mixed>,input:array<string,mixed>,evaluation:array<string,mixed>}
     */
    public function save(Actor $actor, array $input, ?string $comparisonId = null, ?string $expectedRevision = null): array
    {
        $this->authorize($actor);
        $input = CoverageInput::normalize($input);
        $catalog = $this->catalogs->resolve($this->profile($input));
        return (new PdoTransaction($this->pdo))->run(function () use ($actor, $input, $comparisonId, $expectedRevision, $catalog): array {
            if ($comparisonId === null) {
                if ($expectedRevision !== null) {
                    throw DomainViolation::because('A predecessor requires an existing comparison.');
                }
                $comparisonId = Uuid::uuid4()->toString();
                $this->pdo->prepare('INSERT INTO coverage_comparison (id,creator_subject) VALUES (?,?)')->execute([$comparisonId, $actor->identifier()]);
            } else {
                $this->lockCurrent($actor, $comparisonId, $expectedRevision);
            }
            if (($input['schemaVersion'] ?? '') === '1.3.1') {
                $previous = $expectedRevision === null ? [] : $this->decode($this->row($actor, $expectedRevision)['input_json']);
                $this->validatePriceChanges($input, $previous);
                $this->validateSourceLineage($input, $previous);
                $input = $this->adopt($input, $previous, $actor->identifier(), gmdate('Y-m-d\TH:i:s\Z'));
                foreach ($input['snapshots'] ?? [] as $snapshot) {
                    $stored = (new CoverageSnapshotStore())->preview($actor, $snapshot['id']);
                    if (!$this->sameEvidence($snapshot, $stored)) {
                        throw DomainViolation::because('Source snapshots must match the preserved private review.');
                    }
                }
            }
            $revision = Uuid::uuid4()->toString();
            $evaluation = (new CoverageEvaluator())->evaluate($input, $catalog);
            $state = $evaluation['ready'] ? 'READY_TO_CALCULATE' : 'INCOMPLETE';
            $this->pdo->prepare('INSERT INTO coverage_revision (id,comparison_id,predecessor_id,input_json,evaluation_json,catalog_version,catalog_sha256,rule_version,state) VALUES (?,?,?,?,?,?,?,?,?)')->execute([
                $revision, $comparisonId, $expectedRevision, json_encode($input, JSON_THROW_ON_ERROR), json_encode($evaluation, JSON_THROW_ON_ERROR), $catalog->releaseId(), $catalog->manifestDigest(), CatalogSnapshot::OLAM_RULE, $state,
            ]);
            (new CoverageRevisionPackageStore($this->pdo))->insert($revision, $catalog);
            $this->pdo->prepare('UPDATE coverage_comparison SET current_revision_id = ? WHERE id = ?')->execute([$revision, $comparisonId]);
            $this->audit($revision, $actor, 'REVISION_CREATED');
            return $this->read($actor, $revision);
        });
    }

    /** @return array{comparisonId:string,revisionId:string,state:string,catalogVersion:string,ruleVersion:string,catalogContext:Context|null,confirmedAt:?string,synthetic:bool,customer:array<string,mixed>,input:array<string,mixed>,evaluation:array<string,mixed>} */
    public function read(Actor $actor, string $revision): array
    {
        $this->authorize($actor);
        $row = $this->row($actor, $revision);
        $catalog = $this->retainedCatalog($row);
        $input = $this->decode($row['input_json']);
        $customer = $input['customer'] ?? null;
        if (!is_array($customer)) {
            throw DomainViolation::because('Saved comparison customer scope is invalid.');
        }
        /** @var array<string,mixed> $customer */
        return ['comparisonId' => (string) $row['comparison_id'], 'revisionId' => (string) $row['id'], 'state' => (string) $row['state'], 'catalogVersion' => (string) $row['catalog_version'], 'ruleVersion' => (string) $row['rule_version'], 'catalogContext' => $catalog?->context(), 'confirmedAt' => is_string($row['confirmed_at']) ? str_replace(' ', 'T', $row['confirmed_at']) . 'Z' : null, 'synthetic' => true, 'customer' => $customer, 'input' => $input, 'evaluation' => $this->decode($row['evaluation_json'])];
    }

    public function catalogForRevision(Actor $actor, string $revision): ?CatalogSnapshot
    {
        $this->authorize($actor);
        return $this->retainedCatalog($this->row($actor, $revision));
    }

    /** @return array{comparisonId:string,revisionId:string,state:string,catalogVersion:string,ruleVersion:string,catalogContext:Context|null,confirmedAt:?string,synthetic:bool,customer:array<string,mixed>,input:array<string,mixed>,evaluation:array<string,mixed>} */
    public function confirm(Actor $actor, string $revision): array
    {
        $this->authorize($actor);
        return (new PdoTransaction($this->pdo))->run(function () use ($actor, $revision): array {
            $row = $this->row($actor, $revision);
            $catalog = $this->catalogs->resolveForConfirmation($this->profile(CoverageInput::normalize($this->decode($row['input_json']))));
            $this->lockCurrent($actor, (string) $row['comparison_id'], $revision);
            $row = $this->row($actor, $revision, true);
            $input = $this->decode($row['input_json']);
            $retained = $this->retainedCatalog($row);
            if ($retained === null) {
                throw DomainViolation::because('Legacy drafts require saving and reviewing a successor revision.');
            }
            if ($row['state'] !== 'READY_TO_CALCULATE' || !$this->sameEvidence($retained->context(), $catalog->context())) {
                throw DomainViolation::because('The revision is incomplete, already confirmed or its catalog/rule requires a new review.');
            }
            $evaluation = (new CoverageEvaluator())->evaluate($input, $catalog);
            if (!$evaluation['ready'] || !$this->sameEvidence($evaluation, $this->decode($row['evaluation_json']))) {
                throw DomainViolation::because('Review facts changed or remain unresolved. Save and review a new revision.');
            }
            $this->pdo->prepare("UPDATE coverage_revision SET state = 'CONFIRMED', confirmed_by = ?, confirmed_at = UTC_TIMESTAMP(6) WHERE id = ?")->execute([$actor->identifier(), $revision]);
            $this->audit($revision, $actor, 'COMPARISON_CONFIRMED');
            return $this->read($actor, $revision);
        });
    }

    private function lockCurrent(Actor $actor, string $comparisonId, ?string $expected): void
    {
        $query = $this->pdo->prepare('SELECT current_revision_id FROM coverage_comparison WHERE id = ? AND BINARY creator_subject = BINARY ? FOR UPDATE');
        $query->execute([$comparisonId, $actor->identifier()]);
        $current = $query->fetchColumn();
        if (!is_string($current) || $current !== $expected) {
            throw DomainViolation::because('The comparison is unavailable or a newer revision exists. Reopen its latest review.');
        }
    }

    /** @return array<string,mixed> */
    private function row(Actor $actor, string $revision, bool $lock = false): array
    {
        $query = $this->pdo->prepare('SELECT r.* FROM coverage_revision r JOIN coverage_comparison c ON c.id = r.comparison_id WHERE r.id = ? AND BINARY c.creator_subject = BINARY ?' . ($lock ? ' FOR UPDATE' : ''));
        $query->execute([$revision, $actor->identifier()]);
        $row = $query->fetch(PDO::FETCH_ASSOC);
        if (!is_array($row)) {
            throw DomainViolation::because('The comparison is unavailable.');
        }
        return $row;
    }

    /** @return array<string,mixed> */
    private function decode(mixed $value): array
    {
        $decoded = is_string($value) ? json_decode($value, true, 32, JSON_THROW_ON_ERROR) : null;
        if (!is_array($decoded) || array_is_list($decoded)) {
            throw DomainViolation::because('Saved comparison data is invalid.');
        }
        return $decoded;
    }

    /** @param array<string,mixed> $input */
    private function profile(array $input): string
    {
        return ($input['schemaVersion'] ?? '') === '1.3.1' ? 'scenario-1.3.1' : 'legacy-coverage';
    }

    /** @param array<string,mixed> $row */
    private function retainedCatalog(array $row): ?CatalogSnapshot
    {
        $evaluation = $this->decode($row['evaluation_json']);
        $catalog = (new CoverageRevisionPackageStore($this->pdo))->read((string) $row['id']);
        $marked = array_key_exists('catalogContext', $evaluation);
        if (!$marked && $catalog === null) {
            return null;
        }
        if (!$marked || $catalog === null || !$this->sameEvidence($evaluation['catalogContext'], $catalog->context())
            || $catalog->profileId() !== $this->profile(CoverageInput::normalize($this->decode($row['input_json'])))
            || $row['catalog_version'] !== $catalog->releaseId() || $row['catalog_sha256'] !== $catalog->manifestDigest()
            || $row['rule_version'] !== CatalogSnapshot::OLAM_RULE) {
            throw DomainViolation::because('Saved catalog attachment and revision context disagree.');
        }
        return $catalog;
    }

    /** @param array<string,mixed> $input
     * @param array<string,mixed> $previous
     */
    private function validatePriceChanges(array &$input, array $previous): void
    {
        foreach (['lines', 'otherCosts'] as $collection) {
            $prior = array_column($previous[$collection] ?? [], null, 'id');
            foreach ($input[$collection] as &$record) {
                $old = $prior[$record['id']]['price'] ?? null;
                $price = $record['price'];
                if (!is_array($old) || $old['amount'] === null) {
                    continue;
                }
                if (!is_array($price) || $price['amount'] === null || !\Brick\Math\BigDecimal::of($price['amount'])->isEqualTo($old['amount'])) {
                    $reason = is_array($price) ? $price['reason'] : ($record['selectionReason'] ?? '');
                    if (!is_string($reason) || mb_strlen(trim($reason)) < 10) {
                        throw DomainViolation::because('A price change requires an explicit rationale; the earlier adopted amount remains in the predecessor revision.');
                    }
                    if (is_array($price)) {
                        $record['price']['originalAmount'] = $old['originalAmount'] ?? $old['amount'];
                    }
                }
            }
            unset($record);
        }
    }

    /** @param array<string,mixed> $input
     * @param array<string,mixed> $previous
     */
    private function validateSourceLineage(array &$input, array $previous): void
    {
        $snapshots = array_column($input['snapshots'] ?? [], null, 'id');
        foreach ($previous['snapshots'] ?? [] as $old) {
            if (!$this->sameEvidence($snapshots[$old['id']] ?? null, $old)) {
                throw DomainViolation::because('Preserve every earlier source snapshot. Deselect rows explicitly instead of removing their evidence.');
            }
        }
        $rawRows = [];
        foreach ($snapshots as $snapshot) {
            foreach ($snapshot['issues'] as $issue) {
                if (in_array($issue['code'], ['IMAGE_TRANSCRIPTION_REQUIRED', 'IMAGE_VISUAL_REVIEW_REQUIRED', 'COLUMN_MAPPING_REQUIRED', 'SHEET_MAPPING_REQUIRED'], true)) {
                    throw DomainViolation::because('Complete source column mapping and any required image visual review before adopting its facts.');
                }
            }
            foreach ($snapshot['rows'] as $row) {
                $rawRows[$snapshot['id'] . ':' . $row['sheet'] . ':' . $row['row']] = $row;
            }
        }
        $lines = array_column($input['lines'] ?? [], null, 'id');
        $references = [];
        foreach ($input['lines'] as &$line) {
            $source = $line['sourceId'];
            if (isset($rawRows[$source])) {
                $raw = $rawRows[$source];
                if ($line['rawSku'] !== $raw['sku'] || $line['description'] !== $raw['description']) {
                    throw DomainViolation::because('Original imported SKU and description are immutable. Use an explicit correction and adopted description.');
                }
                if ($line['rowType'] !== $raw['rowType']) {
                    throw DomainViolation::because('Preserve imported product classification. Deselect a product explicitly instead of relabeling it as a note.');
                }
                if ($raw['unitPrice'] !== null) {
                    if (is_array($line['price'])) {
                        $line['price']['originalAmount'] = $raw['unitPrice'];
                        if (($line['price']['amount'] === null || !\Brick\Math\BigDecimal::of($line['price']['amount'])->isEqualTo($raw['unitPrice'])) && mb_strlen(trim($line['price']['reason'])) < 10) {
                            throw DomainViolation::because('Changing an imported amount requires an explicit price-override reason. The original amount remains preserved.');
                        }
                    } elseif (mb_strlen(trim($line['selectionReason'])) < 10) {
                        throw DomainViolation::because('Replacing the imported unit amount with a catalog or reusable price requires a selection reason.');
                    }
                }
                $references[$source] = true;
            }
        }
        unset($line);
        foreach ($rawRows as $source => $raw) {
            if ($raw['rowType'] === 'PRODUCT' && !isset($references[$source])) {
                throw DomainViolation::because('Every imported product must remain linked to its preserved row. Deselect it explicitly when outside scope.');
            }
        }
        foreach ($previous['lines'] ?? [] as $old) {
            if (isset($rawRows[$old['sourceId']])) {
                $line = $lines[$old['id']] ?? null;
                if (!is_array($line) || $line['sourceId'] !== $old['sourceId'] || $line['rawSku'] !== $old['rawSku'] || $line['description'] !== $old['description']) {
                    throw DomainViolation::because('Earlier imported rows and their original identity cannot be dropped or relinked.');
                }
            }
        }
    }

    /** Current adoption is recorded separately from unobserved approvals claimed by imported documents.
     * @param array<mixed> $record
     * @param array<mixed> $previous
     * @return array<mixed>
     */
    private function adopt(array $record, array $previous, string $actor, string $at): array
    {
        $authority = isset($record['state'], $record['evidence']) && in_array($record['state'], ['UNRESOLVED', 'ASSUMED', 'CONFIRMED'], true)
            ? ['actor', 'at'] : (isset($record['field']) && array_key_exists('oldValue', $record) && array_key_exists('newValue', $record) ? ['actor', 'at'] : (isset($record['verification'], $record['periodBasis']) ? ['approvedBy', 'approvedAt'] : []));
        if ($authority !== []) {
            [$actorField, $timeField] = $authority;
            $facts = array_diff_key($record, array_flip($authority));
            $oldFacts = array_diff_key($previous, array_flip($authority));
            $unchanged = $this->sameEvidence($facts, $oldFacts) && is_string($previous[$actorField] ?? null) && $previous[$actorField] !== '';
            $record[$actorField] = $unchanged ? $previous[$actorField] : $actor;
            $record[$timeField] = $unchanged ? $previous[$timeField] : $at;
        }
        foreach ($record as $key => $value) {
            if (is_array($value) && $key !== 'snapshots') {
                $record[$key] = $this->adopt($value, is_array($previous[$key] ?? null) ? $previous[$key] : [], $actor, $at);
            }
        }
        return $record;
    }

    /** JSON object order may change in MySQL; lists, values and types remain significant. */
    private function sameEvidence(mixed $first, mixed $second): bool
    {
        return $this->canonical($first) === $this->canonical($second);
    }

    private function canonical(mixed $value): mixed
    {
        if (!is_array($value)) {
            return $value;
        }
        if (!array_is_list($value)) {
            ksort($value);
        }
        return array_map($this->canonical(...), $value);
    }

    private function authorize(Actor $actor): void
    {
        if (!$actor->canConfirmAnalysis()) {
            throw DomainViolation::because('Representative access is required.');
        }
    }

    private function audit(string $revision, Actor $actor, string $action): void
    {
        $this->pdo->prepare('INSERT INTO coverage_audit (id,revision_id,actor_subject,action) VALUES (?,?,?,?)')->execute([Uuid::uuid4()->toString(), $revision, $actor->identifier(), $action]);
    }
}
