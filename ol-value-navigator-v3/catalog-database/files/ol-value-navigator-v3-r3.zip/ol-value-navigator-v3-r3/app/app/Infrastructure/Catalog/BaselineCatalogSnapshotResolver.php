<?php

declare(strict_types=1);

namespace App\Infrastructure\Catalog;

use App\Application\Package\CatalogPackageValidator;
use App\Application\Package\CatalogSnapshotResolver;
use App\Application\Package\PackageEnvelopeDecoder;
use App\Domain\Coverage\CoverageCatalog;
use App\Domain\Coverage\ScenarioCatalog;
use App\Domain\Package\CatalogPackageContract;
use App\Domain\Package\CatalogSnapshot;
use App\Domain\Package\SemanticCatalogPackage;

/** Explicit immutable bootstrap composition, never a fallback or active-selection cache. */
final readonly class BaselineCatalogSnapshotResolver implements CatalogSnapshotResolver
{
    private SemanticCatalogPackage $package;

    public function __construct(?SemanticCatalogPackage $package = null)
    {
        if ($package !== null) {
            $this->package = $package;
            return;
        }
        $profiles = [
            'legacy-coverage' => ['entries' => CoverageCatalog::entries(), 'offerings' => CoverageCatalog::offerings(), 'scenarioPrices' => [], 'applicability' => []],
            'scenario-1.3.1' => ['entries' => ScenarioCatalog::entries(), 'offerings' => CoverageCatalog::offerings(), 'scenarioPrices' => ScenarioCatalog::prices(), 'applicability' => [ScenarioCatalog::VCF_PRICE_ID => ['VCF-CLD-FND-5']]],
        ];
        $bytes = (new BaselineCatalogPackageBuilder())->build('bootstrap-20260910', 'bootstrap-mappings-20260910', 'bootstrap-prices-20260910', $profiles, ['Explicit bootstrap capture of complete legacy and scenario providers.']);
        $envelope = (new PackageEnvelopeDecoder(CatalogPackageContract::PROFILES, CatalogPackageContract::MEMBER_SCHEMAS))->decode($bytes['manifest'], $bytes['mappings'], $bytes['prices']);
        $this->package = (new CatalogPackageValidator())->validate($envelope);
    }

    public function resolve(string $profileId): CatalogSnapshot
    {
        return new CatalogSnapshot($this->package, $profileId);
    }

    public function resolveForConfirmation(string $profileId): CatalogSnapshot
    {
        return $this->resolve($profileId);
    }
}
