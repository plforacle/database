<?php

declare(strict_types=1);

namespace App\Infrastructure\Persistence;

use App\Application\Package\CatalogPackageValidator;
use App\Domain\Package\CatalogPackageContract;
use App\Domain\Package\CatalogSnapshot;
use App\Domain\Package\PackageAcceptanceDocument;
use App\Domain\Package\PackageEnvelope;
use App\Domain\Package\SemanticCatalogPackage;
use App\Domain\Package\StrictJsonObjectDecoder as Json;
use App\Domain\Shared\DomainViolation;
use PDO;
use PDOException;

/** @phpstan-type Status array{channel:string,releaseId:?string,generation:int}
 * @phpstan-type Release array{package:SemanticCatalogPackage,acceptanceJson:string,admission:array<string,mixed>,publisher:string,approvalReference:string}
 */
final readonly class PdoPackageRepository
{
    public function __construct(private PDO $pdo)
    {
    }

    /** @return Release */
    public function readRelease(string $id): array
    {
        Json::identifier($id);
        try {
            // Bound every blob on the server before transferring any payload to PHP.
            $statement = $this->pdo->prepare('SELECT r.release_id,r.manifest_sha256,r.mapping_id,r.price_id,r.publisher,
                CASE WHEN OCTET_LENGTH(r.manifest_bytes)<=65536 THEN r.manifest_bytes END AS manifest_bytes,
                m.schema_version AS mapping_schema,m.sha256 AS mapping_sha256,
                CASE WHEN OCTET_LENGTH(m.json_bytes)<=8388608 THEN m.json_bytes END AS mapping_bytes,
                p.schema_version AS price_schema,p.sha256 AS price_sha256,
                CASE WHEN OCTET_LENGTH(p.json_bytes)<=8388608 THEN p.json_bytes END AS price_bytes,
                a.publisher AS admission_publisher,a.approval_reference,a.acceptance_sha256,a.evidence_sha256,
                CASE WHEN OCTET_LENGTH(a.acceptance_bytes)<=4194304 THEN a.acceptance_bytes END AS acceptance_bytes,
                CASE WHEN OCTET_LENGTH(a.evidence_bytes)<=65536 THEN a.evidence_bytes END AS evidence_bytes
                FROM package_release r
                JOIN package_member m ON m.kind=r.mapping_kind AND m.member_id=r.mapping_id
                JOIN package_member p ON p.kind=r.price_kind AND p.member_id=r.price_id
                JOIN package_admission a ON a.release_id=r.release_id WHERE r.release_id=?');
            $statement->execute([$id]);
            $row = $statement->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException) {
            throw DomainViolation::because('Published package is unavailable.');
        }
        if (!is_array($row)) {
            throw DomainViolation::because('Published package is unavailable.');
        }
        foreach ($row as $value) {
            if (!is_string($value)) {
                throw DomainViolation::because('Published package data is invalid.');
            }
        }
        $envelope = PackageEnvelope::fromJson($row['manifest_bytes'], $row['mapping_bytes'], $row['price_bytes'], CatalogPackageContract::PROFILES, CatalogPackageContract::MEMBER_SCHEMAS);
        $package = (new CatalogPackageValidator())->validate($envelope);
        if ($envelope->releaseId() !== $id || $envelope->manifestDigest() !== $row['manifest_sha256']
            || $row['publisher'] !== $row['admission_publisher'] || $row['publisher'] === '') {
            throw DomainViolation::because('Published package identity is invalid.');
        }
        foreach (['mappings' => 'mapping', 'prices' => 'price'] as $kind => $prefix) {
            $member = $envelope->member($kind);
            if ($member->id() !== $row[$prefix . '_id'] || $member->schemaVersion() !== $row[$prefix . '_schema'] || $member->digest() !== $row[$prefix . '_sha256']) {
                throw DomainViolation::because('Published member identity is invalid.');
            }
        }
        if (hash('sha256', $row['acceptance_bytes']) !== $row['acceptance_sha256'] || hash('sha256', $row['evidence_bytes']) !== $row['evidence_sha256']) {
            throw DomainViolation::because('Published admission integrity is invalid.');
        }
        self::evidenceReference($row['approval_reference']);
        $admission = $this->admission($package, $row['acceptance_bytes'], $row['evidence_bytes']);
        return ['package' => $package, 'acceptanceJson' => $row['acceptance_bytes'], 'admission' => $admission, 'publisher' => $row['publisher'], 'approvalReference' => $row['approval_reference']];
    }

    /** @return Status */
    public function status(string $channel = 'coverage'): array
    {
        return $this->selection($channel);
    }

    /** @return Status */
    public function selection(string $channel, string $lock = ''): array
    {
        if ($channel !== 'coverage' || !in_array($lock, ['', 'FOR SHARE', 'FOR UPDATE'], true)
            || ($lock !== '' && !$this->pdo->inTransaction())) {
            throw DomainViolation::because('Package selection requires a valid channel and transaction.');
        }
        try {
            $statement = $this->pdo->prepare('SELECT release_id,generation FROM package_channel WHERE channel=? ' . $lock);
            $statement->execute([$channel]);
            $row = $statement->fetch(PDO::FETCH_ASSOC);
        } catch (PDOException) {
            throw DomainViolation::because('Package channel is unavailable.');
        }
        if (!is_array($row) || (!is_string($row['release_id']) && $row['release_id'] !== null)) {
            throw DomainViolation::because('Package channel is unavailable.');
        }
        $generation = self::generation($row['generation']);
        if (($generation === 0) !== ($row['release_id'] === null)) {
            throw DomainViolation::because('Package channel is invalid.');
        }
        return ['channel' => $channel, 'releaseId' => $row['release_id'], 'generation' => $generation];
    }

    public static function generation(mixed $value): int
    {
        if (is_string($value) && preg_match('/\A(?:0|[1-9][0-9]*)\z/D', $value) === 1
            && (strlen($value) < strlen((string) PHP_INT_MAX) || (strlen($value) === strlen((string) PHP_INT_MAX) && strcmp($value, (string) PHP_INT_MAX) <= 0))) {
            $value = (int) $value;
        }
        if (!is_int($value) || $value < 0) {
            throw DomainViolation::because('Package generation is invalid.');
        }
        return $value;
    }

    public static function evidenceReference(string $value): void
    {
        if (trim($value) === '' || strlen($value) > 1024 || preg_match('/[\x00-\x1F\x7F]/', $value) === 1) {
            throw DomainViolation::because('Package review evidence is invalid.');
        }
    }

    /** Validates closed retained identities without running business evaluators on runtime reads.
     * @return array<string,mixed>
     */
    private function admission(SemanticCatalogPackage $package, string $acceptance, string $evidence): array
    {
        $document = PackageAcceptanceDocument::fromJson($package, $acceptance);
        $receipt = Json::decode($evidence, 65536);
        $identities = ['format' => 'package-admission-1', 'manifestSha256' => $package->envelope()->manifestDigest(),
            'acceptanceSha256' => hash('sha256', $acceptance), 'validator' => 'semantic-catalog-1',
            'checks' => 'package-acceptance-1', 'olamRule' => CatalogSnapshot::OLAM_RULE, 'vmwareRule' => CatalogSnapshot::VMWARE_RULE];
        Json::keys($receipt, [...array_keys($identities), 'cases']);
        foreach ($identities as $key => $value) {
            if ($receipt->{$key} !== $value) {
                throw DomainViolation::because('Published admission contract is unsupported.');
            }
        }
        if (!is_array($receipt->cases) || !array_is_list($receipt->cases) || count($receipt->cases) !== count($document->cases())) {
            throw DomainViolation::because('Published admission cases are invalid.');
        }
        $cases = [];
        foreach ($document->cases() as $index => $case) {
            $result = Json::object($receipt->cases[$index]);
            Json::keys($result, ['id', 'profileId', 'resultSha256', 'outcome']);
            if ($result->id !== $case['id'] || $result->profileId !== $case['profileId'] || $result->outcome !== 'PASS'
                || !is_string($result->resultSha256) || preg_match('/\A[0-9a-f]{64}\z/D', $result->resultSha256) !== 1) {
                throw DomainViolation::because('Published admission case is invalid.');
            }
            $cases[] = get_object_vars($result);
        }
        return [...$identities, 'cases' => $cases];
    }
}
