<?php

declare(strict_types=1);

namespace App\Infrastructure\Console;

use App\Domain\Shared\DomainViolation;
use App\Infrastructure\Catalog\BaselineCatalogSnapshotResolver;

/** Offline candidate authoring only: deliberately produces no acceptance receipt. */
final class PackageBaselineWriter
{
    /** @return array{outcome:string,releaseId:string,manifestSha256:string} */
    public function write(string $directory): array
    {
        if ($directory === '' || str_contains($directory, '://') || str_contains($directory, "\0")) {
            throw DomainViolation::because('A new local output directory is required.');
        }
        $envelope = (new BaselineCatalogSnapshotResolver())->resolve('legacy-coverage')->package()->envelope();
        if (!@mkdir($directory, 0700)) {
            throw DomainViolation::because('Output directory could not be created exclusively.');
        }
        foreach (['manifest' => $envelope->manifestJson(), 'mappings' => $envelope->member('mappings')->json(), 'prices' => $envelope->member('prices')->json()] as $kind => $bytes) {
            $path = $directory . '/' . $kind . '.json';
            $file = @fopen($path, 'xb');
            if ($file === false) {
                throw DomainViolation::because('Candidate authoring failed; partial output was retained.');
            }
            try {
                if (!@chmod($path, 0600) || @fwrite($file, $bytes) !== strlen($bytes) || !@fflush($file)) {
                    throw DomainViolation::because('Candidate authoring failed; partial output was retained.');
                }
            } finally {
                if (!@fclose($file)) {
                    throw DomainViolation::because('Candidate authoring failed; partial output was retained.');
                }
            }
        }
        return ['outcome' => 'authored', 'releaseId' => $envelope->releaseId(), 'manifestSha256' => $envelope->manifestDigest()];
    }
}
