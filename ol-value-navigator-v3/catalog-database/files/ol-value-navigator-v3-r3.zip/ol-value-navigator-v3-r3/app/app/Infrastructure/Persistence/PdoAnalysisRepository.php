<?php

declare(strict_types=1);

namespace App\Infrastructure\Persistence;

use App\Domain\Analysis\AnalysisRepository;
use App\Domain\Analysis\AnalysisState;
use App\Domain\Analysis\ConfirmedLine;
use App\Domain\Analysis\LineDecision;
use App\Domain\Calculation\ComparisonTotals;
use App\Domain\Extraction\ExtractionResult;
use App\Domain\Matching\MatchResult;
use App\Domain\Shared\Actor;
use App\Domain\Shared\AnalysisId;
use App\Domain\Shared\CatalogVersionId;
use App\Domain\Shared\RedactedSourceText;
use App\Domain\Shared\RevisionId;
use PDO;
use JsonException;
use Ramsey\Uuid\Uuid;
use UnexpectedValueException;

final readonly class PdoAnalysisRepository implements AnalysisRepository
{
    public function __construct(private PDO $pdo)
    {
    }

    public function createDraft(
        AnalysisId $analysisId,
        RevisionId $revisionId,
        Actor $actor,
        RedactedSourceText $source,
        CatalogVersionId $catalogVersionId,
    ): void {
        $analysis = $this->pdo->prepare(
            'INSERT INTO analysis (id, creator_subject, access_scope) VALUES (?, ?, ?)',
        );
        $analysis->execute([(string) $analysisId, $actor->identifier(), $actor->identifier()]);

        $revision = $this->pdo->prepare(
            'INSERT INTO analysis_revision (id, analysis_id, source_text, extraction_mode, catalog_version_id, state, creator_subject) VALUES (?, ?, ?, ?, ?, ?, ?)',
        );
        $revision->execute([
            (string) $revisionId,
            (string) $analysisId,
            $source->value(),
            null,
            (string) $catalogVersionId,
            AnalysisState::DRAFT->name,
            $actor->identifier(),
        ]);

        $currentRevision = $this->pdo->prepare('UPDATE analysis SET current_revision_id = ? WHERE id = ?');
        $currentRevision->execute([(string) $revisionId, (string) $analysisId]);
    }

    public function findForSubject(AnalysisId $analysisId, Actor $subject): ?array
    {
        $statement = $this->pdo->prepare(
            'SELECT id, current_revision_id AS currentRevisionId, creator_subject AS creatorSubject, access_scope AS accessScope FROM analysis WHERE id = ? AND creator_subject = ?',
        );
        $statement->execute([(string) $analysisId, $subject->identifier()]);
        $row = $statement->fetch(PDO::FETCH_ASSOC);

        if (!is_array($row)) {
            return null;
        }

        $id = $row['id'] ?? null;
        $currentRevisionId = $row['currentRevisionId'] ?? null;
        $creatorSubject = $row['creatorSubject'] ?? null;
        $accessScope = $row['accessScope'] ?? null;
        if (!is_string($id)
            || !is_string($creatorSubject)
            || !is_string($accessScope)
            || !is_string($currentRevisionId) && $currentRevisionId !== null
        ) {
            throw new UnexpectedValueException('Analysis persistence returned an invalid row.');
        }

        return compact('id', 'currentRevisionId', 'creatorSubject', 'accessScope');
    }

    public function findRevisionForSubject(RevisionId $revisionId, Actor $subject): ?array
    {
        $statement = $this->pdo->prepare(
            'SELECT revision.id, revision.analysis_id AS analysisId, revision.state, revision.catalog_version_id AS catalogVersionId
             FROM analysis_revision AS revision
             INNER JOIN analysis ON analysis.id = revision.analysis_id
             WHERE revision.id = ? AND analysis.creator_subject = ?',
        );
        $statement->execute([(string) $revisionId, $subject->identifier()]);
        $row = $statement->fetch(PDO::FETCH_ASSOC);
        if (!is_array($row)) {
            return null;
        }
        $id = $row['id'] ?? null;
        $analysisId = $row['analysisId'] ?? null;
        $state = $row['state'] ?? null;
        $catalogVersionId = $row['catalogVersionId'] ?? null;
        if (!is_string($id)
            || !is_string($analysisId)
            || !is_string($state)
            || !is_string($catalogVersionId)
        ) {
            throw new UnexpectedValueException('Analysis revision persistence returned an invalid row.');
        }

        foreach (AnalysisState::cases() as $analysisState) {
            if ($analysisState->name === $state) {
                return [
                    'id' => $id,
                    'analysisId' => $analysisId,
                    'state' => $analysisState,
                    'catalogVersionId' => $catalogVersionId,
                ];
            }
        }

        throw new UnexpectedValueException('Analysis revision persistence returned an invalid state.');
    }

    public function findDraftForSubject(RevisionId $revisionId, Actor $subject): ?array
    {
        $statement = $this->pdo->prepare(
            'SELECT source_text AS source FROM analysis_revision WHERE id = ? AND creator_subject = ? AND state = ? FOR UPDATE',
        );
        $statement->execute([(string) $revisionId, $subject->identifier(), AnalysisState::DRAFT->name]);
        $row = $statement->fetch(PDO::FETCH_ASSOC);
        if (!is_array($row) || !is_string($row['source'] ?? null)) {
            return null;
        }

        return ['source' => RedactedSourceText::fromString($row['source'])];
    }

    public function recordExtraction(
        RevisionId $revisionId,
        Actor $subject,
        ExtractionResult $result,
        AnalysisState $state,
    ): void {
        $evidence = $result->evidence();
        $revision = $this->pdo->prepare(
            'UPDATE analysis_revision SET extraction_mode = ?, model_identifier = ?, extraction_contract_version = ?, prompt_template_version = ?, ai_response_digest = ?, state = ? WHERE id = ? AND creator_subject = ? AND state = ?',
        );
        $revision->execute([
            $result->mode()->name,
            $evidence->modelIdentifier(),
            $evidence->contractVersion(),
            $evidence->promptTemplateVersion(),
            $evidence->responseDigest(),
            $state->name,
            (string) $revisionId,
            $subject->identifier(),
            AnalysisState::DRAFT->name,
        ]);
        if ($revision->rowCount() !== 1) {
            throw new UnexpectedValueException('The extraction revision is not an owned draft.');
        }

        $line = $this->pdo->prepare(
            'INSERT INTO analysis_line (id, analysis_revision_id, extraction_line_id, source_start, source_end, extracted_identifier, quantity, match_state, decision) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
        );
        foreach ($result->candidates() as $candidate) {
            $line->execute([
                Uuid::uuid4()->toString(),
                (string) $revisionId,
                $candidate->lineId(),
                $candidate->sourceStart(),
                $candidate->sourceEnd(),
                $candidate->sku(),
                $candidate->quantity(),
                'UNRESOLVED',
                'PENDING',
            ]);
        }
    }

    public function lockLineForReview(RevisionId $revisionId, string $lineId, Actor $actor): ?array
    {
        $statement = $this->pdo->prepare(
            'SELECT revision.state, revision.catalog_version_id AS catalogVersionId,
                    line_item.decision, line_item.extracted_identifier AS extractedIdentifier,
                    line_item.resolved_sku AS resolvedSku, CAST(line_item.quantity AS CHAR) AS quantity
             FROM analysis_line AS line_item
             INNER JOIN analysis_revision AS revision ON revision.id = line_item.analysis_revision_id
             INNER JOIN analysis ON analysis.id = revision.analysis_id
             WHERE revision.id = ? AND line_item.extraction_line_id = ? AND analysis.creator_subject = ?
             FOR UPDATE',
        );
        $statement->execute([(string) $revisionId, $lineId, $actor->identifier()]);
        $row = $statement->fetch(PDO::FETCH_ASSOC);
        if (!is_array($row)) {
            return null;
        }

        $state = $row['state'] ?? null;
        $catalogVersionId = $row['catalogVersionId'] ?? null;
        $decision = $row['decision'] ?? null;
        if (!is_string($state) || !is_string($catalogVersionId) || !is_string($decision)) {
            throw new UnexpectedValueException('Analysis review persistence returned an invalid line.');
        }

        return [
            'state' => $this->analysisState($state),
            'catalogVersionId' => $catalogVersionId,
            'decision' => $this->lineDecision($decision),
            'extractedIdentifier' => $this->nullableString($row['extractedIdentifier'] ?? null),
            'resolvedSku' => $this->nullableString($row['resolvedSku'] ?? null),
            'quantity' => $this->nullableString($row['quantity'] ?? null),
        ];
    }

    public function confirmLine(
        RevisionId $revisionId,
        string $lineId,
        Actor $actor,
        MatchResult $match,
        ConfirmedLine $line,
        LineDecision $decision,
        ?string $correctedIdentifier,
    ): void {
        $governedSku = $match->governedSku();
        $description = $match->description();
        $unit = $match->unit();
        $annualUsdPrice = $match->annualUsdPrice();
        if ($governedSku === null || $description === null || $unit === null || $annualUsdPrice === null) {
            throw new UnexpectedValueException('An exact match is required to persist a confirmed line.');
        }

        $statement = $this->pdo->prepare(
            'UPDATE analysis_line
             SET resolved_sku = ?, resolved_description = ?, match_state = ?,
                 match_rationale = ?, decision = ?, corrected_identifier = ?, quantity = ?,
                 annual_usd_price = ?, currency = ?, annual_term = ?, unit_basis = ?,
                 exclusion_reason = NULL, confirmed_by_subject = ?, confirmed_at = UTC_TIMESTAMP(6)
             WHERE analysis_revision_id = ? AND extraction_line_id = ? AND decision = ?',
        );
        $statement->execute([
            $governedSku,
            $description,
            $match->state()->name,
            'Exact governed SKU match.',
            $decision->name,
            $correctedIdentifier,
            (string) $line->quantity,
            $annualUsdPrice,
            'USD',
            'ANNUAL',
            $unit,
            $actor->identifier(),
            (string) $revisionId,
            $lineId,
            LineDecision::PENDING->name,
        ]);
        if ($statement->rowCount() !== 1) {
            throw new UnexpectedValueException('The pending analysis line could not be confirmed.');
        }
    }

    public function excludeLine(
        RevisionId $revisionId,
        string $lineId,
        Actor $actor,
        string $reason,
    ): void {
        $statement = $this->pdo->prepare(
            'UPDATE analysis_line
             SET decision = ?, exclusion_reason = ?, confirmed_by_subject = ?, confirmed_at = UTC_TIMESTAMP(6)
             WHERE analysis_revision_id = ? AND extraction_line_id = ? AND decision = ?',
        );
        $statement->execute([
            LineDecision::EXCLUDED->name,
            $reason,
            $actor->identifier(),
            (string) $revisionId,
            $lineId,
            LineDecision::PENDING->name,
        ]);
        if ($statement->rowCount() !== 1) {
            throw new UnexpectedValueException('The pending analysis line could not be excluded.');
        }
    }

    public function selectOption(
        RevisionId $revisionId,
        string $lineId,
        CatalogVersionId $catalogVersionId,
        string $optionSku,
        Actor $actor,
    ): void {
        $line = $this->pdo->prepare(
            'SELECT line_item.id
             FROM analysis_line AS line_item
             INNER JOIN analysis_revision AS revision ON revision.id = line_item.analysis_revision_id
             INNER JOIN analysis ON analysis.id = revision.analysis_id
             WHERE revision.id = ? AND line_item.extraction_line_id = ? AND analysis.creator_subject = ?
             FOR UPDATE',
        );
        $line->execute([(string) $revisionId, $lineId, $actor->identifier()]);
        $analysisLineId = $line->fetchColumn();

        $option = $this->pdo->prepare(
            'SELECT id FROM catalog_sku WHERE catalog_version_id = ? AND governed_sku = ?',
        );
        $option->execute([(string) $catalogVersionId, $optionSku]);
        $catalogSkuId = $option->fetchColumn();
        if (!is_string($analysisLineId) || !is_string($catalogSkuId)) {
            throw new UnexpectedValueException('The resolved line or governed option was not found in persistence.');
        }

        $selection = $this->pdo->prepare(
            'INSERT INTO option_selection (id, analysis_line_id, analysis_revision_id, catalog_sku_id, catalog_version_id, selected_by_subject) VALUES (?, ?, ?, ?, ?, ?)',
        );
        $selection->execute([
            Uuid::uuid4()->toString(),
            $analysisLineId,
            (string) $revisionId,
            $catalogSkuId,
            (string) $catalogVersionId,
            $actor->identifier(),
        ]);
    }

    public function lockReadinessSnapshot(RevisionId $revisionId): ?array
    {
        $revision = $this->pdo->prepare(
            'SELECT state, catalog_version_id AS catalogVersionId FROM analysis_revision WHERE id = ? FOR UPDATE',
        );
        $revision->execute([(string) $revisionId]);
        $revisionRow = $revision->fetch(PDO::FETCH_ASSOC);
        if (!is_array($revisionRow)) {
            return null;
        }
        $state = $revisionRow['state'] ?? null;
        $catalogVersionId = $revisionRow['catalogVersionId'] ?? null;
        if (!is_string($state) || !is_string($catalogVersionId)) {
            throw new UnexpectedValueException('Analysis readiness persistence returned an invalid revision.');
        }

        $statement = $this->pdo->prepare(
            'SELECT COALESCE(line_item.extraction_line_id, line_item.id) AS lineId,
                    line_item.match_state AS matchState, line_item.decision,
                    line_item.resolved_sku AS resolvedSku,
                    line_item.resolved_description AS resolvedDescription,
                    CAST(line_item.quantity AS CHAR) AS quantity,
                    CAST(line_item.annual_usd_price AS CHAR) AS annualUsdPrice,
                    line_item.currency, line_item.annual_term AS annualTerm,
                    line_item.unit_basis AS unitBasis, line_item.exclusion_reason AS exclusionReason,
                    selected_sku.governed_sku AS selectedOptionSku
             FROM analysis_line AS line_item
             LEFT JOIN option_selection AS selection
                ON selection.analysis_line_id = line_item.id
                AND selection.analysis_revision_id = line_item.analysis_revision_id
             LEFT JOIN catalog_sku AS selected_sku
                ON selected_sku.id = selection.catalog_sku_id
                AND selected_sku.catalog_version_id = selection.catalog_version_id
             WHERE line_item.analysis_revision_id = ?
             ORDER BY line_item.id',
        );
        $statement->execute([(string) $revisionId]);
        $rows = $statement->fetchAll(PDO::FETCH_ASSOC);
        $lines = [];
        foreach ($rows as $row) {
            $lineId = $row['lineId'] ?? null;
            $matchState = $row['matchState'] ?? null;
            $decision = $row['decision'] ?? null;
            if (!is_string($lineId) || !is_string($matchState) || !is_string($decision)) {
                throw new UnexpectedValueException('Analysis readiness persistence returned an invalid line.');
            }

            $lines[] = [
                'lineId' => $lineId,
                'matchState' => $matchState,
                'decision' => $this->lineDecision($decision),
                'resolvedSku' => $this->nullableString($row['resolvedSku'] ?? null),
                'resolvedDescription' => $this->nullableString($row['resolvedDescription'] ?? null),
                'quantity' => $this->nullableString($row['quantity'] ?? null),
                'annualUsdPrice' => $this->nullableString($row['annualUsdPrice'] ?? null),
                'currency' => $this->nullableString($row['currency'] ?? null),
                'annualTerm' => $this->nullableString($row['annualTerm'] ?? null),
                'unitBasis' => $this->nullableString($row['unitBasis'] ?? null),
                'exclusionReason' => $this->nullableString($row['exclusionReason'] ?? null),
                'selectedOptionSku' => $this->nullableString($row['selectedOptionSku'] ?? null),
            ];
        }

        return [
            'state' => $this->analysisState($state),
            'catalogVersionId' => $catalogVersionId,
            'lines' => $lines,
        ];
    }

    public function updateRevisionState(
        RevisionId $revisionId,
        AnalysisState $from,
        AnalysisState $to,
    ): void {
        $statement = $this->pdo->prepare(
            'UPDATE analysis_revision SET state = ? WHERE id = ? AND state = ?',
        );
        $statement->execute([$to->name, (string) $revisionId, $from->name]);
        if ($statement->rowCount() !== 1) {
            throw new UnexpectedValueException('The analysis readiness state could not be updated.');
        }
    }

    /**
     * @return array{state: AnalysisState, catalogVersionId: string, extractionMode: string|null, modelIdentifier: string|null, extractionContractVersion: string|null, promptTemplateVersion: string|null, responseDigest: string|null, lines: list<array{lineId: string, extractedIdentifier: string|null, matchState: string, decision: LineDecision, resolvedSku: string|null, resolvedDescription: string|null, quantity: string|null, annualUsdPrice: string|null, currency: string|null, annualTerm: string|null, unitBasis: string|null, exclusionReason: string|null, selectedOptionSku: string|null}>}|null
     */
    public function lockConfirmationSnapshot(RevisionId $revisionId, Actor $actor): ?array
    {
        $revision = $this->pdo->prepare(
            'SELECT revision.state, revision.catalog_version_id AS catalogVersionId,
                    revision.extraction_mode AS extractionMode,
                    revision.model_identifier AS modelIdentifier,
                    revision.extraction_contract_version AS extractionContractVersion,
                    revision.prompt_template_version AS promptTemplateVersion,
                    revision.ai_response_digest AS responseDigest
             FROM analysis_revision AS revision
             INNER JOIN analysis ON analysis.id = revision.analysis_id
             WHERE revision.id = ? AND analysis.creator_subject = ?
             FOR UPDATE',
        );
        $revision->execute([(string) $revisionId, $actor->identifier()]);
        $revisionRow = $revision->fetch(PDO::FETCH_ASSOC);
        if (!is_array($revisionRow)) {
            return null;
        }

        $state = $revisionRow['state'] ?? null;
        $catalogVersionId = $revisionRow['catalogVersionId'] ?? null;
        $extractionMode = $this->nullableString($revisionRow['extractionMode'] ?? null);
        if (!is_string($state) || !is_string($catalogVersionId)) {
            throw new UnexpectedValueException('Analysis confirmation persistence returned an invalid revision.');
        }

        $statement = $this->pdo->prepare(
            'SELECT COALESCE(line_item.extraction_line_id, line_item.id) AS lineId,
                    line_item.extracted_identifier AS extractedIdentifier,
                    line_item.match_state AS matchState, line_item.decision,
                    line_item.resolved_sku AS resolvedSku,
                    line_item.resolved_description AS resolvedDescription,
                    CAST(line_item.quantity AS CHAR) AS quantity,
                    CAST(line_item.annual_usd_price AS CHAR) AS annualUsdPrice,
                    line_item.currency, line_item.annual_term AS annualTerm,
                    line_item.unit_basis AS unitBasis, line_item.exclusion_reason AS exclusionReason,
                    selected_sku.governed_sku AS selectedOptionSku
             FROM analysis_line AS line_item
             LEFT JOIN option_selection AS selection
                ON selection.analysis_line_id = line_item.id
                AND selection.analysis_revision_id = line_item.analysis_revision_id
             LEFT JOIN catalog_sku AS selected_sku
                ON selected_sku.id = selection.catalog_sku_id
                AND selected_sku.catalog_version_id = selection.catalog_version_id
             WHERE line_item.analysis_revision_id = ?
             ORDER BY line_item.id
             FOR UPDATE',
        );
        $statement->execute([(string) $revisionId]);
        $lines = [];
        foreach ($statement->fetchAll(PDO::FETCH_ASSOC) as $row) {
            $lineId = $row['lineId'] ?? null;
            $matchState = $row['matchState'] ?? null;
            $decision = $row['decision'] ?? null;
            if (!is_string($lineId) || !is_string($matchState) || !is_string($decision)) {
                throw new UnexpectedValueException('Analysis confirmation persistence returned an invalid line.');
            }
            $lines[] = [
                'lineId' => $lineId,
                'extractedIdentifier' => $this->nullableString($row['extractedIdentifier'] ?? null),
                'matchState' => $matchState,
                'decision' => $this->lineDecision($decision),
                'resolvedSku' => $this->nullableString($row['resolvedSku'] ?? null),
                'resolvedDescription' => $this->nullableString($row['resolvedDescription'] ?? null),
                'quantity' => $this->nullableString($row['quantity'] ?? null),
                'annualUsdPrice' => $this->nullableString($row['annualUsdPrice'] ?? null),
                'currency' => $this->nullableString($row['currency'] ?? null),
                'annualTerm' => $this->nullableString($row['annualTerm'] ?? null),
                'unitBasis' => $this->nullableString($row['unitBasis'] ?? null),
                'exclusionReason' => $this->nullableString($row['exclusionReason'] ?? null),
                'selectedOptionSku' => $this->nullableString($row['selectedOptionSku'] ?? null),
            ];
        }

        return [
            'state' => $this->analysisState($state),
            'catalogVersionId' => $catalogVersionId,
            'extractionMode' => $extractionMode,
            'modelIdentifier' => $this->nullableString($revisionRow['modelIdentifier'] ?? null),
            'extractionContractVersion' => $this->nullableString($revisionRow['extractionContractVersion'] ?? null),
            'promptTemplateVersion' => $this->nullableString($revisionRow['promptTemplateVersion'] ?? null),
            'responseDigest' => $this->nullableString($revisionRow['responseDigest'] ?? null),
            'lines' => $lines,
        ];
    }

    /**
     * @param list<string> $assumptions
     * @param list<array{lineId: string, reason: string}> $exclusions
     * @return array{sourceAnnualTotal: string, sourceThreeYearTotal: string, sourceFiveYearTotal: string, optionAnnualTotal: string, optionThreeYearTotal: string, optionFiveYearTotal: string, currency: string, annualTerm: string}
     * @throws JsonException
     */
    public function insertCalculationResult(
        RevisionId $revisionId,
        ComparisonTotals $source,
        ComparisonTotals $option,
        array $assumptions,
        array $exclusions,
    ): array {
        $statement = $this->pdo->prepare(
            'INSERT INTO calculation_result (
                id, analysis_revision_id, currency, annual_term,
                source_annual_total, source_three_year_total, source_five_year_total,
                option_annual_total, option_three_year_total, option_five_year_total,
                assumptions, exclusions
             ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
        );
        $statement->execute([
            Uuid::uuid4()->toString(),
            (string) $revisionId,
            'USD',
            'ANNUAL',
            $source->annual->getAmount()->__toString(),
            $source->threeYear->getAmount()->__toString(),
            $source->fiveYear->getAmount()->__toString(),
            $option->annual->getAmount()->__toString(),
            $option->threeYear->getAmount()->__toString(),
            $option->fiveYear->getAmount()->__toString(),
            json_encode($assumptions, JSON_THROW_ON_ERROR),
            json_encode($exclusions, JSON_THROW_ON_ERROR),
        ]);

        $stored = $this->pdo->prepare(
            'SELECT CAST(source_annual_total AS CHAR) AS sourceAnnualTotal,
                    CAST(source_three_year_total AS CHAR) AS sourceThreeYearTotal,
                    CAST(source_five_year_total AS CHAR) AS sourceFiveYearTotal,
                    CAST(option_annual_total AS CHAR) AS optionAnnualTotal,
                    CAST(option_three_year_total AS CHAR) AS optionThreeYearTotal,
                    CAST(option_five_year_total AS CHAR) AS optionFiveYearTotal,
                    currency, annual_term AS annualTerm
             FROM calculation_result WHERE analysis_revision_id = ?',
        );
        $stored->execute([(string) $revisionId]);
        $row = $stored->fetch(PDO::FETCH_ASSOC);
        if (!is_array($row)) {
            throw new UnexpectedValueException('The stored calculation result could not be loaded.');
        }

        $sourceAnnualTotal = $row['sourceAnnualTotal'] ?? null;
        $sourceThreeYearTotal = $row['sourceThreeYearTotal'] ?? null;
        $sourceFiveYearTotal = $row['sourceFiveYearTotal'] ?? null;
        $optionAnnualTotal = $row['optionAnnualTotal'] ?? null;
        $optionThreeYearTotal = $row['optionThreeYearTotal'] ?? null;
        $optionFiveYearTotal = $row['optionFiveYearTotal'] ?? null;
        $currency = $row['currency'] ?? null;
        $annualTerm = $row['annualTerm'] ?? null;
        if (!is_string($sourceAnnualTotal)
            || !is_string($sourceThreeYearTotal)
            || !is_string($sourceFiveYearTotal)
            || !is_string($optionAnnualTotal)
            || !is_string($optionThreeYearTotal)
            || !is_string($optionFiveYearTotal)
            || !is_string($currency)
            || !is_string($annualTerm)
        ) {
            throw new UnexpectedValueException('The stored calculation result is invalid.');
        }

        return compact(
            'sourceAnnualTotal',
            'sourceThreeYearTotal',
            'sourceFiveYearTotal',
            'optionAnnualTotal',
            'optionThreeYearTotal',
            'optionFiveYearTotal',
            'currency',
            'annualTerm',
        );
    }

    /** @return array{confirmedBySubject: string, confirmedAt: string} */
    public function confirmRevision(RevisionId $revisionId, Actor $actor): array
    {
        $statement = $this->pdo->prepare(
            'UPDATE analysis_revision
             SET state = ?, confirmed_by_subject = ?, confirmed_at = UTC_TIMESTAMP(6)
             WHERE id = ? AND creator_subject = ? AND state = ?',
        );
        $statement->execute([
            AnalysisState::CONFIRMED->name,
            $actor->identifier(),
            (string) $revisionId,
            $actor->identifier(),
            AnalysisState::READY_TO_CALCULATE->name,
        ]);
        if ($statement->rowCount() !== 1) {
            throw new UnexpectedValueException('The ready analysis revision could not be confirmed.');
        }

        $stored = $this->pdo->prepare(
            "SELECT confirmed_by_subject AS confirmedBySubject,
                    DATE_FORMAT(confirmed_at, '%Y-%m-%dT%H:%i:%s.%fZ') AS confirmedAt
             FROM analysis_revision WHERE id = ?",
        );
        $stored->execute([(string) $revisionId]);
        $row = $stored->fetch(PDO::FETCH_ASSOC);
        $confirmedBySubject = is_array($row) ? ($row['confirmedBySubject'] ?? null) : null;
        $confirmedAt = is_array($row) ? ($row['confirmedAt'] ?? null) : null;
        if (!is_string($confirmedBySubject) || !is_string($confirmedAt)) {
            throw new UnexpectedValueException('The confirmed analysis metadata is invalid.');
        }

        return compact('confirmedBySubject', 'confirmedAt');
    }

    /** @return array<string, mixed>|null */
    public function findConfirmedComparisonForSubject(RevisionId $revisionId, Actor $actor): ?array
    {
        $statement = $this->pdo->prepare(
            "SELECT CAST(result.source_annual_total AS CHAR) AS sourceAnnualTotal,
                    CAST(result.source_three_year_total AS CHAR) AS sourceThreeYearTotal,
                    CAST(result.source_five_year_total AS CHAR) AS sourceFiveYearTotal,
                    CAST(result.option_annual_total AS CHAR) AS optionAnnualTotal,
                    CAST(result.option_three_year_total AS CHAR) AS optionThreeYearTotal,
                    CAST(result.option_five_year_total AS CHAR) AS optionFiveYearTotal,
                    result.currency, result.annual_term AS annualTerm,
                    result.assumptions, result.exclusions,
                    revision.catalog_version_id AS catalogVersionId,
                    revision.confirmed_by_subject AS confirmedBySubject,
                    DATE_FORMAT(revision.confirmed_at, '%Y-%m-%dT%H:%i:%s.%fZ') AS confirmedAt,
                    revision.extraction_mode AS extractionMode,
                    revision.model_identifier AS modelIdentifier,
                    revision.extraction_contract_version AS extractionContractVersion,
                    revision.prompt_template_version AS promptTemplateVersion,
                    revision.ai_response_digest AS responseDigest
             FROM calculation_result AS result
             INNER JOIN analysis_revision AS revision ON revision.id = result.analysis_revision_id
             INNER JOIN analysis ON analysis.id = revision.analysis_id
             WHERE revision.id = ? AND revision.state = ? AND analysis.creator_subject = ?",
        );
        $statement->execute([(string) $revisionId, AnalysisState::CONFIRMED->name, $actor->identifier()]);
        $row = $statement->fetch(PDO::FETCH_ASSOC);
        if (!is_array($row)) {
            return null;
        }

        $lines = $this->pdo->prepare(
            'SELECT COALESCE(line_item.extraction_line_id, line_item.id) AS lineId,
                    line_item.decision, line_item.resolved_sku AS sourceSku,
                    CAST(line_item.quantity AS CHAR) AS quantity,
                    CAST(line_item.annual_usd_price AS CHAR) AS sourceAnnualUsdPrice,
                    line_item.unit_basis AS unitBasis,
                    option_sku.governed_sku AS optionSku,
                    CAST(option_sku.annual_usd_price AS CHAR) AS optionAnnualUsdPrice
             FROM analysis_line AS line_item
             INNER JOIN option_selection AS selection
                ON selection.analysis_line_id = line_item.id
                AND selection.analysis_revision_id = line_item.analysis_revision_id
             INNER JOIN catalog_sku AS option_sku
                ON option_sku.id = selection.catalog_sku_id
                AND option_sku.catalog_version_id = selection.catalog_version_id
             WHERE line_item.analysis_revision_id = ?
                AND line_item.decision IN (?, ?)
             ORDER BY line_item.id',
        );
        $lines->execute([
            (string) $revisionId,
            LineDecision::CONFIRMED->name,
            LineDecision::CORRECTED_CONFIRMED->name,
        ]);
        $includedLines = [];
        foreach ($lines->fetchAll(PDO::FETCH_ASSOC) as $line) {
            $keys = [
                'lineId',
                'decision',
                'sourceSku',
                'quantity',
                'sourceAnnualUsdPrice',
                'unitBasis',
                'optionSku',
                'optionAnnualUsdPrice',
            ];
            $included = [];
            foreach ($keys as $key) {
                $value = $line[$key] ?? null;
                if (!is_string($value)) {
                    throw new UnexpectedValueException('Confirmed comparison persistence returned an invalid included line.');
                }
                $included[$key] = $value;
            }
            $includedLines[] = $included;
        }

        $assumptions = $this->jsonList($row['assumptions'] ?? null, 'assumptions');
        $excludedLines = $this->jsonList($row['exclusions'] ?? null, 'exclusions');
        unset($row['assumptions'], $row['exclusions']);

        return [
            ...$row,
            'includedLines' => $includedLines,
            'excludedLines' => $excludedLines,
            'assumptions' => $assumptions,
        ];
    }

    private function analysisState(string $state): AnalysisState
    {
        foreach (AnalysisState::cases() as $candidate) {
            if ($candidate->name === $state) {
                return $candidate;
            }
        }

        throw new UnexpectedValueException('Analysis persistence returned an invalid state.');
    }

    private function lineDecision(string $decision): LineDecision
    {
        foreach (LineDecision::cases() as $candidate) {
            if ($candidate->name === $decision) {
                return $candidate;
            }
        }

        throw new UnexpectedValueException('Analysis persistence returned an invalid line decision.');
    }

    private function nullableString(mixed $value): ?string
    {
        if ($value === null || is_string($value)) {
            return $value;
        }

        throw new UnexpectedValueException('Analysis persistence returned an invalid nullable string.');
    }

    /** @return list<mixed> */
    private function jsonList(mixed $value, string $field): array
    {
        if (!is_string($value)) {
            throw new UnexpectedValueException(sprintf('Confirmed comparison %s are invalid.', $field));
        }
        $decoded = json_decode($value, true);
        if (!is_array($decoded) || !array_is_list($decoded)) {
            throw new UnexpectedValueException(sprintf('Confirmed comparison %s are invalid.', $field));
        }

        return $decoded;
    }
}
