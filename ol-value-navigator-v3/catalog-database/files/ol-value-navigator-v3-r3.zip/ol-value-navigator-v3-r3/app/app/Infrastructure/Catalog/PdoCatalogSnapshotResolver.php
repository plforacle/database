<?php

declare(strict_types=1);

namespace App\Infrastructure\Catalog;

use App\Application\Package\CatalogSnapshotResolver;
use App\Domain\Package\CatalogSnapshot;
use App\Domain\Shared\DomainViolation;
use App\Infrastructure\Persistence\PdoPackageRepository;
use PDO;

final readonly class PdoCatalogSnapshotResolver implements CatalogSnapshotResolver
{
    public function __construct(private PDO $pdo, private string $channel = 'coverage')
    {
    }

    public function resolve(string $profileId): CatalogSnapshot
    {
        return $this->snapshot($profileId, '');
    }

    public function resolveForConfirmation(string $profileId): CatalogSnapshot
    {
        return $this->snapshot($profileId, 'FOR SHARE');
    }

    private function snapshot(string $profileId, string $lock): CatalogSnapshot
    {
        $repository = new PdoPackageRepository($this->pdo);
        $selection = $repository->selection($this->channel, $lock);
        if ($selection['releaseId'] === null) {
            throw DomainViolation::because('No package is active for coverage review.');
        }
        $release = $repository->readRelease($selection['releaseId']);
        return new CatalogSnapshot($release['package'], $profileId, $this->channel, $selection['generation']);
    }
}
