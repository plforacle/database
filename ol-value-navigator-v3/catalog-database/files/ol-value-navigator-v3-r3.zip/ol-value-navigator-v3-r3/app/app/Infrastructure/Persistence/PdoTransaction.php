<?php

declare(strict_types=1);

namespace App\Infrastructure\Persistence;

use PDO;

final readonly class PdoTransaction
{
    public function __construct(private PDO $pdo)
    {
    }

    /**
     * @template T
     * @param callable(PDO): T $operation
     * @return T
     */
    public function run(callable $operation): mixed
    {
        $this->pdo->beginTransaction();

        try {
            $result = $operation($this->pdo);
            $this->pdo->commit();

            return $result;
        } catch (\Throwable $exception) {
            if ($this->pdo->inTransaction()) {
                $this->pdo->rollBack();
            }

            throw $exception;
        }
    }
}
