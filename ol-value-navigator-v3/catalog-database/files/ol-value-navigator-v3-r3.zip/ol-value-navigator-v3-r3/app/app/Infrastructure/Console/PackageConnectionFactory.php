<?php

declare(strict_types=1);

namespace App\Infrastructure\Console;

use App\Domain\Shared\DomainViolation;
use App\Infrastructure\Identity\PdoPackagePublisherPrincipal;
use Closure;
use PDO;

final readonly class PackageConnectionFactory
{
    private Closure $environment;
    private Closure $connect;

    /** @param null|Closure(string):string $environment
     * @param null|Closure(string,string,string):PDO $connect
     */
    public function __construct(private PackageFileReader $files, ?Closure $environment = null, ?Closure $connect = null)
    {
        $this->environment = $environment ?? static function (string $name): string {
            $value = getenv($name);
            return is_string($value) ? $value : '';
        };
        $this->connect = $connect ?? static fn (string $dsn, string $username, string $password): PDO => new PDO(
            $dsn,
            $username,
            $password,
            [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, PDO::ATTR_EMULATE_PREPARES => false],
        );
    }

    public function runtime(): PDO
    {
        $dsn = $this->required('OLVN_DATABASE_DSN');
        $bytes = $this->files->read($this->required('OLVN_DATABASE_USER_SECRET_PATH'), 16 * 1024, true);
        $secret = json_decode($bytes, true, 32, JSON_THROW_ON_ERROR);
        if (!is_array($secret) || array_keys($secret) !== ['username', 'password']
            || !is_string($secret['username']) || trim($secret['username']) === ''
            || !is_string($secret['password'])) {
            throw DomainViolation::because('Runtime database credential format is invalid.');
        }
        return ($this->connect)($dsn, $secret['username'], $secret['password']);
    }

    /** @return array{pdo:PDO,principal:PdoPackagePublisherPrincipal} */
    public function publisher(): array
    {
        $dsn = $this->required('OLVN_PACKAGE_PUBLISH_DSN');
        $accounts = json_decode($this->required('OLVN_PACKAGE_PUBLISH_ACCOUNTS'), true, 8, JSON_THROW_ON_ERROR);
        if (!is_array($accounts) || !array_is_list($accounts) || $accounts === [] || count($accounts) > 32) {
            throw DomainViolation::because('Publisher accounts must be a bounded exact-account list.');
        }
        foreach ($accounts as $account) {
            if (!is_string($account)) {
                throw DomainViolation::because('Publisher account is invalid.');
            }
        }
        $user = $this->files->read($this->required('OLVN_PACKAGE_PUBLISH_USER_SECRET_PATH'), 4096, true);
        $password = $this->files->read($this->required('OLVN_PACKAGE_PUBLISH_PASSWORD_SECRET_PATH'), 4096, true);
        if (trim($user) === '' || str_contains($user, "\0") || str_contains($password, "\0")) {
            throw DomainViolation::because('Publisher credentials are invalid.');
        }
        $pdo = ($this->connect)($dsn, $user, $password);
        $principal = new PdoPackagePublisherPrincipal($pdo, $accounts);
        $principal->authenticatedIdentifier();
        return ['pdo' => $pdo, 'principal' => $principal];
    }

    private function required(string $name): string
    {
        $value = ($this->environment)($name);
        if (trim($value) === '') {
            throw DomainViolation::because('Required package connection configuration is unavailable.');
        }
        return $value;
    }
}
