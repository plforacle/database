<?php

declare(strict_types=1);

namespace App\Infrastructure\Persistence;

use App\Domain\Analysis\AnalysisState;
use App\Domain\Audit\AuditAction;
use App\Domain\Audit\AuditRepository;
use App\Domain\Shared\Actor;
use App\Domain\Shared\AuditEventId;
use App\Domain\Shared\RequestId;
use App\Domain\Shared\RevisionId;
use PDO;

final readonly class PdoAuditRepository implements AuditRepository
{
    public function __construct(private PDO $pdo)
    {
    }

    public function append(
        RevisionId $revisionId,
        Actor $actor,
        AuditAction $action,
        ?AnalysisState $previousState,
        ?AnalysisState $resultingState,
        RequestId $requestId,
    ): void {
        $eventId = AuditEventId::new();
        $statement = $this->pdo->prepare(
            'INSERT INTO audit_event (id, analysis_revision_id, actor_subject, action, previous_state, resulting_state, request_id, payload) VALUES (?, ?, ?, ?, ?, ?, ?, NULL)',
        );
        $statement->execute([
            (string) $eventId,
            (string) $revisionId,
            $actor->identifier(),
            $action->name,
            $previousState?->name,
            $resultingState?->name,
            (string) $requestId,
        ]);
    }
}
