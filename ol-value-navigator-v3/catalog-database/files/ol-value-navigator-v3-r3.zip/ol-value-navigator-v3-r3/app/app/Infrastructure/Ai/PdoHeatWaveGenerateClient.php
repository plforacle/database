<?php

declare(strict_types=1);

namespace App\Infrastructure\Ai;

use App\Application\Extraction\HeatWaveGenerateClient;
use App\Domain\Shared\DomainViolation;
use PDO;

final readonly class PdoHeatWaveGenerateClient implements HeatWaveGenerateClient
{
    public function __construct(private PDO $pdo, private string $configuredModelIdentifier)
    {
        if (trim($configuredModelIdentifier) === '' || strlen($configuredModelIdentifier) > 255) {
            throw DomainViolation::because('The HeatWave model identifier is required.');
        }
    }

    public function generate(string $prompt, string $modelIdentifier): string
    {
        if (!hash_equals($this->configuredModelIdentifier, $modelIdentifier)) {
            throw DomainViolation::because('The configured HeatWave model identifier must be used.');
        }
        $statement = $this->pdo->prepare(
            "SELECT sys.ML_GENERATE(:prompt, JSON_OBJECT('task', 'generation', 'model_id', :model_id, 'language', 'en', 'temperature', 0, 'max_tokens', 2048)) AS response",
        );
        $statement->execute(['prompt' => $prompt, 'model_id' => $modelIdentifier]);
        $response = $statement->fetchColumn();
        if (!is_string($response)) {
            throw new \RuntimeException('HeatWave did not return an extraction response.');
        }

        return $response;
    }
}
