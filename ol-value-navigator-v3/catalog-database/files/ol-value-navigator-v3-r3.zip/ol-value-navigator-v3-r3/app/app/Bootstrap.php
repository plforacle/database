<?php

declare(strict_types=1);

namespace App;

use App\Application\Analysis\CreateDemoAnalysis;
use App\Application\Package\CatalogSnapshotResolver;
use App\Infrastructure\Catalog\PdoCatalogSnapshotResolver;
use App\Infrastructure\Catalog\LazyCatalogSnapshotResolver;
use App\Application\Calculation\ConfirmDemoComparison;
use App\Application\Calculation\DemoComparisonPresenter;
use App\Application\Extraction\ExtractCandidates;
use App\Application\Extraction\Extractor;
use App\Application\Matching\MatchCandidates;
use App\Application\Review\EvaluateReadiness;
use App\Application\Review\ResolveLine;
use App\Application\Review\SelectDemoOption;
use App\Domain\Calculation\SubscriptionCalculator;
use App\Domain\Shared\DomainViolation;
use App\Http\Action\Demo\ConfirmAction;
use App\Http\Action\Demo\CoverageAction;
use App\Http\Action\Demo\CreateAnalysisAction;
use App\Http\Action\Demo\ExtractAction;
use App\Http\Action\Demo\ManualCandidatesAction;
use App\Http\Action\Demo\ResolveLineAction;
use App\Http\Action\Demo\ReviewAction;
use App\Http\Action\Demo\ShowAnalysisAction;
use App\Http\DemoAnalysisQuery;
use App\Http\DemoPage;
use App\Http\Middleware\CsrfMiddleware;
use App\Http\Middleware\DemoRepresentativeMiddleware;
use App\Http\Middleware\SecurityHeadersMiddleware;
use App\Infrastructure\Ai\HeatWaveExtractor;
use App\Infrastructure\Ai\PdoHeatWaveGenerateClient;
use App\Infrastructure\Catalog\SyntheticCatalogRepository;
use App\Infrastructure\Identity\ConfiguredSyntheticRepresentative;
use App\Infrastructure\Persistence\PdoAnalysisRepository;
use App\Infrastructure\Persistence\PdoAuditRepository;
use App\Infrastructure\Persistence\PdoTransaction;
use App\Infrastructure\Persistence\CoverageStore;
use DI\ContainerBuilder;
use JsonException;
use PDO;
use Psr\Container\ContainerInterface;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Slim\App;
use Slim\Factory\AppFactory;
use Slim\Routing\RouteCollectorProxy;

final class Bootstrap
{
    /**
     * @param array<string, mixed> $settings
     */
    public static function container(array $settings): ContainerInterface
    {
        $builder = new ContainerBuilder();
        $builder->addDefinitions(['settings' => $settings]);

        return $builder->build();
    }

    /**
     * @param array<string, mixed> $settings
     *
     * @return App<ContainerInterface|null>
     */
    public static function app(array $settings, PDO $pdo, ?Extractor $extractor = null, ?CatalogSnapshotResolver $catalogs = null): App
    {
        $environment = self::requiredSetting($settings, 'environment');
        $subject = self::requiredSetting($settings, 'demoRepresentativeSubject');
        $modelIdentifier = self::requiredSetting($settings, 'heatWaveModelIdentifier');
        $context = new ConfiguredSyntheticRepresentative($subject);
        $actor = $context->current();
        $transaction = new PdoTransaction($pdo);
        $analyses = new PdoAnalysisRepository($pdo);
        $audit = new PdoAuditRepository($pdo);
        $catalog = new SyntheticCatalogRepository();
        $presenter = new DemoComparisonPresenter();
        $pages = new DemoPage(__DIR__ . '/Views');
        $query = new DemoAnalysisQuery($transaction, $analyses);
        $extractor ??= new HeatWaveExtractor(
            new PdoHeatWaveGenerateClient($pdo, $modelIdentifier),
            $modelIdentifier,
        );

        $create = new CreateDemoAnalysis($transaction, $analyses, $audit);
        $extract = new ExtractCandidates($transaction, $analyses, $audit, $extractor, $actor);
        $matcher = new MatchCandidates($catalog);
        $resolve = new ResolveLine($transaction, $analyses, $audit, $matcher);
        $select = new SelectDemoOption($transaction, $analyses, $catalog);
        $readiness = new EvaluateReadiness($transaction, $analyses, $catalog);
        $confirm = new ConfirmDemoComparison(
            $transaction,
            $analyses,
            $audit,
            $catalog,
            new SubscriptionCalculator(),
            $presenter,
        );

        $catalogs ??= new LazyCatalogSnapshotResolver(static fn (): CatalogSnapshotResolver => new PdoCatalogSnapshotResolver($pdo));
        $coverageAction = new CoverageAction(new CoverageStore($pdo, $catalogs), $pages, $catalogs);
        $createAction = new CreateAnalysisAction($create, $pages);
        $extractAction = new ExtractAction($extract, $query, $pages);
        $manualAction = new ManualCandidatesAction($extract, $query, $pages);
        $reviewAction = new ReviewAction($query, $pages);
        $resolveAction = new ResolveLineAction($resolve, $select, $readiness, $query, $pages);
        $confirmAction = new ConfirmAction($confirm, $query, $pages);
        $showAction = new ShowAnalysisAction($query, $presenter, $pages);

        AppFactory::setContainer(self::container($settings));
        $app = AppFactory::create();
        $app->get('/health/live', function (
            ServerRequestInterface $_request,
            ResponseInterface $response,
        ): ResponseInterface {
            $response->getBody()->write('{"status":"ok"}');

            return $response->withHeader('Content-Type', 'application/json');
        });

        $group = $app->group('/demo', function (RouteCollectorProxy $routes) use (
            $createAction,
            $extractAction,
            $manualAction,
            $reviewAction,
            $resolveAction,
            $confirmAction,
            $showAction,
            $coverageAction,
        ): void {
            $routes->get('', [$createAction, 'form']);
            $routes->get('/coverage', [$coverageAction, 'form']);
            $routes->post('/coverage', [$coverageAction, 'save']);
            $routes->get('/coverage/new', [$coverageAction, 'newScenario']);
            $routes->post('/coverage/edit', [$coverageAction, 'editScenario']);
            $routes->post('/coverage/import', [$coverageAction, 'importScenario']);
            $routes->get('/coverage/source/{sourceId}/image', [$coverageAction, 'sourceImage']);
            $routes->get('/coverage/source/{sourceId}', [$coverageAction, 'sourcePreview']);
            $routes->post('/coverage/source/{sourceId}', [$coverageAction, 'reviewSource']);
            $routes->get('/coverage/{revisionId}', [$coverageAction, 'form']);
            $routes->post('/coverage/{revisionId}/confirm', [$coverageAction, 'confirm']);
            $routes->get('/coverage/{revisionId}/pptx', [$coverageAction, 'export']);
            $routes->post('/analyses', [$createAction, 'create']);
            $routes->get('/analyses/{analysisId}', $showAction);
            $routes->post('/analyses/{analysisId}/extract', $extractAction);
            $routes->post('/analyses/{analysisId}/manual', $manualAction);
            $routes->get('/analyses/{analysisId}/review', $reviewAction);
            $routes->post('/analyses/{analysisId}/resolve', $resolveAction);
            $routes->post('/analyses/{analysisId}/confirm', $confirmAction);
        });
        $group->add(new DemoRepresentativeMiddleware($context));
        $group->add(new CsrfMiddleware(
            !in_array($environment, ['test', 'loopback'], true),
            $pages,
        ));
        $group->add(new SecurityHeadersMiddleware());

        return $app;
    }

    /** @param array<string, mixed> $settings
     * @throws JsonException
     */
    public static function database(array $settings): PDO
    {
        $dsn = self::requiredSetting($settings, 'databaseDsn');
        $secretPath = self::requiredSetting($settings, 'databaseUserSecretPath');
        $encoded = @file_get_contents($secretPath);
        if (!is_string($encoded)) {
            throw DomainViolation::because('The configured database user secret is unavailable.');
        }
        $secret = json_decode($encoded, true, 32, JSON_THROW_ON_ERROR);
        if (!is_array($secret)
            || array_keys($secret) !== ['username', 'password']
            || !is_string($secret['username'])
            || trim($secret['username']) === ''
            || !is_string($secret['password'])
        ) {
            throw DomainViolation::because('The configured database user secret is invalid.');
        }

        return new PDO($dsn, $secret['username'], $secret['password'], [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
    }

    /** @param array<string, mixed> $settings */
    private static function requiredSetting(array $settings, string $key): string
    {
        $value = $settings[$key] ?? null;
        if (!is_string($value) || trim($value) === '') {
            $message = match ($key) {
                'demoRepresentativeSubject' => 'Synthetic representative subject is required.',
                'heatWaveModelIdentifier' => 'HeatWave model identifier is required.',
                'databaseDsn' => 'Database DSN is required.',
                'databaseUserSecretPath' => 'Database user secret path is required.',
                default => sprintf('Application setting %s is required.', $key),
            };
            throw DomainViolation::because($message);
        }

        return trim($value);
    }
}
