<?php

declare(strict_types=1);

namespace App\Application\Catalog;

use App\Domain\Shared\Actor;

interface CatalogOwnerPrincipal
{
    public function authenticatedActor(): Actor;
}
