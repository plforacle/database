<?php

declare(strict_types=1);

namespace App\Application\Review;

use App\Application\Matching\MatchCandidates;
use App\Domain\Analysis\AnalysisRepository;
use App\Domain\Analysis\AnalysisState;
use App\Domain\Analysis\ConfirmedLine;
use App\Domain\Analysis\LineDecision;
use App\Domain\Audit\AuditAction;
use App\Domain\Audit\AuditRepository;
use App\Domain\Extraction\CandidateLine;
use App\Domain\Matching\MatchResult;
use App\Domain\Matching\MatchState;
use App\Domain\Shared\Actor;
use App\Domain\Shared\CatalogVersionId;
use App\Domain\Shared\DomainViolation;
use App\Domain\Shared\RequestId;
use App\Domain\Shared\ResourceNotFound;
use App\Domain\Shared\RevisionId;
use App\Infrastructure\Persistence\PdoTransaction;

final readonly class ResolveLine
{
    public function __construct(
        private PdoTransaction $transaction,
        private AnalysisRepository $analyses,
        private AuditRepository $audit,
        private MatchCandidates $matcher,
    ) {
    }

    public function confirm(
        RevisionId $revisionId,
        string $lineId,
        Actor $actor,
        RequestId $requestId,
    ): void {
        $this->assertRepresentative($actor);
        $this->transaction->run(function () use ($revisionId, $lineId, $actor, $requestId): void {
            $line = $this->requiredPendingLine($revisionId, $lineId, $actor);
            $match = $this->match($lineId, $line['extractedIdentifier'], $line['quantity'], $line['catalogVersionId']);
            $confirmed = $this->confirmedLine($match, $line['quantity']);
            $this->analyses->confirmLine(
                $revisionId,
                $lineId,
                $actor,
                $match,
                $confirmed,
                LineDecision::CONFIRMED,
                null,
            );
            $this->audit->append(
                $revisionId,
                $actor,
                AuditAction::LINE_CONFIRMED,
                $line['state'],
                $line['state'],
                $requestId,
            );
        });
    }

    /** @param array<string, mixed> $correction */
    public function correctAndConfirm(
        RevisionId $revisionId,
        string $lineId,
        array $correction,
        Actor $actor,
        RequestId $requestId,
    ): void {
        $this->assertRepresentative($actor);
        $this->assertCorrectionShape($correction);
        $sku = $correction['sku'];
        $quantity = $correction['quantity'];
        if (!is_string($sku) || !is_string($quantity)) {
            throw DomainViolation::because('A correction accepts only string sku and quantity fields.');
        }

        $this->transaction->run(function () use ($revisionId, $lineId, $sku, $quantity, $actor, $requestId): void {
            $line = $this->requiredPendingLine($revisionId, $lineId, $actor);
            $match = $this->match($lineId, $sku, $quantity, $line['catalogVersionId']);
            $confirmed = $this->confirmedLine($match, $quantity);
            $this->analyses->confirmLine(
                $revisionId,
                $lineId,
                $actor,
                $match,
                $confirmed,
                LineDecision::CORRECTED_CONFIRMED,
                $sku,
            );
            $this->audit->append(
                $revisionId,
                $actor,
                AuditAction::LINE_CORRECTED,
                $line['state'],
                $line['state'],
                $requestId,
            );
        });
    }

    public function exclude(
        RevisionId $revisionId,
        string $lineId,
        string $reason,
        Actor $actor,
        RequestId $requestId,
    ): void {
        $this->assertRepresentative($actor);
        $reason = $this->validatedExclusionReason($reason);
        $this->transaction->run(function () use ($revisionId, $lineId, $reason, $actor, $requestId): void {
            $line = $this->requiredPendingLine($revisionId, $lineId, $actor);
            $this->analyses->excludeLine($revisionId, $lineId, $actor, $reason);
            $this->audit->append(
                $revisionId,
                $actor,
                AuditAction::LINE_EXCLUDED,
                $line['state'],
                $line['state'],
                $requestId,
            );
        });
    }

    /**
     * @return array{state: AnalysisState, catalogVersionId: string, decision: LineDecision, extractedIdentifier: string|null, resolvedSku: string|null, quantity: string|null}
     */
    private function requiredPendingLine(RevisionId $revisionId, string $lineId, Actor $actor): array
    {
        $line = $this->analyses->lockLineForReview($revisionId, $lineId, $actor);
        if ($line === null) {
            throw ResourceNotFound::because('The owned review line was not found.');
        }
        if (!in_array($line['state'], [AnalysisState::NEEDS_REVIEW, AnalysisState::INCOMPLETE], true)) {
            throw DomainViolation::because('Line decisions require a reviewable analysis revision.');
        }
        if ($line['decision'] !== LineDecision::PENDING) {
            throw DomainViolation::because('Only a pending line may be resolved.');
        }

        return $line;
    }

    private function match(string $lineId, ?string $sku, ?string $quantity, string $catalogVersionId): MatchResult
    {
        return $this->matcher->match(
            new CandidateLine($lineId, 0, 0, '', $sku, $quantity),
            CatalogVersionId::fromString($catalogVersionId),
        );
    }

    private function confirmedLine(MatchResult $match, ?string $quantity): ConfirmedLine
    {
        if ($match->state() !== MatchState::EXACT
            || $match->governedSku() === null
            || $match->description() === null
            || trim($match->description()) === ''
            || $match->annualUsdPrice() === null
            || $match->unit() === null
            || $quantity === null
        ) {
            throw DomainViolation::because('Only an exact governed line with complete facts may be confirmed.');
        }

        return ConfirmedLine::annualUsd(
            $match->governedSku(),
            $quantity,
            $match->annualUsdPrice(),
            unitBasisPresent: trim($match->unit()) !== '',
        );
    }

    /** @param array<string, mixed> $correction */
    private function assertCorrectionShape(array $correction): void
    {
        $keys = array_keys($correction);
        sort($keys);
        if ($keys !== ['quantity', 'sku']) {
            throw DomainViolation::because('A correction accepts exactly sku and quantity.');
        }
    }

    private function validatedExclusionReason(string $reason): string
    {
        $reason = trim($reason);
        if (strlen($reason) > 2000) {
            throw DomainViolation::because('An exclusion reason must contain between 1 and 500 characters.');
        }
        $characterCount = preg_match_all('/./us', $reason, $matches);
        if ($reason === '' || $characterCount === false || $characterCount > 500) {
            throw DomainViolation::because('An exclusion reason must contain between 1 and 500 characters.');
        }

        return $reason;
    }

    private function assertRepresentative(Actor $actor): void
    {
        if (!$actor->canConfirmAnalysis()) {
            throw DomainViolation::because('Line decisions require the representative capability.');
        }
    }
}
