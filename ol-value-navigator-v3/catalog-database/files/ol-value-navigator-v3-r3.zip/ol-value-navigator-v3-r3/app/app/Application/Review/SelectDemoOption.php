<?php

declare(strict_types=1);

namespace App\Application\Review;

use App\Domain\Analysis\AnalysisRepository;
use App\Domain\Analysis\AnalysisState;
use App\Domain\Analysis\LineDecision;
use App\Domain\Catalog\CatalogRepository;
use App\Domain\Shared\Actor;
use App\Domain\Shared\CatalogVersionId;
use App\Domain\Shared\DomainViolation;
use App\Domain\Shared\RequestId;
use App\Domain\Shared\ResourceNotFound;
use App\Domain\Shared\RevisionId;
use App\Infrastructure\Persistence\PdoTransaction;

final readonly class SelectDemoOption
{
    public function __construct(
        private PdoTransaction $transaction,
        private AnalysisRepository $analyses,
        private CatalogRepository $catalog,
    ) {
    }

    public function execute(
        RevisionId $revision,
        string $lineId,
        string $optionSku,
        Actor $actor,
        RequestId $_requestId,
    ): void {
        if (!$actor->canConfirmAnalysis()) {
            throw DomainViolation::because('Option selection requires the representative capability.');
        }

        $this->transaction->run(function () use ($revision, $lineId, $optionSku, $actor): void {
            $line = $this->analyses->lockLineForReview($revision, $lineId, $actor);
            if ($line === null) {
                throw ResourceNotFound::because('The owned review line was not found.');
            }
            if (!in_array($line['state'], [AnalysisState::NEEDS_REVIEW, AnalysisState::INCOMPLETE], true)
                || !in_array($line['decision'], [LineDecision::CONFIRMED, LineDecision::CORRECTED_CONFIRMED], true)
                || $line['resolvedSku'] === null
            ) {
                throw DomainViolation::because('An option may be selected only for a resolved review line.');
            }

            $catalogVersionId = CatalogVersionId::fromString($line['catalogVersionId']);
            $eligible = $this->catalog->eligibleOptions($catalogVersionId, $line['resolvedSku']);
            $allowed = array_filter(
                $eligible,
                static fn (array $option): bool => $option['sku'] === $optionSku,
            );
            if (count($allowed) !== 1) {
                throw DomainViolation::because('The selected option is not currently eligible for this governed line.');
            }

            $this->analyses->selectOption($revision, $lineId, $catalogVersionId, $optionSku, $actor);
        });
    }
}
