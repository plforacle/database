<?php

declare(strict_types=1);

namespace App\Application\Package;

use App\Domain\Shared\DomainViolation;
use App\Infrastructure\Persistence\PdoPackageRepository;
use App\Infrastructure\Persistence\PdoTransaction;
use PDO;
use PDOException;

/** @phpstan-type Receipt array{outcome:string,channel:string,previousReleaseId:?string,releaseId:string,generation:int,publisher:string} */
final readonly class ActivatePackage
{
    public function __construct(private PDO $pdo, private PackagePublisherPrincipal $principal)
    {
    }

    /** @return Receipt */
    public function execute(string $release, int $expectedGeneration, string $reason, string $approvalReference, string $channel = 'coverage'): array
    {
        return $this->transition('activate', $release, $expectedGeneration, $reason, $approvalReference, $channel);
    }

    /** @return Receipt */
    public function rollback(string $release, int $expectedGeneration, string $reason, string $approvalReference, string $channel = 'coverage'): array
    {
        return $this->transition('rollback', $release, $expectedGeneration, $reason, $approvalReference, $channel);
    }

    /** @return Receipt */
    private function transition(string $operation, string $release, int $expectedGeneration, string $reason, string $approvalReference, string $channel): array
    {
        $publisher = $this->principal->authenticatedIdentifier();
        PdoPackageRepository::generation($expectedGeneration);
        PdoPackageRepository::evidenceReference($reason);
        PdoPackageRepository::evidenceReference($approvalReference);
        if ($channel !== 'coverage' || $expectedGeneration === PHP_INT_MAX || $this->pdo->inTransaction()) {
            throw DomainViolation::because('Package transition requires a valid channel, generation and its own transaction.');
        }
        $repository = new PdoPackageRepository($this->pdo);
        $target = $repository->readRelease($release);
        if ((new PackageAcceptanceRunner())->verify($target['package'], $target['acceptanceJson']) !== $target['admission']) {
            throw DomainViolation::because('Retained package acceptance no longer agrees.');
        }
        try {
            return (new PdoTransaction($this->pdo))->run(function () use ($repository, $operation, $release, $expectedGeneration, $reason, $approvalReference, $channel, $publisher): array {
                $current = $repository->selection($channel, 'FOR UPDATE');
                if ($current['generation'] !== $expectedGeneration || $current['releaseId'] === $release) {
                    throw DomainViolation::because('Package transition is stale or already active.');
                }
                if ($operation === 'rollback') {
                    $history = $this->pdo->prepare('SELECT 1 FROM package_activation WHERE channel=? AND release_id=? LIMIT 1');
                    $history->execute([$channel, $release]);
                    if ($history->fetchColumn() === false) {
                        throw DomainViolation::because('Package rollback requires retained channel history.');
                    }
                }
                $generation = $expectedGeneration + 1;
                $this->pdo->prepare('INSERT INTO package_activation(channel,generation,previous_generation,previous_release_id,release_id,publisher,reason,approval_reference,operation) VALUES(?,?,?,?,?,?,?,?,?)')
                    ->execute([$channel, $generation, $expectedGeneration, $current['releaseId'], $release, $publisher, $reason, $approvalReference, $operation]);
                $update = $this->pdo->prepare('UPDATE package_channel SET release_id=?,generation=? WHERE channel=?');
                $update->execute([$release, $generation, $channel]);
                if ($update->rowCount() !== 1) {
                    throw DomainViolation::because('Package pointer update failed.');
                }
                return ['outcome' => $operation === 'rollback' ? 'rolled_back' : 'activated', 'channel' => $channel, 'previousReleaseId' => $current['releaseId'], 'releaseId' => $release, 'generation' => $generation, 'publisher' => $publisher];
            });
        } catch (PDOException) {
            throw DomainViolation::because('Package transition failed without changing the active selection.');
        }
    }
}
