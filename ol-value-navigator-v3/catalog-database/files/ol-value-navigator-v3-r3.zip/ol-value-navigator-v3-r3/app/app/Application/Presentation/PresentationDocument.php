<?php

declare(strict_types=1);

namespace App\Application\Presentation;

use UnexpectedValueException;

/**
 * Validated value-only input to an OOXML writer; no saved-record or profile policy.
 *
 * @phpstan-type TextOperation array{kind:'text',text:string,x:int|float,y:int|float,w:int|float,h:int|float,size:positive-int,bold:bool,color:string}
 * @phpstan-type TableOperation array{kind:'table',rows:non-empty-list<non-empty-list<string>>,x:int|float,y:int|float,widths:non-empty-list<int|float>,rowHeight:int|float,size:positive-int}
 * @phpstan-type Operation TextOperation|TableOperation
 * @phpstan-type Value array{format:'presentation-document-1',slides:list<list<Operation>>,notes:list<string>,disclosure:string}
 */
final readonly class PresentationDocument
{
    /** @param Value $value */
    private function __construct(private array $value)
    {
    }

    /** @param array<string,mixed> $value */
    public static function fromArray(array $value): self
    {
        self::keys($value, ['format', 'slides', 'notes', 'disclosure']);
        if ($value['format'] !== 'presentation-document-1' || !is_array($value['slides'])
            || !array_is_list($value['slides']) || !in_array(count($value['slides']), [3, 4, 5], true)
            || !is_array($value['notes']) || !array_is_list($value['notes'])
            || count($value['notes']) !== count($value['slides'])) {
            throw new UnexpectedValueException('Invalid presentation document format, slides or notes.');
        }
        $slides = [];
        foreach ($value['slides'] as $slide) {
            if (!is_array($slide) || !array_is_list($slide)) {
                throw new UnexpectedValueException('Presentation slides must contain operation lists.');
            }
            $operations = [];
            foreach ($slide as $operation) {
                $operations[] = self::operation($operation);
            }
            $slides[] = $operations;
        }
        $notes = array_map(self::text(...), $value['notes']);
        return new self(['format' => 'presentation-document-1', 'slides' => $slides, 'notes' => $notes, 'disclosure' => self::text($value['disclosure'])]);
    }

    /** @return Value */
    public function toArray(): array
    {
        return $this->value;
    }

    /** @return Operation */
    private static function operation(mixed $operation): array
    {
        if (!is_array($operation)) {
            throw new UnexpectedValueException('Invalid presentation operation.');
        }
        $kind = $operation['kind'] ?? null;
        if ($kind === 'text') {
            self::keys($operation, ['kind', 'text', 'x', 'y', 'w', 'h', 'size', 'bold', 'color']);
            if (!is_bool($operation['bold']) || !is_string($operation['color']) || preg_match('/\A[0-9a-fA-F]{6}\z/D', $operation['color']) !== 1) {
                throw new UnexpectedValueException('Invalid text weight or color.');
            }
            return ['kind' => 'text', 'text' => self::text($operation['text']), 'x' => self::number($operation['x']), 'y' => self::number($operation['y']), 'w' => self::number($operation['w'], true), 'h' => self::number($operation['h'], true), 'size' => self::size($operation['size']), 'bold' => (bool) $operation['bold'], 'color' => (string) $operation['color']];
        }
        if ($kind !== 'table') {
            throw new UnexpectedValueException('Unknown presentation operation.');
        }
        self::keys($operation, ['kind', 'rows', 'x', 'y', 'widths', 'rowHeight', 'size']);
        if (!is_array($operation['widths']) || !array_is_list($operation['widths']) || $operation['widths'] === []
            || !is_array($operation['rows']) || !array_is_list($operation['rows']) || $operation['rows'] === []) {
            throw new UnexpectedValueException('Presentation table must have rows and widths.');
        }
        $widths = array_map(static fn (mixed $width): int|float => self::number($width, true), $operation['widths']);
        $rows = [];
        foreach ($operation['rows'] as $row) {
            if (!is_array($row) || !array_is_list($row) || count($row) !== count($widths)) {
                throw new UnexpectedValueException('Presentation table cell and width counts disagree.');
            }
            $rows[] = array_map(self::text(...), $row);
        }
        $rowHeight = self::number($operation['rowHeight'], true);
        self::number(array_sum($widths), true);
        self::number(count($rows) * $rowHeight, true);
        return ['kind' => 'table', 'rows' => $rows, 'x' => self::number($operation['x']), 'y' => self::number($operation['y']), 'widths' => $widths, 'rowHeight' => $rowHeight, 'size' => self::size($operation['size'])];
    }

    /** @param array<array-key,mixed> $value
     * @param list<string> $keys
     */
    private static function keys(array $value, array $keys): void
    {
        if (count($value) !== count($keys) || array_diff($keys, array_keys($value)) !== []) {
            throw new UnexpectedValueException('Missing or unknown presentation document fields.');
        }
    }

    private static function text(mixed $value): string
    {
        if (!is_string($value) || preg_match('/[^\x{9}\x{A}\x{D}\x{20}-\x{D7FF}\x{E000}-\x{FFFD}\x{10000}-\x{10FFFF}]/u', $value) !== 0) {
            throw new UnexpectedValueException('Invalid UTF-8 or XML presentation text.');
        }
        return $value;
    }

    private static function number(mixed $value, bool $positive = false): int|float
    {
        if ((!is_int($value) && !is_float($value)) || !is_finite((float) $value) || ($positive ? $value <= 0 : $value < 0)) {
            throw new UnexpectedValueException('Invalid presentation geometry.');
        }
        // Keep the writer's integer EMU conversion representable, including
        // rounded positive dimensions and aggregate table extents.
        if ($value > intdiv(PHP_INT_MAX, 914400) - 1 || ($positive && round($value * 914400) < 1)) {
            throw new UnexpectedValueException('Presentation geometry exceeds the writer range.');
        }
        return $value;
    }

    /** @return positive-int */
    private static function size(mixed $value): int
    {
        if (!is_int($value) || $value <= 0 || $value > 4000) {
            throw new UnexpectedValueException('Invalid presentation font size.');
        }
        return $value;
    }
}
