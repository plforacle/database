<?php

declare(strict_types=1);

namespace App\Application\Catalog;

use App\Domain\Shared\CatalogVersionId;
use PDO;

final class CatalogContentDigester
{
    /** @return array{source_digest: string, sku_digest: string, alias_digest: string, mapping_digest: string} */
    public function forVersion(PDO $pdo, CatalogVersionId $id): array
    {
        $version = (string) $id;

        return [
            'source_digest' => $this->digest($this->rows(
                $pdo,
                'SELECT citation, worksheet_reference FROM catalog_source WHERE catalog_version_id = ? ORDER BY worksheet_reference, citation',
                $version,
            )),
            'sku_digest' => $this->digest($this->rows(
                $pdo,
                'SELECT sku.governed_sku, sku.description, sku.unit, CAST(sku.annual_usd_price AS CHAR) AS annual_usd_price, CAST(sku.effective_from AS CHAR) AS effective_from, CAST(sku.effective_to AS CHAR) AS effective_to, source.citation AS source_citation, source.worksheet_reference AS source_worksheet_reference FROM catalog_sku AS sku INNER JOIN catalog_source AS source ON source.id = sku.catalog_source_id AND source.catalog_version_id = sku.catalog_version_id WHERE sku.catalog_version_id = ? ORDER BY sku.governed_sku',
                $version,
            )),
            'alias_digest' => $this->digest($this->rows(
                $pdo,
                'SELECT sku.governed_sku, alias.normalized_alias FROM catalog_alias AS alias INNER JOIN catalog_sku AS sku ON sku.id = alias.catalog_sku_id AND sku.catalog_version_id = alias.catalog_version_id WHERE alias.catalog_version_id = ? ORDER BY sku.governed_sku, alias.normalized_alias',
                $version,
            )),
            'mapping_digest' => $this->digest($this->rows(
                $pdo,
                'SELECT source.governed_sku AS source_sku, target.governed_sku AS oracle_sku, mapping.rationale FROM catalog_mapping AS mapping INNER JOIN catalog_sku AS source ON source.id = mapping.source_catalog_sku_id AND source.catalog_version_id = mapping.catalog_version_id INNER JOIN catalog_sku AS target ON target.id = mapping.oracle_catalog_sku_id AND target.catalog_version_id = mapping.catalog_version_id WHERE mapping.catalog_version_id = ? ORDER BY source.governed_sku, target.governed_sku, mapping.rationale',
                $version,
            )),
        ];
    }

    /** @return list<array<string, string|null>> */
    private function rows(PDO $pdo, string $sql, string $version): array
    {
        $statement = $pdo->prepare($sql);
        $statement->execute([$version]);
        $rows = $statement->fetchAll(PDO::FETCH_ASSOC);

        /** @var list<array<string, string|null>> $rows */
        return $rows;
    }

    /** @param list<array<string, string|null>> $rows */
    private function digest(array $rows): string
    {
        return hash('sha256', json_encode($rows, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
    }
}
