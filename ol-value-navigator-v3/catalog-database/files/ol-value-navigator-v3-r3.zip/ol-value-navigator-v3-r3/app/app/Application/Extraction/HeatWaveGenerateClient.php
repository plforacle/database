<?php

declare(strict_types=1);

namespace App\Application\Extraction;

interface HeatWaveGenerateClient
{
    /** Returns the complete sys.ML_GENERATE JSON value; callers must not persist or log it. */
    public function generate(string $prompt, string $modelIdentifier): string;
}
