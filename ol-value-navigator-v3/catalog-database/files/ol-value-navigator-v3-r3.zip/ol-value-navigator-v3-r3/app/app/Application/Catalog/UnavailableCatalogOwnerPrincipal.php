<?php

declare(strict_types=1);

namespace App\Application\Catalog;

use App\Domain\Shared\Actor;
use App\Domain\Shared\DomainViolation;

final class UnavailableCatalogOwnerPrincipal implements CatalogOwnerPrincipal
{
    public function authenticatedActor(): Actor
    {
        throw DomainViolation::because('A trusted authenticated catalog-owner principal is unavailable.');
    }
}
