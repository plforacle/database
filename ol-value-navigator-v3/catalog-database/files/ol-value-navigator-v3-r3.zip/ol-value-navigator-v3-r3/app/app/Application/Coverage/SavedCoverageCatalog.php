<?php

declare(strict_types=1);

namespace App\Application\Coverage;

use App\Domain\Package\CatalogSnapshot;
use UnexpectedValueException;

/** Display records are intentionally narrower than admitted calculation records. */
final class SavedCoverageCatalog
{
    /** @param array<string,mixed> $saved
     * @return array{catalog:array<string,array<string,mixed>>,offerings:array<string,array<string,mixed>>,prices:array<string,array<string,mixed>>}
     */
    public static function fromRevision(array $saved, ?CatalogSnapshot $catalog): array
    {
        SavedResultContract::validate($saved);
        if ($catalog !== null) {
            if (SavedResultContract::selection($catalog->context()) !== SavedResultContract::selection($saved['catalogContext'])) {
                throw new UnexpectedValueException('Retained catalog and saved context disagree.');
            }
            return ['catalog' => $catalog->entries(), 'offerings' => $catalog->offerings(), 'prices' => $catalog->scenarioPrices()];
        }
        if (($saved['catalogContext'] ?? null) !== null) {
            throw new UnexpectedValueException('A package revision requires its retained catalog.');
        }
        $entries = $offerings = [];
        foreach ($saved['evaluation']['lines'] ?? [] as $line) {
            $id = $line['sku'] ?? '';
            if (is_string($id) && $id !== '') {
                $entries[$id] = ['description' => $line['description'] ?? $id, 'unit' => $line['unit'] ?? '', 'readiness' => 'Historical'];
            }
        }
        foreach ($saved['evaluation']['groups'] ?? [] as $group) {
            foreach (['offering', 'minimumOffering', 'minOffering', 'selectedOffering', 'additionalOffering'] as $key) {
                $id = $group[$key] ?? '';
                if (is_string($id) && $id !== '') {
                    $description = $key === 'offering' ? ($group['offeringDescription'] ?? $group['offeringMetadata']['description'] ?? $id) : $id;
                    $offerings[$id] ??= ['description' => $description];
                }
            }
        }
        // Also preserve literal input IDs absent from incomplete historical evaluations.
        foreach ($saved['input']['lines'] ?? [] as $line) {
            $id = $line['sku'] ?? '';
            if (is_string($id) && $id !== '') {
                $entries[$id] ??= ['description' => $id];
            }
        }
        foreach ($saved['input']['groups'] ?? [] as $group) {
            foreach (['offering', 'additionalOffering'] as $key) {
                $id = $group[$key] ?? '';
                if (is_string($id) && $id !== '') {
                    $offerings[$id] ??= ['description' => $id];
                }
            }
        }
        return ['catalog' => $entries, 'offerings' => $offerings, 'prices' => []];
    }
}
