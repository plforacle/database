<?php

declare(strict_types=1);

namespace App\Application\Matching;

use App\Domain\Catalog\CatalogRepository;
use App\Domain\Extraction\CandidateLine;
use App\Domain\Matching\EligibleOption;
use App\Domain\Matching\MatchResult;
use App\Domain\Shared\CatalogVersionId;

final readonly class MatchCandidates
{
    public function __construct(private CatalogRepository $catalog)
    {
    }

    public function match(CandidateLine $candidate, CatalogVersionId $catalog): MatchResult
    {
        $candidateSku = $candidate->sku();
        if ($candidateSku === null || $candidateSku === '') {
            return MatchResult::unresolved();
        }

        $facts = $this->catalog->findSku($catalog, $candidateSku);
        if ($facts === null || $facts['sku'] !== $candidateSku) {
            return MatchResult::unresolved();
        }

        $options = array_map(
            static fn (array $option): EligibleOption => new EligibleOption(
                $option['sku'],
                $option['description'],
                $option['unit'],
                $option['annualUsdPrice'],
                $option['rationale'],
            ),
            $this->catalog->eligibleOptions($catalog, $candidateSku),
        );

        return MatchResult::exact(
            $facts['sku'],
            $facts['description'],
            $facts['unit'],
            $facts['annualUsdPrice'],
            $options,
        );
    }
}
