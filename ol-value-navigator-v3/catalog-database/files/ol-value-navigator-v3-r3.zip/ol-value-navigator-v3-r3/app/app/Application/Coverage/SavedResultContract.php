<?php

declare(strict_types=1);

namespace App\Application\Coverage;

use App\Domain\Package\CatalogPackageContract;
use App\Domain\Package\CatalogSnapshot;
use UnexpectedValueException;

/** Dispatches saved evidence only; never resolves or recalculates current data. */
final class SavedResultContract
{
    /** @param array<string,mixed> $saved */
    public static function validate(array $saved): void
    {
        if (!is_array($saved['evaluation'] ?? null) || (isset($saved['input']) && !is_array($saved['input']))) {
            throw new UnexpectedValueException('Missing structured saved result.');
        }
        $inputSchema = $saved['input']['schemaVersion'] ?? 'legacy-coverage';
        $resultSchema = $saved['evaluation']['schemaVersion'] ?? 'legacy-coverage';
        $profile = match ($inputSchema) {
            'legacy-coverage' => 'legacy-coverage',
            '1.3.1' => 'scenario-1.3.1',
            default => throw new UnexpectedValueException('Unknown saved input contract.'),
        };
        if ($resultSchema !== $inputSchema || ($saved['ruleVersion'] ?? null) !== CatalogSnapshot::OLAM_RULE) {
            throw new UnexpectedValueException('Unsupported or mismatched saved result contract.');
        }
        $context = $saved['catalogContext'] ?? null;
        $marker = $saved['evaluation']['catalogContext'] ?? null;
        if ($context === null && $marker === null) {
            // Frozen pre-package shapes use the same engine-owned 20-node OLAM rule.
            if (array_key_exists('catalogContext', $saved['evaluation'])) {
                throw new UnexpectedValueException('Malformed saved result context.');
            }
            return;
        }
        if (!is_array($context) || !is_array($marker)) {
            throw new UnexpectedValueException('Missing saved result context.');
        }
        ksort($context);
        ksort($marker);
        $keys = ['format', 'channel', 'generation', 'releaseId', 'manifestSha256', 'mappingId', 'mappingSha256', 'priceId', 'priceSha256', 'profileId', 'inputSchema', 'resultSchema', 'ruleModel', 'olamRule', 'vmwareRule'];
        sort($keys);
        if (array_keys($context) !== $keys || $context !== $marker
            || ($context['format'] ?? null) !== 'catalog-snapshot-1'
            || ($context['profileId'] ?? null) !== $profile
            || ($context['olamRule'] ?? null) !== CatalogSnapshot::OLAM_RULE
            || ($context['vmwareRule'] ?? null) !== CatalogSnapshot::VMWARE_RULE
            || !is_int($context['generation']) || $context['generation'] < 0) {
            throw new UnexpectedValueException('Invalid saved catalog context.');
        }
        foreach (CatalogPackageContract::PROFILES[$profile] as $key => $value) {
            if ($context[$key] !== $value) {
                throw new UnexpectedValueException('Unknown saved calculation contract.');
            }
        }
        foreach (['channel', 'releaseId', 'mappingId', 'priceId'] as $key) {
            if (!is_string($context[$key]) || preg_match('/^[A-Za-z0-9][A-Za-z0-9._-]{0,99}$/D', $context[$key]) !== 1) {
                throw new UnexpectedValueException('Invalid saved catalog identity.');
            }
        }
        foreach (['manifestSha256', 'mappingSha256', 'priceSha256'] as $key) {
            if (!is_string($context[$key]) || preg_match('/^[0-9a-f]{64}$/D', $context[$key]) !== 1) {
                throw new UnexpectedValueException('Invalid saved catalog digest.');
            }
        }
        if (($saved['catalogVersion'] ?? null) !== $context['releaseId']) {
            throw new UnexpectedValueException('Saved release metadata disagrees with its contract.');
        }
        foreach (['mappingVersion' => 'mappingId', 'priceVersion' => 'priceId'] as $key => $identity) {
            if (($saved['evaluation'][$key] ?? null) !== $context[$identity]) {
                throw new UnexpectedValueException('Saved member metadata disagrees with its contract.');
            }
        }
        if ($profile === 'scenario-1.3.1') {
            foreach (['mapping' => 'mappingId', 'catalog' => 'releaseId', 'prices' => 'priceId', 'olam' => 'olamRule', 'vmware' => 'vmwareRule'] as $key => $identity) {
                if (($saved['evaluation']['versions'][$key] ?? null) !== $context[$identity]) {
                    throw new UnexpectedValueException('Saved scenario versions disagree with its contract.');
                }
            }
        }
    }

    /** Review hint only; this fingerprint never selects or authorizes a package.
     * @param array<string,mixed> $context
     */
    public static function selection(array $context): string
    {
        ksort($context);
        return hash('sha256', json_encode($context, JSON_THROW_ON_ERROR));
    }
}
