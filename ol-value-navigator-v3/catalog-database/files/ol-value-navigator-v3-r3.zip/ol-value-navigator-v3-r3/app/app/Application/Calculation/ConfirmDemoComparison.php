<?php

declare(strict_types=1);

namespace App\Application\Calculation;

use App\Domain\Analysis\AnalysisState;
use App\Domain\Analysis\AnalysisRepository;
use App\Domain\Analysis\ConfirmedLine;
use App\Domain\Analysis\LineDecision;
use App\Domain\Analysis\StateTransition;
use App\Domain\Audit\AuditAction;
use App\Domain\Audit\AuditRepository;
use App\Domain\Calculation\SubscriptionCalculator;
use App\Domain\Catalog\CatalogRepository;
use App\Domain\Shared\Actor;
use App\Domain\Shared\CatalogVersionId;
use App\Domain\Shared\DomainViolation;
use App\Domain\Shared\RequestId;
use App\Domain\Shared\ResourceNotFound;
use App\Domain\Shared\RevisionId;
use App\Infrastructure\Persistence\PdoTransaction;
use Brick\Math\BigDecimal;

final readonly class ConfirmDemoComparison
{
    /** @var list<string> */
    private const ASSUMPTIONS = [
        'Constant quantities and annual USD unit prices.',
        'Zero escalation, zero growth, no currency conversion, and no discounts.',
    ];

    private const SYNTHETIC_CATALOG_VERSION_ID = '00000000-0000-4000-8000-000000000901';

    public function __construct(
        private PdoTransaction $transaction,
        private AnalysisRepository $analyses,
        private AuditRepository $audit,
        private CatalogRepository $catalog,
        private SubscriptionCalculator $calculator,
        private DemoComparisonPresenter $presenter,
    ) {
    }

    public function execute(RevisionId $revision, Actor $actor, RequestId $requestId): DemoComparisonView
    {
        $this->assertRepresentative($actor);

        /** @var array{projection: array<string, mixed>|null, error: string|null} $attempt */
        $attempt = $this->transaction->run(function () use ($revision, $actor, $requestId): array {
            $snapshot = $this->analyses->lockConfirmationSnapshot($revision, $actor);
            if ($snapshot === null) {
                throw ResourceNotFound::because('The owned analysis revision was not found.');
            }
            if ($snapshot['state'] !== AnalysisState::READY_TO_CALCULATE) {
                $this->recordWithheld($revision, $actor, $requestId, $snapshot['state']);

                return ['projection' => null, 'error' => 'Comparative totals require a ready analysis revision.'];
            }

            try {
                $this->assertPermittedEvidence($snapshot);
                [$sourceLines, $optionLines, $includedLines, $excludedLines] = $this->confirmedLines($snapshot);
                $sourceTotals = $this->calculator->calculate($sourceLines);
                $optionTotals = $this->calculator->calculate($optionLines);
            } catch (DomainViolation $exception) {
                $this->recordWithheld($revision, $actor, $requestId, $snapshot['state']);

                return ['projection' => null, 'error' => $exception->getMessage()];
            }

            $storedTotals = $this->analyses->insertCalculationResult(
                $revision,
                $sourceTotals,
                $optionTotals,
                self::ASSUMPTIONS,
                $excludedLines,
            );
            StateTransition::assertAllowed(AnalysisState::READY_TO_CALCULATE, AnalysisState::CONFIRMED);
            $confirmed = $this->analyses->confirmRevision($revision, $actor);
            $this->audit->append(
                $revision,
                $actor,
                AuditAction::ANALYSIS_CONFIRMED,
                AnalysisState::READY_TO_CALCULATE,
                AnalysisState::CONFIRMED,
                $requestId,
            );
            $this->audit->append(
                $revision,
                $actor,
                AuditAction::CALCULATION_PRODUCED,
                AnalysisState::READY_TO_CALCULATE,
                AnalysisState::CONFIRMED,
                $requestId,
            );

            return [
                'projection' => [
                    ...$storedTotals,
                    'includedLines' => $includedLines,
                    'excludedLines' => $excludedLines,
                    'assumptions' => self::ASSUMPTIONS,
                    'catalogVersionId' => $snapshot['catalogVersionId'],
                    'confirmedBySubject' => $confirmed['confirmedBySubject'],
                    'confirmedAt' => $confirmed['confirmedAt'],
                    'extractionMode' => $snapshot['extractionMode'],
                    'modelIdentifier' => $snapshot['modelIdentifier'],
                    'extractionContractVersion' => $snapshot['extractionContractVersion'],
                    'promptTemplateVersion' => $snapshot['promptTemplateVersion'],
                    'responseDigest' => $snapshot['responseDigest'],
                ],
                'error' => null,
            ];
        });

        if ($attempt['projection'] === null) {
            throw DomainViolation::because($attempt['error'] ?? 'Comparative totals were withheld.');
        }

        return $this->presenter->present($attempt['projection']);
    }

    /**
     * @param array{state: AnalysisState, catalogVersionId: string, extractionMode: string|null, modelIdentifier: string|null, extractionContractVersion: string|null, promptTemplateVersion: string|null, responseDigest: string|null, lines: list<array{lineId: string, extractedIdentifier: string|null, matchState: string, decision: LineDecision, resolvedSku: string|null, resolvedDescription: string|null, quantity: string|null, annualUsdPrice: string|null, currency: string|null, annualTerm: string|null, unitBasis: string|null, exclusionReason: string|null, selectedOptionSku: string|null}>} $snapshot
     * @return array{list<ConfirmedLine>, list<ConfirmedLine>, list<array{lineId: string, decision: string, sourceSku: string, quantity: string, sourceAnnualUsdPrice: string, unitBasis: string, optionSku: string, optionAnnualUsdPrice: string}>, list<array{lineId: string, reason: string}>}
     */
    private function confirmedLines(array $snapshot): array
    {
        if ($snapshot['catalogVersionId'] !== self::SYNTHETIC_CATALOG_VERSION_ID) {
            throw DomainViolation::because('Demo confirmation requires the fixed synthetic catalog.');
        }

        $catalogVersionId = CatalogVersionId::fromString($snapshot['catalogVersionId']);
        $sourceLines = [];
        $optionLines = [];
        $includedLines = [];
        $excludedLines = [];

        foreach ($snapshot['lines'] as $line) {
            if ($line['decision'] === LineDecision::EXCLUDED) {
                $reason = $line['exclusionReason'];
                $characterCount = is_string($reason) ? preg_match_all('/./us', trim($reason), $matches) : false;
                if ($reason === null
                    || trim($reason) === ''
                    || strlen(trim($reason)) > 2000
                    || $characterCount === false
                    || $characterCount > 500
                ) {
                    throw DomainViolation::because('Every excluded line requires a reason.');
                }
                $excludedLines[] = ['lineId' => $line['lineId'], 'reason' => $reason];

                continue;
            }

            if (!in_array($line['decision'], [LineDecision::CONFIRMED, LineDecision::CORRECTED_CONFIRMED], true)
                || $line['matchState'] !== 'EXACT'
                || $line['resolvedSku'] === null
                || $line['resolvedDescription'] === null
                || $line['quantity'] === null
                || $line['annualUsdPrice'] === null
                || $line['currency'] === null
                || $line['annualTerm'] === null
                || $line['unitBasis'] === null
                || $line['selectedOptionSku'] === null
            ) {
                throw DomainViolation::because('Every included line requires complete confirmed governed facts.');
            }

            $source = $this->catalog->findSku($catalogVersionId, $line['resolvedSku']);
            $option = $this->selectedEligibleOption(
                $catalogVersionId,
                $line['resolvedSku'],
                $line['selectedOptionSku'],
            );
            if ($source === null
                || $source['annualUsdPrice'] === null
                || $source['description'] !== $line['resolvedDescription']
                || $source['unit'] !== $line['unitBasis']
                || !$this->sameDecimal($source['annualUsdPrice'], $line['annualUsdPrice'])
            ) {
                throw DomainViolation::because('Included source facts must match the pinned synthetic catalog.');
            }

            $sourceLines[] = ConfirmedLine::annualUsd(
                $line['resolvedSku'],
                $line['quantity'],
                $line['annualUsdPrice'],
                $line['currency'],
                $line['annualTerm'],
                trim($line['unitBasis']) !== '',
            );
            $optionLines[] = ConfirmedLine::annualUsd(
                $option['sku'],
                $line['quantity'],
                $option['annualUsdPrice'],
                unitBasisPresent: trim($option['unit']) !== '',
            );
            $includedLines[] = [
                'lineId' => $line['lineId'],
                'decision' => $line['decision']->name,
                'sourceSku' => $line['resolvedSku'],
                'quantity' => $line['quantity'],
                'sourceAnnualUsdPrice' => $line['annualUsdPrice'],
                'unitBasis' => $line['unitBasis'],
                'optionSku' => $option['sku'],
                'optionAnnualUsdPrice' => $option['annualUsdPrice'],
            ];
        }

        if ($sourceLines === [] || count($sourceLines) !== count($optionLines)) {
            throw DomainViolation::because('At least one complete included line is required.');
        }

        return [$sourceLines, $optionLines, $includedLines, $excludedLines];
    }

    /**
     * @param array{extractionMode: string|null, modelIdentifier: string|null, extractionContractVersion: string|null, promptTemplateVersion: string|null, responseDigest: string|null} $snapshot
     */
    private function assertPermittedEvidence(array $snapshot): void
    {
        $evidence = [
            $snapshot['modelIdentifier'],
            $snapshot['extractionContractVersion'],
            $snapshot['promptTemplateVersion'],
            $snapshot['responseDigest'],
        ];
        if ($snapshot['extractionMode'] === 'MANUAL' && array_filter($evidence, static fn (?string $value): bool => $value !== null) === []) {
            return;
        }
        if ($snapshot['extractionMode'] !== 'AI'
            || array_filter($evidence, static fn (?string $value): bool => $value === null || trim($value) === '') !== []
            || preg_match('/^[0-9a-f]{64}$/D', $snapshot['responseDigest'] ?? '') !== 1
        ) {
            throw DomainViolation::because('Extraction evidence must match the recorded extraction mode.');
        }
    }

    /** @return array{sku: string, description: string, unit: string, annualUsdPrice: string, rationale: string} */
    private function selectedEligibleOption(
        CatalogVersionId $catalogVersionId,
        string $sourceSku,
        string $selectedOptionSku,
    ): array {
        $selected = array_values(array_filter(
            $this->catalog->eligibleOptions($catalogVersionId, $sourceSku),
            static fn (array $option): bool => $option['sku'] === $selectedOptionSku,
        ));
        if (count($selected) !== 1) {
            throw DomainViolation::because('Every included line requires one explicitly selected eligible option.');
        }

        return $selected[0];
    }

    private function sameDecimal(string $expected, string $actual): bool
    {
        if (preg_match('/^-?\d+(?:\.\d+)?$/D', $expected) !== 1
            || preg_match('/^-?\d+(?:\.\d+)?$/D', $actual) !== 1
        ) {
            return false;
        }

        return BigDecimal::of($expected)->compareTo(BigDecimal::of($actual)) === 0;
    }

    private function recordWithheld(
        RevisionId $revision,
        Actor $actor,
        RequestId $requestId,
        AnalysisState $state,
    ): void {
        $this->audit->append(
            $revision,
            $actor,
            AuditAction::CALCULATION_WITHHELD,
            $state,
            $state,
            $requestId,
        );
    }

    private function assertRepresentative(Actor $actor): void
    {
        if (!$actor->canConfirmAnalysis()) {
            throw DomainViolation::because('Confirmation requires the representative capability.');
        }
    }
}
