<?php

declare(strict_types=1);

namespace App\Application\Analysis;

use App\Domain\Analysis\AnalysisRepository;
use App\Domain\Audit\AuditAction;
use App\Domain\Audit\AuditRepository;
use App\Domain\Analysis\AnalysisState;
use App\Domain\Shared\Actor;
use App\Domain\Shared\AnalysisId;
use App\Domain\Shared\CatalogVersionId;
use App\Domain\Shared\DomainViolation;
use App\Domain\Shared\RedactedSourceText;
use App\Domain\Shared\RequestId;
use App\Domain\Shared\RevisionId;
use App\Infrastructure\Persistence\PdoTransaction;

final readonly class CreateDemoAnalysis
{
    public function __construct(
        private PdoTransaction $transaction,
        private AnalysisRepository $analyses,
        private AuditRepository $audit,
    ) {
    }

    public function execute(
        Actor $actor,
        RedactedSourceText $source,
        CatalogVersionId $catalog,
        RequestId $requestId,
    ): AnalysisId {
        if (!$actor->canConfirmAnalysis()) {
            throw DomainViolation::because('Analysis creation requires the representative capability.');
        }

        $analysisId = AnalysisId::new();
        $revisionId = RevisionId::new();

        $this->transaction->run(function () use ($analysisId, $revisionId, $actor, $source, $catalog, $requestId): void {
            $this->analyses->createDraft($analysisId, $revisionId, $actor, $source, $catalog);
            $this->audit->append(
                $revisionId,
                $actor,
                AuditAction::ANALYSIS_CREATED,
                null,
                AnalysisState::DRAFT,
                $requestId,
            );
        });

        return $analysisId;
    }
}
