<?php

declare(strict_types=1);

namespace App\Application\Presentation;

use App\Infrastructure\Presentation\PptxWriter;

/** Coordinates prepared content and the OOXML output adapter. */
final class PresentationExporter
{
    /** @param array<string,mixed> $snapshot */
    public function export(array $snapshot, int $slideCount = 4): string
    {
        $document = (new PresentationComposer())->compose($snapshot, $slideCount);
        return (new PptxWriter())->write($document);
    }
}
