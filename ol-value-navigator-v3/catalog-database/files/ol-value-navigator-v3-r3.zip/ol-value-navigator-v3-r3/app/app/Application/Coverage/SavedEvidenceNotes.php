<?php

declare(strict_types=1);

namespace App\Application\Coverage;

use UnexpectedValueException;

/** @internal Lossless, bounded representation of saved facts, never recalculation. */
final class SavedEvidenceNotes
{
    // 4 MiB input + two 8 MiB package members, plus structural/derived headroom.
    private const MAX_BYTES = 32 * 1024 * 1024;
    // Covers two input trees plus derived results, even for densely packed counts.
    private const MAX_NODES = 5000000;
    private const MAX_DEPTH = 64;
    private const MAX_STRING_BYTES = 4 * 1024 * 1024;
    private const INTERN_BYTES = 256;
    private const JSON_FLAGS = JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRESERVE_ZERO_FRACTION | JSON_THROW_ON_ERROR;

    private int $bytes = 0;
    private int $nodes = 0;
    /** @var array<string,string> */
    private array $savedText = [];
    /** @var array<string,string> */
    private array $textIds = [];
    /** @var list<array{path:list<int|string>,textId:string}> */
    private array $references = [];

    /** All values/keys remain exact; path references disambiguate literal marker text.
     * @param array<string,mixed> $records
     */
    public static function encode(array $records): string
    {
        $encoder = new self();
        $projected = $encoder->value($records, []);
        $json = self::json([
            'format' => 'saved-evidence-notes-1',
            'instructions' => 'Each textReferences path identifies an exact string replaced in records. Replace that value with savedText[textId] to recover the original facts. Unreferenced values are unchanged.',
            'records' => $projected, 'textReferences' => $encoder->references, 'savedText' => $encoder->savedText,
        ]);
        if (strlen($json) > self::MAX_BYTES) {
            throw new UnexpectedValueException('Saved evidence exceeds the bounded notes limit.');
        }
        return $json;
    }

    /** @param list<int|string> $path */
    private function value(mixed $value, array $path): mixed
    {
        if (++$this->nodes > self::MAX_NODES || count($path) > self::MAX_DEPTH) {
            throw new UnexpectedValueException('Saved evidence exceeds the bounded traversal limit.');
        }
        $this->reserve(2);
        if (is_array($value)) {
            $result = [];
            foreach ($value as $key => $child) {
                if (is_string($key)) {
                    self::text($key);
                }
                $this->reserve(strlen(self::json($key)) + 2);
                $result[$key] = $this->value($child, [...$path, $key]);
            }
            return $result;
        }
        if (is_string($value)) {
            self::text($value);
            if (strlen($value) >= self::INTERN_BYTES) {
                $hash = hash('sha256', $value);
                $id = $this->textIds[$hash] ?? null;
                if ($id === null) {
                    $id = 'T' . (count($this->savedText) + 1);
                    $this->reserve(strlen(self::json($value)) + strlen($id) + 4);
                    $this->savedText[$id] = $value;
                    $this->textIds[$hash] = $id;
                } elseif ($this->savedText[$id] !== $value) {
                    throw new UnexpectedValueException('Saved text identity collision.');
                }
                $reference = ['path' => $path, 'textId' => $id];
                $this->reserve(strlen(self::json($reference)));
                $this->references[] = $reference;
                $value = '[Saved text ' . $id . ']';
            }
        } elseif ($value !== null && !is_bool($value) && !is_int($value) && !(is_float($value) && is_finite($value))) {
            throw new UnexpectedValueException('Invalid saved evidence value.');
        }
        $this->reserve(strlen(self::json($value)));
        return $value;
    }

    private function reserve(int $bytes): void
    {
        $this->bytes += $bytes;
        if ($this->bytes > self::MAX_BYTES) {
            throw new UnexpectedValueException('Saved evidence exceeds the bounded notes limit.');
        }
    }

    private static function text(string $value): void
    {
        if (strlen($value) > self::MAX_STRING_BYTES || !mb_check_encoding($value, 'UTF-8')
            || preg_match('/[\x00-\x08\x0b\x0c\x0e-\x1f\x{FFFE}\x{FFFF}]/u', $value)) {
            throw new UnexpectedValueException('Invalid or oversized saved evidence text.');
        }
    }

    private static function json(mixed $value): string
    {
        try {
            return json_encode($value, self::JSON_FLAGS, self::MAX_DEPTH + 8);
        } catch (\JsonException $error) {
            throw new UnexpectedValueException('Invalid saved evidence encoding.', 0, $error);
        }
    }
}
