<?php

declare(strict_types=1);

namespace App\Application\Review;

use App\Domain\Analysis\AnalysisRepository;
use App\Domain\Analysis\AnalysisState;
use App\Domain\Analysis\ConfirmedLine;
use App\Domain\Analysis\LineDecision;
use App\Domain\Analysis\StateTransition;
use App\Domain\Calculation\SubscriptionCalculator;
use App\Domain\Catalog\CatalogRepository;
use App\Domain\Shared\CatalogVersionId;
use App\Domain\Shared\DomainViolation;
use App\Domain\Shared\ResourceNotFound;
use App\Domain\Shared\RevisionId;
use App\Infrastructure\Persistence\PdoTransaction;
use Brick\Math\BigDecimal;

final readonly class EvaluateReadiness
{
    public function __construct(
        private PdoTransaction $transaction,
        private AnalysisRepository $analyses,
        private CatalogRepository $catalog,
    ) {
    }

    public function forRevision(RevisionId $revision): AnalysisState
    {
        return $this->transaction->run(function () use ($revision): AnalysisState {
            $snapshot = $this->analyses->lockReadinessSnapshot($revision);
            if ($snapshot === null) {
                throw ResourceNotFound::because('The analysis revision was not found.');
            }
            if (!in_array(
                $snapshot['state'],
                [AnalysisState::NEEDS_REVIEW, AnalysisState::INCOMPLETE, AnalysisState::READY_TO_CALCULATE],
                true,
            )) {
                throw DomainViolation::because('Readiness requires a reviewable analysis revision.');
            }

            $target = $this->isComplete($snapshot)
                ? AnalysisState::READY_TO_CALCULATE
                : AnalysisState::INCOMPLETE;
            if ($snapshot['state'] !== $target) {
                StateTransition::assertAllowed($snapshot['state'], $target);
                $this->analyses->updateRevisionState($revision, $snapshot['state'], $target);
            }

            return $target;
        });
    }

    /**
     * @param array{state: AnalysisState, catalogVersionId: string, lines: list<array{lineId: string, matchState: string, decision: LineDecision, resolvedSku: string|null, resolvedDescription: string|null, quantity: string|null, annualUsdPrice: string|null, currency: string|null, annualTerm: string|null, unitBasis: string|null, exclusionReason: string|null, selectedOptionSku: string|null}>} $snapshot
     */
    private function isComplete(array $snapshot): bool
    {
        if ($snapshot['lines'] === []) {
            return false;
        }

        $catalogVersionId = CatalogVersionId::fromString($snapshot['catalogVersionId']);
        $includedLineCount = 0;
        foreach ($snapshot['lines'] as $line) {
            if ($line['decision'] === LineDecision::EXCLUDED) {
                if (!$this->hasValidExclusionReason($line['exclusionReason'])) {
                    return false;
                }

                continue;
            }

            ++$includedLineCount;
            if (!$this->isCompleteIncludedLine($catalogVersionId, $line)) {
                return false;
            }
        }

        return $includedLineCount > 0;
    }

    /**
     * @param array{lineId: string, matchState: string, decision: LineDecision, resolvedSku: string|null, resolvedDescription: string|null, quantity: string|null, annualUsdPrice: string|null, currency: string|null, annualTerm: string|null, unitBasis: string|null, exclusionReason: string|null, selectedOptionSku: string|null} $line
     */
    private function isCompleteIncludedLine(CatalogVersionId $catalogVersionId, array $line): bool
    {
        if (!in_array($line['decision'], [LineDecision::CONFIRMED, LineDecision::CORRECTED_CONFIRMED], true)
            || $line['matchState'] !== 'EXACT'
            || $line['resolvedSku'] === null
            || $line['resolvedDescription'] === null
            || trim($line['resolvedDescription']) === ''
            || $line['quantity'] === null
            || $line['annualUsdPrice'] === null
            || $line['currency'] !== 'USD'
            || $line['annualTerm'] !== 'ANNUAL'
            || $line['unitBasis'] === null
            || trim($line['unitBasis']) === ''
            || $line['selectedOptionSku'] === null
        ) {
            return false;
        }

        $source = $this->catalog->findSku($catalogVersionId, $line['resolvedSku']);
        if ($source === null
            || $source['annualUsdPrice'] === null
            || trim($source['description']) === ''
            || $source['description'] !== $line['resolvedDescription']
            || $source['unit'] !== $line['unitBasis']
            || !$this->sameDecimal($source['annualUsdPrice'], $line['annualUsdPrice'])
        ) {
            return false;
        }

        $selected = null;
        foreach ($this->catalog->eligibleOptions($catalogVersionId, $line['resolvedSku']) as $option) {
            if ($option['sku'] === $line['selectedOptionSku']) {
                $selected = $option;
                break;
            }
        }
        if ($selected === null
            || trim($selected['description']) === ''
            || trim($selected['unit']) === ''
            || trim($selected['annualUsdPrice']) === ''
        ) {
            return false;
        }

        try {
            $calculator = new SubscriptionCalculator();
            $calculator->calculate([ConfirmedLine::annualUsd(
                $line['resolvedSku'],
                $line['quantity'],
                $line['annualUsdPrice'],
                $line['currency'],
                $line['annualTerm'],
                true,
            )]);
            $calculator->calculate([ConfirmedLine::annualUsd(
                $selected['sku'],
                $line['quantity'],
                $selected['annualUsdPrice'],
                unitBasisPresent: trim($selected['unit']) !== '',
            )]);
        } catch (DomainViolation) {
            return false;
        }

        return true;
    }

    private function sameDecimal(string $expected, string $actual): bool
    {
        if (preg_match('/^-?\d+(?:\.\d+)?$/D', $expected) !== 1
            || preg_match('/^-?\d+(?:\.\d+)?$/D', $actual) !== 1
        ) {
            return false;
        }

        return BigDecimal::of($expected)->compareTo(BigDecimal::of($actual)) === 0;
    }

    private function hasValidExclusionReason(?string $reason): bool
    {
        if ($reason === null || trim($reason) === '' || strlen(trim($reason)) > 2000) {
            return false;
        }

        $count = preg_match_all('/./us', trim($reason), $matches);

        return $count !== false && $count <= 500;
    }
}
