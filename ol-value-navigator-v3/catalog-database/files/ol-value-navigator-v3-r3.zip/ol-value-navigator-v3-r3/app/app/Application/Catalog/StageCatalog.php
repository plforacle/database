<?php

declare(strict_types=1);

namespace App\Application\Catalog;

use App\Domain\Shared\Actor;
use App\Domain\Shared\CatalogVersionId;
use App\Domain\Shared\DomainViolation;
use App\Infrastructure\Catalog\CatalogWorkbookReader;
use App\Infrastructure\Persistence\PdoTransaction;
use PDO;
use Ramsey\Uuid\Uuid;

final readonly class StageCatalog
{
    /** @param array<string, mixed> $manifest */
    public function __construct(
        private PDO $pdo,
        private CatalogWorkbookReader $reader,
        private ReconcileCatalog $reconciler,
        private array $manifest,
        private CatalogContentDigester $contentDigester,
    ) {
    }

    public function execute(string $path, string $expectedSha256, Actor $actor): CatalogVersionId
    {
        if (!$actor->canImportCatalog()) {
            throw DomainViolation::because('Catalog staging requires the catalog-importer capability.');
        }
        if (preg_match('/^[0-9a-f]{64}$/', $expectedSha256) !== 1) {
            throw DomainViolation::because('Approved workbook SHA-256 must be 64 lowercase hexadecimal characters.');
        }
        if (!is_file($path) || !is_readable($path)) {
            throw DomainViolation::because('Approved workbook is not readable.');
        }
        $actualSha256 = hash_file('sha256', $path);
        if (!is_string($actualSha256) || !hash_equals($expectedSha256, $actualSha256)) {
            throw DomainViolation::because('Workbook SHA-256 does not match the approved baseline.');
        }

        $catalog = $this->reader->read($path, $this->manifest);
        $report = $this->reconciler->execute($catalog);
        if (($report['status'] ?? null) !== 'PASS') {
            throw DomainViolation::because('Catalog reconciliation did not pass.');
        }
        $finalSha256 = hash_file('sha256', $path);
        if (!is_string($finalSha256)
            || !hash_equals($actualSha256, $finalSha256)
            || !hash_equals($expectedSha256, $finalSha256)
        ) {
            throw DomainViolation::because('Workbook changed while it was being parsed and reconciled.');
        }
        $encodedReport = json_encode($report, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
        $catalogVersionId = CatalogVersionId::fromString(Uuid::uuid4()->toString());

        return (new PdoTransaction($this->pdo))->run(function (PDO $pdo) use ($path, $actualSha256, $catalog, $encodedReport, $catalogVersionId): CatalogVersionId {
            $this->insertVersion($pdo, $path, $actualSha256, $catalog, $catalogVersionId);
            $sourceIds = $this->insertSources($pdo, $catalog, $catalogVersionId);
            [$skuIds, $oracleIdsByTier] = $this->insertSkus($pdo, $catalog, $catalogVersionId, $sourceIds);
            $this->insertMappings($pdo, $catalog, $catalogVersionId, $skuIds, $oracleIdsByTier);
            $digests = $this->contentDigester->forVersion($pdo, $catalogVersionId);
            $this->recordReconciliation($pdo, $catalogVersionId, $actualSha256, $digests, $encodedReport);

            return $catalogVersionId;
        });
    }

    /** @param array<string, mixed> $catalog */
    private function insertVersion(PDO $pdo, string $path, string $sha256, array $catalog, CatalogVersionId $id): void
    {
        $workbookVersion = $this->cellValue($catalog, 'Controls!B23');
        $effectiveOn = $this->catalogEffectiveDate($catalog);
        $statement = $pdo->prepare(
            'INSERT INTO catalog_version (id, version, status, source_filename, source_sha256, effective_on) VALUES (?, ?, ?, ?, ?, ?)',
        );
        $statement->execute([
            (string) $id,
            $workbookVersion . '-' . substr($sha256, 0, 12),
            'DRAFT',
            basename($path),
            $sha256,
            $effectiveOn,
        ]);
    }

    /**
     * @param array<string, mixed> $catalog
     * @return array<string, string>
     */
    private function insertSources(PDO $pdo, array $catalog, CatalogVersionId $catalogVersionId): array
    {
        $sourceIds = [];
        $statement = $pdo->prepare(
            'INSERT INTO catalog_source (id, catalog_version_id, citation, worksheet_reference, approved_by, approved_at) VALUES (?, ?, ?, ?, ?, ?)',
        );
        foreach ($this->table($catalog, 'sources') as $source) {
            $sourceKey = $this->required($source, 'source_id');
            $id = Uuid::uuid5((string) $catalogVersionId, 'source:' . $sourceKey)->toString();
            $citation = json_encode($source, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
            $statement->execute([
                $id,
                (string) $catalogVersionId,
                $citation,
                sprintf('Sources & Versions!A%s:J%s', $source['_worksheet_row'], $source['_worksheet_row']),
                null,
                null,
            ]);
            $sourceIds[$sourceKey] = $id;
        }

        return $sourceIds;
    }

    /**
     * @param array<string, mixed> $catalog
     * @param array<string, string> $sourceIds
     * @return array{array<string, string>, array<string, string>}
     */
    private function insertSkus(PDO $pdo, array $catalog, CatalogVersionId $catalogVersionId, array $sourceIds): array
    {
        $statement = $pdo->prepare(
            'INSERT INTO catalog_sku (id, catalog_version_id, governed_sku, description, unit, annual_usd_price, effective_from, catalog_source_id) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
        );
        $skuIds = [];
        $oracleIdsByTier = [];
        $rhEffectiveOn = $this->rhEffectiveDate($catalog);
        $rhSourceId = $sourceIds[$this->provenanceSourceId('rh_catalog')] ?? null;
        if (!is_string($rhSourceId)) {
            throw DomainViolation::because('RH catalog provenance does not resolve to a governed source.');
        }
        foreach ($this->table($catalog, 'rh_catalog') as $row) {
            $sku = $this->required($row, 'sku');
            $id = Uuid::uuid5((string) $catalogVersionId, 'sku:' . $sku)->toString();
            $statement->execute([
                $id,
                (string) $catalogVersionId,
                $sku,
                $this->required($row, 'product'),
                $this->required($row, 'pricing_metric'),
                $row['scenario_price'] ?? null,
                $rhEffectiveOn,
                $rhSourceId,
            ]);
            $skuIds[$sku] = $id;
        }
        $olSourceId = $sourceIds[$this->provenanceSourceId('ol_catalog')] ?? null;
        if (!is_string($olSourceId)) {
            throw DomainViolation::because('Oracle catalog provenance does not resolve to a governed source.');
        }
        foreach ($this->table($catalog, 'ol_catalog') as $row) {
            $sku = $this->required($row, 'offering_id');
            $tier = $this->required($row, 'oracle_offering');
            $id = Uuid::uuid5((string) $catalogVersionId, 'sku:' . $sku)->toString();
            $statement->execute([
                $id,
                (string) $catalogVersionId,
                $sku,
                $this->required($row, 'description'),
                $this->required($row, 'metric'),
                $this->required($row, 'annual_price'),
                $this->required($row, 'effective_date'),
                $olSourceId,
            ]);
            $skuIds[$sku] = $id;
            $oracleIdsByTier[$tier] = $id;
        }

        return [$skuIds, $oracleIdsByTier];
    }

    /**
     * @param array{source_digest: string, sku_digest: string, alias_digest: string, mapping_digest: string} $digests
     */
    private function recordReconciliation(
        PDO $pdo,
        CatalogVersionId $id,
        string $sha256,
        array $digests,
        string $report,
    ): void {
        $statement = $pdo->prepare('CALL record_catalog_reconciliation(?, ?, ?, ?, ?, ?, ?, ?)');
        $statement->execute([
            Uuid::uuid4()->toString(),
            (string) $id,
            $sha256,
            $digests['source_digest'],
            $digests['sku_digest'],
            $digests['alias_digest'],
            $digests['mapping_digest'],
            $report,
        ]);
        $statement->closeCursor();
    }

    /**
     * @param array<string, mixed> $catalog
     * @param array<string, string> $skuIds
     * @param array<string, string> $oracleIdsByTier
     */
    private function insertMappings(PDO $pdo, array $catalog, CatalogVersionId $catalogVersionId, array $skuIds, array $oracleIdsByTier): void
    {
        $statement = $pdo->prepare(
            'INSERT INTO catalog_mapping (id, catalog_version_id, source_catalog_sku_id, oracle_catalog_sku_id, rationale) VALUES (?, ?, ?, ?, ?)',
        );
        foreach ($this->table($catalog, 'mapping') as $row) {
            if (($row['mapping_status'] ?? null) !== 'APPROVED') {
                continue;
            }
            $sku = $this->required($row, 'rh_sku');
            $sourceSkuId = $skuIds[$sku] ?? null;
            if (!is_string($sourceSkuId)) {
                throw DomainViolation::because('Approved mapping source SKU is not staged.');
            }
            foreach ($this->tiers($this->required($row, 'allowed_oracle_tiers')) as $tier) {
                $oracleSkuId = $oracleIdsByTier[$tier] ?? null;
                if (!is_string($oracleSkuId)) {
                    throw DomainViolation::because('Approved mapping Oracle tier is not staged.');
                }
                $id = Uuid::uuid5((string) $catalogVersionId, 'mapping:' . $sku . ':' . $tier)->toString();
                $statement->execute([
                    $id,
                    (string) $catalogVersionId,
                    $sourceSkuId,
                    $oracleSkuId,
                    $this->required($row, 'notes'),
                ]);
            }
        }
    }

    /** @param array<string, mixed> $catalog */
    private function cellValue(array $catalog, string $reference): string
    {
        $cell = $catalog['cells'][$reference] ?? null;
        if (!is_array($cell) || !is_string($cell['value'] ?? null) || trim($cell['value']) === '') {
            throw DomainViolation::because(sprintf('Required workbook control %s is missing.', $reference));
        }

        return $cell['value'];
    }

    /** @param array<string, mixed> $catalog */
    private function catalogEffectiveDate(array $catalog): string
    {
        $olRows = $this->table($catalog, 'ol_catalog');
        $dates = array_map(fn (array $row): string => $this->required($row, 'effective_date'), $olRows);
        sort($dates, SORT_STRING);

        return $dates[0] ?? throw DomainViolation::because('Oracle catalog effective date is missing.');
    }

    /** @param array<string, mixed> $catalog */
    private function rhEffectiveDate(array $catalog): string
    {
        $version = $this->cellValue($catalog, 'Controls!B24');
        if (preg_match('/^(\d{4}-\d{2}-\d{2})-/', $version, $matches) !== 1) {
            throw DomainViolation::because('RH catalog version does not contain its governed effective date.');
        }

        return $matches[1];
    }

    /**
     * @param array<string, mixed> $catalog
     * @return list<array<string, string|null>>
     */
    private function table(array $catalog, string $name): array
    {
        $rows = $catalog['tables'][$name] ?? null;
        if (!is_array($rows)) {
            throw DomainViolation::because(sprintf('Required workbook table "%s" is missing.', $name));
        }

        /** @var list<array<string, string|null>> $rows */
        return $rows;
    }

    /** @param array<string, string|null> $row */
    private function required(array $row, string $field): string
    {
        $value = $row[$field] ?? null;
        if (!is_string($value) || trim($value) === '') {
            throw DomainViolation::because(sprintf('Required catalog field "%s" is missing.', $field));
        }

        return $value;
    }

    /** @return list<string> */
    private function tiers(string $value): array
    {
        $aliases = [
            'Basic' => 'Oracle Linux Basic',
            'Premier' => 'Oracle Linux Premier',
            'Premier Plus' => 'Oracle Linux Premier Plus',
        ];

        return array_map(
            static fn (string $tier): string => $aliases[trim($tier)] ?? trim($tier),
            explode('|', $value),
        );
    }

    private function provenanceSourceId(string $table): string
    {
        $definition = $this->manifest['provenance'][$table] ?? null;
        if (!is_array($definition)) {
            throw DomainViolation::because(sprintf('Catalog provenance manifest for %s is missing.', $table));
        }
        $sourceId = $definition['source_id'] ?? null;
        if (!is_string($sourceId) || trim($sourceId) === '') {
            throw DomainViolation::because(sprintf('Catalog provenance source for %s is missing.', $table));
        }

        return $sourceId;
    }
}
