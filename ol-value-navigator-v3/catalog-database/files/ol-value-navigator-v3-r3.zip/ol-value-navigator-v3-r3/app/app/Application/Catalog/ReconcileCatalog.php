<?php

declare(strict_types=1);

namespace App\Application\Catalog;

use App\Domain\Shared\DomainViolation;
use Brick\Math\BigDecimal;
use Brick\Math\RoundingMode;

final readonly class ReconcileCatalog
{
    /** @param array<string, mixed> $manifest */
    public function __construct(private array $manifest)
    {
    }

    /**
     * @param array<string, mixed> $catalog
     * @return array<string, mixed>
     */
    public function execute(array $catalog): array
    {
        $tables = $catalog['tables'] ?? null;
        if (!is_array($tables)) {
            throw DomainViolation::because('Workbook catalog tables are missing.');
        }

        $rhRows = $this->rows($tables, 'rh_catalog');
        $olRows = $this->rows($tables, 'ol_catalog');
        $mappingRows = $this->rows($tables, 'mapping');
        $sourceRows = $this->rows($tables, 'sources');
        $checkRows = $this->rows($tables, 'checks');
        $this->assertRowCounts([
            'rh_catalog' => count($rhRows),
            'ol_catalog' => count($olRows),
            'mapping' => count($mappingRows),
            'sources' => count($sourceRows),
            'checks' => count($checkRows),
        ]);
        $this->assertControls($catalog['cells'] ?? []);

        $rhBySku = $this->indexUnique($rhRows, 'sku', 'RH catalog SKUs must be unique.');
        $olById = $this->indexUnique($olRows, 'offering_id', 'Oracle catalog offering IDs must be unique.');
        $sourceById = $this->indexUnique($sourceRows, 'source_id', 'Catalog source IDs must be unique.');
        $mappingBySku = $this->indexUnique($mappingRows, 'rh_sku', 'SKU mapping rows must be unique by RH SKU.');

        $this->assertSources($sourceRows);
        $this->assertRhRows($rhRows);
        $olByTier = $this->assertOracleRows($olRows);
        $this->assertProvenance($sourceById, ['rh_catalog' => $rhRows, 'ol_catalog' => $olRows]);
        $approvedRelationships = $this->assertMappings($mappingRows, $rhBySku, $olByTier);
        $this->assertChecks($checkRows);

        if (array_keys($rhBySku) !== array_keys($mappingBySku)) {
            throw DomainViolation::because('Every RH catalog row must have exactly one governed mapping row.');
        }
        if ($olById === [] || $sourceById === []) {
            throw DomainViolation::because('Oracle offerings and catalog sources are required.');
        }

        $digests = [];
        foreach (['rh_catalog' => $rhRows, 'ol_catalog' => $olRows, 'mapping' => $mappingRows, 'sources' => $sourceRows, 'checks' => $checkRows] as $name => $rows) {
            $digests[$name] = hash('sha256', json_encode($rows, JSON_THROW_ON_ERROR | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE));
        }
        foreach ($this->manifest['expected']['digests'] ?? [] as $name => $expectedDigest) {
            if (($digests[$name] ?? null) !== $expectedDigest) {
                throw DomainViolation::because(sprintf('Workbook %s digest does not match the approved catalog baseline.', $name));
            }
        }

        $scenarios = [];
        foreach ($this->manifest['scenarios'] ?? [] as $scenario) {
            if (!is_array($scenario)) {
                throw DomainViolation::because('Semantic scenario manifest is invalid.');
            }
            $name = $this->requiredString($scenario, 'name', 'Semantic scenario name is required.');
            $scenarios[$name] = $this->scenario($scenario, $rhBySku, $mappingBySku, $olByTier);
        }

        return [
            'status' => 'PASS',
            'counts' => [
                'rh_catalog_rows' => count($rhRows),
                'ol_catalog_rows' => count($olRows),
                'mapping_rows' => count($mappingRows),
                'source_rows' => count($sourceRows),
                'check_rows' => count($checkRows),
                'approved_relationships' => $approvedRelationships,
            ],
            'digests' => $digests,
            'scenarios' => $scenarios,
            'target_excel_cached_results' => 'UNVERIFIED',
        ];
    }

    /**
     * @param array<string, mixed> $tables
     * @return list<array<string, string|null>>
     */
    private function rows(array $tables, string $name): array
    {
        $rows = $tables[$name] ?? null;
        if (!is_array($rows)) {
            throw DomainViolation::because(sprintf('Workbook table "%s" is missing.', $name));
        }
        foreach ($rows as $row) {
            if (!is_array($row)) {
                throw DomainViolation::because(sprintf('Workbook table "%s" contains an invalid row.', $name));
            }
        }

        /** @var list<array<string, string|null>> $rows */
        return $rows;
    }

    /** @param array<string, int> $actual */
    private function assertRowCounts(array $actual): void
    {
        foreach ($this->manifest['expected']['row_counts'] ?? [] as $name => $expected) {
            if (($actual[$name] ?? null) !== $expected) {
                throw DomainViolation::because(sprintf('Workbook %s row count does not match the approved baseline.', $name));
            }
        }
    }

    private function assertControls(mixed $cells): void
    {
        if (!is_array($cells)) {
            throw DomainViolation::because('Workbook control cells are missing.');
        }
        foreach ($this->manifest['controls']['values'] ?? [] as $reference => $expected) {
            $cell = $cells[$reference] ?? null;
            if (!is_array($cell) || ($cell['formula'] ?? null) !== null || ($cell['value'] ?? null) !== $expected) {
                throw DomainViolation::because(sprintf('Workbook control %s does not match the approved baseline.', $reference));
            }
        }
        foreach ($this->manifest['controls']['formulas'] ?? [] as $reference => $expected) {
            $cell = $cells[$reference] ?? null;
            if (!is_array($cell) || ($cell['formula'] ?? null) !== $expected) {
                throw DomainViolation::because(sprintf('Workbook control relationship %s does not match the approved baseline.', $reference));
            }
        }
    }

    /**
     * @param list<array<string, string|null>> $rows
     * @return array<string, array<string, string|null>>
     */
    private function indexUnique(array $rows, string $field, string $message): array
    {
        $indexed = [];
        foreach ($rows as $row) {
            $value = $this->requiredString($row, $field, $message);
            if (isset($indexed[$value])) {
                throw DomainViolation::because($message);
            }
            $indexed[$value] = $row;
        }

        return $indexed;
    }

    /** @param list<array<string, string|null>> $rows */
    private function assertSources(array $rows): void
    {
        $allowedTypes = $this->allowed('source_types');
        foreach ($rows as $row) {
            $this->assertAllowed($this->requiredString($row, 'source_type', 'Catalog source type is required.'), $allowedTypes, 'Catalog source type is not allowed.');
            $this->requiredString($row, 'url_or_path', 'Catalog source URL or path is required.');
            $this->requiredString($row, 'verified', 'Catalog source verification date is required.');
            $this->requiredString($row, 'owner', 'Catalog source owner is required.');
        }
    }

    /** @param list<array<string, string|null>> $rows */
    private function assertRhRows(array $rows): void
    {
        $allowedTreatments = $this->allowed('rh_treatments');
        $allowedReadiness = $this->allowed('price_readiness');
        foreach ($rows as $row) {
            $this->requiredString($row, 'product', 'RH catalog product is required.');
            $this->requiredString($row, 'pricing_metric', 'RH catalog pricing metric is required.');
            $this->requiredString($row, 'source_url', 'RH catalog row source URL is required.');
            if (($row['currency'] ?? null) !== 'USD' || ($row['term'] ?? null) !== '1 Year' && ($row['term'] ?? null) !== '1 Year extension' && ($row['term'] ?? null) !== '1 Year - unverified') {
                throw DomainViolation::because('RH catalog rows must retain their governed annual USD basis.');
            }
            $readiness = $this->requiredString($row, 'price_readiness', 'RH price readiness is required.');
            $this->assertAllowed($readiness, $allowedReadiness, 'RH price readiness is not allowed.');
            $this->assertAllowed($this->requiredString($row, 'v1_treatment', 'RH treatment is required.'), $allowedTreatments, 'RH treatment is not allowed.');
            if (($row['scenario_price'] ?? null) === null && !in_array($readiness, ['MISSING CURRENT PRICE', 'MISSING VERIFIED PRICE'], true)) {
                throw DomainViolation::because('A missing RH scenario price must retain an explicit missing-price status.');
            }
        }
    }

    /**
     * @param list<array<string, string|null>> $rows
     * @return array<string, array<string, string|null>>
     */
    private function assertOracleRows(array $rows): array
    {
        $allowedTiers = $this->allowed('oracle_tiers');
        $byTier = [];
        $ranks = [];
        foreach ($rows as $row) {
            $tier = $this->requiredString($row, 'oracle_offering', 'Oracle offering is required.');
            $this->assertAllowed($tier, $allowedTiers, 'Oracle offering is not allowed.');
            if (isset($byTier[$tier])) {
                throw DomainViolation::because('Oracle offering names must be unique.');
            }
            if (($row['currency'] ?? null) !== 'USD' || ($row['term'] ?? null) !== '1 Year' || ($row['metric'] ?? null) !== 'Physical CPU Pair') {
                throw DomainViolation::because('Oracle catalog rows must retain the governed annual USD CPU-pair basis.');
            }
            $this->requiredString($row, 'annual_price', 'Oracle annual price is required.');
            $this->requiredString($row, 'source_url', 'Oracle catalog row source URL is required.');
            $rank = $this->requiredString($row, 'tier_rank', 'Oracle tier rank is required.');
            if (isset($ranks[$rank])) {
                throw DomainViolation::because('Oracle tier ranks must be unique.');
            }
            $ranks[$rank] = true;
            $byTier[$tier] = $row;
        }

        return $byTier;
    }

    /**
     * @param array<string, array<string, string|null>> $sourcesById
     * @param array<string, list<array<string, string|null>>> $tables
     */
    private function assertProvenance(array $sourcesById, array $tables): void
    {
        foreach (['rh_catalog', 'ol_catalog'] as $tableName) {
            $definition = $this->manifest['provenance'][$tableName] ?? null;
            if (!is_array($definition)) {
                throw DomainViolation::because(sprintf('Workbook %s provenance manifest is missing.', $tableName));
            }
            $sourceId = $definition['source_id'] ?? null;
            $expectedLocation = $definition['source_register_url_or_path'] ?? null;
            $source = is_string($sourceId) ? ($sourcesById[$sourceId] ?? null) : null;
            if (!is_array($source)
                || !is_string($expectedLocation)
                || ($source['url_or_path'] ?? null) !== $expectedLocation
            ) {
                throw DomainViolation::because(sprintf('Workbook %s provenance does not match the fixed source register relationship.', $tableName));
            }
            if (($definition['require_row_source_url_match'] ?? false) === true) {
                foreach ($tables[$tableName] as $row) {
                    if (($row['source_url'] ?? null) !== $expectedLocation) {
                        throw DomainViolation::because(sprintf('Workbook %s row provenance does not match its governed source.', $tableName));
                    }
                }
            }
        }
    }

    /**
     * @param list<array<string, string|null>> $rows
     * @param array<string, array<string, string|null>> $rhBySku
     * @param array<string, array<string, string|null>> $olByTier
     */
    private function assertMappings(array $rows, array $rhBySku, array $olByTier): int
    {
        $allowedStatuses = $this->allowed('mapping_statuses');
        $relationships = 0;
        foreach ($rows as $row) {
            $sku = $this->requiredString($row, 'rh_sku', 'Mapping RH SKU is required.');
            $rh = $rhBySku[$sku] ?? null;
            if ($rh === null) {
                throw DomainViolation::because('Every mapping must reference a governed RH SKU.');
            }
            if (($row['v1_treatment'] ?? null) !== ($rh['v1_treatment'] ?? null)) {
                throw DomainViolation::because('RH catalog and mapping treatments must match.');
            }
            $status = $this->requiredString($row, 'mapping_status', 'Mapping status is required.');
            $this->assertAllowed($status, $allowedStatuses, 'Mapping status is not allowed.');
            if ($status !== 'APPROVED') {
                continue;
            }
            if (($row['coverage_group_required'] ?? null) !== 'Yes') {
                throw DomainViolation::because('Approved calculation mappings must require an explicit coverage group.');
            }
            $this->requiredString($row, 'notes', 'Approved mapping rationale is required.');
            foreach ($this->tiers($row['allowed_oracle_tiers'] ?? null) as $tier) {
                if (!isset($olByTier[$tier])) {
                    throw DomainViolation::because('Approved mapping references an unknown Oracle tier.');
                }
                ++$relationships;
            }
        }

        return $relationships;
    }

    /** @param list<array<string, string|null>> $rows */
    private function assertChecks(array $rows): void
    {
        $allowed = $this->allowed('check_severities');
        foreach ($rows as $row) {
            $this->requiredString($row, 'check', 'Workbook check name is required.');
            $this->assertAllowed($this->requiredString($row, 'severity', 'Workbook check severity is required.'), $allowed, 'Workbook check severity is not allowed.');
        }
    }

    /**
     * @param array<string, mixed> $scenario
     * @param array<string, array<string, string|null>> $rhBySku
     * @param array<string, array<string, string|null>> $mappingBySku
     * @param array<string, array<string, string|null>> $olByTier
     * @return array{model_status: string, rhel_subtotal: string, oracle_subtotal: string, difference: string|null}
     */
    private function scenario(array $scenario, array $rhBySku, array $mappingBySku, array $olByTier): array
    {
        $coverage = $scenario['coverage'] ?? null;
        $lines = $scenario['lines'] ?? null;
        $expected = $scenario['expected'] ?? null;
        if (!is_array($coverage) || !is_array($lines) || !is_array($expected)) {
            throw DomainViolation::because('Semantic scenario manifest is incomplete.');
        }
        $tier = $this->requiredString($coverage, 'oracle_tier', 'Scenario Oracle tier is required.');
        $oracle = $olByTier[$tier] ?? null;
        if ($oracle === null) {
            throw DomainViolation::because('Scenario Oracle tier is not governed.');
        }
        $systems = $this->positiveInteger($coverage, 'systems');
        $cpusPerSystem = $this->positiveInteger($coverage, 'cpus_per_system');
        $pairs = $systems * intdiv($cpusPerSystem + 1, 2);

        $rhelTotal = BigDecimal::zero()->toScale(2);
        $incomplete = false;
        foreach ($lines as $line) {
            if (!is_array($line)) {
                throw DomainViolation::because('Semantic scenario line is invalid.');
            }
            $sku = $this->requiredString($line, 'sku', 'Scenario SKU is required.');
            $quantity = $this->positiveInteger($line, 'quantity');
            $rh = $rhBySku[$sku] ?? null;
            $mapping = $mappingBySku[$sku] ?? null;
            if ($rh === null || $mapping === null || !in_array($tier, $this->tiers($mapping['allowed_oracle_tiers'] ?? null), true)) {
                throw DomainViolation::because('Semantic scenario does not follow a governed mapping.');
            }
            $price = $rh['scenario_price'] ?? null;
            if ($price === null) {
                $incomplete = true;
                continue;
            }
            $rhelTotal = $rhelTotal->plus(BigDecimal::of($price)->multipliedBy($quantity)->toScale(2, RoundingMode::UNNECESSARY));
        }
        $oracleTotal = BigDecimal::of($this->requiredString($oracle, 'annual_price', 'Oracle annual price is required.'))
            ->multipliedBy($pairs)
            ->toScale(2, RoundingMode::UNNECESSARY);
        $difference = $incomplete ? null : $this->money($rhelTotal->minus($oracleTotal));
        $actual = [
            'model_status' => $incomplete ? 'INCOMPLETE' : 'READY',
            'rhel_subtotal' => $this->money($rhelTotal),
            'oracle_subtotal' => $this->money($oracleTotal),
            'difference' => $difference,
        ];
        foreach ($actual as $field => $value) {
            if (($expected[$field] ?? null) !== $value) {
                throw DomainViolation::because(sprintf('Semantic scenario "%s" does not match expected %s.', $scenario['name'], $field));
            }
        }

        return $actual;
    }

    /** @return list<string> */
    private function tiers(?string $value): array
    {
        if ($value === null || trim($value) === '') {
            throw DomainViolation::because('Approved mapping requires at least one Oracle tier.');
        }
        $aliases = [
            'Basic' => 'Oracle Linux Basic',
            'Premier' => 'Oracle Linux Premier',
            'Premier Plus' => 'Oracle Linux Premier Plus',
        ];
        $tiers = [];
        foreach (explode('|', $value) as $tier) {
            $tier = trim($tier);
            $tiers[] = $aliases[$tier] ?? $tier;
        }

        return $tiers;
    }

    /** @return list<string> */
    private function allowed(string $key): array
    {
        $values = $this->manifest['allowed'][$key] ?? null;
        if (!is_array($values)) {
            throw DomainViolation::because(sprintf('Allowed-value manifest "%s" is missing.', $key));
        }

        return array_values(array_map('strval', $values));
    }

    /** @param list<string> $allowed */
    private function assertAllowed(string $value, array $allowed, string $message): void
    {
        if (!in_array($value, $allowed, true)) {
            throw DomainViolation::because($message);
        }
    }

    /** @param array<string, mixed> $row */
    private function requiredString(array $row, string $field, string $message): string
    {
        $value = $row[$field] ?? null;
        if (!is_string($value) || trim($value) === '') {
            throw DomainViolation::because($message);
        }

        return $value;
    }

    /** @param array<string, mixed> $row */
    private function positiveInteger(array $row, string $field): int
    {
        $value = $this->requiredString($row, $field, sprintf('%s must be a positive integer.', $field));
        if (!ctype_digit($value) || (int) $value < 1) {
            throw DomainViolation::because(sprintf('%s must be a positive integer.', $field));
        }

        return (int) $value;
    }

    private function money(BigDecimal $value): string
    {
        return (string) $value->toScale(2, RoundingMode::UNNECESSARY);
    }
}
