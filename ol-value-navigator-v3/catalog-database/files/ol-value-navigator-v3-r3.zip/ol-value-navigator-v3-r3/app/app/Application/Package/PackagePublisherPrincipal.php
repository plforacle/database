<?php

declare(strict_types=1);

namespace App\Application\Package;

interface PackagePublisherPrincipal
{
    public function authenticatedIdentifier(): string;
}
