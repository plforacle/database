<?php

declare(strict_types=1);

namespace App\Application\Package;

use App\Domain\Coverage\CoverageEvaluator;
use App\Domain\Package\CatalogSnapshot;
use App\Domain\Package\PackageAcceptanceDocument;
use App\Domain\Package\SemanticCatalogPackage;
use App\Domain\Shared\DomainViolation;
use JsonException;
use stdClass;

final class PackageAcceptanceRunner
{
    /**
     * @return array{
     *   format:string,manifestSha256:string,acceptanceSha256:string,
     *   validator:string,checks:string,olamRule:string,vmwareRule:string,
     *   cases:list<array{id:string,profileId:string,resultSha256:string,outcome:string}>
     * }
     */
    public function verify(SemanticCatalogPackage $package, string $acceptanceJson): array
    {
        $document = PackageAcceptanceDocument::fromJson($package, $acceptanceJson);
        $results = [];
        foreach ($document->cases() as $index => $case) {
            $snapshot = new CatalogSnapshot($package, $case['profileId']);
            $evaluation = (new CoverageEvaluator())->evaluate($case['input'], $snapshot);
            if (($evaluation['catalogContext'] ?? null) !== $snapshot->context()) {
                throw DomainViolation::because('Package acceptance evaluation used the wrong catalog context.');
            }
            $expectedResult = $evaluation;
            unset($expectedResult['catalogContext']);
            if (!$document->expectedMatches($index, $expectedResult)) {
                throw DomainViolation::because('Package acceptance result does not match the expected result.');
            }
            $results[] = [
                'id' => $case['id'],
                'profileId' => $case['profileId'],
                'resultSha256' => hash('sha256', self::canonicalJson($evaluation)),
                'outcome' => 'PASS',
            ];
        }

        return [
            'format' => 'package-admission-1',
            'manifestSha256' => $package->envelope()->manifestDigest(),
            'acceptanceSha256' => hash('sha256', $acceptanceJson),
            'validator' => 'semantic-catalog-1',
            'checks' => 'package-acceptance-1',
            'olamRule' => CatalogSnapshot::OLAM_RULE,
            'vmwareRule' => CatalogSnapshot::VMWARE_RULE,
            'cases' => $results,
        ];
    }

    /**
     * Receipt result digests encode JSON with associative object keys sorted using
     * SORT_STRING, list order retained, scalar types retained, UTF-8 and slashes
     * unescaped, and zero-fraction floats preserved.
     */
    private static function canonicalJson(mixed $value): string
    {
        try {
            return json_encode(
                self::sortObjectKeys($value),
                JSON_THROW_ON_ERROR | JSON_PRESERVE_ZERO_FRACTION | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE,
            );
        } catch (JsonException) {
            throw DomainViolation::because('Package acceptance result cannot be canonically encoded.');
        }
    }

    private static function sortObjectKeys(mixed $value): mixed
    {
        if ($value instanceof stdClass) {
            $properties = get_object_vars($value);
            ksort($properties, SORT_STRING);
            $result = new stdClass();
            foreach ($properties as $key => $item) {
                $result->{$key} = self::sortObjectKeys($item);
            }

            return $result;
        }
        if (!is_array($value)) {
            return $value;
        }
        if (array_is_list($value)) {
            return array_map(self::sortObjectKeys(...), $value);
        }
        ksort($value, SORT_STRING);
        foreach ($value as &$item) {
            $item = self::sortObjectKeys($item);
        }
        unset($item);

        return $value;
    }
}
