<?php

declare(strict_types=1);

namespace App\Application\Extraction;

use RuntimeException;

final class InvalidExtractionResponse extends RuntimeException
{
    public static function because(string $reason): self
    {
        return new self('The extraction response did not satisfy the governed contract: ' . $reason);
    }
}
