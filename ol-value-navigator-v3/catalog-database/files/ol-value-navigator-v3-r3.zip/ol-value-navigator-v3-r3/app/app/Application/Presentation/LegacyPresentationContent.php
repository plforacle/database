<?php

declare(strict_types=1);

namespace App\Application\Presentation;

use App\Domain\Package\CatalogPackageContract;
use DateTimeImmutable;
use UnexpectedValueException;

/**
 * Validates and prepares historical legacy facts without active catalog access.
 * @phpstan-type Data array{meta: array<string,string>, customer: array<string,string>, totals: array<string,string>, groups: list<array<string,string>>, lines: list<array<string,string>>, exclusions: list<string>, advisories: list<string>}
 * @phpstan-type Prepared array{meta: array<string,string>, customer: array<string,string>, totals: array<string,string>, groups: list<array<string,string>>, lines: list<array<string,string>>, exclusions: list<string>, advisories: list<string>, notes:string,disclosure:string,warning:string,hasCapacityGap:bool,hasPublicYum:bool}
 */
final class LegacyPresentationContent
{
    private const DISCLOSURE = 'Synthetic catalog — not approved pricing. Annual USD subscriptions; no migration, services or discounts included. Not full TCO.';
    private const CAPACITY_WARNING = 'OLAM support capacity review required. This cost scenario leaves declared nodes outside the selected support capacity.';
    private const PUBLIC_YUM_DISCLOSURE = 'Public Yum is self-support with no paid Oracle support entitlement.';

    /** @param array<string,mixed> $snapshot
     * @return Prepared
     */
    public function prepare(array $snapshot): array
    {
        $data = $this->validate($snapshot);
        return $data + ['notes' => $this->notes($data), 'disclosure' => self::DISCLOSURE,
            'warning' => $this->scenarioWarning($data), 'hasCapacityGap' => $this->hasCapacityGap($data), 'hasPublicYum' => $this->hasPublicYum($data)];
    }

    /** @param array<string,mixed> $snapshot
     * @return Data
     */
    private function validate(array $snapshot): array
    {
        $evaluation = $this->object($snapshot['evaluation'] ?? null);
        if (($snapshot['state'] ?? null) !== 'CONFIRMED' || ($snapshot['synthetic'] ?? null) !== true
            || ($evaluation['ready'] ?? null) !== true || ($evaluation['blockers'] ?? null) !== []
            || (isset($evaluation['completeness']) && $evaluation['completeness'] !== 'COMPLETE')) {
            throw new UnexpectedValueException('Only confirmed, ready synthetic comparisons without blockers can be exported.');
        }
        $meta = [];
        foreach (['revisionId', 'catalogVersion', 'ruleVersion', 'confirmedAt'] as $key) {
            $meta[$key] = $this->text($snapshot[$key] ?? null, 100);
        }
        if (($snapshot['catalogContext'] ?? null) !== null) {
            $context = $snapshot['catalogContext'];
            $meta['selection'] = 'Saved release: ' . $context['releaseId'] . ' · Profile: ' . $context['profileId'] . ' · ' . ($context['generation'] === 0 ? 'Bootstrap selection (unactivated)' : 'Selection generation: ' . $context['generation']);
        }
        $meta['capacityBasis'] = isset($evaluation['mappingVersion']) ? 'FINAL' : 'BASE';
        foreach (['mappingVersion', 'priceVersion'] as $key) {
            $meta[$key] = $this->text($evaluation[$key] ?? $snapshot[$key] ?? $meta['catalogVersion'], 100);
        }
        if (!preg_match('/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d{1,6})?(?:Z|[+-]\d{2}:\d{2})$/D', $meta['confirmedAt'])) {
            throw new UnexpectedValueException('Confirmation date must be an ISO timestamp with timezone.');
        }
        try {
            new DateTimeImmutable($meta['confirmedAt']);
            $dateErrors = DateTimeImmutable::getLastErrors();
            if ($dateErrors !== false && ($dateErrors['warning_count'] || $dateErrors['error_count'])) {
                throw new UnexpectedValueException('Invalid confirmation date.');
            }
        } catch (\Exception $exception) {
            throw new UnexpectedValueException('Invalid confirmation date.', 0, $exception);
        }
        $customer = [];
        $rawCustomer = $this->object($snapshot['customer'] ?? null);
        foreach (['name' => 120, 'objective' => 300, 'scope' => 400, 'nextStep' => 300] as $key => $limit) {
            $customer[$key] = $this->text($rawCustomer[$key] ?? null, $limit);
        }
        $totals = [];
        foreach (['sourceAnnual', 'oracleAnnual', 'savingsAnnual', 'sourceThreeYear', 'oracleThreeYear', 'sourceFiveYear', 'oracleFiveYear'] as $key) {
            $totals[$key] = $this->money($evaluation[$key] ?? null, $key === 'savingsAnnual');
        }
        $groups = [];
        foreach ($this->rows($evaluation['groups'] ?? null, 5) as $raw) {
            $group = [];
            foreach (['id', 'label', 'offering', 'olamStatus'] as $key) {
                $group[$key] = $this->text($raw[$key] ?? null, $key === 'label' ? 80 : 100);
            }
            if (!in_array($group['olamStatus'], ['NOT_APPLICABLE', 'COVERED', 'COVERED_WITH_ADDITIONAL_SUPPORT', 'SUFFICIENT_FOR_DECLARED_NODES', 'GAP_REQUIRES_REVIEW'], true)
                || (isset($raw['supportCapacityStatus']) && $raw['supportCapacityStatus'] !== $group['olamStatus'])
                || (isset($raw['completeness']) && $raw['completeness'] !== 'COMPLETE')
                || (isset($raw['complete']) && $raw['complete'] !== true)) {
                throw new UnexpectedValueException('OLAM coverage is unresolved.');
            }
            foreach (['supportUnits', 'demand', 'capacity', 'shortfall', 'additionalUnits'] as $key) {
                $value = $raw[$key] ?? null;
                if ($key === 'demand' && $value === null && $group['olamStatus'] === 'NOT_APPLICABLE') {
                    $group[$key] = 'N/A';
                    continue;
                }
                $maximum = $key === 'capacity' ? 99999999999 : 999999999;
                if (!is_int($value) || $value < 0 || $value > $maximum) {
                    throw new UnexpectedValueException('Invalid saved count: ' . $key);
                }
                $group[$key] = (string) $value;
            }
            foreach (['annualCost', 'additionalCost'] as $key) {
                $group[$key] = $this->money($raw[$key] ?? null);
            }
            if ($group['shortfall'] !== '0' && !in_array($group['olamStatus'], ['COVERED_WITH_ADDITIONAL_SUPPORT', 'GAP_REQUIRES_REVIEW'], true)) {
                throw new UnexpectedValueException('Unresolved OLAM shortfall.');
            }
            $group['capacityBasis'] = in_array($group['olamStatus'], ['SUFFICIENT_FOR_DECLARED_NODES', 'GAP_REQUIRES_REVIEW'], true) ? 'FINAL' : $meta['capacityBasis'];
            if ($group['capacityBasis'] === 'FINAL' && $group['olamStatus'] !== 'NOT_APPLICABLE'
                && ((int) $group['shortfall'] !== max(0, (int) $group['demand'] - (int) $group['capacity'])
                    || ($group['olamStatus'] === 'GAP_REQUIRES_REVIEW' && $group['shortfall'] === '0'))) {
                throw new UnexpectedValueException('Saved OLAM capacity and status disagree.');
            }
            $group['minOffering'] = $this->text($raw['minimumOffering'] ?? $raw['minOffering'] ?? $group['offering'], 100);
            $group['selectedOffering'] = $this->text($raw['selectedOffering'] ?? $group['offering'], 100);
            $group['additionalOffering'] = isset($raw['additionalOffering']) && $raw['additionalOffering'] !== '' ? $this->text($raw['additionalOffering'], 100) : 'Not recorded';
            $indicated = $raw['additionalPairsIndicated'] ?? 0;
            if (!is_int($indicated) || $indicated < 0 || $indicated > 999999999) {
                throw new UnexpectedValueException('Invalid saved additional pair indication.');
            }
            $group['additionalPairsIndicated'] = (string) $indicated;
            $offeringMetadata = isset($raw['offeringMetadata']) ? $this->object($raw['offeringMetadata']) : [];
            $group['offeringProvenance'] = isset($offeringMetadata['provenance']) ? $this->text($offeringMetadata['provenance'], CatalogPackageContract::EVIDENCE_BYTES) : '';
            $groups[] = $group;
        }
        $lines = [];
        foreach ($this->rows($evaluation['lines'] ?? null, 10) as $raw) {
            $line = [];
            foreach (['sku' => 100, 'description' => CatalogPackageContract::TEXT_BYTES, 'unit' => 80, 'priceBasis' => 200, 'provenance' => CatalogPackageContract::EVIDENCE_BYTES] as $key => $limit) {
                $line[$key] = $this->text($raw[$key] ?? ($key === 'description' ? ($raw['sku'] ?? null) : null), $limit);
            }
            $quantity = $raw['quantity'] ?? null;
            if (is_int($quantity) && $quantity >= 0 && $quantity <= 999999999) {
                $quantity = (string) $quantity;
            }
            $line['quantity'] = $this->money($quantity);
            $line['annualCost'] = $this->money($raw['annualCost'] ?? null);
            $metadata = isset($raw['catalogMetadata']) ? $this->object($raw['catalogMetadata']) : [];
            $line['capabilityRule'] = isset($metadata['capabilityRule']) ? $this->text($metadata['capabilityRule'], CatalogPackageContract::EVIDENCE_BYTES) : '';
            $line['scopeDisclosure'] = ($metadata['workstation'] ?? false) === true ? 'Workstation comparison covers the physical OS. Included guest entitlement is outside this priced scope. Hardware and application compatibility require separate review.' : '';
            $lines[] = $line;
        }
        $exclusions = $evaluation['exclusions'] ?? null;
        if (!is_array($exclusions) || !array_is_list($exclusions) || count($exclusions) > 10) {
            throw new UnexpectedValueException('Invalid exclusions.');
        }
        $exclusions = array_map(fn (mixed $value): string => $this->text($value, CatalogPackageContract::TEXT_BYTES + 100 + 2), $exclusions);
        $rawAdvisories = $evaluation['advisories'] ?? [];
        if (!is_array($rawAdvisories) || !array_is_list($rawAdvisories) || count($rawAdvisories) > 50) {
            throw new UnexpectedValueException('Invalid saved advisories.');
        }
        $advisories = [];
        foreach ($rawAdvisories as $raw) {
            $advisory = $this->object($raw);
            $advisories[] = $this->text($advisory['code'] ?? null, 100) . ' (' . $this->text($advisory['groupId'] ?? null, 100) . '): ' . $this->text($advisory['message'] ?? null, 1000);
        }
        return compact('meta', 'customer', 'totals', 'groups', 'lines', 'exclusions', 'advisories');
    }

    /** @return array<string,mixed> */
    private function object(mixed $value): array
    {
        if (!is_array($value) || array_is_list($value)) {
            throw new UnexpectedValueException('Missing structured comparison fields.');
        }
        foreach (array_keys($value) as $key) {
            if (!is_string($key)) {
                throw new UnexpectedValueException('Invalid comparison field.');
            }
        }
        return $value;
    }

    /** @return list<array<string,mixed>> */
    private function rows(mixed $value, int $maximum): array
    {
        if (!is_array($value) || !array_is_list($value) || count($value) < 1 || count($value) > $maximum) {
            throw new UnexpectedValueException('Comparison rows are missing or exceed the presentation limit.');
        }
        return array_map($this->object(...), $value);
    }

    private function text(mixed $value, int $limit): string
    {
        if (!is_string($value) || trim($value) === '' || mb_strlen($value) > $limit
            || preg_match('/[^\x{9}\x{A}\x{D}\x{20}-\x{D7FF}\x{E000}-\x{FFFD}\x{10000}-\x{10FFFF}]/u', $value) !== 0) {
            throw new UnexpectedValueException('Missing, invalid or overlong presentation text.');
        }
        return preg_replace('/\s+/u', ' ', trim($value)) ?? throw new UnexpectedValueException('Invalid text encoding.');
    }

    private function money(mixed $value, bool $signed = false): string
    {
        $pattern = $signed ? '/^-?\d{1,15}(?:\.\d{1,4})?$/D' : '/^\d{1,15}(?:\.\d{1,4})?$/D';
        if (!is_string($value) || !preg_match($pattern, $value)) {
            throw new UnexpectedValueException('Missing or malformed saved numeric value.');
        }
        return $value;
    }

    /** @param Data $data */
    private function hasCapacityGap(array $data): bool
    {
        foreach ($data['groups'] as $group) {
            if ($group['olamStatus'] === 'GAP_REQUIRES_REVIEW') {
                return true;
            }
        }
        return false;
    }

    /** @param Data $data */
    private function hasPublicYum(array $data): bool
    {
        return in_array('OL-PUBLIC-YUM', array_column($data['groups'], 'selectedOffering'), true);
    }

    /** @param Data $data */
    private function scenarioWarning(array $data): string
    {
        return trim(($this->hasCapacityGap($data) ? self::CAPACITY_WARNING : '') . ' ' . ($this->hasPublicYum($data) ? self::PUBLIC_YUM_DISCLOSURE : ''));
    }

    /** @param Data $data */
    private function notes(array $data): string
    {
        $notes = self::DISCLOSURE . "\n\n" . implode("\n", $data['customer']);
        $notes .= "\n\nSaved comparison trace\n" . implode("\n", $data['meta']);
        if ($data['meta']['capacityBasis'] === 'FINAL') {
            $notes .= "\nMapping version: " . $data['meta']['mappingVersion'] . "\nPrice version: " . $data['meta']['priceVersion'];
        }
        if ($this->scenarioWarning($data) !== '') {
            $notes .= "\n\n" . $this->scenarioWarning($data);
        }
        if ($data['advisories'] !== []) {
            $notes .= "\n\nSaved advisories\n" . implode("\n", $data['advisories']);
        }
        foreach ($data['lines'] as $line) {
            $notes .= "\n\nSource: " . $line['sku'] . ' — ' . $line['description']
                . "\nQuantity: " . $line['quantity'] . ' ' . $line['unit'] . '; annual USD: ' . $line['annualCost']
                . "\nPrice basis: " . $line['priceBasis'] . "\nProvenance: " . $line['provenance'];
            if ($line['capabilityRule'] !== '') {
                $notes .= "\nMapping scope: " . $line['capabilityRule'];
            }
            if ($line['scopeDisclosure'] !== '') {
                $notes .= "\n" . $line['scopeDisclosure'];
            }
        }
        foreach ($data['groups'] as $group) {
            $notes .= "\n\nPopulation: " . $group['label'] . ' (' . $group['id'] . ')'
                . "\nOffering: " . $group['offering'] . '; support units: ' . $group['supportUnits'] . '; base annual USD: ' . $group['annualCost']
                . "\nOLAM status: " . $group['olamStatus'] . '; demand: ' . $group['demand'] . '; capacity: ' . $group['capacity']
                . ($group['capacityBasis'] === 'FINAL' ? '; Remaining OLAM node gap: ' : '; base shortfall before extra support: ') . $group['shortfall']
                . "\nAdditional support units: " . $group['additionalUnits'] . '; additional annual USD: ' . $group['additionalCost'];
            if ($group['capacityBasis'] === 'FINAL') {
                $notes .= "\nMinimum offering: " . $group['minOffering'] . '; Selected offering: ' . $group['selectedOffering']
                    . "\nExtra support offering: " . $group['additionalOffering'] . '; Additional pairs indicated: ' . $group['additionalPairsIndicated'];
            }
            if ($group['offeringProvenance'] !== '') {
                $notes .= "\nOracle offering provenance: " . $group['offeringProvenance'];
            }
        }
        return $notes . "\n\nExclusions\n" . implode("\n", $data['exclusions']) . "\n\nLong customer narrative, labels and exclusions may be abbreviated on slides; these notes preserve the full text.";
    }

}
