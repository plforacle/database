<?php

declare(strict_types=1);

namespace App\Application\Catalog;

use App\Domain\Shared\CatalogVersionId;
use App\Domain\Shared\DomainViolation;
use App\Infrastructure\Persistence\PdoTransaction;
use PDO;
use Ramsey\Uuid\Uuid;

final readonly class ActivateCatalog
{
    private CatalogContentDigester $contentDigester;

    public function __construct(
        private PDO $pdo,
        private CatalogOwnerPrincipal $principal,
        ?CatalogContentDigester $contentDigester = null,
    ) {
        $this->contentDigester = $contentDigester ?? new CatalogContentDigester();
    }

    public function execute(CatalogVersionId $id, string $evidenceReference): void
    {
        $owner = $this->principal->authenticatedActor();
        if (!$owner->canOwnCatalog()) {
            throw DomainViolation::because('Catalog activation requires the catalog-owner capability.');
        }
        $evidenceReference = trim($evidenceReference);
        if ($evidenceReference === '') {
            throw DomainViolation::because('Catalog activation requires an approval evidence reference.');
        }
        if (strlen($evidenceReference) > 255 || preg_match('/[\x00-\x1F\x7F]/', $evidenceReference) === 1) {
            throw DomainViolation::because('Catalog approval evidence reference is invalid.');
        }

        (new PdoTransaction($this->pdo))->run(function (PDO $pdo) use ($id, $owner, $evidenceReference): void {
            $target = $pdo->prepare('SELECT status, source_sha256 FROM catalog_version WHERE id = ? FOR UPDATE');
            $target->execute([(string) $id]);
            $row = $target->fetch(PDO::FETCH_ASSOC);
            if (!is_array($row)) {
                throw DomainViolation::because('Catalog version was not found.');
            }
            if (($row['status'] ?? null) !== 'DRAFT') {
                throw DomainViolation::because('Only a reconciled DRAFT catalog version may be activated.');
            }
            $reconciliation = $pdo->prepare(
                'SELECT status, workbook_sha256, source_digest, sku_digest, alias_digest, mapping_digest FROM catalog_reconciliation WHERE catalog_version_id = ?',
            );
            $reconciliation->execute([(string) $id]);
            $record = $reconciliation->fetch(PDO::FETCH_ASSOC);
            if (!is_array($record) || ($record['status'] ?? null) !== 'PASS') {
                throw DomainViolation::because('Catalog activation requires an immutable passing reconciliation record.');
            }
            if (!is_string($record['workbook_sha256'] ?? null)
                || !is_string($row['source_sha256'] ?? null)
                || !hash_equals($row['source_sha256'], $record['workbook_sha256'])
            ) {
                throw DomainViolation::because('Catalog reconciliation does not match the staged governed content.');
            }
            $digests = $this->contentDigester->forVersion($pdo, $id);
            foreach ($digests as $field => $digest) {
                if (!is_string($record[$field] ?? null) || !hash_equals($record[$field], $digest)) {
                    throw DomainViolation::because('Catalog reconciliation does not match the staged governed content.');
                }
            }

            $active = $pdo->query(
                'SELECT activation.id AS activation_id, activation.catalog_version_id FROM catalog_activation AS activation WHERE activation.deactivated_at IS NULL FOR UPDATE',
            );
            if ($active === false) {
                throw DomainViolation::because('Active catalog record could not be read.');
            }
            $previous = $active->fetch(PDO::FETCH_ASSOC);
            if (is_array($previous)) {
                $deactivate = $pdo->prepare('UPDATE catalog_activation SET deactivated_at = NOW(6) WHERE id = ?');
                $deactivate->execute([$previous['activation_id']]);
                $retire = $pdo->prepare(
                    'UPDATE catalog_version SET status = ?, retired_by = ?, retired_at = NOW(6) WHERE id = ?',
                );
                $retire->execute(['RETIRED', $owner->identifier(), $previous['catalog_version_id']]);
            }

            $approveSources = $pdo->prepare(
                'UPDATE catalog_source SET approved_by = ?, approved_at = NOW(6) WHERE catalog_version_id = ? AND approved_by IS NULL AND approved_at IS NULL',
            );
            $approveSources->execute([$owner->identifier(), (string) $id]);
            $unapprovedSources = $pdo->prepare(
                'SELECT COUNT(*) FROM catalog_source WHERE catalog_version_id = ? AND (approved_by IS NULL OR approved_at IS NULL)',
            );
            $unapprovedSources->execute([(string) $id]);
            if ($unapprovedSources->fetchColumn() !== 0) {
                throw DomainViolation::because('Catalog activation requires owner approval of every governed source.');
            }

            $approve = $pdo->prepare(
                'UPDATE catalog_version SET status = ?, approved_by = ?, approved_at = NOW(6) WHERE id = ?',
            );
            $approve->execute(['APPROVED', $owner->identifier(), (string) $id]);
            $activate = $pdo->prepare(
                'INSERT INTO catalog_activation (id, catalog_version_id, activated_by, approval_evidence_reference) VALUES (?, ?, ?, ?)',
            );
            $activate->execute([
                Uuid::uuid4()->toString(),
                (string) $id,
                $owner->identifier(),
                $evidenceReference,
            ]);
        });
    }
}
