<?php

declare(strict_types=1);

namespace App\Application\Package;

use App\Domain\Package\PackageEnvelope;
use App\Domain\Package\SemanticCatalogPackage;

final class CatalogPackageValidator
{
    public function validate(PackageEnvelope $envelope): SemanticCatalogPackage
    {
        return SemanticCatalogPackage::fromEnvelope($envelope);
    }
}
