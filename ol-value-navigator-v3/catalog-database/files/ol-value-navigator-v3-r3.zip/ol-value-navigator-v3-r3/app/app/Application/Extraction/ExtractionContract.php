<?php

declare(strict_types=1);

namespace App\Application\Extraction;

use App\Domain\Extraction\CandidateLine;
use App\Domain\Shared\RedactedSourceText;
use JsonException;

final readonly class ExtractionContract
{
    /** @var array{contractVersion: string, promptTemplateVersion: string, maximumLines: int, maximumLineBytes: int, maximumIntegerDigits: int, maximumFractionalDigits: int} */
    private array $definition;

    public function __construct()
    {
        /** @var array{contractVersion: string, promptTemplateVersion: string, maximumLines: int, maximumLineBytes: int, maximumIntegerDigits: int, maximumFractionalDigits: int} $definition */
        $definition = require dirname(__DIR__, 3) . '/resources/ai/extraction-contract-v1.php';
        $this->definition = $definition;
    }

    public function contractVersion(): string
    {
        return $this->definition['contractVersion'];
    }
    public function promptTemplateVersion(): string
    {
        return $this->definition['promptTemplateVersion'];
    }

    /** @return list<CandidateLine> */
    public function validate(RedactedSourceText $source, string $inner): array
    {
        try {
            $decoded = json_decode($inner, true, 512, JSON_THROW_ON_ERROR);
        } catch (JsonException) {
            throw InvalidExtractionResponse::because('inner JSON is malformed.');
        }
        if (!is_array($decoded) || array_is_list($decoded) || !$this->hasExactKeys($decoded, ['lines']) || !is_array($decoded['lines']) || !array_is_list($decoded['lines'])) {
            throw InvalidExtractionResponse::because('inner JSON has an unsupported shape.');
        }
        if (count($decoded['lines']) > $this->definition['maximumLines']) {
            throw InvalidExtractionResponse::because('inner JSON exceeds the candidate limit.');
        }

        $lines = [];
        $ids = [];
        foreach ($decoded['lines'] as $line) {
            if (!is_array($line) || array_is_list($line) || !$this->hasExactKeys($line, ['lineId', 'sourceStart', 'sourceEnd', 'sourceExcerpt', 'sku', 'quantity'])) {
                throw InvalidExtractionResponse::because('a candidate has unsupported fields.');
            }
            $lineId = $line['lineId'];
            $start = $line['sourceStart'];
            $end = $line['sourceEnd'];
            $excerpt = $line['sourceExcerpt'];
            $sku = $line['sku'];
            $quantity = $line['quantity'];
            if (!is_string($lineId) || trim($lineId) === '' || strlen($lineId) > 128 || preg_match('//u', $lineId) !== 1
                || !is_int($start) || !is_int($end) || !is_string($excerpt) || preg_match('//u', $excerpt) !== 1
                || strlen($excerpt) > $this->definition['maximumLineBytes'] || !is_null($sku) && (!is_string($sku) || trim($sku) === '' || strlen($sku) > 255 || preg_match('//u', $sku) !== 1)
                || !is_null($quantity) && (!is_string($quantity) || preg_match('/^(?:0|[1-9][0-9]{0,14})(?:\.[0-9]{1,4})?$/', $quantity) !== 1 || preg_match('/^0(?:\.0+)?$/', $quantity) === 1)
            ) {
                throw InvalidExtractionResponse::because('a candidate has invalid values.');
            }
            if ($start < 0 || $end <= $start || $end > strlen($source->value()) || substr($source->value(), $start, $end - $start) !== $excerpt || isset($ids[$lineId])) {
                throw InvalidExtractionResponse::because('a candidate has an invalid source span or duplicate identifier.');
            }
            $ids[$lineId] = true;
            $lines[] = new CandidateLine($lineId, $start, $end, $excerpt, $sku, $quantity);
        }

        $spans = $lines;
        usort($spans, static fn (CandidateLine $left, CandidateLine $right): int => $left->sourceStart() <=> $right->sourceStart());
        for ($index = 1; $index < count($spans); ++$index) {
            if ($spans[$index]->sourceStart() < $spans[$index - 1]->sourceEnd()) {
                throw InvalidExtractionResponse::because('candidate source spans overlap.');
            }
        }

        return $lines;
    }

    /** @param array<string, mixed> $value
     * @param list<string> $keys
     */
    private function hasExactKeys(array $value, array $keys): bool
    {
        return count($value) === count($keys) && array_diff(array_keys($value), $keys) === [] && array_diff($keys, array_keys($value)) === [];
    }
}
