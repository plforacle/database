<?php

declare(strict_types=1);

namespace App\Application\Calculation;

use UnexpectedValueException;

final class DemoComparisonPresenter
{
    private const TITLE = 'Synthetic subscription-cost comparison — not full TCO or approved pricing';

    private const CATALOG_LABEL = 'SYNTHETIC DEMO CATALOG — NOT ORACLE PRICING';

    private const CATALOG_VERSION_ID = '00000000-0000-4000-8000-000000000901';

    /** @param array<string, mixed> $confirmed */
    public function present(array $confirmed): DemoComparisonView
    {
        return new DemoComparisonView(
            self::TITLE,
            false,
            $this->decimal($confirmed, 'sourceAnnualTotal'),
            $this->decimal($confirmed, 'sourceThreeYearTotal'),
            $this->decimal($confirmed, 'sourceFiveYearTotal'),
            $this->decimal($confirmed, 'optionAnnualTotal'),
            $this->decimal($confirmed, 'optionThreeYearTotal'),
            $this->decimal($confirmed, 'optionFiveYearTotal'),
            $this->fixedString($confirmed, 'currency', 'USD'),
            $this->fixedString($confirmed, 'annualTerm', 'ANNUAL'),
            $this->includedLines($confirmed['includedLines'] ?? null),
            $this->excludedLines($confirmed['excludedLines'] ?? null),
            $this->stringList($confirmed['assumptions'] ?? null, 'assumptions'),
            $this->fixedString($confirmed, 'catalogVersionId', self::CATALOG_VERSION_ID),
            self::CATALOG_LABEL,
            $this->requiredString($confirmed, 'confirmedBySubject'),
            $this->requiredString($confirmed, 'confirmedAt'),
            $this->extractionMode($confirmed),
            [
                'modelIdentifier' => $this->nullableString($confirmed, 'modelIdentifier'),
                'extractionContractVersion' => $this->nullableString($confirmed, 'extractionContractVersion'),
                'promptTemplateVersion' => $this->nullableString($confirmed, 'promptTemplateVersion'),
                'responseDigest' => $this->nullableString($confirmed, 'responseDigest'),
            ],
        );
    }

    /** @param array<string, mixed> $values */
    private function requiredString(array $values, string $key): string
    {
        $value = $values[$key] ?? null;
        if (!is_string($value) || trim($value) === '') {
            throw new UnexpectedValueException(sprintf('Confirmed comparison field %s is invalid.', $key));
        }

        return $value;
    }

    /** @param array<string, mixed> $values */
    private function decimal(array $values, string $key): string
    {
        $value = $this->requiredString($values, $key);
        if (preg_match('/^(?:0|[1-9][0-9]{0,14})\.\d{4}$/D', $value) !== 1) {
            throw new UnexpectedValueException(sprintf('Confirmed comparison field %s is invalid.', $key));
        }

        return $value;
    }

    /** @param array<string, mixed> $values */
    private function fixedString(array $values, string $key, string $expected): string
    {
        $value = $this->requiredString($values, $key);
        if ($value !== $expected) {
            throw new UnexpectedValueException(sprintf('Confirmed comparison field %s is invalid.', $key));
        }

        return $value;
    }

    /** @param array<string, mixed> $values */
    private function extractionMode(array $values): string
    {
        $mode = $this->requiredString($values, 'extractionMode');
        if (!in_array($mode, ['AI', 'MANUAL'], true)) {
            throw new UnexpectedValueException('Confirmed comparison field extractionMode is invalid.');
        }

        return $mode;
    }

    /** @param array<string, mixed> $values */
    private function nullableString(array $values, string $key): ?string
    {
        $value = $values[$key] ?? null;
        if ($value !== null && !is_string($value)) {
            throw new UnexpectedValueException(sprintf('Confirmed comparison field %s is invalid.', $key));
        }

        return $value;
    }

    /**
     * @return list<array{lineId: string, decision: string, sourceSku: string, quantity: string, sourceAnnualUsdPrice: string, unitBasis: string, optionSku: string, optionAnnualUsdPrice: string}>
     */
    private function includedLines(mixed $value): array
    {
        if (!is_array($value)) {
            throw new UnexpectedValueException('Confirmed comparison included lines are invalid.');
        }

        $lines = [];
        foreach ($value as $line) {
            if (!is_array($line)) {
                throw new UnexpectedValueException('Confirmed comparison included lines are invalid.');
            }
            $lines[] = [
                'lineId' => $this->requiredString($line, 'lineId'),
                'decision' => $this->requiredString($line, 'decision'),
                'sourceSku' => $this->requiredString($line, 'sourceSku'),
                'quantity' => $this->requiredString($line, 'quantity'),
                'sourceAnnualUsdPrice' => $this->requiredString($line, 'sourceAnnualUsdPrice'),
                'unitBasis' => $this->requiredString($line, 'unitBasis'),
                'optionSku' => $this->requiredString($line, 'optionSku'),
                'optionAnnualUsdPrice' => $this->requiredString($line, 'optionAnnualUsdPrice'),
            ];
        }

        if ($lines === []) {
            throw new UnexpectedValueException('Confirmed comparison included lines are invalid.');
        }

        return $lines;
    }

    /** @return list<array{lineId: string, reason: string}> */
    private function excludedLines(mixed $value): array
    {
        if (!is_array($value)) {
            throw new UnexpectedValueException('Confirmed comparison excluded lines are invalid.');
        }

        $lines = [];
        foreach ($value as $line) {
            if (!is_array($line)) {
                throw new UnexpectedValueException('Confirmed comparison excluded lines are invalid.');
            }
            $lines[] = [
                'lineId' => $this->requiredString($line, 'lineId'),
                'reason' => $this->requiredString($line, 'reason'),
            ];
        }

        return $lines;
    }

    /** @return list<string> */
    private function stringList(mixed $value, string $field): array
    {
        if (!is_array($value) || $value === []) {
            throw new UnexpectedValueException(sprintf('Confirmed comparison %s are invalid.', $field));
        }

        $strings = [];
        foreach ($value as $item) {
            if (!is_string($item) || trim($item) === '') {
                throw new UnexpectedValueException(sprintf('Confirmed comparison %s are invalid.', $field));
            }
            $strings[] = $item;
        }

        return $strings;
    }
}
