<?php

declare(strict_types=1);

namespace App\Application\Identity;

use App\Domain\Shared\Actor;

interface RepresentativeContext
{
    public function current(): Actor;
}
