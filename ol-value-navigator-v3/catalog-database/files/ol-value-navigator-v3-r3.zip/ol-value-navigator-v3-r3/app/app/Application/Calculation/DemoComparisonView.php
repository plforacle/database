<?php

declare(strict_types=1);

namespace App\Application\Calculation;

final readonly class DemoComparisonView
{
    /**
     * @param list<array{lineId: string, decision: string, sourceSku: string, quantity: string, sourceAnnualUsdPrice: string, unitBasis: string, optionSku: string, optionAnnualUsdPrice: string}> $includedLines
     * @param list<array{lineId: string, reason: string}> $excludedLines
     * @param list<string> $assumptions
     * @param array{modelIdentifier: string|null, extractionContractVersion: string|null, promptTemplateVersion: string|null, responseDigest: string|null} $aiEvidence
     */
    public function __construct(
        public string $title,
        public bool $isRecommendation,
        public string $sourceAnnualTotal,
        public string $sourceThreeYearTotal,
        public string $sourceFiveYearTotal,
        public string $optionAnnualTotal,
        public string $optionThreeYearTotal,
        public string $optionFiveYearTotal,
        public string $currency,
        public string $annualTerm,
        public array $includedLines,
        public array $excludedLines,
        public array $assumptions,
        public string $catalogVersionId,
        public string $catalogLabel,
        public string $confirmedBySubject,
        public string $confirmedAt,
        public string $extractionMode,
        public array $aiEvidence,
    ) {
    }
}
