<?php

declare(strict_types=1);

namespace App\Application\Package;

use App\Domain\Package\CatalogSnapshot;

interface CatalogSnapshotResolver
{
    public function resolve(string $profileId): CatalogSnapshot;

    /**
     * Resolve inside the confirmation transaction, before comparison/revision locks.
     * Mutable adapters must lock the channel on that same PDO connection through commit.
     */
    public function resolveForConfirmation(string $profileId): CatalogSnapshot;
}
