<?php

declare(strict_types=1);

namespace App\Application\Presentation;

use App\Application\Coverage\SavedResultContract;
use App\Application\Coverage\SavedEvidenceNotes;
use Brick\Math\BigDecimal;
use Brick\Math\RoundingMode;
use UnexpectedValueException;

/**
 * Prepares saved v1.3.1 values, preserving the original description API.
 *
 * @phpstan-type Description array{panels:list<array{title:string,body:string,rows:list<non-empty-list<string>>,warning:string}>,notes:string,disclosure:string}
 * @phpstan-type Layout array{title:string,basis:string,months:int,percentage:string,scope:string,offeringIds:list<string>,groupRows:non-empty-list<non-empty-list<string>>,poolRows:non-empty-list<non-empty-list<string>>,costRows:non-empty-list<non-empty-list<string>>,nextStep:string,exclusions:list<string>,label:string,warning:string,notes:string,disclosure:string}
 */
final class ScenarioPresentationContent
{
    /** @param array<string,mixed> $snapshot
     * @return Description
     */
    public function describe(array $snapshot, int $slideCount): array
    {
        return $this->prepare($snapshot, $slideCount)['description'];
    }

    /** @internal Layout-only fields; no new saved or public export contract.
     * @param array<string,mixed> $snapshot
     * @return Layout
     */
    public function forLayout(array $snapshot, int $slideCount): array
    {
        return $this->prepare($snapshot, $slideCount)['layout'];
    }

    /** @param array<string,mixed> $snapshot
     * @return array{description:Description,layout:Layout}
     */
    private function prepare(array $snapshot, int $slideCount): array
    {
        SavedResultContract::validate($snapshot);
        $e = self::record($snapshot['evaluation'] ?? null);
        $input = self::record($snapshot['input'] ?? null);
        if (($snapshot['state'] ?? '') !== 'CONFIRMED' || ($snapshot['synthetic'] ?? false) !== true
            || ($e['schemaVersion'] ?? '') !== '1.3.1' || ($e['ready'] ?? false) !== true || ($e['blockers'] ?? null) !== [] || ($e['reviews'] ?? null) !== []
            || (($e['completeness'] ?? '') !== 'COMPLETE' || !in_array($e['resultLabel'] ?? '', ['ILLUSTRATIVE', 'VALIDATED_INPUTS'], true))) {
            throw new UnexpectedValueException('Only confirmed, complete financial scenarios can be exported.');
        }
        $months = $e['termMonths'] ?? null;
        if (!in_array($months, [12, 36], true) || ($input['period']['months'] ?? null) !== $months) {
            throw new UnexpectedValueException('The saved comparison period is inconsistent.');
        }
        foreach (['Annual', 'Term'] as $period) {
            $source = self::money($e['source' . $period] ?? null);
            $oracle = self::money($e['oracle' . $period] ?? null);
            $difference = self::money($e['savings' . $period] ?? null, true);
            if (!BigDecimal::of($source)->minus($oracle)->isEqualTo($difference)) {
                throw new UnexpectedValueException('Saved financial totals do not reconcile.');
            }
            $percent = $period === 'Term' ? 'termPercent' : 'savingsPercent';
            $expected = BigDecimal::of($source)->isZero() ? null : (string) BigDecimal::of($difference)->multipliedBy(100)->dividedBy($source, 2, RoundingMode::HALF_UP);
            if (($e[$percent] ?? null) !== $expected) {
                throw new UnexpectedValueException('Saved percentage does not match its monetary totals.');
            }
        }
        $warning = '';
        $hasUnknown = false;
        $poolRows = [['OLAM pool', 'Unique nodes', 'Capacity', 'Support review']];
        foreach (self::records($e['pools'] ?? []) as $pool) {
            $nodes = $pool['uniqueNodes'] ?? null;
            $capacity = $pool['capacity'] ?? null;
            $excess = $pool['excess'] ?? null;
            $indicated = $pool['additionalPairsIndicated'] ?? null;
            foreach ([$nodes, $capacity, $excess, $indicated] as $count) {
                if ($count !== null && (!is_int($count) || $count < 0)) {
                    throw new UnexpectedValueException('Invalid saved support-capacity count.');
                }
            }
            $unknown = $nodes === null || $capacity === null;
            if (($unknown && ($excess !== null || $indicated !== null)) || (!$unknown && ($excess !== max(0, $nodes - $capacity) || $indicated !== (int) ceil($excess / 20)))) {
                throw new UnexpectedValueException('Unknown support demand or allocation cannot produce a calculated gap.');
            }
            $hasUnknown = $hasUnknown || $unknown;
            if ($unknown || $excess > 0) {
                $warning = 'OLAM coverage unverified or insufficient. This financial comparison does not establish fully supported coverage.';
            }
            $poolRows[] = [self::text($pool['id'] ?? ''), $nodes === null ? 'Unknown' : self::number($nodes), $capacity === null ? 'Unknown' : self::number($capacity), $unknown ? 'Review required' : ($excess > 0 ? 'Gap: ' . self::number($excess) : 'Declared nodes covered')];
        }
        if ($hasUnknown && ($e['mode'] ?? '') !== 'ILLUSTRATIVE') {
            throw new UnexpectedValueException('Unverified coverage requires an illustrative result.');
        }
        $customer = self::record($snapshot['customer'] ?? null);
        $label = self::text($e['resultLabel']);
        $basis = ($e['mode'] ?? '') === 'ILLUSTRATIVE' ? 'Illustrative' : 'Validated public inputs';
        $disclosure = 'Synthetic / deliberately redacted scenario. Subscription/support costs only; no full migration TCO or recoverable historical-spend claim.';
        $scope = $basis . ' · ' . $months . ' months · USD' . "\n" . self::text($customer['scope'] ?? 'Declared comparison scope');
        $groupRows = [['Target group', 'Systems', 'CPU pairs', 'Oracle offering']];
        $offeringIds = [];
        foreach (self::records($e['groups'] ?? []) as $group) {
            if (($group['complete'] ?? false) !== true) {
                throw new UnexpectedValueException('A partial target group cannot be presented as complete savings.');
            }
            $offeringIds[] = self::text($group['offering'] ?? '');
            $groupRows[] = [self::text($group['label'] ?? $group['id'] ?? ''), self::text($group['systems'] ?? ''), self::text($group['pairs'] ?? ''), self::text($group['offeringDescription'] ?? $group['offering'] ?? '')];
        }
        $costRows = [['Matched USD period', 'Source', 'Target', 'Difference']];
        $costRows[] = ['Annual / annualized equivalent', self::number($e['sourceAnnual']), self::number($e['oracleAnnual']), self::number($e['savingsAnnual'])];
        $costRows[] = [$months . ' months', self::number($e['sourceTerm']), self::number($e['oracleTerm']), self::number($e['savingsTerm'])];
        $costBody = $basis . ' · ' . $months . ' months · Difference ' . ($e['termPercent'] ?? 'N/A') . '%'
            . "\nAnnualized amounts for prepaid prices are display equivalents, not annual invoices.";
        $exclusions = implode('; ', array_map(self::text(...), is_array($e['exclusions'] ?? null) ? $e['exclusions'] : []));
        $panels = [];
        if ($slideCount >= 4) {
            $groupBody = $scope . (count($groupRows) > 7 ? "\nShowing 6 of " . (count($groupRows) - 1) . ' target groups; the complete inventory is in speaker notes.' : '');
            $panels[] = ['title' => self::text($customer['name'] ?? 'Subscription comparison'), 'body' => $groupBody, 'rows' => array_slice($groupRows, 0, 7), 'warning' => $warning];
        }
        $panels[] = ['title' => 'Subscription costs · ' . $months . ' months', 'body' => $costBody, 'rows' => $costRows, 'warning' => $warning];
        $poolBody = 'Concurrent capacity is not multiplied by the financial term. No extra support pairs are purchased automatically.'
            . (count($poolRows) > 7 ? "\nShowing 6 of " . (count($poolRows) - 1) . ' pools; every pool is retained in speaker notes.' : '');
        $panels[] = ['title' => 'Automation support capacity', 'body' => $poolBody, 'rows' => count($poolRows) > 1 ? array_slice($poolRows, 0, 7) : [], 'warning' => $warning === '' && count($poolRows) === 1 ? 'OLAM is not applicable to this selected scope.' : $warning];
        if ($slideCount === 5) {
            $panels[] = ['title' => 'Scope, prices and exclusions', 'body' => $label . "\n" . $exclusions, 'rows' => [], 'warning' => 'Source rates retain their recorded authority and period. Scenario prices are not public MSRP.'];
        }
        $panels[] = ['title' => 'Review and next step', 'body' => self::text($customer['nextStep'] ?? 'Confirm the declared inputs') . "\n\n" . $exclusions, 'rows' => [], 'warning' => $scope . "\n" . $warning];
        $notes = $disclosure . "\n" . $label . "\n" . $scope . "\n" . $warning . "\n\nSaved evidence and applied versions\n"
            . SavedEvidenceNotes::encode(['revisionId' => $snapshot['revisionId'] ?? '', 'confirmedAt' => $snapshot['confirmedAt'] ?? '', 'versions' => $e['versions'] ?? [], 'customer' => $customer, 'input' => $input, 'evaluation' => $e]);
        return [
            'description' => compact('panels', 'notes', 'disclosure'),
            'layout' => [
                'title' => self::text($customer['name'] ?? 'Subscription comparison'),
                'basis' => $basis, 'months' => $months, 'percentage' => self::text($e['termPercent'] ?? 'N/A'),
                'scope' => self::text($customer['scope'] ?? 'Declared comparison scope'),
                'offeringIds' => $offeringIds, 'groupRows' => $groupRows, 'poolRows' => $poolRows, 'costRows' => $costRows,
                'nextStep' => self::text($customer['nextStep'] ?? 'Confirm the declared inputs'),
                'exclusions' => array_values(array_map(self::text(...), is_array($e['exclusions'] ?? null) ? $e['exclusions'] : [])),
                'label' => $label, 'warning' => $warning, 'notes' => $notes, 'disclosure' => $disclosure,
            ],
        ];
    }

    /** @return array<string,mixed> */
    private static function record(mixed $value): array
    {
        if (!is_array($value) || array_is_list($value)) {
            throw new UnexpectedValueException('Missing saved scenario record.');
        }
        return $value;
    }

    /** @return list<array<string,mixed>> */
    private static function records(mixed $value): array
    {
        if (!is_array($value) || !array_is_list($value) || count($value) > 2000) {
            throw new UnexpectedValueException('Invalid saved scenario list.');
        }
        return array_map(self::record(...), $value);
    }

    private static function text(mixed $value, int $maximum = 20000): string
    {
        if (!is_scalar($value) || !mb_check_encoding((string) $value, 'UTF-8') || mb_strlen((string) $value) > $maximum || preg_match('/[\x00-\x08\x0b\x0c\x0e-\x1f\x{FFFE}\x{FFFF}]/u', (string) $value)) {
            throw new UnexpectedValueException('Invalid saved presentation text.');
        }
        return (string) $value;
    }

    private static function money(mixed $value, bool $signed = false): string
    {
        if (!is_string($value) || preg_match($signed ? '/^-?\d{1,15}\.\d{2}$/D' : '/^\d{1,15}\.\d{2}$/D', $value) !== 1) {
            throw new UnexpectedValueException('Malformed saved monetary amount.');
        }
        return $value;
    }

    private static function number(mixed $value): string
    {
        $text = self::text($value);
        return preg_replace('/\B(?=(\d{3})+(?!\d))/', ',', $text) ?? $text;
    }
}
