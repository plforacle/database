<?php

declare(strict_types=1);

namespace App\Application\Extraction;

use App\Domain\Analysis\AnalysisRepository;
use App\Domain\Analysis\AnalysisState;
use App\Domain\Audit\AuditAction;
use App\Domain\Audit\AuditRepository;
use App\Domain\Extraction\ExtractionEvidence;
use App\Domain\Extraction\ExtractionResult;
use App\Domain\Shared\Actor;
use App\Domain\Shared\RequestId;
use App\Domain\Shared\ResourceNotFound;
use App\Domain\Shared\RevisionId;
use App\Infrastructure\Persistence\PdoTransaction;

final readonly class ExtractCandidates
{
    public function __construct(
        private PdoTransaction $transaction,
        private AnalysisRepository $analyses,
        private AuditRepository $audit,
        private Extractor $extractor,
        private Actor $actor,
    ) {
    }

    public function execute(RevisionId $revisionId, RequestId $requestId): ExtractionResult
    {
        $draft = $this->transaction->run(fn (): ?array => $this->analyses->findDraftForSubject($revisionId, $this->actor));
        if ($draft === null) {
            throw ResourceNotFound::because('The owned draft analysis revision was not found.');
        }
        try {
            $result = $this->extractor->extract($draft['source'], $requestId);
            $state = AnalysisState::NEEDS_REVIEW;
            $action = AuditAction::EXTRACTION_COMPLETED;
        } catch (\RuntimeException) {
            $result = new ExtractionResult(ExtractionEvidence::manual(), []);
            $state = AnalysisState::DRAFT;
            $action = AuditAction::EXTRACTION_FAILED;
        }

        return $this->transaction->run(function () use ($revisionId, $requestId, $result, $state, $action): ExtractionResult {
            $this->analyses->recordExtraction($revisionId, $this->actor, $result, $state);
            $this->audit->append($revisionId, $this->actor, $action, AnalysisState::DRAFT, $state, $requestId);

            return $result;
        });
    }

    /** @param list<array<string, mixed>> $lines */
    public function acceptManual(RevisionId $revisionId, array $lines, RequestId $requestId): ExtractionResult
    {
        $draft = $this->transaction->run(fn (): ?array => $this->analyses->findDraftForSubject($revisionId, $this->actor));
        if ($draft === null) {
            throw ResourceNotFound::because('The owned draft analysis revision was not found.');
        }
        $result = (new AcceptManualCandidates())->accept($draft['source'], $lines);

        return $this->transaction->run(function () use ($revisionId, $requestId, $result): ExtractionResult {
            $this->analyses->recordExtraction($revisionId, $this->actor, $result, AnalysisState::NEEDS_REVIEW);
            $this->audit->append($revisionId, $this->actor, AuditAction::EXTRACTION_COMPLETED, AnalysisState::DRAFT, AnalysisState::NEEDS_REVIEW, $requestId);

            return $result;
        });
    }
}
