<?php

declare(strict_types=1);

namespace App\Application\Extraction;

use App\Domain\Extraction\ExtractionEvidence;
use App\Domain\Extraction\ExtractionResult;
use App\Domain\Shared\RedactedSourceText;
use JsonException;

final readonly class AcceptManualCandidates
{
    private ExtractionContract $contract;

    public function __construct()
    {
        $this->contract = new ExtractionContract();
    }

    /** @param list<array<string, mixed>> $lines */
    public function accept(RedactedSourceText $source, array $lines): ExtractionResult
    {
        try {
            $inner = json_encode(['lines' => $lines], JSON_THROW_ON_ERROR);
        } catch (JsonException) {
            throw InvalidExtractionResponse::because('manual candidates cannot be encoded.');
        }

        return new ExtractionResult(ExtractionEvidence::manual(), $this->contract->validate($source, $inner));
    }
}
