<?php

declare(strict_types=1);

namespace App\Application\Coverage;

use App\Domain\Shared\DomainViolation;

/** Converts the business editor's scalar fields; calculation authority stays in the normalizer. */
final class ScenarioForm
{
    private const PATHS = [
        'customer\.(name|objective|scope|nextStep)', 'mode', 'period\.(months|currency|startDate|endDate|dateLocale|inclusiveEnd|model|constantRateConfirmed|evidence|asOfDate)',
        'scope\.(label|state|evidence|reduced)',
        'groups\.\d+\.(id|label|populationKey|systemIds|systems|cpusPerSystem|deployment|offering|olamRequired|workstationScope|coverage\.(state|evidence))',
        'lines\.\d+\.(id|sourceId|sku|description|adoptedDescription|identityState|identityEvidence|rowType|selected|quantity|quantityBasis|groupIds|subscriptionId|poolId|organization|startDate|endDate|selectionReason|priceRecordId|suppliedTotal|suppliedTotalBasis|suppliedTotalCurrency|(coverage|quantityState)\.(state|evidence)|sourceEstate\.(deployment|systems|cpusPerSystem|guests|managedNodes|prerequisiteEvidence|duplicateEvidence)|price\.(id|amount|currency|metric|periodBasis|termMonths|basis|verification|evidence|reason|effectiveOn|observedOn|installments)|vmware\.(intent|quantityMode|productVersion|metric|(sizing|retirement|commercialPolicy)\.(state|evidence|date|commitmentEnd|version|minimum|step|scope)|features\.\d+\.(name|status|evidence|costIds)|sourceHosts\.\d+\.(id|cpus)))',
        'pools\.\d+\.(id|groupIds|uniqueNodes|coverage\.(state|evidence)|allocations\.\d+\.(groupId|pairs)|extraPurchases\.\d+\.(id|offering|units))',
        'otherCosts\.\d+\.(id|label|sku|groupIds|side|required|price\.(id|amount|currency|metric|periodBasis|termMonths|basis|verification|evidence|reason|installments))',
    ];

    /** @param array<string,mixed> $base
     * @param array<string,mixed> $fields
     * @return array<string,mixed>
     */
    public static function apply(array $base, array $fields): array
    {
        if (count($fields) > 5000) {
            throw DomainViolation::because('The editor contains too many fields.');
        }
        foreach ($fields as $path => $value) {
            if (!is_string($value) || preg_match('/^(?:' . implode('|', self::PATHS) . ')$/D', $path) !== 1) {
                throw DomainViolation::because('The editor contains an unsupported field. Approval identities and computed values are server-owned.');
            }
            $parts = explode('.', $path);
            $leaf = end($parts);
            if (in_array($leaf, ['selected', 'required', 'olamRequired', 'constantRateConfirmed', 'reduced', 'inclusiveEnd'], true)) {
                if (!in_array($value, ['', '0', '1'], true)) {
                    throw DomainViolation::because('Select an explicit yes, no or unknown review value.');
                }
                $value = $value === '' ? null : $value === '1';
            } elseif (in_array($leaf, ['months', 'termMonths'], true)) {
                if (!in_array($value, ['12', '36'], true)) {
                    throw DomainViolation::because('Select a 12 or 36 month comparison.');
                }
                $value = (int) $value;
            } elseif ($leaf === 'installments') {
                $value = trim($value) === '' ? [] : array_map(static fn (string $amount): ?string => trim($amount) === '' ? null : trim($amount), explode(',', $value));
            } elseif (in_array($leaf, ['groupIds', 'systemIds', 'costIds', 'cpus'], true)) {
                $value = trim($value) === '' ? [] : array_values(array_filter(array_map('trim', explode(',', $value)), static fn (string $part): bool => $part !== ''));
            }
            $target = & $base;
            foreach ($parts as $index => $part) {
                if ($index === count($parts) - 1) {
                    $target[$part] = $value;
                    break;
                }
                if (!isset($target[$part]) || !is_array($target[$part])) {
                    $target[$part] = [];
                }
                $target = & $target[$part];
            }
            unset($target);
        }
        foreach ($base['lines'] ?? [] as $index => $line) {
            if (is_array($line) && isset($line['price']) && is_array($line['price']) && trim((string) ($line['price']['amount'] ?? '')) === '') {
                $base['lines'][$index]['price'] = null;
            }
        }
        return $base;
    }
}
