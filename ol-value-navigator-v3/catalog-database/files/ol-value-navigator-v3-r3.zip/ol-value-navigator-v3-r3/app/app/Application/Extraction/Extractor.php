<?php

declare(strict_types=1);

namespace App\Application\Extraction;

use App\Domain\Extraction\ExtractionResult;
use App\Domain\Shared\RedactedSourceText;
use App\Domain\Shared\RequestId;

interface Extractor
{
    public function extract(RedactedSourceText $source, RequestId $requestId): ExtractionResult;
}
