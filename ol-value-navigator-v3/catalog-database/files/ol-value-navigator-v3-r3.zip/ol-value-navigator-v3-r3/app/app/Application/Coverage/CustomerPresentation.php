<?php

declare(strict_types=1);

namespace App\Application\Coverage;

use App\Application\Presentation\PresentationExporter;

/** Stable export API for saved comparisons. */
final class CustomerPresentation
{
    /** @param array<string,mixed> $snapshot */
    public function export(array $snapshot, int $slideCount = 4): string
    {
        return (new PresentationExporter())->export($snapshot, $slideCount);
    }
}
