<?php

declare(strict_types=1);

namespace App\Application\Presentation;

use App\Application\Coverage\SavedResultContract;
use UnexpectedValueException;

/**
 * Composes the existing layouts from saved facts; never writes XML or opens IO.
 *
 * @phpstan-import-type Prepared from LegacyPresentationContent
 * @phpstan-import-type Layout from ScenarioPresentationContent
 * @phpstan-import-type Operation from PresentationDocument
 * @phpstan-import-type TextOperation from PresentationDocument
 * @phpstan-import-type TableOperation from PresentationDocument
 */
final class PresentationComposer
{
    /** @param array<string,mixed> $snapshot */
    public function compose(array $snapshot, int $slideCount): PresentationDocument
    {
        SavedResultContract::validate($snapshot);
        if (!in_array($slideCount, [3, 4, 5], true)) {
            throw new UnexpectedValueException('Choose 3, 4 or 5 slides.');
        }
        if (($snapshot['input']['schemaVersion'] ?? '') === '1.3.1') {
            return $this->scenario((new ScenarioPresentationContent())->forLayout($snapshot, $slideCount), $slideCount);
        }
        $data = (new LegacyPresentationContent())->prepare($snapshot);
        $slides = [];
        if ($slideCount >= 4) {
            $slides[] = $this->scope($data);
        }
        $slides[] = $this->costs($data);
        $slides[] = $this->capacity($data);
        if ($slideCount === 5) {
            $slides[] = $this->sources($data);
        }
        $slides[] = $this->decision($data, $slideCount === 3);
        return PresentationDocument::fromArray(['format' => 'presentation-document-1', 'slides' => $slides, 'notes' => array_fill(0, $slideCount, $data['notes']), 'disclosure' => $data['disclosure']]);
    }

    /** @param Layout $data */
    private function scenario(array $data, int $slideCount): PresentationDocument
    {
        $slides = [];
        if ($slideCount >= 4) {
            $slides[] = $this->scenarioScope($data);
        }
        $slides[] = $this->scenarioCosts($data);
        $slides[] = $this->scenarioCapacity($data);
        if ($slideCount === 5) {
            $slides[] = $this->scenarioExclusions($data);
        }
        $slides[] = $this->scenarioDecision($data);
        $notes = array_fill(0, $slideCount, 'The complete saved evidence is in slide 1 speaker notes. All inventory, prices, assumptions and text references are preserved there.');
        $notes[0] = $data['notes'];
        return PresentationDocument::fromArray(['format' => 'presentation-document-1', 'slides' => $slides, 'notes' => $notes, 'disclosure' => $data['disclosure']]);
    }

    /** @param Layout $data
     * @return list<Operation>
     */
    private function scenarioScope(array $data): array
    {
        $rows = $this->inventoryRows($data['groupRows'], [4.2, 1.75, 1.75, 4.3]);
        $shown = count($rows) - 1;
        $total = count($data['groupRows']) - 1;
        $offeringExcerpts = false;
        foreach ($rows as $i => &$row) {
            if ($i === 0) {
                continue;
            }
            $bounded = $this->excerpt($row[3], 4.05, 16, 2);
            $normalized = trim(preg_replace('/\s+/u', ' ', $row[3]) ?? $row[3]);
            if (str_replace("\n", ' ', $bounded) !== $normalized) {
                $offering = $this->offeringExcerpt('ID excerpt: ', $data['offeringIds'][$i - 1])
                    . "\n" . $this->offeringExcerpt('Description: ', $row[3]);
                $offeringExcerpts = true;
            } else {
                $offering = $bounded;
            }
            $row = [$row[0], $row[1], $row[2], $offering];
        }
        unset($row);
        $notice = $offeringExcerpts
            ? 'Labels may be excerpts. Complete offering IDs, descriptions and other text in notes.'
            : 'Title, labels and scope may be shortened. Complete inventory and text in notes.';
        return [
            $this->heading($this->excerpt($data['title'], 12.1, 32, 1)),
            $this->box($this->basis($data), .6, 1.5, 12, .35, 18),
            $this->box($this->excerpt($data['scope'], 12, 18, 2), .6, 1.93, 12, .65, 18),
            $this->box('Showing ' . $shown . ' of ' . $total . ' target groups. ' . $notice, .6, 2.58, 12, .25, 14),
            $this->table($rows, .6, 2.88, [4.2, 1.75, 1.75, 4.3], .61, 16),
            $this->scenarioWarning($data['warning']),
        ];
    }

    /** @param Layout $data
     * @return list<Operation>
     */
    private function scenarioCosts(array $data): array
    {
        return [
            $this->heading('Subscription costs · ' . $data['months'] . ' months'),
            $this->box($this->basis($data) . ' · Difference ' . $data['percentage'] . '%', .6, 1.5, 12, .5, 18),
            $this->box('Annualized amounts for prepaid prices are display equivalents, not annual invoices.', .6, 2.04, 12, .55, 18),
            $this->table($data['costRows'], .6, 2.8, [4.1, 2.63, 2.63, 2.64], .84, 16),
            $this->scenarioWarning($data['warning']),
        ];
    }

    /** @param Layout $data
     * @return list<Operation>
     */
    private function scenarioCapacity(array $data): array
    {
        $content = [
            $this->heading('Automation support capacity'),
            $this->box('Concurrent capacity is not multiplied by the financial term. No extra support pairs are purchased automatically.', .6, 1.28, 12, .85, 18),
        ];
        $rows = $this->inventoryRows($data['poolRows'], [4.3, 1.75, 1.8, 4.15]);
        $total = count($data['poolRows']) - 1;
        if ($total > 0) {
            $content[] = $this->box('Showing ' . (count($rows) - 1) . ' of ' . $total . ' pools. Identifiers may be shortened. Complete inventory in notes.', .6, 2.58, 12, .25, 14);
            $content[] = $this->table($rows, .6, 2.88, [4.3, 1.75, 1.8, 4.15], .61, 16);
        }
        $content[] = $this->scenarioWarning($total === 0 ? 'OLAM is not applicable to this selected scope.' : $data['warning']);
        return $content;
    }

    /** @param Layout $data
     * @return list<Operation>
     */
    private function scenarioExclusions(array $data): array
    {
        $content = [
            $this->heading('Scope, prices and exclusions'),
            $this->box($data['label'], .6, 1.5, 12, .35, 18, true),
            $this->box($this->basis($data), .6, 1.94, 12, .35, 18),
            $this->box('Recorded exclusions', .6, 2.4, 12, .4, 18, true),
        ];
        foreach (array_slice($data['exclusions'], 0, 3) as $i => $exclusion) {
            $content[] = $this->box($this->excerpt(($i + 1) . '. ' . $exclusion, 12, 18, 2), .6, 3.1 + $i * .91, 12, .65, 18);
        }
        $content[] = $this->box($data['exclusions'] === [] ? 'No explicit exclusions recorded.' : 'Showing ' . min(3, count($data['exclusions'])) . ' of ' . count($data['exclusions']) . ' exclusions as excerpts. Complete wording and all exclusions are in notes.', .6, 5.84, 12, .4, 14);
        $content[] = $this->scenarioWarning('Source rates retain their recorded authority and period. Scenario prices are not public MSRP.');
        return $content;
    }

    /** @param Layout $data
     * @return list<Operation>
     */
    private function scenarioDecision(array $data): array
    {
        $nextStep = $this->excerpt($data['nextStep'], 12, 18, 2);
        $limit = str_ends_with($nextStep, '…') ? 2 : 3;
        $content = [
            $this->heading('Review and next step'),
            $this->box($this->basis($data), .6, 1.5, 12, .35, 18),
            $this->box('Next step', .6, 2.04, 12, .35, 18, true),
            $this->box($nextStep, .6, 2.5, 12, .65, 18),
            $this->box('Recorded exclusions', .6, 3.55, 12, .4, 18, true),
        ];
        foreach (array_slice($data['exclusions'], 0, $limit) as $i => $exclusion) {
            $content[] = $this->box($this->excerpt(($i + 1) . '. ' . $exclusion, 12, 18, $limit === 2 ? 2 : 1), .6, 4.01 + $i * ($limit === 2 ? .78 : .52), 12, $limit === 2 ? .65 : .35, 18);
        }
        $content[] = $this->box($data['exclusions'] === [] ? 'No explicit exclusions recorded. Complete next step and saved evidence in notes.' : 'Next step and exclusions shown as excerpts. ' . min($limit, count($data['exclusions'])) . ' of ' . count($data['exclusions']) . ' exclusions visible. Complete wording in notes.', .6, 5.84, 12, .4, 14);
        $content[] = $this->scenarioWarning($data['warning']);
        return $content;
    }

    /** @param Layout $data */
    private function basis(array $data): string
    {
        return $data['basis'] . ' · ' . $data['months'] . ' months · USD';
    }

    /** @return TextOperation */
    private function scenarioWarning(string $warning): array
    {
        return $this->box($warning, .6, 6.4, 12, .6, 16, true, 'B84032');
    }

    /** @param non-empty-list<non-empty-list<string>> $rows
     * @param non-empty-list<float> $widths
     * @return non-empty-list<non-empty-list<string>>
     */
    private function inventoryRows(array $rows, array $widths): array
    {
        $visible = array_slice($rows, 0, 5);
        foreach ($visible as $i => &$row) {
            if ($i > 0) {
                $row[0] = $this->excerpt($row[0], $widths[0] - .25, 16, 2);
            }
        }
        unset($row);
        return $visible;
    }

    private function offeringExcerpt(string $prefix, string $value): string
    {
        $prefixWidth = array_sum(array_map($this->glyphWidth(...), mb_str_split($prefix))) * 16 / 72;
        return $prefix . $this->excerpt($value, 4.05 - $prefixWidth, 16, 1);
    }

    /**
     * Conservative Arial line budgeting for display-only excerpts. Explicit line
     * breaks also bound unbroken identifiers; the full original remains in notes.
     */
    private function excerpt(string $text, float $width, int $size, int $limit): string
    {
        $text = trim(preg_replace('/\s+/u', ' ', $text) ?? $text);
        $characters = mb_str_split($text);
        $lines = [];
        $line = '';
        $used = 0.0;
        $capacity = $width * 72 / $size;
        foreach ($characters as $character) {
            $advance = $this->glyphWidth($character);
            if ($used + $advance > $capacity) {
                if (count($lines) === $limit - 1) {
                    while ($used + 1.0 > $capacity && $line !== '') {
                        $used -= $this->glyphWidth(mb_substr($line, -1));
                        $line = mb_substr($line, 0, -1);
                    }
                    $space = mb_strrpos($line, ' ');
                    if ($space !== false && $space > mb_strlen($line) / 2) {
                        $line = mb_substr($line, 0, $space);
                    }
                    return implode("\n", [...$lines, rtrim($line) . '…']);
                }
                // Prefer word boundaries, retaining every remainder character.
                $space = mb_strrpos($line, ' ');
                $tail = '';
                if ($space !== false && $space > mb_strlen($line) / 2) {
                    $tail = mb_substr($line, $space + 1);
                    $line = mb_substr($line, 0, $space);
                }
                $lines[] = rtrim($line);
                $line = $tail;
                $used = array_sum(array_map($this->glyphWidth(...), mb_str_split($line)));
            }
            if ($line === '' && $character === ' ') {
                continue;
            }
            $line .= $character;
            $used += $advance;
        }
        return implode("\n", [...$lines, rtrim($line)]);
    }

    private function glyphWidth(string $character): float
    {
        if ($character === '@') {
            return 1.1;
        }
        if ($character === '`') {
            return .4;
        }
        if (str_contains(" ilI.,:;!'|", $character)) {
            return .32;
        }
        if (str_contains('MW%&mw', $character)) {
            return 1.0;
        }
        if ($character >= 'A' && $character <= 'Z') {
            return .8;
        }
        return strlen($character) > 1 ? 1.1 : .63;
    }

    /** @param Prepared $data
     * @return list<Operation>
     */
    private function scope(array $data): array
    {
        return [
            $this->box($data['hasPublicYum'] ? 'Oracle Linux cost comparison' : 'Oracle Linux subscription comparison', .6, .5, 12.1, 1.25, 36, true),
            $this->box($data['customer']['name'], .6, 1.9, 12, 1, 28, true, 'B84032'),
            $this->box($this->summary($data['customer']['objective'], 220), .6, 3.0, 11.8, 1.25, 24),
            $this->box('Scope', .6, 4.55, 2, .4, 18, true),
            $this->box($data['customer']['scope'], .6, 5.05, 11.8, 1.2, 19),
        ];
    }

    /** @param Prepared $data
     * @return list<Operation>
     */
    private function costs(array $data): array
    {
        $rows = [
            ['Period · USD', 'Source subscriptions', $data['hasPublicYum'] ? 'Oracle Linux offering' : 'Oracle Linux support'],
            ['Annual', $data['totals']['sourceAnnual'], $data['totals']['oracleAnnual']],
            ['Three years', $data['totals']['sourceThreeYear'], $data['totals']['oracleThreeYear']],
            ['Five years', $data['totals']['sourceFiveYear'], $data['totals']['oracleFiveYear']],
        ];
        return [
            $this->heading('Subscription cost comparison'),
            $this->table($rows, .6, 1.6, [3.3, 4.4, 4.4], .65, 21),
            $this->box('Annual difference · source less Oracle', .6, 4.5, 8, .5, 20, true),
            $this->box($data['totals']['savingsAnnual'] . ' USD', .6, 5.03, 9, .7, 32, true, 'B84032'),
            $data['warning'] !== ''
                ? $this->box($data['warning'], .6, 5.95, 12, .9, 18, true, 'B84032')
                : $this->box('Saved comparison values. Constant quantities and annual USD prices across each period. Source price basis and provenance appear in speaker notes.', .6, 6.03, 12, .65, 15),
        ];
    }

    /** @param Prepared $data
     * @return list<Operation>
     */
    private function capacity(array $data): array
    {
        $finalCapacity = $data['meta']['capacityBasis'] === 'FINAL';
        $rows = [['Population / offering', 'Support units', $finalCapacity ? 'OLAM nodes / final capacity' : 'OLAM demand / base capacity', 'Extra units / annual USD']];
        foreach ($data['groups'] as $group) {
            $capacity = $group['demand'] . ' / ' . $group['capacity'];
            if ($group['olamStatus'] === 'GAP_REQUIRES_REVIEW') {
                $capacity .= "\nGap: " . $group['shortfall'] . ' node' . ($group['shortfall'] === '1' ? '' : 's');
            }
            $rows[] = [$this->summary($group['label'], 23) . "\n" . $this->summary($group['offering'], 23), $group['supportUnits'], $capacity, $group['additionalUnits'] . ' / ' . $group['additionalCost']];
        }
        return [
            $this->heading('Coverage and OLAM capacity'),
            $this->table($rows, .6, 1.5, [4.2, 1.5, 3.0, 3.4], .69, 16),
            $data['warning'] !== ''
                ? $this->box($data['warning'] . ($data['hasCapacityGap'] ? ' Final capacity includes purchased extra pairs.' : ''), .6, 5.85, 12, .98, 17, true, 'B84032')
                : $this->box($finalCapacity
                    ? 'OLAM: Oracle Linux Automation Manager. Final capacity includes purchased extra pairs. Nodes are unique managed instances; N/A means not requested. Extra support is included once in the Oracle total.'
                    : 'OLAM: Oracle Linux Automation Manager. Base capacity precedes extra support. Demand/capacity are managed instances; N/A means not requested. Extra support is included once in the Oracle total.', .6, 5.9, 12, .9, 17),
        ];
    }

    /** @param Prepared $data
     * @return list<Operation>
     */
    private function sources(array $data): array
    {
        $rows = [['Source subscription', 'Quantity / unit', 'Annual USD']];
        foreach ($data['lines'] as $line) {
            $rows[] = [$this->summary($line['sku'], 30), $line['quantity'] . ' / ' . $this->summary($line['unit'], 15), $line['annualCost']];
        }
        return [
            $this->heading('Source subscription basis'),
            $this->table($rows, .6, 1.45, [5.2, 3.5, 3.4], .44, 15),
            $this->box('Descriptions, price basis and provenance are preserved in the speaker notes.', .6, 6.5, 12, .35, 14),
        ];
    }

    /** @param Prepared $data
     * @return list<Operation>
     */
    private function decision(array $data, bool $includeScope): array
    {
        $content = [$this->heading('Scope and next decision')];
        $y = 1.5;
        if ($includeScope) {
            $content[] = $this->box($this->summary($data['customer']['name'] . ' — ' . $data['customer']['objective'], 140), .6, $y, 12, .9, 20, true);
            $content[] = $this->box($this->summary($data['customer']['scope'], 220), .6, 2.4, 12, .9, 17);
            $y = 3.35;
        }
        $content[] = $this->box('Next step', .6, $y, 3, .4, 18, true, 'B84032');
        $content[] = $this->box($this->summary($data['customer']['nextStep'], 180), .6, $y + .45, 12, .8, 19);
        $exclusions = $data['exclusions'] === [] ? 'No explicit population exclusions recorded.' : implode('; ', $data['exclusions']);
        $content[] = $this->box('Exclusions: ' . $this->summary($exclusions, $includeScope ? 300 : 700), .6, $y + 1.35, 12, $includeScope ? 1.2 : 2.5, $includeScope ? 15 : 18);
        $trace = 'Catalog: ' . $data['meta']['catalogVersion'] . "\nRule: " . $data['meta']['ruleVersion']
            . "\nRevision: " . $data['meta']['revisionId'] . ' · Confirmed: ' . $data['meta']['confirmedAt'];
        if ($data['meta']['capacityBasis'] === 'FINAL') {
            $trace = 'Mapping: ' . $data['meta']['mappingVersion'] . ' · Prices: ' . $data['meta']['priceVersion']
                . "\nRule: " . $data['meta']['ruleVersion'] . "\nRevision: " . $data['meta']['revisionId'] . ' · Confirmed: ' . $data['meta']['confirmedAt'];
        }
        $content[] = $this->box($trace, .6, 6.02, 12, .83, 13);
        return $content;
    }

    private function summary(string $text, int $limit): string
    {
        return mb_strlen($text) <= $limit ? $text : mb_substr($text, 0, $limit - 1) . '…';
    }

    /** @return TextOperation */
    private function heading(string $title): array
    {
        return $this->box($title, .6, .5, 12.1, .85, 32, true);
    }

    /** @param positive-int $size
     * @return TextOperation
     */
    private function box(string $text, float $x, float $y, float $w, float $h, int $size, bool $bold = false, string $color = '282923'): array
    {
        return ['kind' => 'text', 'text' => $text, 'x' => $x, 'y' => $y, 'w' => $w, 'h' => $h, 'size' => $size, 'bold' => $bold, 'color' => $color];
    }

    /** @param non-empty-list<non-empty-list<string>> $rows
     * @param non-empty-list<float> $widths
     * @param positive-int $size
     * @return TableOperation
     */
    private function table(array $rows, float $x, float $y, array $widths, float $rowHeight, int $size): array
    {
        return ['kind' => 'table', 'rows' => $rows, 'x' => $x, 'y' => $y, 'widths' => $widths, 'rowHeight' => $rowHeight, 'size' => $size];
    }
}
