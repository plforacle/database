<?php

declare(strict_types=1);

namespace App\Application\Package;

use App\Domain\Package\PackageEnvelope;

/**
 * Pure application boundary; caller supplies all bytes and supported contracts.
 * @phpstan-import-type Profiles from PackageEnvelope
 * @phpstan-import-type MemberSchemas from PackageEnvelope
 */
final readonly class PackageEnvelopeDecoder
{
    /**
     * @param Profiles $supportedProfiles
     * @param MemberSchemas $supportedMemberSchemas
     */
    public function __construct(private array $supportedProfiles, private array $supportedMemberSchemas)
    {
    }

    public function decode(string $manifestJson, string $mappingJson, string $priceJson): PackageEnvelope
    {
        return PackageEnvelope::fromJson(
            $manifestJson,
            $mappingJson,
            $priceJson,
            $this->supportedProfiles,
            $this->supportedMemberSchemas,
        );
    }
}
