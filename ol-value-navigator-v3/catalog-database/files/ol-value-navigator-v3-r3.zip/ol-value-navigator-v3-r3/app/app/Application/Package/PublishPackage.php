<?php

declare(strict_types=1);

namespace App\Application\Package;

use App\Domain\Package\CatalogPackageContract;
use App\Domain\Package\PackageEnvelope;
use App\Domain\Shared\DomainViolation;
use App\Infrastructure\Persistence\PdoPackageRepository;
use App\Infrastructure\Persistence\PdoTransaction;
use PDO;
use PDOException;

final readonly class PublishPackage
{
    public function __construct(private PDO $pdo, private PackagePublisherPrincipal $principal)
    {
    }

    /** @return array{outcome:string,releaseId:string,manifestSha256:string,publisher:string} */
    public function execute(string $manifest, string $mapping, string $price, string $acceptance, string $approvalReference): array
    {
        $publisher = $this->principal->authenticatedIdentifier();
        PdoPackageRepository::evidenceReference($approvalReference);
        $envelope = PackageEnvelope::fromJson($manifest, $mapping, $price, CatalogPackageContract::PROFILES, CatalogPackageContract::MEMBER_SCHEMAS);
        $package = (new CatalogPackageValidator())->validate($envelope);
        $admission = (new PackageAcceptanceRunner())->verify($package, $acceptance);
        $evidence = json_encode($admission, JSON_THROW_ON_ERROR);
        if ($this->pdo->inTransaction() || strlen($evidence) > 65536) {
            throw DomainViolation::because('Package publication requires its own bounded transaction.');
        }
        try {
            $outcome = (new PdoTransaction($this->pdo))->run(function () use ($envelope, $acceptance, $admission, $evidence, $publisher, $approvalReference): string {
                $existing = $this->pdo->prepare('SELECT release_id FROM package_release WHERE release_id=?');
                $existing->execute([$envelope->releaseId()]);
                if ($existing->fetchColumn() !== false) {
                    $retained = (new PdoPackageRepository($this->pdo))->readRelease($envelope->releaseId());
                    if ($retained['package']->envelope()->manifestJson() !== $envelope->manifestJson()
                        || $retained['package']->envelope()->member('mappings')->json() !== $envelope->member('mappings')->json()
                        || $retained['package']->envelope()->member('prices')->json() !== $envelope->member('prices')->json()
                        || $retained['acceptanceJson'] !== $acceptance || $retained['admission'] !== $admission
                        || $retained['publisher'] !== $publisher || $retained['approvalReference'] !== $approvalReference) {
                        throw DomainViolation::because('Package release conflicts with retained publication.');
                    }
                    return 'unchanged';
                }
                foreach (['mappings', 'prices'] as $kind) {
                    $member = $envelope->member($kind);
                    $select = $this->pdo->prepare('SELECT schema_version,sha256,CASE WHEN OCTET_LENGTH(json_bytes)<=8388608 THEN json_bytes END AS json_bytes FROM package_member WHERE kind=? AND member_id=?');
                    $select->execute([$kind, $member->id()]);
                    $row = $select->fetch(PDO::FETCH_ASSOC);
                    if (is_array($row)) {
                        if ($row['schema_version'] !== $member->schemaVersion() || $row['sha256'] !== $member->digest() || $row['json_bytes'] !== $member->json()) {
                            throw DomainViolation::because('Package member conflicts with retained publication.');
                        }
                    } else {
                        $this->pdo->prepare('INSERT INTO package_member(kind,member_id,schema_version,sha256,json_bytes) VALUES(?,?,?,?,?)')
                            ->execute([$kind, $member->id(), $member->schemaVersion(), $member->digest(), $member->json()]);
                    }
                }
                $this->pdo->prepare('INSERT INTO package_release(release_id,manifest_bytes,manifest_sha256,mapping_id,price_id,publisher) VALUES(?,?,?,?,?,?)')
                    ->execute([$envelope->releaseId(), $envelope->manifestJson(), $envelope->manifestDigest(), $envelope->member('mappings')->id(), $envelope->member('prices')->id(), $publisher]);
                $this->pdo->prepare('INSERT INTO package_admission(release_id,acceptance_bytes,acceptance_sha256,evidence_bytes,evidence_sha256,publisher,approval_reference) VALUES(?,?,?,?,?,?,?)')
                    ->execute([$envelope->releaseId(), $acceptance, hash('sha256', $acceptance), $evidence, hash('sha256', $evidence), $publisher, $approvalReference]);
                return 'published';
            });
        } catch (PDOException) {
            throw DomainViolation::because('Package publication failed without changing retained releases.');
        }
        return ['outcome' => $outcome, 'releaseId' => $envelope->releaseId(), 'manifestSha256' => $envelope->manifestDigest(), 'publisher' => $publisher];
    }
}
