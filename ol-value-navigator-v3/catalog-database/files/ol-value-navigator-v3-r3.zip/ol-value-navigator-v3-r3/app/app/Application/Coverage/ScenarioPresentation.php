<?php

declare(strict_types=1);

namespace App\Application\Coverage;

use App\Application\Presentation\ScenarioPresentationContent;

/** Stable saved-scenario presentation API. */
final class ScenarioPresentation
{
    /** @param array<string,mixed> $snapshot
     * @return array{panels:list<array{title:string,body:string,rows:list<non-empty-list<string>>,warning:string}>,notes:string,disclosure:string}
     */
    public function describe(array $snapshot, int $slideCount): array
    {
        return (new ScenarioPresentationContent())->describe($snapshot, $slideCount);
    }
}
