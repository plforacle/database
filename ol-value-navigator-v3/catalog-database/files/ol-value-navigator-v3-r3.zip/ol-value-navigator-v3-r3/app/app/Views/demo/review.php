<?php

declare(strict_types=1);

/** @var array<string, mixed> $data */
/** @var callable(mixed): string $escape */
$csrfToken = is_string($data['csrfToken'] ?? null) ? $data['csrfToken'] : '';
$analysisId = is_string($data['analysisId'] ?? null) ? $data['analysisId'] : '';
$revisionId = is_string($data['revisionId'] ?? null) ? $data['revisionId'] : '';
$state = $data['state'] ?? null;
$lines = is_array($data['lines'] ?? null) ? $data['lines'] : [];
$ready = $state === \App\Domain\Analysis\AnalysisState::READY_TO_CALCULATE;
$stateLabel = match ($state) {
    \App\Domain\Analysis\AnalysisState::READY_TO_CALCULATE => 'Ready to calculate',
    \App\Domain\Analysis\AnalysisState::INCOMPLETE => 'Incomplete — totals withheld',
    default => 'Human review required',
};
?>
<p class="eyebrow">Steps 3–4 · Governed validation and resolution</p>
<h1>Resolve every candidate before a total can exist.</h1>
<p class="lede">Confirm an exact synthetic SKU, correct only SKU and quantity, or exclude the line with a reason. Descriptions, units, prices, mappings, and catalog identity are server-owned.</p>
<div class="state-callout <?= $ready ? 'state-callout--ready' : 'state-callout--warning' ?>"><strong><?= $escape($stateLabel) ?></strong><span>Revision <code><?= $escape($revisionId) ?></code></span></div>

<div class="line-stack">
<?php foreach ($lines as $line): ?>
    <?php
    if (!is_array($line)) {
        continue;
    }
    $lineId = is_string($line['lineId'] ?? null) ? $line['lineId'] : '';
    $identifier = is_string($line['extractedIdentifier'] ?? null) ? $line['extractedIdentifier'] : 'No SKU supplied';
    $quantity = is_string($line['quantity'] ?? null) ? $line['quantity'] : '';
    $decision = $line['decision'] ?? null;
    $pending = $decision === \App\Domain\Analysis\LineDecision::PENDING;
    $included = in_array($decision, [\App\Domain\Analysis\LineDecision::CONFIRMED, \App\Domain\Analysis\LineDecision::CORRECTED_CONFIRMED], true);
    $selected = is_string($line['selectedOptionSku'] ?? null) ? $line['selectedOptionSku'] : null;
    ?>
    <article class="line-docket">
        <header><div><span class="line-id"><?= $escape($lineId) ?></span><h2><?= $escape($identifier) ?></h2></div><span class="decision-chip"><?= $escape($decision instanceof \App\Domain\Analysis\LineDecision ? $decision->name : 'UNKNOWN') ?></span></header>
        <dl class="line-facts"><div><dt>Quantity</dt><dd><?= $escape($quantity !== '' ? $quantity : 'Not supplied') ?></dd></div><div><dt>Match</dt><dd><?= $escape($line['matchState'] ?? '') ?></dd></div><div><dt>Selected option</dt><dd><?= $escape($selected ?? 'None') ?></dd></div></dl>

        <?php if ($pending): ?>
            <div class="decision-grid">
                <form method="post" action="/demo/analyses/<?= $escape($analysisId) ?>/resolve" class="decision-form">
                    <input type="hidden" name="_csrf" value="<?= $escape($csrfToken) ?>"><input type="hidden" name="line_id" value="<?= $escape($lineId) ?>"><input type="hidden" name="decision" value="confirm"><input type="hidden" name="option_sku" value="SYN-OL-BASE">
                    <h3>Confirm exact candidate</h3><p>Server re-matches the submitted identifier and pins the eligible option.</p><button type="submit">Confirm and select option</button>
                </form>
                <form method="post" action="/demo/analyses/<?= $escape($analysisId) ?>/resolve" class="decision-form">
                    <input type="hidden" name="_csrf" value="<?= $escape($csrfToken) ?>"><input type="hidden" name="line_id" value="<?= $escape($lineId) ?>"><input type="hidden" name="decision" value="correct"><input type="hidden" name="option_sku" value="SYN-OL-BASE">
                    <h3>Correct candidate</h3><label for="sku-<?= $escape($lineId) ?>">SKU</label><input id="sku-<?= $escape($lineId) ?>" name="sku" value="SYN-RHEL-BASE" required><label for="quantity-<?= $escape($lineId) ?>">Quantity</label><input id="quantity-<?= $escape($lineId) ?>" name="quantity" value="<?= $escape($quantity) ?>" required><button type="submit">Correct, confirm, and select</button>
                </form>
                <form method="post" action="/demo/analyses/<?= $escape($analysisId) ?>/resolve" class="decision-form">
                    <input type="hidden" name="_csrf" value="<?= $escape($csrfToken) ?>"><input type="hidden" name="line_id" value="<?= $escape($lineId) ?>"><input type="hidden" name="decision" value="exclude">
                    <h3>Exclude line</h3><label for="reason-<?= $escape($lineId) ?>">Reason</label><textarea id="reason-<?= $escape($lineId) ?>" name="exclusion_reason" rows="2" required></textarea><button class="button-secondary" type="submit">Exclude with reason</button>
                </form>
            </div>
        <?php elseif ($included && $selected === null): ?>
            <form method="post" action="/demo/analyses/<?= $escape($analysisId) ?>/resolve" class="action-row">
                <input type="hidden" name="_csrf" value="<?= $escape($csrfToken) ?>"><input type="hidden" name="line_id" value="<?= $escape($lineId) ?>"><input type="hidden" name="decision" value="select"><input type="hidden" name="option_sku" value="SYN-OL-BASE"><button type="submit">Select governed option</button>
            </form>
        <?php endif; ?>
    </article>
<?php endforeach; ?>
</div>

<?php if ($ready): ?>
    <form method="post" action="/demo/analyses/<?= $escape($analysisId) ?>/confirm" class="confirmation-gate">
        <input type="hidden" name="_csrf" value="<?= $escape($csrfToken) ?>">
        <div><p class="eyebrow">Step 5 · Deterministic PHP</p><h2>All included lines are complete.</h2><p>Confirmation writes both sides, changes state, and appends both events atomically.</p></div>
        <button type="submit">Confirm synthetic totals</button>
    </form>
<?php endif; ?>
