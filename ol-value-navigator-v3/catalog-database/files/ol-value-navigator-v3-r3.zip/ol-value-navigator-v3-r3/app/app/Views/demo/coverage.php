<?php

declare(strict_types=1);

/** @var array<string,mixed> $data */
/** @var callable(mixed):string $escape */
$input = is_array($data['input'] ?? null) ? $data['input'] : [];
$customer = is_array($input['customer'] ?? null) ? $input['customer'] : [];
$snapshot = is_array($data['snapshot'] ?? null) ? $data['snapshot'] : [];
$editing = $data['editing'] ?? false;
$historical = $snapshot !== [] && !$editing;
$evaluation = !$editing && is_array($snapshot['evaluation'] ?? null) ? $snapshot['evaluation'] : [];
$groups = is_array($input['groups'] ?? null) ? $input['groups'] : [];
$lines = is_array($input['lines'] ?? null) ? $input['lines'] : [];
$catalog = is_array($data['catalog'] ?? null) ? $data['catalog'] : [];
$offerings = is_array($data['offerings'] ?? null) ? $data['offerings'] : [];
$token = $data['csrfToken'] ?? '';
$partial = is_array($evaluation['partial'] ?? null) ? $evaluation['partial'] : [];
$advisories = is_array($evaluation['advisories'] ?? null) ? $evaluation['advisories'] : [];
$capacityLabels = [
    'NOT_APPLICABLE' => 'Not required',
    'SUFFICIENT_FOR_DECLARED_NODES' => 'Sufficient for declared nodes',
    'GAP_REQUIRES_REVIEW' => 'Support capacity gap',
    'REVIEW_REQUIRED' => 'Managed-node count needs review',
    'COVERED' => 'Covered',
    'COVERED_WITH_ADDITIONAL_SUPPORT' => 'Covered with additional support',
    'BLOCKED' => 'Needs review',
];
$offeringName = static function (mixed $id) use ($offerings): string {
    if (!is_string($id) || $id === '') {
        return 'Unresolved';
    }
    $offering = $offerings[$id] ?? null;
    return is_array($offering) && is_string($offering['description'] ?? null) ? $offering['description'] : $id;
};
$hasOlamGap = false;
foreach ($advisories as $advisory) {
    if (is_array($advisory) && ($advisory['code'] ?? '') === 'OLAM_SUPPORT_CAPACITY_REVIEW') {
        $hasOlamGap = true;
    }
}
// Allocate unused identifiers independently of compacted row positions.
$usedIds = [];
foreach ($groups as $group) {
    if (is_array($group) && is_string($group['id'] ?? null)) {
        $usedIds[] = $group['id'];
    }
}
for ($slot = count($groups); $slot < 5; ++$slot) {
    $candidate = 1;
    while (in_array('group-' . $candidate, $usedIds, true)) {
        ++$candidate;
    }
    $availableId = 'group-' . $candidate;
    $groups[] = ['id' => $availableId];
    $usedIds[] = $availableId;
}
?>
<p><a href="/demo/coverage/new">New v1.3.1 comparison →</a></p>

<p class="eyebrow">Shared coverage · Automation capacity · Customer presentation</p>
<h1>A comparison built around the customer's footprint.</h1>
<p class="lede">Use synthetic customer details and inventory only. SYN-prefixed entries use invented prices and mappings. Red Hat comparisons use the reviewed catalog, public prices and Oracle support requirements. Self-support without supported add-ons starts at Public Yum at no cost; vendor support starts at Basic. Each population uses the lowest qualifying Oracle offering unless you select a higher tier. The separate VMware mapping remains available.</p>
<?php if ($historical): ?>
    <div class="state-callout"><strong><?= $escape(match ($snapshot['state'] ?? '') {
        'READY_TO_CALCULATE' => 'Ready to confirm',
        'CONFIRMED' => 'Confirmed comparison',
        default => ($evaluation['completeness'] ?? '') === 'PARTIAL' ? 'Partial comparison' : 'Comparison needs review',
    }) ?></strong><span>Revision <?= $escape($snapshot['revisionId'] ?? '') ?></span></div>
    <?php if (is_array($evaluation['blockers'] ?? null) && $evaluation['blockers'] !== []): ?>
        <h2>Resolve before confirming the full comparison</h2>
        <ul><?php foreach ($evaluation['blockers'] as $block): ?><li><?= $escape($block) ?></li><?php endforeach; ?></ul>
        <p>The full comparison and PowerPoint remain unavailable while these items need review. Any partial comparison below includes the same complete populations on both sides.</p>
    <?php endif; ?>
    <?php if ($advisories !== []): ?>
        <div class="state-callout state-callout--warning" role="note"><div><strong>Support and scope advisories</strong><ul><?php foreach ($advisories as $advisory): if (!is_array($advisory)) {
            continue;
        } ?><li><?= $escape($advisory['message'] ?? '') ?></li><?php endforeach; ?></ul>
        <?php if ($hasOlamGap): ?><p>This cost scenario does not fully support every declared OLAM node. Only the additional pairs you enter are priced; confirming the comparison preserves this capacity warning.</p><?php endif; ?></div></div>
    <?php endif; ?>
    <table><caption>Complete annual subscription comparison · USD</caption><thead><tr><th>Current subscriptions</th><th>Oracle cost including selected OLAM additions</th><th>Annual difference</th></tr></thead><tbody><tr>
        <td><?= $escape($evaluation['sourceAnnual'] ?? 'Unresolved') ?></td><td><?= $escape($evaluation['oracleAnnual'] ?? 'Unresolved') ?></td><td><?= $escape($evaluation['savingsAnnual'] ?? 'Withheld') ?></td>
    </tr></tbody></table>
    <?php if (isset($evaluation['savingsPercent'])): ?><p>Annual subscription savings: <?= $escape($evaluation['savingsPercent']) ?>% of the included source cost.</p><?php endif; ?>
    <?php if (($evaluation['completeness'] ?? '') === 'PARTIAL' && $partial !== []): ?>
        <table><caption>Partial annual comparison · complete populations only · USD</caption><thead><tr><th>Current subscriptions in scope</th><th>Oracle cost for the same populations</th><th>Annual difference in scope</th></tr></thead><tbody><tr>
            <td><?= $escape($partial['sourceAnnual'] ?? 'Unresolved') ?></td><td><?= $escape($partial['oracleAnnual'] ?? 'Unresolved') ?></td><td><?= $escape($partial['savingsAnnual'] ?? 'Withheld') ?></td>
        </tr></tbody></table>
        <?php if (isset($partial['savingsPercent'])): ?><p>Partial subscription savings: <?= $escape($partial['savingsPercent']) ?>% for these complete populations only.</p><?php endif; ?>
        <?php $partialLabels = [];
        foreach (is_array($evaluation['groups'] ?? null) ? $evaluation['groups'] : [] as $result) {
            if (is_array($result) && in_array($result['id'] ?? '', is_array($partial['groupIds'] ?? null) ? $partial['groupIds'] : [], true)) {
                $partialLabels[] = (string) ($result['label'] ?? $result['id']);
            }
        } ?>
        <?php if ($partialLabels !== []): ?><p>Included populations: <?= $escape(implode(', ', $partialLabels)) ?>.</p><?php endif; ?>
        <p>Populations needing review are omitted from both sides. These figures are not total estate savings and cannot be confirmed or exported as a full comparison.</p>
    <?php endif; ?>
    <p>Annual source reference cost: <?= $escape($evaluation['sourceReferenceAnnual'] ?? 'Unresolved') ?> USD. RHEL add-ons within that amount: <?= $escape($evaluation['rhelAddOnReferenceAnnual'] ?? 'Unresolved') ?> USD. These amounts omit excluded and deferred lifecycle rows; historical prices may require revalidation.</p>
    <p>Three- and five-year projections repeat annual subscription costs without escalation or discounting. Migration, services, hardware and tax are outside this comparison.</p>
    <?php if (is_array($evaluation['groups'] ?? null)): ?>
        <table><caption>Required and selected Oracle offerings</caption><thead><tr><th>Population</th><th>Minimum offering</th><th>Selected offering</th><th>Price comparison</th></tr></thead><tbody>
        <?php foreach ($evaluation['groups'] as $result): if (!is_array($result)) {
            continue;
        } ?>
            <tr><td><?= $escape($result['label'] ?? '') ?></td><td><?= $escape($offeringName($result['minimumOffering'] ?? null)) ?></td><td><?= $escape($result['offeringMetadata']['description'] ?? $offeringName($result['offering'] ?? null)) ?></td><td><?= $escape(($result['complete'] ?? $evaluation['ready'] ?? false) === true ? 'Complete' : 'Needs review') ?></td></tr>
        <?php endforeach; ?></tbody></table>
        <?php if (isset($evaluation['completeness'])): ?>
            <table><caption>Annual price components by population · USD</caption><thead><tr><th>Population</th><th>Source subscriptions</th><th>Oracle including purchased extra pairs</th><th>Annual difference</th></tr></thead><tbody>
            <?php foreach ($evaluation['groups'] as $result): if (!is_array($result)) {
                continue;
            } ?>
                <tr><td><?= $escape($result['label'] ?? '') ?><?php if (($result['complete'] ?? false) !== true): ?><br>Needs review — omitted from comparable totals<?php endif; ?></td><td><?= $escape($result['sourceAnnual'] ?? 'Unresolved') ?></td><td><?= $escape($result['oracleAnnual'] ?? 'Unresolved') ?></td><td><?= $escape(($result['complete'] ?? false) === true ? ($result['savingsAnnual'] ?? 'Withheld') : 'Withheld') ?></td></tr>
            <?php endforeach; ?></tbody></table>
            <p>A known component price does not establish a complete comparison. An incomplete population has no calculated difference and is omitted from both sides of partial totals.</p>
        <?php endif; ?>
        <table><caption>Purchased support and OLAM capacity</caption><thead><tr><th>Population</th><th>System CPU-pair units</th><th>Managed nodes / support capacity</th><th>Extra pairs purchased / annual USD</th><th>Remaining capacity review</th></tr></thead><tbody>
        <?php foreach ($evaluation['groups'] as $result): if (!is_array($result)) {
            continue;
        } ?>
            <tr><td><?= $escape($result['label'] ?? '') ?></td><td><?= $escape($result['supportUnits'] ?? 'Unknown') ?></td><td><?= $escape($result['demand'] ?? (($result['olamStatus'] ?? '') === 'NOT_APPLICABLE' ? 'N/A' : 'Unknown')) ?> / <?= $escape($result['capacity'] ?? '') ?><?php if (!isset($result['supportCapacityStatus']) && ($result['olamStatus'] ?? '') !== 'NOT_APPLICABLE'): ?> base<?php endif; ?></td><td><?= $escape($result['additionalUnits'] ?? '') ?> / <?= $escape($result['additionalCost'] ?? 'Unresolved') ?></td><td><?= $escape($capacityLabels[$result['supportCapacityStatus'] ?? $result['olamStatus'] ?? ''] ?? 'Needs review') ?><?php if (($result['additionalPairsIndicated'] ?? 0) > 0): ?><br><?= $escape($result['additionalPairsIndicated']) ?> further pairs indicated<?php endif; ?></td></tr>
        <?php endforeach; ?></tbody></table>
    <?php endif; ?>
    <details><summary>Price evidence, exclusions and traceability</summary>
        <p>Catalog <?= $escape($snapshot['catalogVersion'] ?? '') ?> · Rule <?= $escape($snapshot['ruleVersion'] ?? '') ?> · Confirmed <?= $escape($snapshot['confirmedAt'] ?? 'Not yet') ?></p>
        <?php if (isset($evaluation['mappingVersion']) || isset($evaluation['priceVersion'])): ?><p>Mapping version <?= $escape($evaluation['mappingVersion'] ?? 'Not recorded') ?> · Price version <?= $escape($evaluation['priceVersion'] ?? 'Not recorded') ?></p><?php endif; ?>
        <?php foreach (is_array($evaluation['lines'] ?? null) ? $evaluation['lines'] : [] as $line): if (!is_array($line)) {
            continue;
        } ?>
            <p><strong><?= $escape($line['sku'] ?? '') ?></strong> · <?= $escape($line['quantity'] ?? 'Unknown') ?> <?= $escape($line['unit'] ?? '') ?> · <?= $escape($line['priceBasis'] ?? '') ?><br><?= $escape($line['provenance'] ?? '') ?></p>
            <?php $metadata = is_array($line['catalogMetadata'] ?? null) ? $line['catalogMetadata'] : []; ?>
            <p><?= $escape($metadata['capabilityRule'] ?? '') ?></p>
            <?php foreach (is_array($line['eligibleOfferingDescriptions'] ?? null) ? $line['eligibleOfferingDescriptions'] : [] as $description): ?>
                <p>Eligible offering: <?= $escape($description) ?></p>
            <?php endforeach; ?>
        <?php endforeach; ?>
        <ul><?php foreach (is_array($evaluation['exclusions'] ?? null) ? $evaluation['exclusions'] : [] as $exclusion): ?><li><?= $escape($exclusion) ?></li><?php endforeach; ?></ul>
        <?php if (is_array($evaluation['reviews'] ?? null) && $evaluation['reviews'] !== []): ?>
            <ul><?php foreach ($evaluation['reviews'] as $review): if (!is_array($review)) {
                continue;
            } ?><li><?= $escape($review['code'] ?? '') ?>: <?= $escape($review['message'] ?? '') ?></li><?php endforeach; ?></ul>
        <?php endif; ?>
        <p><a href="https://www.oracle.com/contracts/docs/lic_definitions_and_rules_v061526.pdf">OLAM policy reference, June 15, 2026, pages 52–53</a>. This fixture grants no commercial entitlement or cross-contract pooling approval.</p>
    </details>
    <?php if (($snapshot['state'] ?? '') === 'READY_TO_CALCULATE' && ($snapshot['catalogContext'] ?? null) !== null): ?>
        <form method="post" action="/demo/coverage/<?= $escape($snapshot['revisionId'] ?? '') ?>/confirm" class="action-row">
            <input type="hidden" name="_csrf" value="<?= $escape($token) ?>"><button type="submit">Confirm reviewed comparison</button>
        </form>
    <?php elseif (($snapshot['state'] ?? '') === 'CONFIRMED'): ?>
        <form method="get" action="/demo/coverage/<?= $escape($snapshot['revisionId'] ?? '') ?>/pptx" class="action-row">
            <label>Presentation length <select name="slides"><option value="3">3 slides · Executive summary</option><option value="4" selected>4 slides · Recommended</option><option value="5">5 slides · Expanded detail</option></select></label>
            <button type="submit">Download editable PowerPoint</button>
        </form>
        <p>Use the successor editor to prepare a new revision.</p>
    <?php endif; ?>
<?php endif; ?>
<?php if ($editing): ?><p>Draft edits have not been saved or calculated. Save and review a new revision to see its results.</p><?php endif; ?>
<?php if (($data['reviewChanged'] ?? false) === true): ?><p>The catalog selection changed since editing. Review this new, unconfirmed revision before confirming.</p><?php endif; ?>
<?php if ($historical): ?><p><a href="/demo/coverage/<?= $escape($snapshot['revisionId']) ?>?edit=1">Edit a successor with the current catalog</a></p>
<?php if (($snapshot['catalogContext'] ?? null) === null): ?><p>Historical catalog details are limited to saved evidence. Save and review a successor before confirming an old draft.</p><?php else: ?><p>Saved release <?= $escape($snapshot['catalogContext']['releaseId']) ?> · Profile <?= $escape($snapshot['catalogContext']['profileId']) ?> · <?= $snapshot['catalogContext']['generation'] === 0 ? 'Bootstrap selection (unactivated)' : 'Selection generation ' . $escape($snapshot['catalogContext']['generation']) ?></p><?php endif; ?>
<?php endif; ?>
<form method="post" action="/demo/coverage" class="docket-form">
    <fieldset<?= $historical ? ' disabled' : '' ?>><legend><?= $historical ? 'Saved inputs' : 'Draft inputs' ?></legend>
    <input type="hidden" name="editorSelection" value="<?= $escape($data['editorSelection'] ?? '') ?>">
    <input type="hidden" name="_csrf" value="<?= $escape($token) ?>">
    <input type="hidden" name="comparisonId" value="<?= $escape($snapshot['comparisonId'] ?? '') ?>">
    <input type="hidden" name="expectedRevision" value="<?= $escape($snapshot['revisionId'] ?? '') ?>">
    <h2>Customer objective and scope</h2>
    <?php foreach (['name' => 'Synthetic customer name', 'objective' => 'Customer objective', 'scope' => 'Comparison scope', 'nextStep' => 'Recommended next step'] as $key => $label): ?>
        <label><?= $escape($label) ?><input name="scenario[customer][<?= $escape($key) ?>]" value="<?= $escape($customer[$key] ?? '') ?>" maxlength="<?= $key === 'name' ? '80' : '300' ?>" required></label>
    <?php endforeach; ?>
    <label>Inventory and assignment review evidence<textarea name="scenario[populationEvidence]" maxlength="1000" rows="3"><?= $escape($input['populationEvidence'] ?? '') ?></textarea></label>
    <p class="field-hint">Confirm distinct populations, homogeneous CPU counts and nonoverlapping entitlements. Every included source row must cover one complete population. Split subscriptions spanning populations explicitly and reconcile their total quantity before entry.</p>
    <h2>Covered populations</h2>
    <p>Paid Oracle support is charged once per population, even when several source subscriptions apply to it. Public yum self-support has no subscription charge. Leave unused populations blank.</p>
    <?php for ($i = 0; $i < 5; ++$i): $g = is_array($groups[$i] ?? null) ? $groups[$i] : [];
        $id = $g['id'] ?? 'group-' . ($i + 1); ?>
        <details<?= isset($g['populationKey']) ? ' open' : '' ?>><summary>Population <?= $i + 1 ?><?= isset($g['label']) ? ' · ' . $escape($g['label']) : ' · Add optional population' ?></summary>
        <input type="hidden" name="scenario[groups][<?= $i ?>][id]" value="<?= $escape($id) ?>">
        <?php foreach (['label' => 'Display name', 'populationKey' => 'Unique inventory population identifier'] as $key => $label): ?>
            <label><?= $escape($label) ?><input name="scenario[groups][<?= $i ?>][<?= $escape($key) ?>]" maxlength="80" value="<?= $escape($g[$key] ?? '') ?>"></label>
        <?php endforeach; ?>
        <label>Oracle target deployment<select name="scenario[groups][<?= $i ?>][deployment]"><?php foreach (['' => 'Select target deployment', 'PHYSICAL' => 'Physical systems', 'VIRTUAL_GUEST' => 'Virtual guests — quantity review required', 'CLOUD' => 'Cloud — quantity review required'] as $value => $label): ?><option value="<?= $escape($value) ?>"<?= ($g['deployment'] ?? '') === $value ? ' selected' : '' ?>><?= $escape($label) ?></option><?php endforeach; ?></select></label>
        <?php foreach (['systems' => 'Unique physical systems', 'cpusPerSystem' => 'Physical CPUs per system'] as $key => $label): ?>
            <label><?= $escape($label) ?><input type="number" min="1" max="<?= $key === 'systems' ? '1000000' : '1024' ?>" step="1" name="scenario[groups][<?= $i ?>][<?= $escape($key) ?>]" value="<?= $escape($g[$key] ?? ($key === 'cpusPerSystem' ? 2 : '')) ?>"></label>
        <?php endforeach; ?>
        <p class="field-hint">Count physical processors, not cores or vCPUs. Round CPU pairs for each system; separate populations with different CPU counts. Virtual guests, cloud and unspecified targets remain outside the physical-pair calculation.</p>
        <label>Population evidence<textarea name="scenario[groups][<?= $i ?>][populationEvidence]" maxlength="1000" rows="2"><?= $escape($g['populationEvidence'] ?? '') ?></textarea></label>
        <label>Oracle offering<select name="scenario[groups][<?= $i ?>][offering]"><option value="">Automatic — lowest qualifying offering</option><?php if (($g['offering'] ?? '') !== '' && !isset($offerings[$g['offering']])): ?><option value="<?= $escape($g['offering']) ?>" selected><?= $escape($g['offering']) ?> — Unavailable in selected catalog; review required</option><?php endif; ?>
            <?php foreach ($offerings as $sku => $offering): if (!is_array($offering)) {
                continue;
            } ?><option value="<?= $escape($sku) ?>"<?= ($g['offering'] ?? '') === $sku ? ' selected' : '' ?>><?= $escape($offering['description'] ?? '') ?> · <?= $escape(($offering['unit'] ?? '') === 'NONE' ? '0 USD / no paid support subscription' : (isset($offering['price']) ? $offering['price'] . ' USD / CPU pair / year' : 'Price pending verification')) ?></option><?php endforeach; ?>
        </select></label>
        <details><summary>Red Hat quantity and entitlement review</summary>
            <p>Review the source estate separately from the Oracle target. Confirm that each subscription quantity covers its socket, guest or managed-node scope, and any prerequisites. Base subscriptions and bundles must not count the same entitlement twice.</p>
            <label>Red Hat source deployment<select name="scenario[groups][<?= $i ?>][sourceDeployment]"><?php foreach (['' => 'Select source deployment', 'PHYSICAL' => 'Physical systems', 'VIRTUAL_GUEST' => 'Virtual guests', 'CLOUD' => 'Cloud'] as $value => $label): ?><option value="<?= $escape($value) ?>"<?= ($g['sourceDeployment'] ?? '') === $value ? ' selected' : '' ?>><?= $escape($label) ?></option><?php endforeach; ?></select></label>
            <?php foreach (['sourceSystems' => 'Red Hat source systems', 'sourceCpusPerSystem' => 'Physical CPUs per Red Hat source system', 'sourceGuests' => 'Red Hat guests requiring subscription coverage', 'sourceManagedNodes' => 'Red Hat unique automation managed nodes'] as $key => $label): ?>
                <label><?= $escape($label) ?><input type="number" min="<?= $key === 'sourceCpusPerSystem' ? '1' : '0' ?>" max="<?= $key === 'sourceCpusPerSystem' ? '1024' : '1000000' ?>" step="1" name="scenario[groups][<?= $i ?>][<?= $escape($key) ?>]" value="<?= $escape($g[$key] ?? ($key === 'sourceCpusPerSystem' ? 2 : '')) ?>"></label>
            <?php endforeach; ?>
            <p class="field-hint">Blank means unknown. Enter zero only when you have confirmed that no guests or managed nodes are in scope. Red Hat node packs and subscription quantities do not create Oracle physical systems.</p>
            <?php foreach (['sourceQuantityEvidence' => 'Evidence for Red Hat quantities and source estate', 'prerequisiteEvidence' => 'Evidence of required base subscriptions and add-on prerequisites', 'duplicateEntitlementEvidence' => 'If base and bundle entitlements overlap, explain the separately purchased scope'] as $key => $label): ?>
                <label><?= $escape($label) ?><textarea name="scenario[groups][<?= $i ?>][<?= $escape($key) ?>]" maxlength="1000" rows="2"><?= $escape($g[$key] ?? '') ?></textarea></label>
            <?php endforeach; ?>
            <label>Red Hat source quantities and entitlements confirmed?<select name="scenario[groups][<?= $i ?>][sourceEntitlementsConfirmed]"><option value="0">Not yet confirmed</option><option value="1"<?= ($g['sourceEntitlementsConfirmed'] ?? false) === true ? ' selected' : '' ?>>Yes — reviewed for this population</option></select></label>
        </details>
        <details><summary>Workstation scope, when applicable</summary>
            <p>This is an OS-only comparison. Oracle has no workstation-specific support offering in this mapping. Review hardware and application compatibility separately; a Red Hat workstation's guest entitlement is not automatically replaced by Basic.</p>
            <label>Workstation comparison limitation acknowledged?<select name="scenario[groups][<?= $i ?>][workstationScopeAcknowledged]"><option value="0">Not acknowledged / no workstation in scope</option><option value="1"<?= ($g['workstationScopeAcknowledged'] ?? false) === true ? ' selected' : '' ?>>Yes — OS-only scope and limitations reviewed</option></select></label>
            <label>Workstation guest scope<select name="scenario[groups][<?= $i ?>][workstationGuestScope]"><?php foreach (['' => 'Select when a workstation is included', 'EXCLUDED' => 'Guest excluded from this comparison', 'REQUIRED' => 'Guest support required — resolve coverage separately'] as $value => $label): ?><option value="<?= $escape($value) ?>"<?= ($g['workstationGuestScope'] ?? '') === $value ? ' selected' : '' ?>><?= $escape($label) ?></option><?php endforeach; ?></select></label>
        </details>
        <label>OLAM required?<select name="scenario[groups][<?= $i ?>][olamRequired]"><option value="0">No</option><option value="1"<?= ($g['olamRequired'] ?? false) === true ? ' selected' : '' ?>>Yes</option></select></label>
        <?php foreach (['demand' => 'Unique OLAM managed instances (blank means unknown)', 'allocatedUnits' => 'System CPU-pair units allocated exclusively to this population', 'additionalUnits' => 'Additional OLAM support pairs to purchase'] as $key => $label): ?>
            <label><?= $escape($label) ?><input type="number" min="0" max="<?= $key === 'allocatedUnits' ? '512000000' : '1000000' ?>" step="1" name="scenario[groups][<?= $i ?>][<?= $escape($key) ?>]" value="<?= $escape($g[$key] ?? ($key === 'additionalUnits' ? 0 : '')) ?>"></label>
        <?php endforeach; ?>
        <?php $additionalOffering = ($g['additionalOffering'] ?? '') === '' ? 'OL-PREMIER' : $g['additionalOffering']; ?>
        <label>Offering for additional OLAM pairs<select name="scenario[groups][<?= $i ?>][additionalOffering]"><?php if (($g['additionalOffering'] ?? '') !== '' && ($offerings[$g['additionalOffering']]['olam'] ?? false) !== true): ?><option value="<?= $escape($g['additionalOffering']) ?>" selected><?= $escape($g['additionalOffering']) ?> — Unavailable in selected catalog; review required</option><?php endif; ?><?php foreach ($offerings as $sku => $offering): if (!is_array($offering) || ($offering['olam'] ?? false) !== true) {
            continue;
        } ?><option value="<?= $escape($sku) ?>"<?= $additionalOffering === $sku ? ' selected' : '' ?>><?= $escape($offering['description'] ?? '') ?> · <?= $escape(isset($offering['price']) ? $offering['price'] . ' USD / pair / year' : 'Price pending verification') ?></option><?php endforeach; ?></select></label>
        <label>Managed-instance and entitlement allocation evidence<textarea name="scenario[groups][<?= $i ?>][allocationEvidence]" maxlength="1000" rows="2"><?= $escape($g['allocationEvidence'] ?? '') ?></textarea></label>
        <p class="field-hint">Each eligible Premier or Premier Plus CPU pair supports 20 managed instances. Allocate all eligible system pairs once and count each managed node once across populations. Only additional pairs explicitly entered above increase cost; a known capacity gap remains visible as an advisory. Additional pairs do not create systems or upgrade their support tier. An unknown managed-node count requires review before confirmation.</p>
        </details>
    <?php endfor; ?>
    <h2>Source subscriptions</h2>
    <p>Source units retain their own metric. They never substitute for physical inventory or managed-instance demand. Leave unused rows unselected.</p>
    <?php for ($i = 0; $i < 10; ++$i): $line = is_array($lines[$i] ?? null) ? $lines[$i] : []; ?>
        <details<?= $line !== [] ? ' open' : '' ?>><summary>Source subscription <?= $i + 1 ?><?= $line !== [] ? ' · ' . $escape($line['sku'] ?? '') : '' ?></summary>
            <label>Original source row identifier<input name="scenario[lines][<?= $i ?>][sourceId]" maxlength="40" value="<?= $escape($line['sourceId'] ?? 'source-' . ($i + 1)) ?>"></label>
            <label>Original included subscription quantity<input type="number" min="1" max="1000000" name="scenario[lines][<?= $i ?>][originalQuantity]" value="<?= $escape($line['originalQuantity'] ?? '') ?>"></label>
            <p class="field-hint">For a source row split across populations, repeat its identifier, SKU and original included total. Included portions must reconcile to that total; excluded portions do not enter reconciliation.</p>
            <label>Source SKU<select name="scenario[lines][<?= $i ?>][sku]"><option value="">Unused row</option><?php if (($line['sku'] ?? '') !== '' && !isset($catalog[$line['sku']])): ?><option value="<?= $escape($line['sku']) ?>" selected><?= $escape($line['sku']) ?> — Unavailable in selected catalog; review required</option><?php endif; ?><?php foreach ($catalog as $sku => $entry): if (!is_array($entry)) {
                continue;
            } ?><option value="<?= $escape($sku) ?>"<?= ($line['sku'] ?? '') === $sku ? ' selected' : '' ?>><?= $escape($sku) ?> · <?= $escape($entry['description'] ?? '') ?> · <?= $escape($entry['unit'] ?? '') ?> · <?= $escape($entry['readiness'] ?? '') ?></option><?php endforeach; ?></select></label>
            <label>Source subscription quantity<input type="number" min="1" max="1000000" step="1" name="scenario[lines][<?= $i ?>][quantity]" value="<?= $escape($line['quantity'] ?? '') ?>"></label>
            <label>Complete population covered<select name="scenario[lines][<?= $i ?>][groupId]"><option value="">Unresolved</option><?php for ($j = 0; $j < 5; ++$j): $target = is_array($groups[$j] ?? null) ? ($groups[$j]['id'] ?? 'group-' . ($j + 1)) : 'group-' . ($j + 1); ?><option value="<?= $escape($target) ?>"<?= ($line['groupId'] ?? '') === $target ? ' selected' : '' ?>>Population <?= $j + 1 ?></option><?php endfor; ?></select></label>
            <label>Explicit exclusion reason (blank includes this line)<input name="scenario[lines][<?= $i ?>][exclusionReason]" maxlength="500" value="<?= $escape($line['exclusionReason'] ?? '') ?>"></label>
        </details>
    <?php endfor; ?>
    <button type="submit">Save revision and review coverage</button>
    </fieldset>
</form>
