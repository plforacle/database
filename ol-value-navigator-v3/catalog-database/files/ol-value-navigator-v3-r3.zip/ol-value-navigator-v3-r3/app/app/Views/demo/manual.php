<?php

declare(strict_types=1);

/** @var array<string, mixed> $data */
/** @var callable(mixed): string $escape */
$csrfToken = is_string($data['csrfToken'] ?? null) ? $data['csrfToken'] : '';
$analysisId = is_string($data['analysisId'] ?? null) ? $data['analysisId'] : '';
?>
<p class="eyebrow">Step 2 · Disclosed contingency</p>
<h1>HeatWave is unavailable. Use structured manual fallback.</h1>
<p class="lede">No fake AI candidates were inserted. Enter one candidate using the same source-span and decimal contract the live extractor must satisfy.</p>
<div class="state-callout state-callout--warning"><strong>Manual mode is active</strong><span>This result will retain no model identifier or AI response digest.</span></div>
<form method="post" action="/demo/analyses/<?= $escape($analysisId) ?>/manual" class="docket-form form-grid">
    <input type="hidden" name="_csrf" value="<?= $escape($csrfToken) ?>">
    <div class="field-wide"><label for="source_excerpt">Exact source excerpt</label><input id="source_excerpt" name="source_excerpt" type="text" required></div>
    <div><label for="line_id">Line ID</label><input id="line_id" name="line_id" type="text" value="line-1" required></div>
    <div><label for="sku">Candidate SKU</label><input id="sku" name="sku" type="text" value="SYN-RHEL-BASE" required></div>
    <div><label for="quantity">Quantity</label><input id="quantity" name="quantity" type="text" inputmode="decimal" value="2" required></div>
    <div><label for="source_start">Start byte</label><input id="source_start" name="source_start" type="number" min="0" value="0" required></div>
    <div><label for="source_end">End byte</label><input id="source_end" name="source_end" type="number" min="1" value="16" required></div>
    <div class="field-wide"><button type="submit">Validate manual candidate</button></div>
</form>
