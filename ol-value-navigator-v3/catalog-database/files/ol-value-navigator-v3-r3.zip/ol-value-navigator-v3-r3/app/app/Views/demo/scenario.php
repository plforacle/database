<?php

declare(strict_types=1);

/** @var array<string,mixed> $data */
/** @var callable(mixed):string $escape */
$input = $data['input'];
$snapshot = $data['snapshot'] ?? null;
$editing = $data['editing'] ?? false;
$e = $editing ? null : ($snapshot['evaluation'] ?? null);
$historical = $snapshot !== null && !$editing;
$visibleIssues = [];
$olamCoverageWarned = false;
foreach (array_merge($e['reviews'] ?? [], $e['advisories'] ?? []) as $issue) {
    $visibleIssues[($issue['code'] ?? '') . "\0" . ($issue['message'] ?? '')] = $issue;
    $olamCoverageWarned = $olamCoverageWarned || ($issue['code'] ?? '') === 'OLAM_COVERAGE_UNVERIFIED';
}
$value = static function (string $path) use ($input): mixed {
    $current = $input;
    foreach (explode('.', $path) as $key) {
        $current = is_array($current) ? ($current[$key] ?? null) : null;
    }
    return $current;
};
$money = static function (mixed $amount): string {
    if (!is_string($amount) || preg_match('/^-?\d+(?:\.\d+)?$/D', $amount) !== 1) {
        return 'Unknown';
    }
    [$whole, $fraction] = array_pad(explode('.', $amount, 2), 2, '00');
    return (preg_replace('/\B(?=(\d{3})+(?!\d))/', ',', $whole) ?? $whole) . '.' . str_pad($fraction, 2, '0') . ' USD';
};
$status = static fn (mixed $text): string => ucwords(strtolower(str_replace('_', ' ', is_string($text) ? $text : 'Unknown')));
$field = static function (string $path, string $label, ?array $options = null) use ($escape, $value): void {
    $current = $value($path);
    $current = is_array($current) ? implode(', ', $current) : (is_bool($current) ? ($current ? '1' : '0') : ($current ?? ''));
    echo '<label>' . $escape($label);
    if ($options !== null) {
        echo '<select name="edit[' . $escape($path) . ']">';
        if ($current !== '' && !array_key_exists((string) $current, $options)) {
            echo '<option value="' . $escape($current) . '" selected>' . $escape($current) . ' — Unavailable in selected catalog; review required</option>';
        }
        foreach ($options as $key => $caption) {
            echo '<option value="' . $escape($key) . '"' . ((string) $key === (string) $current ? ' selected' : '') . '>' . $escape($caption) . '</option>';
        }
        echo '</select>';
    } else {
        echo '<input name="edit[' . $escape($path) . ']" value="' . $escape($current) . '" maxlength="2000"' . (preg_match('/^lines\.\d+\.sku$/D', $path) ? ' list="scenario-skus"' : '') . '>';
    }
    echo '</label>';
};
$states = ['UNRESOLVED' => 'Needs review', 'ASSUMED' => 'Explicit illustrative assumption', 'CONFIRMED' => 'Confirmed'];
$yesNo = ['0' => 'No', '1' => 'Yes'];
$featureCaptions = ['storage' => 'Storage / vSAN', 'networking' => 'Networking / NSX / security', 'backup' => 'Backup / recovery', 'operations' => 'Operations / automation', 'kubernetes' => 'Kubernetes / Tanzu', 'vdi' => 'VDI', 'integrations' => 'Integrations', 'guest_support' => 'Guest / application support'];
$assertion = static function (string $path, string $label) use ($field, $states): void {
    $field($path . '.state', $label, $states);
    $field($path . '.evidence', $label . ' — evidence / rationale');
};
$offerings = ['' => 'Suggest minimum qualifying support'];
foreach ($data['offerings'] as $id => $offering) {
    $offerings[$id] = $offering['description'];
}
$price = static function (string $path) use ($field, $value, $escape, $money): void {
    $field($path . '.amount', 'Unit amount (exact USD decimal; blank = unresolved)');
    $field($path . '.metric', 'Billing unit / metric');
    $field($path . '.periodBasis', 'Price covers', ['UNKNOWN' => 'Unknown — review before calculation', 'ANNUAL_UNIT_RATE' => 'Annual unit rate', 'ANNUAL_INSTALLMENT' => 'Annual installment of a longer commitment', 'FULL_TERM_UNIT_PRICE' => 'Full-term unit price', 'FULL_TERM_LINE_TOTAL' => 'Full-term line total']);
    $field($path . '.termMonths', 'Price term', [12 => '12 months', 36 => '36 months']);
    $field($path . '.basis', 'Price source', ['SCENARIO_SUPPLIED' => 'Supplied scenario price', 'HISTORICAL_PUBLIC' => 'Historical public price', 'MANUFACTURER_LIST' => 'Manufacturer list price', 'RESELLER_ADVERTISED' => 'Advertised reseller price']);
    $field($path . '.verification', 'Price review', ['UNVERIFIED' => 'Unverified', 'USER_VERIFIED' => 'I adopt the amount, metric and period', 'INDEPENDENTLY_VERIFIED_PUBLIC' => 'Claimed public evidence — server review required']);
    $field($path . '.evidence', 'Price evidence / source reference');
    $field($path . '.reason', 'Reason for adopting this price');
    $field($path . '.installments', 'Optional annual unit installments in order, comma separated (blank entry = unknown)');
    echo '<p>Original unit amount: ' . $escape($money($value($path . '.originalAmount'))) . '. Derived from preserved source or earlier adoption.</p>';
};
?>
<p class="eyebrow">Rules v1.3.1 · reviewed subscription comparison</p>
<h1>RHEL and VMware to Oracle Linux</h1>
<p>Use synthetic or deliberately redacted inputs. Review source purchases, physical targets and shared coverage before confirming a comparison. Prices, support capacity and financial readiness are reviewed separately. Entered public-source claims do not certify independent verification; validated public prices require an admitted record.</p>
<p><a href="/demo/coverage/new">New v1.3.1 comparison</a> · <a href="/demo/coverage">Legacy comparison</a></p>
<details class="scenario-card">
    <summary>Import source</summary>
    <p>Preserve the original file privately, review every sheet and map its columns before adopting rows. Import starts a new draft.</p>
    <form method="post" action="/demo/coverage/import" enctype="multipart/form-data">
        <input type="hidden" name="_csrf" value="<?= $escape($data['csrfToken']) ?>">
        <label>Source worksheet or image<input type="file" name="source" accept=".csv,.tsv,.xlsx,.png,.jpg,.jpeg" required></label>
        <label><input type="checkbox" name="syntheticAcknowledged" value="1" required> This file is synthetic or deliberately redacted.</label>
        <button type="submit">Preserve and preview source</button>
    </form>
</details>
<?php if ($e !== null && !$editing): ?>
<section class="scenario-result">
    <h2><?= $escape($status($e['resultLabel'] ?? 'Comparison needs review') . ' comparison') ?></h2>
    <p><?= $escape($e['termMonths'] ?? '') ?> months · USD · <?= $escape($status($e['completeness'] ?? '')) ?> · Difference <?= $escape($e['termPercent'] === null ? 'Withheld' : $e['termPercent'] . '%') ?></p>
    <?php foreach ($visibleIssues as $issue): ?>
        <p class="scenario-warning"><strong><?= $escape($issue['code'] ?? '') ?></strong> <?= $escape($issue['message'] ?? '') ?></p>
    <?php endforeach; ?>
    <?php foreach ($e['pools'] ?? [] as $pool): ?>
        <?php if (!$olamCoverageWarned && (($pool['uniqueNodes'] ?? null) === null || ($pool['capacity'] ?? null) === null)): $olamCoverageWarned = true; ?>
            <p class="scenario-warning"><strong>OLAM coverage unverified.</strong> Actual unique nodes or eligible allocation remain unknown. Financial arithmetic does not establish complete support.</p>
        <?php endif; ?>
    <?php endforeach; ?>
    <table><thead><tr><th>Matched USD period</th><th>Source</th><th>Target</th><th>Difference</th></tr></thead><tbody>
        <tr><th>Annual / annualized equivalent</th><td><?= $escape($e['sourceAnnual'] === null ? 'Withheld' : $money($e['sourceAnnual'])) ?></td><td><?= $escape($e['oracleAnnual'] === null ? 'Withheld' : $money($e['oracleAnnual'])) ?></td><td><?= $escape($e['savingsAnnual'] === null ? 'Withheld' : $money($e['savingsAnnual'])) ?></td></tr>
        <tr><th><?= $escape($e['termMonths'] ?? '') ?> months</th><td><?= $escape($e['sourceTerm'] === null ? 'Withheld' : $money($e['sourceTerm'])) ?></td><td><?= $escape($e['oracleTerm'] === null ? 'Withheld' : $money($e['oracleTerm'])) ?></td><td><?= $escape($e['savingsTerm'] === null ? 'Withheld' : $money($e['savingsTerm'])) ?></td></tr>
    </tbody></table>
    <p>Full-term prepaid amounts use display-only annualized equivalents. Current rates applied to old dates are modeled costs, not historical invoices or recoverable prepaid spend.</p>
    <?php if (($e['ready'] ?? false) && $snapshot['state'] !== 'CONFIRMED' && ($snapshot['catalogContext'] ?? null) !== null): ?>
        <form method="post" action="/demo/coverage/<?= $escape($snapshot['revisionId']) ?>/confirm"><input type="hidden" name="_csrf" value="<?= $escape($data['csrfToken']) ?>"><button>Confirm reviewed comparison</button></form>
    <?php elseif ($snapshot['state'] === 'CONFIRMED'): ?>
        <p><a class="button" href="/demo/coverage/<?= $escape($snapshot['revisionId']) ?>/pptx">Download editable PowerPoint</a></p>
    <?php endif; ?>
    <details open><summary>Target groups</summary>
        <table><thead><tr><th>Target group</th><th>Systems</th><th>Pairs</th><th>Offering</th><th>Term cost</th></tr></thead><tbody>
        <?php foreach ($e['groups'] ?? [] as $group): ?><tr><td><?= $escape($group['label'] ?? $group['id']) ?></td><td><?= $escape($group['systems'] ?? 'Unknown') ?></td><td><?= $escape($group['pairs'] ?? 'Unknown') ?></td><td><?= $escape($group['offeringDescription'] ?? $group['offering'] ?? 'Unknown') ?></td><td><?= $escape($money($group['term'] ?? null)) ?></td></tr><?php endforeach; ?>
        </tbody></table>
    </details>
    <details open><summary>Source rows and price basis</summary><div class="source-preview"><table><thead><tr><th>SKU</th><th>Quantity</th><th>Unit amount</th><th>Price basis</th><th>Comparable annual</th><th>Comparable term</th><th>Status</th></tr></thead><tbody>
    <?php foreach ($e['lines'] ?? [] as $line): $included = ($line['bucket'] ?? '') === 'included'; ?><tr><td><?= $escape($line['sku'] ?: 'Unresolved SKU') ?></td><td><?= $escape($line['quantity'] ?? 'Unknown') ?></td><td><?= $escape($money($line['price']['amount'] ?? null)) ?></td><td><?= $escape($status($line['price']['basis'] ?? 'Unknown')) ?><br><?= $escape($status($line['price']['periodBasis'] ?? 'Unknown')) ?></td><td><?= $escape($included ? $money($line['annual'] ?? null) : '—') ?></td><td><?= $escape($included ? $money($line['term'] ?? null) : '—') ?></td><td><?= $escape($status($line['bucket'] ?? 'Unknown')) ?><?php foreach ($line['issues'] ?? [] as $issue): ?><br><?= $escape($issue['message'] ?? '') ?><?php endforeach; ?></td></tr><?php endforeach; ?>
    </tbody></table></div></details>
    <details open><summary>Source reconciliation</summary><p>Known excluded amounts are inventory values; they do not contribute to comparable savings. Unknown supplied totals have no calculated variance.</p>
    <table><thead><tr><th>Source bucket</th><th>Rows</th><th>Annual amount</th><th>Term amount</th><th>Unvalued rows</th></tr></thead><tbody>
    <?php foreach (['included' => 'Comparable', 'excluded' => 'Policy excluded', 'held' => 'Held / unresolved', 'outOfPeriod' => 'Out of period / not selected', 'gross' => 'Gross adopted source'] as $key => $label): $bucket = $e['reconciliation'][$key] ?? []; ?><tr><th><?= $escape($label) ?></th><td><?= $escape($bucket['count'] ?? 'Unknown') ?></td><td><?= $escape($money($bucket['annual'] ?? null)) ?></td><td><?= $escape($money($bucket['term'] ?? null)) ?></td><td><?= $escape(implode(', ', $bucket['unvaluedIds'] ?? []) ?: 'None') ?></td></tr><?php endforeach; ?>
    </tbody></table><p>Source total variance: <?= $escape($money($e['reconciliation']['sourceVariance'] ?? null)) ?></p></details>
    <details open><summary>OLAM demand and capacity</summary><table><thead><tr><th>Pool</th><th>Actual nodes</th><th>Allocated pairs</th><th>Capacity</th><th>Excess</th><th>Extra pairs indicated</th><th>Status</th></tr></thead><tbody>
    <?php foreach ($e['pools'] ?? [] as $pool): ?><tr><td><?= $escape($pool['id']) ?></td><td><?= $escape($pool['uniqueNodes'] ?? 'Unknown') ?></td><td><?= $escape($pool['allocatedPairs'] ?? 'Unknown') ?></td><td><?= $escape($pool['capacity'] ?? 'Unknown') ?></td><td><?= $escape($pool['excess'] ?? 'Unknown') ?></td><td><?= $escape($pool['additionalPairsIndicated'] ?? 'Unknown') ?></td><td><?= $escape($status($pool['status'] ?? 'Unknown')) ?></td></tr><?php endforeach; ?>
    </tbody></table><?php if (($e['pools'] ?? []) === []): ?><p>OLAM is not applicable to the selected scope.</p><?php endif; ?></details>
    <details><summary>Independent connected scopes</summary><p>Only complete, independently resolved scopes show a difference. Shared costs and target hosts are charged once.</p><table><thead><tr><th>Scope / groups</th><th>Readiness</th><th>Source term</th><th>Target term</th><th>Difference</th></tr></thead><tbody>
    <?php foreach ($e['scopes'] ?? [] as $scope): ?><tr><td><?= $escape(implode(', ', $scope['groupIds'] ?? [])) ?></td><td><?= ($scope['complete'] ?? false) ? 'Complete' : 'Needs review' ?></td><td><?= $escape($money($scope['sourceTerm'] ?? null)) ?></td><td><?= $escape($money($scope['oracleTerm'] ?? null)) ?></td><td><?= $escape(($scope['complete'] ?? false) ? $money($scope['savingsTerm'] ?? null) : 'Withheld') ?></td></tr><?php endforeach; ?>
    </tbody></table></details>
</section>
<?php elseif ($editing): ?><p class="scenario-warning">Draft edits have not been saved or calculated. Save and review a new revision to see its results.</p><?php endif; ?>
<?php if (($data['reviewChanged'] ?? false) === true): ?><p class="scenario-warning">The catalog selection changed since editing. <?= $editing ? 'Review current catalog choices before saving a new revision.' : 'Review this new, unconfirmed revision before confirming.' ?></p><?php endif; ?>
<?php if ($historical): ?>
<p><a href="/demo/coverage/<?= $escape($snapshot['revisionId']) ?>?edit=1">Edit a successor with the current catalog</a></p>
<?php if (($snapshot['catalogContext'] ?? null) === null): ?><p>Historical catalog details are limited to saved evidence. Save and review a successor before confirming an old draft.</p><?php endif; ?>
<?php endif; ?>
<?php if (($snapshot['catalogContext'] ?? null) !== null && !$editing): ?><p>Saved release <?= $escape($snapshot['catalogContext']['releaseId']) ?> · Profile <?= $escape($snapshot['catalogContext']['profileId']) ?> · <?= $snapshot['catalogContext']['generation'] === 0 ? 'Bootstrap selection (unactivated)' : 'Selection generation ' . $escape($snapshot['catalogContext']['generation']) ?></p><?php endif; ?>
<form method="post" action="/demo/coverage/edit" class="scenario-editor">
    <fieldset<?= $historical ? ' disabled' : '' ?>><legend><?= $historical ? 'Saved inputs' : 'Draft inputs' ?></legend>
    <input type="hidden" name="editorSelection" value="<?= $escape($data['editorSelection'] ?? '') ?>">
    <input type="hidden" name="_csrf" value="<?= $escape($data['csrfToken']) ?>">
    <input type="hidden" name="comparisonId" value="<?= $escape($snapshot['comparisonId'] ?? '') ?>">
    <input type="hidden" name="expectedRevision" value="<?= $escape($snapshot['revisionId'] ?? '') ?>">
    <input type="hidden" name="scenarioJson" value="<?= $escape(json_encode($input, JSON_THROW_ON_ERROR)) ?>">
    <fieldset><legend>Customer and comparison period</legend><div class="scenario-fields">
        <?php foreach (['name' => 'Customer / review name', 'objective' => 'Objective', 'scope' => 'Declared scope', 'nextStep' => 'Next step'] as $key => $label) {
            $field('customer.' . $key, $label);
        } ?>
        <?php $field('mode', 'Comparison mode', ['ILLUSTRATIVE' => 'Illustrative', 'VALIDATED_PUBLIC' => 'Validated public inputs']); ?>
        <?php $field('period.months', 'Comparison period', [12 => '12 months', 36 => '36 months']); ?>
        <?php $field('period.startDate', 'Start date');
$field('period.endDate', 'End date');
$field('period.dateLocale', 'Date convention', ['ISO' => 'YYYY-MM-DD', 'MDY' => 'Month / day / year', 'DMY' => 'Day / month / year']); ?>
        <?php $field('period.inclusiveEnd', 'End date includes the last day', ['' => 'Unknown', '1' => 'Yes', '0' => 'No']); ?>
        <?php $field('period.model', 'Time model', ['CONSTANT_RATE' => 'Constant-rate comparison', 'HISTORICAL_ACTUAL' => 'Historical actual-cost reconstruction', 'FUTURE_RENEWAL' => 'Future renewal']);
$field('period.constantRateConfirmed', 'Adopt constant quantities and annual rates for this term', $yesNo);
$field('period.evidence', 'Period and constant-rate rationale'); ?>
        <?php $field('scope.label', 'Comparison scope label');
$assertion('scope', 'Distinct / connected scope');
$field('scope.reduced', 'Declared reduced scope', $yesNo); ?>
    </div></fieldset>
    <h2>Physical targets</h2><p>Physical CPUs are processors, not cores or vCPUs. Two CPUs is a visible starting assumption. Subscription quantities never determine target host counts automatically.</p>
    <?php foreach ($input['groups'] as $i => $group): $p = 'groups.' . $i; ?>
        <fieldset><legend><?= $escape($group['label'] ?: $group['id']) ?></legend><div class="scenario-fields">
            <?php $field($p . '.id', 'Group ID');
        $field($p . '.label', 'Group name');
        $field($p . '.populationKey', 'Distinct population key');
        $field($p . '.systems', 'Unique physical systems');
        $field($p . '.cpusPerSystem', 'Physical CPUs per system');
        $field($p . '.deployment', 'Target deployment', ['UNKNOWN' => 'Unknown', 'PHYSICAL' => 'Physical Oracle Linux / KVM', 'VIRTUAL_GUEST' => 'Guest only — review', 'CLOUD' => 'Cloud — review']);
        $field($p . '.offering', 'Oracle offering', $offerings);
        $assertion($p . '.coverage', 'Target inventory and coverage'); ?>
        </div><details><summary>Additional target details</summary><div class="scenario-fields"><?php $field($p . '.systemIds', 'Physical system IDs, comma separated (optional)');
        $field($p . '.olamRequired', 'OLAM support required', $yesNo);
        $field($p . '.workstationScope', 'Workstation scope', ['UNRESOLVED' => 'Needs review / not applicable', 'OS_ONLY_GUEST_EXCLUDED' => 'OS only; included guest outside scope']); ?></div></details></fieldset>
    <?php endforeach; ?>
    <button name="op" value="add-group">Add physical target group</button>
    <h2>Source subscriptions</h2><p>Keep distinct purchases as separate rows. For shared coverage, enter the affected group IDs separated by commas. Leave unknown source quantities or prices blank.</p>
    <datalist id="scenario-skus"><?php foreach ($data['catalog'] as $sku => $entry): ?><option value="<?= $escape($sku) ?>"><?= $escape($entry['description']) ?></option><?php endforeach; ?></datalist>
    <?php foreach ($input['lines'] as $i => $line): $p = 'lines.' . $i; ?>
    <fieldset><legend><?= $escape($line['sku'] ?: 'Unresolved source') ?> · <?= $escape($line['id']) ?></legend>
        <div class="scenario-fields"><?php $field($p . '.sku', 'Selected / corrected SKU');
        if ($input['snapshots'] === []) {
            $field($p . '.description', 'Source description');
        } else {
            echo '<p>Preserved source description: ' . $escape($line['description']) . '</p>';
        } $field($p . '.quantity', 'Purchased source units');
        $field($p . '.selected', 'Selected for this period', $yesNo);
        $field($p . '.groupIds', 'Covered target group IDs');
        $field($p . '.quantityBasis', 'What the source quantity means', ['UNKNOWN' => 'Unknown', 'PURCHASED' => 'Purchased subscriptions', 'ASSUMED' => 'Illustrative adopted units', 'MANIFEST_ALLOCATED' => 'Manifest / allocated pool', 'HOST_ASSOCIATED' => 'Host-associated values', 'HOST_INVENTORY' => 'Host inventory', 'CONSUMPTION' => 'Consumption']);
        $assertion($p . '.quantityState', 'Source quantity review');
        $assertion($p . '.coverage', 'Shared target coverage'); ?></div>
        <details open><summary>Source price and period</summary><div class="scenario-fields">
            <?php $records = ['' => 'Catalog price or entered amount'];
        foreach ($data['prices'] as $id => $record) {
            $records[$id] = $id . ' — ' . ($record['amount'] ?? 'Unknown') . ' ' . ($record['currency'] ?? '') . ' / ' . ($record['metric'] ?? '') . ' · ' . ($record['periodBasis'] ?? '');
        } $field($p . '.priceRecordId', 'Reusable adopted price record (explicit selection)', $records);
        $price($p . '.price'); ?>
        </div></details>
        <details><summary>Source entitlement, identity and reconciliation review</summary><div class="scenario-fields">
            <?php $field($p . '.identityState', 'Identity review', ['CATALOG' => 'Compare with exact catalog identity', 'UNRESOLVED' => 'Unknown identity', 'CONFLICT' => 'Material conflict', 'VERIFIED' => 'Reviewed exact identity']);
        $field($p . '.identityEvidence', 'Identity / correction reason and evidence');
        $field($p . '.adoptedDescription', 'Explicitly adopted corrected description');
        $field($p . '.rowType', 'Source row type', ['PRODUCT' => 'Product', 'HEADER' => 'Header', 'TOTAL' => 'Total / subtotal', 'NOTE' => 'Note', 'EMPTY' => 'Empty']);
        $field($p . '.subscriptionId', 'Subscription ID');
        $field($p . '.poolId', 'Source subscription pool ID');
        $field($p . '.organization', 'Source organization');
        $field($p . '.startDate', 'Source start date');
        $field($p . '.endDate', 'Source end date');
        $field($p . '.selectionReason', 'Period selection / exclusion rationale');
        $field($p . '.sourceEstate.deployment', 'RH source deployment', ['UNKNOWN' => 'Unknown', 'PHYSICAL' => 'Physical', 'VIRTUAL_GUEST' => 'Virtual guests']);
        $field($p . '.sourceEstate.systems', 'RH source systems');
        $field($p . '.sourceEstate.cpusPerSystem', 'RH source physical CPUs');
        $field($p . '.sourceEstate.guests', 'RH source guest count');
        $field($p . '.sourceEstate.managedNodes', 'RH managed-node inventory (not pack capacity)');
        $field($p . '.sourceEstate.prerequisiteEvidence', 'Base entitlement prerequisite evidence');
        $field($p . '.sourceEstate.duplicateEvidence', 'Evidence of distinct purchases / repeated pool meaning');
        $field($p . '.suppliedTotal', 'Supplied line total (blank if absent)');
        $field($p . '.suppliedTotalBasis', 'Supplied total period', ['UNKNOWN' => 'Unknown / absent', 'ANNUAL' => 'Annual', 'FULL_TERM' => 'Full selected term']); ?>
        </div><p>Original SKU: <?= $escape($line['rawSku']) ?>. Original file rows remain in the preserved source.</p><button name="op" value="correction:<?= $escape($i) ?>">Record explicit SKU correction</button><button name="op" value="description-correction:<?= $escape($i) ?>">Record explicit description correction</button></details>
        <?php if ($line['vmware'] === null): ?><button name="op" value="vmware:<?= $escape($i) ?>">Review VMware replacement / retention</button>
        <?php else: $v = $p . '.vmware'; ?>
        <details open><summary>VMware source, target and retirement</summary><div class="scenario-fields">
            <?php $field($v . '.intent', 'Migration intent', ['UNRESOLVED' => 'Unresolved', 'RETAIN_VMWARE' => 'Retain VMware', 'REPLACE_VIRTUALIZATION' => 'Replace with Oracle Linux KVM / OLVM']);
            $field($v . '.quantityMode', 'VMware quantity basis', ['CUSTOMER_PRICED_UNITS' => 'Adopted billable cores', 'HARDWARE_DERIVED_ESTIMATE' => 'Estimate from hardware and commercial policy']);
            $field($v . '.productVersion', 'Product / version');
            $assertion($v . '.sizing', 'Source-to-target sizing');
            $assertion($v . '.retirement', 'Retirement / retained commitment');
            $field($v . '.retirement.date', 'Effective retirement / renewal date');
            $field($v . '.retirement.commitmentEnd', 'Existing commitment end');
            $assertion($v . '.commercialPolicy', 'Applicable commercial policy');
            $field($v . '.commercialPolicy.version', 'Commercial-policy version');
            $field($v . '.commercialPolicy.minimum', 'Applicable order minimum, if known');
            $field($v . '.commercialPolicy.step', 'Applicable pack / rounding step, if known'); ?>
        </div>
        <?php foreach ($line['vmware']['sourceHosts'] as $h => $host): ?><div class="scenario-fields"><?php $field($v . '.sourceHosts.' . $h . '.id', 'Source host ID');
            $field($v . '.sourceHosts.' . $h . '.cpus', 'Actual cores on each CPU, comma separated'); ?></div><?php endforeach; ?>
        <button name="op" value="host:<?= $escape($i) ?>">Add source host</button>
        <?php foreach ($line['vmware']['features'] as $f => $feature): ?><div class="scenario-fields"><?php if (isset($featureCaptions[$feature['name']])) {
            echo '<p><strong>' . $escape($featureCaptions[$feature['name']]) . '</strong></p>';
        } else {
            $field($v . '.features.' . $f . '.name', 'Additional bundle capability');
        }
            $field($v . '.features.' . $f . '.status', 'Disposition', ['UNRESOLVED' => 'Unresolved', 'COVERED' => 'Covered by target', 'OUT_OF_SCOPE' => 'Unused / explicitly out of scope', 'RETAINED' => 'Retained and costed', 'REPLACED' => 'Replaced and costed']);
            $field($v . '.features.' . $f . '.evidence', 'Capability evidence');
            $field($v . '.features.' . $f . '.costIds', 'Required other-cost IDs'); ?></div><?php endforeach; ?>
        <button name="op" value="feature:<?= $escape($i) ?>">Add capability requirement</button></details>
        <?php endif; ?>
    </fieldset>
    <?php endforeach; ?>
    <button name="op" value="add-line">Add source subscription</button>
    <h2>Shared OLAM pools</h2><p>Allocate each eligible Premier / Premier Plus CPU pair once. Actual unique nodes remain blank if unknown. Ansible pack capacity is not actual unique-node inventory.</p>
    <?php foreach ($input['pools'] as $i => $pool): $p = 'pools.' . $i; ?><fieldset><legend><?= $escape($pool['id']) ?></legend><div class="scenario-fields"><?php $field($p . '.id', 'Pool ID');
        $field($p . '.groupIds', 'Connected target group IDs');
        $field($p . '.uniqueNodes', 'Actual unique managed nodes');
        $assertion($p . '.coverage', 'Pool coverage and unique allocation'); ?></div>
        <?php foreach ($pool['allocations'] as $a => $allocation): ?><div class="scenario-fields"><?php $field($p . '.allocations.' . $a . '.groupId', 'Allocated group ID');
            $field($p . '.allocations.' . $a . '.pairs', 'Eligible pairs explicitly allocated'); ?></div><?php endforeach; ?><button name="op" value="allocation:<?= $escape($i) ?>">Allocate group pairs</button>
        <?php foreach ($pool['extraPurchases'] as $x => $purchase): ?><div class="scenario-fields"><?php $field($p . '.extraPurchases.' . $x . '.id', 'Additional purchase ID');
            $field($p . '.extraPurchases.' . $x . '.offering', 'Purchased extra support', ['OL-PREMIER' => 'Premier', 'OL-PREMIER-PLUS' => 'Premier Plus']);
            $field($p . '.extraPurchases.' . $x . '.units', 'Explicit extra pairs purchased'); ?></div><?php endforeach; ?><button name="op" value="extra:<?= $escape($i) ?>">Add an explicit capacity purchase</button>
    </fieldset><?php endforeach; ?>
    <button name="op" value="add-pool">Add shared OLAM pool</button>
    <h2>Other retained or replacement costs</h2>
    <?php foreach ($input['otherCosts'] as $i => $cost): $p = 'otherCosts.' . $i; ?><fieldset><legend><?= $escape($cost['id']) ?></legend><div class="scenario-fields"><?php $field($p . '.id', 'Cost ID');
        $field($p . '.label', 'Cost description');
        $field($p . '.sku', 'Product SKU, if applicable');
        $field($p . '.groupIds', 'Affected group IDs');
        $field($p . '.side', 'Include cost on', ['BOTH' => 'Both sides (retained)', 'SOURCE' => 'Source only', 'TARGET' => 'Target only (new replacement)']);
        $field($p . '.required', 'Required cost', $yesNo);
        $price($p . '.price'); ?></div></fieldset><?php endforeach; ?>
    <button name="op" value="add-other">Add retained / replacement cost</button>
    <details><summary>Preserved source evidence and prior adoption</summary><pre><?= $escape(json_encode(['snapshots' => $input['snapshots'], 'sourceCorrections' => array_column($input['lines'], 'corrections'), 'versions' => $e['versions'] ?? []], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES)) ?></pre></details>
    <p>Saving records your current adoption of price overrides, assumptions and corrections. It does not claim that a linked original image or a document-reported earlier approval was inspected.</p>
    <button name="op" value="save" class="primary">Save and review comparison</button>
    </fieldset>
</form>
