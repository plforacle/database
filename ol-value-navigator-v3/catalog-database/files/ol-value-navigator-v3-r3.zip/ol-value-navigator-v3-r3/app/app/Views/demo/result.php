<?php

declare(strict_types=1);

/** @var array<string, mixed> $data */
/** @var callable(mixed): string $escape */
$view = $data['view'] ?? null;
if (!$view instanceof \App\Application\Calculation\DemoComparisonView) {
    throw new \RuntimeException('The confirmed comparison view is unavailable.');
}
?>
<p class="eyebrow">Step 6 · Immutable trace</p>
<h1><?= $escape($view->title) ?></h1>
<p class="lede">This is a deterministic comparison of fixed synthetic annual subscription inputs. It is not a recommendation, full TCO, approved pricing, or customer-ready output.</p>
<div class="result-ledger">
    <section><p class="result-kicker">Synthetic source</p><strong><?= $escape($view->sourceAnnualTotal) ?></strong><span>USD · annual</span><dl><div><dt>Three year</dt><dd><?= $escape($view->sourceThreeYearTotal) ?></dd></div><div><dt>Five year</dt><dd><?= $escape($view->sourceFiveYearTotal) ?></dd></div></dl></section>
    <section><p class="result-kicker">Selected synthetic option</p><strong><?= $escape($view->optionAnnualTotal) ?></strong><span>USD · annual</span><dl><div><dt>Three year</dt><dd><?= $escape($view->optionThreeYearTotal) ?></dd></div><div><dt>Five year</dt><dd><?= $escape($view->optionFiveYearTotal) ?></dd></div></dl></section>
</div>
<section class="trace-section"><h2>Included line trace</h2><div class="table-wrap"><table><thead><tr><th>Line</th><th>Decision</th><th>Source</th><th>Quantity</th><th>Source unit price</th><th>Selected option</th><th>Option unit price</th></tr></thead><tbody><?php foreach ($view->includedLines as $line): ?><tr><td><?= $escape($line['lineId']) ?></td><td><?= $escape($line['decision']) ?></td><td><?= $escape($line['sourceSku']) ?></td><td><?= $escape($line['quantity']) ?></td><td><?= $escape($line['sourceAnnualUsdPrice']) ?></td><td><?= $escape($line['optionSku']) ?></td><td><?= $escape($line['optionAnnualUsdPrice']) ?></td></tr><?php endforeach; ?></tbody></table></div></section>
<?php if ($view->excludedLines !== []): ?><section class="trace-section"><h2>Explicit exclusions</h2><ul class="trace-list"><?php foreach ($view->excludedLines as $line): ?><li><strong><?= $escape($line['lineId']) ?></strong><span><?= $escape($line['reason']) ?></span></li><?php endforeach; ?></ul></section><?php endif; ?>
<section class="trace-grid">
    <div><h2>Calculation assumptions</h2><ul><?php foreach ($view->assumptions as $assumption): ?><li><?= $escape($assumption) ?></li><?php endforeach; ?></ul></div>
    <div><h2>Confirmation evidence</h2><dl class="evidence-list"><div><dt>Catalog</dt><dd><?= $escape($view->catalogLabel) ?><br><code><?= $escape($view->catalogVersionId) ?></code></dd></div><div><dt>Confirmed by</dt><dd><?= $escape($view->confirmedBySubject) ?></dd></div><div><dt>Confirmed at</dt><dd><?= $escape($view->confirmedAt) ?></dd></div><div><dt>Extraction</dt><dd><?= $view->extractionMode === 'AI' ? 'AI extraction evidence' : 'Manual fallback' ?></dd></div><?php if ($view->extractionMode === 'AI'): ?><div><dt>Model identifier</dt><dd><?= $escape($view->aiEvidence['modelIdentifier']) ?></dd></div><div><dt>Contract / prompt</dt><dd><?= $escape($view->aiEvidence['extractionContractVersion']) ?> / <?= $escape($view->aiEvidence['promptTemplateVersion']) ?></dd></div><div><dt>Response digest</dt><dd><code><?= $escape($view->aiEvidence['responseDigest']) ?></code></dd></div><?php endif; ?></dl></div>
</section>
<p class="final-boundary">Recommendation flag: <strong><?= $view->isRecommendation ? 'true' : 'false' ?></strong></p>
