<?php

declare(strict_types=1);

/** @var array<string, mixed> $data */
/** @var callable(mixed): string $escape */
$csrfToken = is_string($data['csrfToken'] ?? null) ? $data['csrfToken'] : '';
$sourceText = is_string($data['sourceText'] ?? null) ? $data['sourceText'] : '';
$error = is_string($data['error'] ?? null) ? $data['error'] : null;
$analysisId = is_string($data['analysisId'] ?? null) ? $data['analysisId'] : null;
?>
<?php if ($analysisId === null): ?>
    <p><a href="/demo/coverage/new">New v1.3.1 comparison →</a></p>
    <p><a href="/demo/coverage">Open shared coverage, OLAM and customer presentation comparison →</a></p>
    <p class="eyebrow">Step 1 · Representative input</p>
    <h1>Paste a deliberately synthetic subscription line.</h1>
    <p class="lede">This demo accepts redacted or synthetic text only. HeatWave may identify candidate SKUs and quantities; governed PHP remains the authority for every fact and total.</p>
    <?php if ($error !== null): ?><p class="form-error" id="source-error" role="alert"><?= $escape($error) ?></p><?php endif; ?>
    <form method="post" action="/demo/analyses" class="docket-form">
        <input type="hidden" name="_csrf" value="<?= $escape($csrfToken) ?>">
        <label for="source_text">Synthetic source text</label>
        <span class="field-hint" id="source-hint">Maximum 32,768 UTF-8 bytes. Do not enter customer data.</span>
        <textarea id="source_text" name="source_text" rows="9" maxlength="32768" aria-describedby="source-hint<?= $error !== null ? ' source-error' : '' ?>"<?= $error !== null ? ' aria-invalid="true"' : '' ?>><?= $escape($sourceText) ?></textarea>
        <div class="example-strip"><span>Demo shape</span><code>SYN-RHEL-BASE x2</code></div>
        <button type="submit">Create private synthetic analysis</button>
    </form>
<?php else: ?>
    <p class="eyebrow">Step 2 · Candidate extraction</p>
    <h1>The draft is isolated. Choose live extraction.</h1>
    <p class="lede">The configured HeatWave adapter will receive the redacted synthetic source through the constrained extraction contract. If it is unavailable or invalid, the workflow switches visibly to manual entry without substituting cached output.</p>
    <div class="state-callout state-callout--neutral"><strong>Draft recorded</strong><span>No candidate has been accepted and no total exists.</span></div>
    <form method="post" action="/demo/analyses/<?= $escape($analysisId) ?>/extract" class="action-row">
        <input type="hidden" name="_csrf" value="<?= $escape($csrfToken) ?>">
        <button type="submit">Extract candidates</button>
    </form>
<?php endif; ?>
