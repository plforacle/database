<?php

declare(strict_types=1);

/** @var array<string, mixed> $data */
/** @var callable(mixed): string $escape */
$pageTitle = is_string($data['pageTitle'] ?? null) ? $data['pageTitle'] : 'OL Value Navigator';
$currentStep = is_string($data['step'] ?? null) ? $data['step'] : 'paste';
$content = is_string($data['content'] ?? null) ? $data['content'] : '';
$scenarioPage = ($data['input']['schemaVersion'] ?? '') === '1.3.1';
$steps = [
    ['id' => 'paste', 'label' => 'Paste', 'owner' => 'Representative'],
    ['id' => 'extract', 'label' => 'Extract', 'owner' => 'HeatWave / manual'],
    ['id' => 'validate', 'label' => 'Validate', 'owner' => 'PHP contract'],
    ['id' => 'resolve', 'label' => 'Resolve', 'owner' => 'Representative'],
    ['id' => 'calculate', 'label' => 'Calculate', 'owner' => 'PHP authority'],
    ['id' => 'record', 'label' => 'Record', 'owner' => 'Immutable trace'],
];
$stepIds = array_column($steps, 'id');
$currentIndex = array_search($currentStep, $stepIds, true);
$currentIndex = is_int($currentIndex) ? $currentIndex : 0;
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= $escape($pageTitle) ?> · OL Value Navigator</title>
    <link rel="stylesheet" href="/assets/app.css">
</head>
<body>
    <div class="boundary-banner" role="note">
        PRIVATE SYNTHETIC DEMO — APPLICATION AUTHENTICATION NOT IMPLEMENTED
    </div>
    <header class="site-header">
        <a class="wordmark" href="/demo" aria-label="OL Value Navigator home">
            <span class="wordmark-mark" aria-hidden="true">OL</span>
            <span><strong>Value Navigator</strong><small>Governed comparison docket</small></span>
        </a>
        <div class="catalog-stamp">
            <span><?= $scenarioPage ? 'Comparison rules v1.3.1' : 'Fixture catalog' ?></span>
            <strong><?= $scenarioPage ? 'Selected price evidence' : 'Not Oracle pricing' ?></strong>
        </div>
    </header>
    <nav class="authority-rail" aria-label="Comparison authority chain">
        <ol>
            <?php foreach ($steps as $index => $railStep): ?>
                <?php $status = $index < $currentIndex ? 'complete' : ($index === $currentIndex ? 'current' : 'pending'); ?>
                <li class="rail-step rail-step--<?= $escape($status) ?>"<?= $status === 'current' ? ' aria-current="step"' : '' ?>>
                    <span class="rail-node" aria-hidden="true"></span>
                    <span class="rail-copy"><strong><?= $escape($railStep['label']) ?></strong><small><?= $escape($railStep['owner']) ?></small></span>
                </li>
            <?php endforeach; ?>
        </ol>
    </nav>
    <main class="page-shell">
        <section class="work-surface">
            <?= $content ?>
        </section>
        <aside class="authority-ledger" aria-labelledby="authority-ledger-title">
            <p class="eyebrow">Authority ledger</p>
            <h2 id="authority-ledger-title">What the browser can—and cannot—decide</h2>
            <dl>
                <div><dt>Representative controls</dt><dd><?= $scenarioPage ? 'Reviewed source quantities, explicit price adoption, corrections, assumptions and support selection.' : 'Synthetic source, SKU correction, quantity, explicit exclusion, and option selection.' ?></dd></div>
                <div><dt>Server owns</dt><dd><?= $scenarioPage ? 'Current adopter, versioned catalog, mappings, validation, revision history and calculated totals.' : 'Identity, role, catalog version, descriptions, mappings, prices, evidence, state, and totals.' ?></dd></div>
                <div><dt>AI authority</dt><dd>Candidate extraction only. Never approval, pricing, mapping, or recommendation.</dd></div>
            </dl>
            <p class="ledger-note">Every total remains absent until all included lines pass the governed PHP checks.</p>
        </aside>
    </main>
</body>
</html>
