<?php

declare(strict_types=1);

/** @var array<string, mixed> $data */
/** @var callable(mixed): string $escape */
$title = is_string($data['title'] ?? null) ? $data['title'] : 'Request could not be completed';
$message = is_string($data['message'] ?? null) ? $data['message'] : 'Return to the synthetic demo and try again.';
$returnPath = is_string($data['returnPath'] ?? null) && str_starts_with($data['returnPath'], '/demo') ? $data['returnPath'] : '/demo';
?>
<p class="eyebrow">Fail-closed boundary</p>
<h1><?= $escape($title) ?></h1>
<p class="lede"><?= $escape($message) ?></p>
<div class="state-callout state-callout--warning"><strong>No authority was inferred</strong><span>Totals, identity, governed facts, and role remain server-owned.</span></div>
<a class="button-link" href="<?= $escape($returnPath) ?>">Return to the governed workflow</a>
