<?php

declare(strict_types=1);

/** @var array<string,mixed> $data */
/** @var callable(mixed):string $escape */
$p = $data['preview'];
$profile = $p['profile'] ?? [];
$imageColumns = ['sku' => 'A', 'description' => 'B', 'quantity' => 'C', 'startDate' => 'D', 'endDate' => 'E', 'unitPrice' => 'F', 'lineTotal' => 'G'];
$image = str_starts_with($p['mediaType'] ?? '', 'image/');
$input = static function (string $key, string $label, mixed $value) use ($escape): void {
    echo '<label>' . $escape($label) . '<input name="profile[' . $escape($key) . ']" value="' . $escape($value) . '"></label>';
};
?>
<h1>Review imported source</h1>
<p><?= $escape($p['filename']) ?> · <?= $escape(count($p['rows'])) ?> preserved rows · <?= $escape($p['sourceType'] ?? 'Unverified source type') ?></p>
<p>This preview preserves the file and raw rows. Column mapping, quantity meaning, price period, SKU identity and physical coverage require separate review before a comparison is complete.</p>
<?php foreach ($p['issues'] as $issue): ?><p class="scenario-warning"><?= $escape(is_array($issue) ? ($issue['message'] ?? $issue['code'] ?? '') : $issue) ?></p><?php endforeach; ?>
<?php if ($image): ?><p><a href="/demo/coverage/source/<?= $escape($p['id']) ?>/image">Open preserved source image</a></p><div class="source-preview"><img src="/demo/coverage/source/<?= $escape($p['id']) ?>/image" alt="Preserved uploaded source; transcribe only visible values"></div><?php endif; ?>
<form method="post" action="/demo/coverage/source/<?= $escape($p['id']) ?>">
    <input type="hidden" name="_csrf" value="<?= $escape($data['csrfToken']) ?>">
    <fieldset><legend>Source meaning and column mapping</legend><div class="scenario-fields">
        <label>Declared source<select name="profile[sourceType]"><?php foreach (['WORKSHEET' => 'Worksheet', 'SATELLITE_EXPORT' => 'Customer-declared Satellite export', 'IMAGE_TRANSCRIPTION' => 'Image transcription'] as $v => $label): ?><option value="<?= $escape($v) ?>"<?= ($profile['sourceType'] ?? ($image ? 'IMAGE_TRANSCRIPTION' : 'WORKSHEET')) === $v ? ' selected' : '' ?>><?= $escape($label) ?></option><?php endforeach; ?></select></label>
        <label>Origin evidence<select name="profile[sourceOrigin]"><option value="UNVERIFIED">Originating application unverified</option><option value="CUSTOMER_DECLARED"<?= ($profile['sourceOrigin'] ?? '') === 'CUSTOMER_DECLARED' ? ' selected' : '' ?>>Customer-declared origin</option></select></label>
        <label>Numerical locale<select name="profile[locale]"><?php foreach (['UNKNOWN' => 'Unknown — do not guess', 'en_US' => '1,234.56', 'de_DE' => '1.234,56', 'fr_FR' => '1 234,56'] as $v => $label): ?><option value="<?= $escape($v) ?>"<?= ($profile['locale'] ?? '') === $v ? ' selected' : '' ?>><?= $escape($label) ?></option><?php endforeach; ?></select></label>
        <label>Date convention<select name="profile[dateLocale]"><?php foreach (['ISO' => 'YYYY-MM-DD', 'MDY' => 'Month/day/year', 'DMY' => 'Day/month/year'] as $v => $label): ?><option value="<?= $escape($v) ?>"<?= ($profile['dateLocale'] ?? '') === $v ? ' selected' : '' ?>><?= $escape($label) ?></option><?php endforeach; ?></select></label>
        <label>Quantity meaning<select name="profile[quantityBasis]"><?php foreach (['UNKNOWN', 'PURCHASED', 'MANIFEST_ALLOCATED', 'HOST_ASSOCIATED', 'HOST_INVENTORY', 'CONSUMPTION', 'ASSUMED'] as $v): ?><option value="<?= $escape($v) ?>"<?= ($profile['quantityBasis'] ?? '') === $v ? ' selected' : '' ?>><?= $escape(str_replace('_', ' ', $v)) ?></option><?php endforeach; ?></select></label>
        <?php $input('headerRow', 'Header row number', $profile['headerRow'] ?? 1); ?>
        <?php if (!$image): foreach (['sku' => 'SKU column', 'description' => 'Description column', 'quantity' => 'Quantity column', 'startDate' => 'Start date column', 'endDate' => 'End date column', 'unitPrice' => 'Unit price column', 'lineTotal' => 'Supplied total column', 'rowType' => 'Row type column'] as $key => $label): ?>
            <label><?= $escape($label) ?> (A, B, C…; blank if absent)<input name="profile[columnMap][<?= $escape($key) ?>]" value="<?= $escape($profile['columnMap'][$key] ?? '') ?>"></label>
        <?php endforeach; endif; ?>
    </div></fieldset>
    <?php if (!$image): $sheetNames = array_values(array_unique(array_column($p['rows'], 'sheet'))); ?>
        <details><summary>Different column layouts by worksheet tab</summary><p>Leave a tab override blank to use the main column mapping above.</p>
        <?php foreach ($sheetNames as $sheetIndex => $sheetName): ?><fieldset><legend><?= $escape($sheetName) ?></legend><div class="scenario-fields">
            <label>Header row<input name="profile[sheetProfiles][<?= $escape($sheetIndex) ?>][headerRow]" value="<?= $escape($profile['sheetProfiles'][$sheetName]['headerRow'] ?? $profile['headerRow'] ?? 1) ?>"></label>
            <?php foreach (['sku', 'description', 'quantity', 'startDate', 'endDate', 'unitPrice', 'lineTotal', 'rowType'] as $fieldName): ?><label><?= $escape($fieldName) ?> column<input name="profile[sheetProfiles][<?= $escape($sheetIndex) ?>][columnMap][<?= $escape($fieldName) ?>]" value="<?= $escape($profile['sheetProfiles'][$sheetName]['columnMap'][$fieldName] ?? '') ?>"></label><?php endforeach; ?>
        </div></fieldset><?php endforeach; ?></details>
    <?php endif; ?>
    <?php if ($image): ?>
        <fieldset><legend>Visible image transcription</legend><p>Enter only what is visible. Leave unreadable or absent amounts blank; document image limitations. The current reviewer is stamped by the server when you submit this visual review.</p>
        <?php for ($r = 0; $r < max(10, count($profile['manualRows'] ?? [])); ++$r): ?><details<?= $r === 0 ? ' open' : '' ?>><summary>Image row <?= $escape($r + 1) ?></summary><div class="scenario-fields">
            <?php foreach (['sku', 'description', 'quantity', 'startDate', 'endDate', 'unitPrice', 'lineTotal'] as $key): ?><label><?= $escape($key) ?><input name="profile[manualRows][<?= $escape($r) ?>][<?= $escape($key) ?>]" value="<?= $escape($profile['manualRows'][$r][$imageColumns[$key]] ?? '') ?>"></label><?php endforeach; ?>
        </div></details><?php endfor; ?>
        <label>Visual review evidence / unreadable or missing fields<input name="profile[visualReview][evidence]" value="<?= $escape($profile['visualReview']['evidence'] ?? '') ?>"></label></fieldset>
    <?php endif; ?>
    <button name="op" value="map">Review mapping / transcription</button>
    <button name="op" value="adopt">Adopt this reviewed preview into a new draft</button>
</form>
<div class="source-preview"><table><thead><tr><th>Sheet / row</th><th>Type</th><th>SKU</th><th>Description</th><th>Quantity</th><th>Unit amount</th><th>Issues</th></tr></thead><tbody>
<?php foreach ($p['rows'] as $row): ?><tr><td><?= $escape($row['sheet']) ?> / <?= $escape($row['row']) ?></td><td><?= $escape($row['rowType']) ?></td><td><?= $escape($row['sku'] ?? '') ?></td><td><?= $escape($row['description'] ?? '') ?></td><td><?= $escape($row['quantity'] ?? 'Unknown') ?></td><td><?= $escape($row['unitPrice'] ?? 'Unknown') ?></td><td><?= $escape(json_encode($row['issues'] ?? [])) ?></td></tr><?php endforeach; ?>
</tbody></table></div>
<details><summary>Raw rows, file hash and parser evidence</summary><pre><?= $escape(json_encode($p, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES)) ?></pre></details>
<p><a href="/demo/coverage/new">Return to a new comparison</a></p>
