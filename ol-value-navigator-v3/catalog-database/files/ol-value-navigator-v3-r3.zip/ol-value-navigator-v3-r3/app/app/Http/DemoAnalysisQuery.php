<?php

declare(strict_types=1);

namespace App\Http;

use App\Domain\Analysis\AnalysisRepository;
use App\Domain\Shared\Actor;
use App\Domain\Shared\AnalysisId;
use App\Domain\Shared\ResourceNotFound;
use App\Domain\Shared\RevisionId;
use App\Infrastructure\Persistence\PdoTransaction;

final readonly class DemoAnalysisQuery
{
    public function __construct(
        private PdoTransaction $transaction,
        private AnalysisRepository $analyses,
    ) {
    }

    /** @return array<string, mixed> */
    public function snapshot(string $analysisRouteId, Actor $actor): array
    {
        try {
            $analysisId = AnalysisId::fromString($analysisRouteId);
        } catch (\DomainException) {
            throw ResourceNotFound::because('Analysis not found.');
        }

        return $this->transaction->run(function () use ($analysisId, $actor): array {
            $analysis = $this->analyses->findForSubject($analysisId, $actor);
            $revisionValue = $analysis['currentRevisionId'] ?? null;
            if (!is_string($revisionValue)) {
                throw ResourceNotFound::because('Analysis not found.');
            }
            try {
                $revisionId = RevisionId::fromString($revisionValue);
            } catch (\DomainException) {
                throw ResourceNotFound::because('Analysis not found.');
            }
            $snapshot = $this->analyses->lockConfirmationSnapshot($revisionId, $actor);
            if ($snapshot === null) {
                throw ResourceNotFound::because('Analysis not found.');
            }

            return [
                'analysisId' => (string) $analysisId,
                'revisionId' => (string) $revisionId,
                ...$snapshot,
            ];
        });
    }

    /** @return array<string, mixed> */
    public function confirmedProjection(string $revisionId, Actor $actor): array
    {
        $projection = $this->analyses->findConfirmedComparisonForSubject(
            RevisionId::fromString($revisionId),
            $actor,
        );
        if ($projection === null) {
            throw ResourceNotFound::because('Analysis not found.');
        }

        return $projection;
    }
}
