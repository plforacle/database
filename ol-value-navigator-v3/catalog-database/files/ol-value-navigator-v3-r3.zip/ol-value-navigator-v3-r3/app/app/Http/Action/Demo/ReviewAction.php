<?php

declare(strict_types=1);

namespace App\Http\Action\Demo;

use App\Domain\Analysis\AnalysisState;
use App\Domain\Shared\ResourceNotFound;
use App\Http\DemoAnalysisQuery;
use App\Http\DemoPage;
use App\Http\DemoRequest;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;

final readonly class ReviewAction
{
    public function __construct(
        private DemoAnalysisQuery $query,
        private DemoPage $pages,
    ) {
    }

    /** @param array<string, string> $args */
    public function __invoke(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        $analysisId = $args['analysisId'] ?? '';
        try {
            $snapshot = $this->query->snapshot($analysisId, DemoRequest::actor($request));
        } catch (ResourceNotFound) {
            return $this->pages->error($response, 404, 'Analysis not found', 'The requested synthetic analysis is unavailable.');
        }
        if ($snapshot['state'] === AnalysisState::CONFIRMED) {
            return $response->withStatus(303)->withHeader('Location', '/demo/analyses/' . $analysisId);
        }
        if ($snapshot['state'] === AnalysisState::DRAFT) {
            return $response->withStatus(303)->withHeader('Location', '/demo/analyses/' . $analysisId);
        }

        return $this->pages->render($response, 'review', [
            'pageTitle' => 'Resolve governed lines',
            'step' => $snapshot['state'] === AnalysisState::READY_TO_CALCULATE ? 'calculate' : 'resolve',
            'csrfToken' => DemoRequest::csrf($request),
            'analysisId' => $analysisId,
            'revisionId' => $snapshot['revisionId'],
            'state' => $snapshot['state'],
            'lines' => $snapshot['lines'],
        ]);
    }
}
