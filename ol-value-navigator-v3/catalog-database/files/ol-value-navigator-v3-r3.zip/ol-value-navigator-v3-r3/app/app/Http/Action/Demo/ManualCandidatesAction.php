<?php

declare(strict_types=1);

namespace App\Http\Action\Demo;

use App\Application\Extraction\ExtractCandidates;
use App\Domain\Shared\DomainViolation;
use App\Domain\Shared\RequestId;
use App\Domain\Shared\ResourceNotFound;
use App\Domain\Shared\RevisionId;
use App\Http\DemoAnalysisQuery;
use App\Http\DemoPage;
use App\Http\DemoRequest;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;

final readonly class ManualCandidatesAction
{
    public function __construct(
        private ExtractCandidates $extract,
        private DemoAnalysisQuery $query,
        private DemoPage $pages,
    ) {
    }

    /** @param array<string, string> $args */
    public function __invoke(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        $analysisId = $args['analysisId'] ?? '';
        try {
            $body = DemoRequest::body($request);
            DemoRequest::exactFields($body, [
                '_csrf',
                'line_id',
                'source_start',
                'source_end',
                'source_excerpt',
                'sku',
                'quantity',
            ]);
            $snapshot = $this->query->snapshot($analysisId, DemoRequest::actor($request));
            $this->extract->acceptManual(RevisionId::fromString((string) $snapshot['revisionId']), [[
                'lineId' => DemoRequest::string($body, 'line_id'),
                'sourceStart' => DemoRequest::unsignedInteger($body, 'source_start'),
                'sourceEnd' => DemoRequest::unsignedInteger($body, 'source_end'),
                'sourceExcerpt' => DemoRequest::string($body, 'source_excerpt'),
                'sku' => DemoRequest::string($body, 'sku'),
                'quantity' => DemoRequest::string($body, 'quantity'),
            ]], RequestId::new());

            return $response->withStatus(303)->withHeader('Location', '/demo/analyses/' . $analysisId . '/review');
        } catch (ResourceNotFound) {
            return $this->pages->error($response, 404, 'Analysis not found', 'The requested synthetic analysis is unavailable.');
        } catch (DomainViolation|\RuntimeException $exception) {
            return $this->pages->error(
                $response,
                422,
                'Manual candidate was not accepted',
                'The structured fields must match the submitted synthetic source exactly.',
                '/demo/analyses/' . $analysisId,
            );
        }
    }
}
