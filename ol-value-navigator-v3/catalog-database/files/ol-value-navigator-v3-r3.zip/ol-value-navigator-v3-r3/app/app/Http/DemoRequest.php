<?php

declare(strict_types=1);

namespace App\Http;

use App\Domain\Shared\Actor;
use App\Domain\Shared\DomainViolation;
use Psr\Http\Message\ServerRequestInterface;

final class DemoRequest
{
    /** @return array<string, mixed> */
    public static function body(ServerRequestInterface $request): array
    {
        $body = $request->getParsedBody();
        if (!is_array($body) || array_is_list($body)) {
            throw DomainViolation::because('This action requires a structured form body.');
        }

        return $body;
    }

    /** @param array<string, mixed> $body
     * @param list<string> $expected
     */
    public static function exactFields(array $body, array $expected): void
    {
        $actual = array_keys($body);
        if (count($actual) !== count($expected)
            || array_diff($actual, $expected) !== []
            || array_diff($expected, $actual) !== []
        ) {
            throw DomainViolation::because('This request included fields this action does not accept.');
        }
    }

    /** @param array<string, mixed> $body */
    public static function string(array $body, string $field): string
    {
        $value = $body[$field] ?? null;
        if (!is_string($value)) {
            throw DomainViolation::because(sprintf('The %s field must be text.', $field));
        }

        return $value;
    }

    /** @param array<string, mixed> $body */
    public static function unsignedInteger(array $body, string $field): int
    {
        $value = self::string($body, $field);
        if ($value === '' || !ctype_digit($value)) {
            throw DomainViolation::because(sprintf('The %s field must be a nonnegative integer.', $field));
        }
        $integer = filter_var($value, FILTER_VALIDATE_INT, ['options' => ['min_range' => 0]]);
        if (!is_int($integer)) {
            throw DomainViolation::because(sprintf('The %s field must be a nonnegative integer.', $field));
        }

        return $integer;
    }

    public static function actor(ServerRequestInterface $request): Actor
    {
        $actor = $request->getAttribute('demoActor');
        if (!$actor instanceof Actor) {
            throw DomainViolation::because('The fixed demo representative is unavailable.');
        }

        return $actor;
    }

    public static function csrf(ServerRequestInterface $request): string
    {
        $token = $request->getAttribute('csrfToken');
        if (!is_string($token) || preg_match('/^[0-9a-f]{64}$/D', $token) !== 1) {
            throw DomainViolation::because('The request verification token is unavailable.');
        }

        return $token;
    }
}
