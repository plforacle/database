<?php

declare(strict_types=1);

namespace App\Http\Action\Demo;

use App\Application\Coverage\CustomerPresentation;
use App\Application\Coverage\ScenarioForm;
use App\Application\Coverage\SavedCoverageCatalog;
use App\Application\Coverage\SavedResultContract;
use App\Application\Package\CatalogSnapshotResolver;
use App\Domain\Coverage\ScenarioInput;
use App\Domain\Coverage\ScenarioImport;
use App\Domain\Coverage\ScenarioVmware;
use App\Infrastructure\Persistence\CoverageSnapshotStore;
use App\Domain\Coverage\CoverageScenario;
use App\Domain\Shared\DomainViolation;
use App\Http\DemoPage;
use App\Http\DemoRequest;
use App\Infrastructure\Persistence\CoverageStore;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;

final readonly class CoverageAction
{
    public function __construct(private CoverageStore $store, private DemoPage $pages, private CatalogSnapshotResolver $catalogs)
    {
    }

    /** @param array<string,string> $args */
    public function form(ServerRequestInterface $request, ResponseInterface $response, array $args = []): ResponseInterface
    {
        try {
            $query = $request->getQueryParams();
            if (array_diff(array_keys($query), ['edit', 'review']) !== [] || (isset($query['edit']) && $query['edit'] !== '1')) {
                throw DomainViolation::because('Choose a saved review or edit its successor.');
            }
            $editing = ($query['edit'] ?? '') === '1';
            $snapshot = isset($args['revisionId']) ? $this->store->read(DemoRequest::actor($request), $args['revisionId']) : null;
            if (($snapshot['input']['schemaVersion'] ?? '') === '1.3.1') {
                return $this->scenarioPage($request, $response, $snapshot['input'], $snapshot, $editing);
            }
            return $this->pages->render($response, 'coverage', [
                'pageTitle' => 'Coverage and customer presentation', 'step' => $snapshot === null || $editing ? 'resolve' : 'calculate',
                'csrfToken' => DemoRequest::csrf($request), 'snapshot' => $snapshot, 'editing' => $editing,
                'reviewChanged' => ($query['review'] ?? '') === 'selection-changed',
                'input' => $snapshot['input'] ?? CoverageScenario::example(),
                ...$this->displayCatalog($request, $snapshot, $editing, 'legacy-coverage'),
            ]);
        } catch (DomainViolation|\UnexpectedValueException $error) {
            $active = !isset($args['revisionId']) || ($request->getQueryParams()['edit'] ?? '') === '1';
            return $this->pages->error($response, $active ? 422 : 404, 'Comparison unavailable', $error->getMessage(), '/demo/coverage');
        }
    }

    public function save(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        try {
            $body = DemoRequest::body($request);
            $selection = $this->editorSelection($body);
            DemoRequest::exactFields($body, ['_csrf', 'comparisonId', 'expectedRevision', 'scenario']);
            $input = $body['scenario'];
            if (!is_array($input) || array_is_list($input)) {
                throw DomainViolation::because('A structured comparison is required.');
            }
            if (($input['schemaVersion'] ?? '') === '1.3.1') {
                return $this->saveScenario($request, $response, $input, DemoRequest::string($body, 'comparisonId'), DemoRequest::string($body, 'expectedRevision'), $selection);
            }
            $groups = $input['groups'] ?? null;
            $lines = $input['lines'] ?? null;
            if (!is_array($groups) || count($groups) > 5 || !is_array($lines) || count($lines) > 10) {
                throw DomainViolation::because('Use up to five populations and ten source subscriptions.');
            }
            $includedGroups = [];
            foreach ($groups as $group) {
                if (!is_array($group)) {
                    throw DomainViolation::because('Population fields are invalid.');
                }
                if (($group['populationKey'] ?? null) === '' && ($group['systems'] ?? null) === '') {
                    continue;
                }
                foreach (['olamRequired' => 'the OLAM requirement', 'sourceEntitlementsConfirmed' => 'the Red Hat source entitlements', 'workstationScopeAcknowledged' => 'the workstation comparison scope'] as $field => $label) {
                    $answer = $group[$field] ?? null;
                    if (!in_array($answer, ['0', '1'], true)) {
                        throw DomainViolation::because('Confirm ' . $label . '.');
                    }
                    $group[$field] = $answer === '1';
                }
                $includedGroups[] = $group;
            }
            $input['groups'] = $includedGroups;
            $input['lines'] = array_values(array_filter($lines, static fn (mixed $line): bool => !is_array($line) || ($line['sku'] ?? null) !== ''));
            $comparisonId = DemoRequest::string($body, 'comparisonId');
            $expected = DemoRequest::string($body, 'expectedRevision');
            $saved = $this->store->save(DemoRequest::actor($request), $input, $comparisonId === '' ? null : $comparisonId, $expected === '' ? null : $expected);
            return $this->savedRedirect($response, $saved, $selection);
        } catch (DomainViolation $error) {
            return $this->pages->error($response, 422, 'Review the comparison inputs', $error->getMessage(), '/demo/coverage');
        }
    }

    public function newScenario(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        try {
            return $this->scenarioPage($request, $response, ScenarioInput::example());
        } catch (DomainViolation $error) {
            return $this->pages->error($response, 422, 'Catalog unavailable', $error->getMessage(), '/demo/coverage');
        }
    }

    public function editScenario(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        try {
            $body = DemoRequest::body($request);
            $selection = $this->editorSelection($body);
            DemoRequest::exactFields($body, ['_csrf', 'comparisonId', 'expectedRevision', 'scenarioJson', 'edit', 'op']);
            $encoded = DemoRequest::string($body, 'scenarioJson');
            if (strlen($encoded) > 4194304) {
                throw DomainViolation::because('The scenario exceeds the review limit.');
            }
            $input = json_decode($encoded, true, 32, JSON_THROW_ON_ERROR);
            if (!is_array($input) || array_is_list($input) || !is_array($body['edit'])) {
                throw DomainViolation::because('Structured editor fields are required.');
            }
            $input = ScenarioForm::apply($input, $body['edit']);
            $op = DemoRequest::string($body, 'op');
            $comparisonId = DemoRequest::string($body, 'comparisonId');
            $expected = DemoRequest::string($body, 'expectedRevision');
            if ($op === 'save') {
                return $this->saveScenario($request, $response, $input, $comparisonId, $expected, $selection);
            }
            if ($op === 'add-line') {
                $input['lines'][] = ['id' => 'line-' . bin2hex(random_bytes(4)), 'identityState' => 'CATALOG'];
            } elseif ($op === 'add-group') {
                $input['groups'][] = ['id' => 'group-' . bin2hex(random_bytes(4))];
            } elseif ($op === 'add-pool') {
                $input['pools'][] = ['id' => 'pool-' . bin2hex(random_bytes(4))];
            } elseif ($op === 'add-other') {
                $input['otherCosts'][] = ['id' => 'cost-' . bin2hex(random_bytes(4))];
            } elseif (preg_match('/^(vmware|host|feature|allocation|extra|correction|description-correction):(\d{1,3})$/D', $op, $match)) {
                $index = (int) $match[2];
                $collection = in_array($match[1], ['allocation', 'extra'], true) ? 'pools' : 'lines';
                if (!isset($input[$collection][$index])) {
                    throw DomainViolation::because('The selected editor row is unavailable.');
                }
                if ($match[1] === 'vmware') {
                    $input['lines'][$index]['vmware'] = ['features' => array_map(static fn (string $name): array => ['name' => $name, 'status' => 'UNRESOLVED'], ScenarioVmware::FEATURES)];
                } elseif ($match[1] === 'host') {
                    $input['lines'][$index]['vmware']['sourceHosts'][] = ['id' => 'source-host-' . bin2hex(random_bytes(4)), 'cpus' => []];
                } elseif ($match[1] === 'feature') {
                    $input['lines'][$index]['vmware']['features'][] = ['name' => 'Required capability', 'status' => 'UNRESOLVED'];
                } elseif ($match[1] === 'allocation') {
                    $input['pools'][$index]['allocations'][] = ['groupId' => '', 'pairs' => null];
                } elseif ($match[1] === 'extra') {
                    $input['pools'][$index]['extraPurchases'][] = ['id' => 'purchase-' . bin2hex(random_bytes(4)), 'offering' => 'OL-PREMIER', 'units' => 0];
                } else {
                    $line = & $input['lines'][$index];
                    $field = $match[1] === 'description-correction' ? 'description' : 'sku';
                    $old = $field === 'sku' ? $line['rawSku'] : $line['description'];
                    $new = $field === 'sku' ? $line['sku'] : $line['adoptedDescription'];
                    if ($old === $new || $new === '' || trim($line['identityEvidence']) === '') {
                        throw DomainViolation::because('Enter the corrected SKU and a reason with evidence before recording the correction.');
                    }
                    $line['corrections'][] = ['field' => $field, 'oldValue' => $old, 'newValue' => $new, 'reason' => $line['identityEvidence'], 'evidence' => $line['identityEvidence']];
                    unset($line);
                }
            } else {
                throw DomainViolation::because('Choose a supported editor action.');
            }
            $input = ScenarioInput::normalize($input);
            $snapshot = $expected === '' ? null : $this->store->read(DemoRequest::actor($request), $expected);
            return $this->scenarioPage($request, $response, $input, $snapshot, true, $selection);
        } catch (DomainViolation|\JsonException $error) {
            return $this->pages->error($response, 422, 'Review the scenario fields', $error->getMessage(), '/demo/coverage/new');
        }
    }

    public function importScenario(ServerRequestInterface $request, ResponseInterface $response): ResponseInterface
    {
        try {
            $body = DemoRequest::body($request);
            DemoRequest::exactFields($body, ['_csrf', 'syntheticAcknowledged']);
            if ($body['syntheticAcknowledged'] !== '1') {
                throw DomainViolation::because('Use only synthetic or deliberately redacted files in this private prototype.');
            }
            $uploads = $request->getUploadedFiles();
            $upload = $uploads['source'] ?? null;
            if (!$upload instanceof \Psr\Http\Message\UploadedFileInterface || count($uploads) !== 1) {
                throw DomainViolation::because('Select exactly one source file.');
            }
            $actor = DemoRequest::actor($request);
            $files = new CoverageSnapshotStore();
            $saved = $files->retain($actor, $upload);
            $preview = ScenarioImport::preview($files->path($actor, $saved['id']), $saved['filename'], ['existingHashes' => $files->hashes($actor)]);
            $preview['id'] = $saved['id'];
            $files->savePreview($actor, $saved['id'], $preview);
            return $response->withStatus(303)->withHeader('Location', '/demo/coverage/source/' . $saved['id']);
        } catch (DomainViolation|\InvalidArgumentException|\RuntimeException $error) {
            return $this->pages->error($response, 422, 'Source review required', $error->getMessage(), '/demo/coverage/new');
        }
    }

    /** @param array<string,string> $args */
    public function sourcePreview(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        try {
            $preview = (new CoverageSnapshotStore())->preview(DemoRequest::actor($request), $args['sourceId']);
            return $this->pages->render($response, 'scenario-import', ['pageTitle' => 'Review imported source', 'step' => 'resolve', 'csrfToken' => DemoRequest::csrf($request), 'preview' => $preview]);
        } catch (DomainViolation $error) {
            return $this->pages->error($response, 404, 'Source unavailable', $error->getMessage(), '/demo/coverage/new');
        }
    }

    /** @param array<string,string> $args */
    public function reviewSource(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        try {
            $body = DemoRequest::body($request);
            DemoRequest::exactFields($body, ['_csrf', 'profile', 'op']);
            if (!is_array($body['profile'])) {
                throw DomainViolation::because('Choose the source column mapping.');
            }
            $actor = DemoRequest::actor($request);
            $files = new CoverageSnapshotStore();
            $existing = $files->preview($actor, $args['sourceId']);
            $profile = $body['profile'];
            $profile['existingHashes'] = $existing['profile']['existingHashes'] ?? [];
            if (isset($profile['headerRow']) && is_string($profile['headerRow']) && ctype_digit($profile['headerRow'])) {
                $profile['headerRow'] = (int) $profile['headerRow'];
            }
            if (isset($profile['columnMap']) && is_array($profile['columnMap'])) {
                $profile['columnMap'] = array_filter($profile['columnMap'], static fn (mixed $value): bool => $value !== '');
            }
            if (isset($profile['sheetProfiles']) && is_array($profile['sheetProfiles'])) {
                $sheetNames = array_values(array_unique(array_column($existing['rows'], 'sheet')));
                $overrides = [];
                foreach ($profile['sheetProfiles'] as $index => $sheetProfile) {
                    if (!is_array($sheetProfile) || !isset($sheetNames[$index]) || !is_array($sheetProfile['columnMap'] ?? null)) {
                        throw DomainViolation::because('Select an existing worksheet tab for its column override.');
                    }
                    $map = array_filter($sheetProfile['columnMap'], static fn (mixed $value): bool => $value !== '');
                    if ($map !== []) {
                        $header = $sheetProfile['headerRow'] ?? '';
                        if (!is_string($header) || !ctype_digit($header)) {
                            throw DomainViolation::because('Header rows must be whole numbers.');
                        }
                        $overrides[$sheetNames[$index]] = ['columnMap' => $map, 'headerRow' => (int) $header];
                    }
                }
                $profile['sheetProfiles'] = $overrides;
            }
            if (isset($profile['manualRows']) && is_array($profile['manualRows'])) {
                $profile['manualRows'] = array_values(array_filter($profile['manualRows'], static fn (mixed $row): bool => is_array($row) && count(array_filter($row, static fn (mixed $value): bool => $value !== '')) > 0));
                $imageColumns = ['sku' => 'A', 'description' => 'B', 'quantity' => 'C', 'startDate' => 'D', 'endDate' => 'E', 'unitPrice' => 'F', 'lineTotal' => 'G'];
                $profile['manualRows'] = array_map(static function (array $row) use ($imageColumns): array {
                    $raw = [];
                    foreach ($imageColumns as $field => $column) {
                        $raw[$column] = $row[$field] ?? '';
                    }
                    return $raw;
                }, $profile['manualRows']);
                $profile['columnMap'] = $imageColumns;
                $profile['headerRow'] = 0;
                $profile['visualReview']['reviewer'] = $actor->identifier();
                $profile['visualReview']['at'] = gmdate('Y-m-d\TH:i:s\Z');
            }
            if (($body['op'] ?? '') === 'map') {
                $preview = ScenarioImport::preview($files->path($actor, $args['sourceId']), $existing['filename'], $profile);
                $preview = $files->revisePreview($actor, $args['sourceId'], $preview);
                return $response->withStatus(303)->withHeader('Location', '/demo/coverage/source/' . $preview['id']);
            }
            if (($body['op'] ?? '') !== 'adopt') {
                throw DomainViolation::because('Choose review mapping or adopt reviewed rows.');
            }
            foreach ($existing['issues'] as $issue) {
                if (in_array($issue['code'], ['IMAGE_TRANSCRIPTION_REQUIRED', 'IMAGE_VISUAL_REVIEW_REQUIRED', 'COLUMN_MAPPING_REQUIRED', 'SHEET_MAPPING_REQUIRED'], true)) {
                    throw DomainViolation::because('Complete column mapping and image visual review before adopting the preview.');
                }
            }
            $input = ScenarioInput::normalize(['customer' => ['name' => 'Redacted source review'], 'snapshots' => [$existing], 'groups' => [['id' => 'g1', 'label' => 'Physical targets to review']], 'lines' => []]);
            foreach ($existing['rows'] as $index => $row) {
                $line = ['id' => 'import-' . $index, 'sourceId' => $existing['id'] . ':' . $row['sheet'] . ':' . $row['row'], 'rawSku' => $row['sku'] ?? '', 'sku' => $row['sku'] ?? '', 'description' => $row['description'] ?? '', 'identityState' => 'CATALOG', 'rowType' => $row['rowType'], 'quantity' => $row['quantity'], 'quantityBasis' => $existing['quantityBasis'], 'startDate' => $row['startDate'] ?? '', 'endDate' => $row['endDate'] ?? '', 'suppliedTotal' => $row['lineTotal'] ?? null];
                if (($row['unitPrice'] ?? null) !== null) {
                    $line['price'] = ['amount' => $row['unitPrice'], 'originalAmount' => $row['unitPrice'], 'periodBasis' => 'UNKNOWN', 'evidence' => 'Transcribed amount from preserved source; review metric, term and authority before adopting.', 'verification' => 'UNVERIFIED'];
                }
                $input['lines'][] = $line;
            }
            $input = ScenarioInput::normalize($input);
            return $this->scenarioPage($request, $response, $input, null, true);
        } catch (DomainViolation|\InvalidArgumentException|\RuntimeException $error) {
            return $this->pages->error($response, 422, 'Review source mapping', $error->getMessage(), '/demo/coverage/source/' . $args['sourceId']);
        }
    }

    /** @param array<string,string> $args */
    public function sourceImage(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        try {
            $path = (new CoverageSnapshotStore())->path(DemoRequest::actor($request), $args['sourceId']);
            $mime = (new \finfo(FILEINFO_MIME_TYPE))->file($path);
            if (!in_array($mime, ['image/png', 'image/jpeg'], true)) {
                throw DomainViolation::because('This source is not a displayable image.');
            }
            $bytes = file_get_contents($path);
            if (!is_string($bytes)) {
                throw DomainViolation::because('The source image is unavailable.');
            }
            $response->getBody()->write($bytes);
            return $response->withHeader('Content-Type', $mime)->withHeader('Cache-Control', 'private, no-store');
        } catch (DomainViolation $error) {
            return $this->pages->error($response, 404, 'Source unavailable', $error->getMessage(), '/demo/coverage/new');
        }
    }

    /** @param array<string,mixed> $input */
    private function saveScenario(ServerRequestInterface $request, ResponseInterface $response, array $input, string $comparisonId, string $expected, string $selection = ''): ResponseInterface
    {
        $saved = $this->store->save(DemoRequest::actor($request), $input, $comparisonId === '' ? null : $comparisonId, $expected === '' ? null : $expected);
        return $this->savedRedirect($response, $saved, $selection);
    }

    /** @param array<string,mixed> $input
     * @param array<string,mixed>|null $snapshot
     */
    private function scenarioPage(ServerRequestInterface $request, ResponseInterface $response, array $input, ?array $snapshot = null, bool $editing = false, string $selection = ''): ResponseInterface
    {
        $display = $this->displayCatalog($request, $snapshot, $editing, 'scenario-1.3.1');
        return $this->pages->render($response, 'scenario', [
            'pageTitle' => 'RHEL and VMware comparison', 'step' => 'resolve', 'csrfToken' => DemoRequest::csrf($request),
            'input' => $input, 'snapshot' => $snapshot, 'editing' => $editing,
            'reviewChanged' => ($request->getQueryParams()['review'] ?? '') === 'selection-changed' || ($selection !== '' && $selection !== $display['editorSelection']),
            ...$display,
        ]);
    }

    /** @param array<string,mixed>|null $saved
     * @return array<string,mixed>
     */
    private function displayCatalog(ServerRequestInterface $request, ?array $saved, bool $editing, string $profile): array
    {
        if ($saved !== null && !$editing) {
            return [...SavedCoverageCatalog::fromRevision($saved, $this->store->catalogForRevision(DemoRequest::actor($request), $saved['revisionId'])), 'editorSelection' => ''];
        }
        $catalog = $this->catalogs->resolve($profile);
        if ($catalog->profileId() !== $profile) {
            throw DomainViolation::because('The selected catalog profile is unavailable.');
        }
        return ['catalog' => $catalog->entries(), 'offerings' => $catalog->offerings(), 'prices' => $catalog->scenarioPrices(), 'editorSelection' => SavedResultContract::selection($catalog->context())];
    }

    /** Extract an optional review hint. It never selects package data.
     * @param array<string,mixed> $body
     */
    private function editorSelection(array &$body): string
    {
        $selection = $body['editorSelection'] ?? '';
        unset($body['editorSelection']);
        if (!is_string($selection) || ($selection !== '' && preg_match('/^[0-9a-f]{64}$/D', $selection) !== 1)) {
            throw DomainViolation::because('The editor selection hint is invalid.');
        }
        return $selection;
    }

    /** @param array<string,mixed> $saved */
    private function savedRedirect(ResponseInterface $response, array $saved, string $selection): ResponseInterface
    {
        $changed = $selection !== '' && $selection !== SavedResultContract::selection($saved['catalogContext']);
        return $response->withStatus(303)->withHeader('Location', '/demo/coverage/' . $saved['revisionId'] . ($changed ? '?review=selection-changed' : ''));
    }

    /** @param array<string,string> $args */
    public function confirm(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        try {
            DemoRequest::exactFields(DemoRequest::body($request), ['_csrf']);
            $saved = $this->store->confirm(DemoRequest::actor($request), $args['revisionId']);
            return $response->withStatus(303)->withHeader('Location', '/demo/coverage/' . $saved['revisionId']);
        } catch (DomainViolation $error) {
            return $this->pages->error($response, 409, 'Confirmation withheld', $error->getMessage(), '/demo/coverage/' . $args['revisionId']);
        }
    }

    /** @param array<string,string> $args */
    public function export(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        try {
            $query = $request->getQueryParams();
            $count = $query['slides'] ?? '4';
            if (!is_string($count) || !in_array($count, ['3', '4', '5'], true) || array_diff(array_keys($query), ['slides']) !== []) {
                throw DomainViolation::because('Choose a three, four or five slide presentation.');
            }
            $snapshot = $this->store->read(DemoRequest::actor($request), $args['revisionId']);
            if ($snapshot['state'] !== 'CONFIRMED' || ($snapshot['evaluation']['ready'] ?? false) !== true) {
                throw DomainViolation::because('Resolve all blockers and confirm this revision before exporting savings.');
            }
            $bytes = (new CustomerPresentation())->export($snapshot, (int) $count);
            $response->getBody()->write($bytes);
            return $response->withHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.presentationml.presentation')
                ->withHeader('Content-Disposition', 'attachment; filename="synthetic-comparison-' . $snapshot['revisionId'] . '.pptx"')
                ->withHeader('Cache-Control', 'private, no-store');
        } catch (DomainViolation|\InvalidArgumentException|\UnexpectedValueException $error) {
            return $this->pages->error($response, 409, 'Presentation unavailable', $error->getMessage(), '/demo/coverage/' . $args['revisionId']);
        }
    }
}
