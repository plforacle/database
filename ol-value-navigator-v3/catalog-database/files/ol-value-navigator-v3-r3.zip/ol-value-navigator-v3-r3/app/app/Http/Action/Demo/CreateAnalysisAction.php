<?php

declare(strict_types=1);

namespace App\Http\Action\Demo;

use App\Application\Analysis\CreateDemoAnalysis;
use App\Domain\Shared\CatalogVersionId;
use App\Domain\Shared\DomainViolation;
use App\Domain\Shared\RedactedSourceText;
use App\Domain\Shared\RequestId;
use App\Http\DemoPage;
use App\Http\DemoRequest;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;

final readonly class CreateAnalysisAction
{
    private const CATALOG_VERSION_ID = '00000000-0000-4000-8000-000000000901';

    public function __construct(
        private CreateDemoAnalysis $create,
        private DemoPage $pages,
    ) {
    }

    /** @param array<string, string> $_args */
    public function form(ServerRequestInterface $request, ResponseInterface $response, array $_args = []): ResponseInterface
    {
        return $this->pages->render($response, 'create', [
            'pageTitle' => 'Start a synthetic comparison',
            'step' => 'paste',
            'csrfToken' => DemoRequest::csrf($request),
            'sourceText' => '',
            'error' => null,
            'analysisId' => null,
        ]);
    }

    /** @param array<string, string> $_args */
    public function create(ServerRequestInterface $request, ResponseInterface $response, array $_args = []): ResponseInterface
    {
        $source = '';
        try {
            $body = DemoRequest::body($request);
            DemoRequest::exactFields($body, ['_csrf', 'source_text']);
            $source = DemoRequest::string($body, 'source_text');
            if (trim($source) === '') {
                throw DomainViolation::because('Synthetic source text is required.');
            }
            $analysisId = $this->create->execute(
                DemoRequest::actor($request),
                RedactedSourceText::fromString($source),
                CatalogVersionId::fromString(self::CATALOG_VERSION_ID),
                RequestId::new(),
            );

            return $response
                ->withStatus(303)
                ->withHeader('Location', '/demo/analyses/' . $analysisId);
        } catch (DomainViolation $exception) {
            return $this->pages->render($response, 'create', [
                'pageTitle' => 'Start a synthetic comparison',
                'step' => 'paste',
                'csrfToken' => DemoRequest::csrf($request),
                'sourceText' => $source,
                'error' => $exception->getMessage(),
                'analysisId' => null,
            ], 422);
        }
    }
}
