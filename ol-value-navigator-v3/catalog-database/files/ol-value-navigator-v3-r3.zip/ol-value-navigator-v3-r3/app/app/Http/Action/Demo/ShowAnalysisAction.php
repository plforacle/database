<?php

declare(strict_types=1);

namespace App\Http\Action\Demo;

use App\Application\Calculation\DemoComparisonPresenter;
use App\Domain\Analysis\AnalysisState;
use App\Domain\Shared\ResourceNotFound;
use App\Http\DemoAnalysisQuery;
use App\Http\DemoPage;
use App\Http\DemoRequest;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;

final readonly class ShowAnalysisAction
{
    public function __construct(
        private DemoAnalysisQuery $query,
        private DemoComparisonPresenter $presenter,
        private DemoPage $pages,
    ) {
    }

    /** @param array<string, string> $args */
    public function __invoke(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        $analysisId = $args['analysisId'] ?? '';
        try {
            $actor = DemoRequest::actor($request);
            $snapshot = $this->query->snapshot($analysisId, $actor);
            if ($snapshot['state'] === AnalysisState::DRAFT) {
                $manual = $snapshot['extractionMode'] === 'MANUAL';

                return $this->pages->render($response, $manual ? 'manual' : 'create', [
                    'pageTitle' => $manual ? 'Structured manual fallback' : 'Extract synthetic candidates',
                    'step' => 'extract',
                    'csrfToken' => DemoRequest::csrf($request),
                    'analysisId' => $analysisId,
                    'sourceText' => '',
                    'error' => null,
                ]);
            }
            if (in_array($snapshot['state'], [
                AnalysisState::NEEDS_REVIEW,
                AnalysisState::INCOMPLETE,
                AnalysisState::READY_TO_CALCULATE,
            ], true)) {
                return $response->withStatus(303)->withHeader('Location', '/demo/analyses/' . $analysisId . '/review');
            }
            if ($snapshot['state'] !== AnalysisState::CONFIRMED) {
                throw ResourceNotFound::because('Analysis not found.');
            }
            $view = $this->presenter->present($this->query->confirmedProjection(
                (string) $snapshot['revisionId'],
                $actor,
            ));

            return $this->pages->render($response, 'result', [
                'pageTitle' => 'Confirmed synthetic comparison',
                'step' => 'record',
                'analysisId' => $analysisId,
                'view' => $view,
            ]);
        } catch (ResourceNotFound|\UnexpectedValueException) {
            return $this->pages->error($response, 404, 'Analysis not found', 'The requested synthetic analysis is unavailable.');
        }
    }
}
