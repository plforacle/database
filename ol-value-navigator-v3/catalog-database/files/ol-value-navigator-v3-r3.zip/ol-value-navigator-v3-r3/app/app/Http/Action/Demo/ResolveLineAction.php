<?php

declare(strict_types=1);

namespace App\Http\Action\Demo;

use App\Application\Review\EvaluateReadiness;
use App\Application\Review\ResolveLine;
use App\Application\Review\SelectDemoOption;
use App\Domain\Shared\DomainViolation;
use App\Domain\Shared\RequestId;
use App\Domain\Shared\ResourceNotFound;
use App\Domain\Shared\RevisionId;
use App\Http\DemoAnalysisQuery;
use App\Http\DemoPage;
use App\Http\DemoRequest;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;

final readonly class ResolveLineAction
{
    public function __construct(
        private ResolveLine $resolve,
        private SelectDemoOption $select,
        private EvaluateReadiness $readiness,
        private DemoAnalysisQuery $query,
        private DemoPage $pages,
    ) {
    }

    /** @param array<string, string> $args */
    public function __invoke(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        $analysisId = $args['analysisId'] ?? '';
        try {
            $body = DemoRequest::body($request);
            $decision = DemoRequest::string($body, 'decision');
            $lineId = DemoRequest::string($body, 'line_id');
            $actor = DemoRequest::actor($request);
            $snapshot = $this->query->snapshot($analysisId, $actor);
            $revision = RevisionId::fromString((string) $snapshot['revisionId']);
            $requestId = RequestId::new();

            if ($decision === 'confirm') {
                DemoRequest::exactFields($body, ['_csrf', 'line_id', 'decision', 'option_sku']);
                $this->resolve->confirm($revision, $lineId, $actor, $requestId);
                $this->select->execute($revision, $lineId, DemoRequest::string($body, 'option_sku'), $actor, $requestId);
            } elseif ($decision === 'correct') {
                DemoRequest::exactFields($body, ['_csrf', 'line_id', 'decision', 'sku', 'quantity', 'option_sku']);
                $this->resolve->correctAndConfirm($revision, $lineId, [
                    'sku' => DemoRequest::string($body, 'sku'),
                    'quantity' => DemoRequest::string($body, 'quantity'),
                ], $actor, $requestId);
                $this->select->execute($revision, $lineId, DemoRequest::string($body, 'option_sku'), $actor, $requestId);
            } elseif ($decision === 'exclude') {
                DemoRequest::exactFields($body, ['_csrf', 'line_id', 'decision', 'exclusion_reason']);
                $this->resolve->exclude(
                    $revision,
                    $lineId,
                    DemoRequest::string($body, 'exclusion_reason'),
                    $actor,
                    $requestId,
                );
            } elseif ($decision === 'select') {
                DemoRequest::exactFields($body, ['_csrf', 'line_id', 'decision', 'option_sku']);
                $this->select->execute($revision, $lineId, DemoRequest::string($body, 'option_sku'), $actor, $requestId);
            } else {
                throw DomainViolation::because('The requested line decision is not supported.');
            }

            $this->readiness->forRevision($revision);

            return $response->withStatus(303)->withHeader('Location', '/demo/analyses/' . $analysisId . '/review');
        } catch (ResourceNotFound) {
            return $this->pages->error($response, 404, 'Analysis not found', 'The requested synthetic analysis is unavailable.');
        } catch (DomainViolation|\UnexpectedValueException $exception) {
            return $this->pages->error(
                $response,
                422,
                'Line decision was not accepted',
                $exception->getMessage(),
                '/demo/analyses/' . $analysisId . '/review',
            );
        }
    }
}
