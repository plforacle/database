<?php

declare(strict_types=1);

namespace App\Http\Action\Demo;

use App\Application\Calculation\ConfirmDemoComparison;
use App\Domain\Shared\DomainViolation;
use App\Domain\Shared\RequestId;
use App\Domain\Shared\ResourceNotFound;
use App\Domain\Shared\RevisionId;
use App\Http\DemoAnalysisQuery;
use App\Http\DemoPage;
use App\Http\DemoRequest;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;

final readonly class ConfirmAction
{
    public function __construct(
        private ConfirmDemoComparison $confirm,
        private DemoAnalysisQuery $query,
        private DemoPage $pages,
    ) {
    }

    /** @param array<string, string> $args */
    public function __invoke(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        $analysisId = $args['analysisId'] ?? '';
        try {
            $body = DemoRequest::body($request);
            DemoRequest::exactFields($body, ['_csrf']);
            $actor = DemoRequest::actor($request);
            $snapshot = $this->query->snapshot($analysisId, $actor);
            $this->confirm->execute(
                RevisionId::fromString((string) $snapshot['revisionId']),
                $actor,
                RequestId::new(),
            );

            return $response->withStatus(303)->withHeader('Location', '/demo/analyses/' . $analysisId);
        } catch (ResourceNotFound) {
            return $this->pages->error($response, 404, 'Analysis not found', 'The requested synthetic analysis is unavailable.');
        } catch (DomainViolation $exception) {
            return $this->pages->error(
                $response,
                422,
                'Totals remain withheld',
                'Resolve every included line and select an eligible synthetic option before confirming totals.',
                '/demo/analyses/' . $analysisId . '/review',
            );
        }
    }
}
