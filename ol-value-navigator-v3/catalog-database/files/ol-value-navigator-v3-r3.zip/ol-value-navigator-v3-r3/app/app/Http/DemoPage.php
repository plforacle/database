<?php

declare(strict_types=1);

namespace App\Http;

use Psr\Http\Message\ResponseInterface;
use RuntimeException;

final readonly class DemoPage
{
    private const TEMPLATES = ['create', 'manual', 'review', 'result', 'error', 'coverage', 'scenario', 'scenario-import'];

    public function __construct(private string $viewRoot)
    {
    }

    /** @param array<string, mixed> $data */
    public function render(
        ResponseInterface $response,
        string $template,
        array $data,
        int $status = 200,
    ): ResponseInterface {
        if (!in_array($template, self::TEMPLATES, true)) {
            throw new RuntimeException('The requested demo template is not allowlisted.');
        }

        $escape = static fn (mixed $value): string => htmlspecialchars(
            is_scalar($value) ? (string) $value : '',
            ENT_QUOTES | ENT_SUBSTITUTE,
            'UTF-8',
        );
        $templateFile = $this->viewRoot . '/demo/' . $template . '.php';
        $content = $this->capture($templateFile, $data, $escape);
        $html = $this->capture($this->viewRoot . '/layout.php', [
            ...$data,
            'content' => $content,
        ], $escape);
        $response->getBody()->write($html);

        return $response
            ->withStatus($status)
            ->withHeader('Content-Type', 'text/html; charset=utf-8');
    }

    public function error(
        ResponseInterface $response,
        int $status,
        string $title,
        string $message,
        string $returnPath = '/demo',
    ): ResponseInterface {
        return $this->render($response, 'error', [
            'pageTitle' => $title,
            'step' => 'resolve',
            'title' => $title,
            'message' => $message,
            'returnPath' => $returnPath,
        ], $status);
    }

    /** @param array<string, mixed> $data
     * @param callable(mixed): string $escape
     */
    private function capture(string $file, array $data, callable $escape): string
    {
        if (!is_file($file)) {
            throw new RuntimeException('A required demo template is unavailable.');
        }

        ob_start();
        try {
            (static function () use ($file, $data, $escape): void {
                require $file;
            })();
            $output = ob_get_clean();
        } catch (\Throwable $exception) {
            ob_end_clean();
            throw $exception;
        }
        if (!is_string($output)) {
            throw new RuntimeException('The demo template could not be rendered.');
        }

        return $output;
    }
}
