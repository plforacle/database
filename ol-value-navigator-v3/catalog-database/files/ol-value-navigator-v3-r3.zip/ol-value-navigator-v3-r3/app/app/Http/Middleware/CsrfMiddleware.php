<?php

declare(strict_types=1);

namespace App\Http\Middleware;

use App\Http\DemoPage;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Server\MiddlewareInterface;
use Psr\Http\Server\RequestHandlerInterface;
use Slim\Psr7\Response;

final readonly class CsrfMiddleware implements MiddlewareInterface
{
    private const SESSION_COOKIE = 'olvn_demo_session';

    private const CSRF_COOKIE = 'olvn_demo_csrf';

    public function __construct(
        private bool $secureCookies,
        private DemoPage $pages,
    ) {
    }

    public function process(ServerRequestInterface $request, RequestHandlerInterface $handler): ResponseInterface
    {
        $cookies = $request->getCookieParams();
        $session = $cookies[self::SESSION_COOKIE] ?? null;
        $cookieToken = $cookies[self::CSRF_COOKIE] ?? null;
        $validSession = is_string($session) && preg_match('/^[0-9a-f]{64}$/D', $session) === 1;
        $expectedToken = $validSession ? $this->tokenFor($session) : null;
        $validCookieToken = is_string($cookieToken)
            && $expectedToken !== null
            && hash_equals($expectedToken, $cookieToken);
        $renew = !$validSession || !$validCookieToken;

        if ($renew) {
            $session = bin2hex(random_bytes(32));
            $expectedToken = $this->tokenFor($session);
        }

        if (!in_array(strtoupper($request->getMethod()), ['GET', 'HEAD', 'OPTIONS'], true)) {
            $body = $request->getParsedBody();
            $submitted = is_array($body) ? ($body['_csrf'] ?? null) : null;
            if ($renew || !is_string($submitted) || !hash_equals($expectedToken, $submitted)) {
                return $this->withCookies(
                    $this->pages->error(
                        new Response(),
                        403,
                        'Request verification failed',
                        'Reload the page and retry the action from the displayed form.',
                    ),
                    $session,
                    $expectedToken,
                );
            }
        }

        $response = $handler->handle($request->withAttribute('csrfToken', $expectedToken));
        if (!$renew) {
            return $response;
        }

        return $this->withCookies($response, $session, $expectedToken);
    }

    private function withCookies(ResponseInterface $response, string $session, string $token): ResponseInterface
    {
        return $response
            ->withAddedHeader('Set-Cookie', $this->cookie(self::SESSION_COOKIE, $session))
            ->withAddedHeader('Set-Cookie', $this->cookie(self::CSRF_COOKIE, $token));
    }

    private function cookie(string $name, string $value): string
    {
        return sprintf(
            '%s=%s; Path=/demo; HttpOnly; SameSite=Lax%s',
            $name,
            $value,
            $this->secureCookies ? '; Secure' : '',
        );
    }

    private function tokenFor(string $session): string
    {
        return hash_hmac('sha256', 'olvn-demo-csrf-v1', $session);
    }
}
