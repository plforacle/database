<?php

declare(strict_types=1);

namespace App\Http\Action\Demo;

use App\Application\Extraction\ExtractCandidates;
use App\Domain\Shared\DomainViolation;
use App\Domain\Shared\RequestId;
use App\Domain\Shared\ResourceNotFound;
use App\Domain\Shared\RevisionId;
use App\Http\DemoAnalysisQuery;
use App\Http\DemoPage;
use App\Http\DemoRequest;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;

final readonly class ExtractAction
{
    public function __construct(
        private ExtractCandidates $extract,
        private DemoAnalysisQuery $query,
        private DemoPage $pages,
    ) {
    }

    /** @param array<string, string> $args */
    public function __invoke(ServerRequestInterface $request, ResponseInterface $response, array $args): ResponseInterface
    {
        $analysisId = $args['analysisId'] ?? '';
        try {
            $body = DemoRequest::body($request);
            DemoRequest::exactFields($body, ['_csrf']);
            $snapshot = $this->query->snapshot($analysisId, DemoRequest::actor($request));
            $this->extract->execute(RevisionId::fromString((string) $snapshot['revisionId']), RequestId::new());

            return $response->withStatus(303)->withHeader('Location', '/demo/analyses/' . $analysisId);
        } catch (ResourceNotFound) {
            return $this->pages->error($response, 404, 'Analysis not found', 'The requested synthetic analysis is unavailable.');
        } catch (DomainViolation $exception) {
            return $this->pages->error($response, 422, 'Extraction could not start', $exception->getMessage(), '/demo/analyses/' . $analysisId);
        }
    }
}
