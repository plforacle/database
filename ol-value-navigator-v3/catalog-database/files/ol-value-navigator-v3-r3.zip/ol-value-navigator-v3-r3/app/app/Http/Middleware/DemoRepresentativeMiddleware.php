<?php

declare(strict_types=1);

namespace App\Http\Middleware;

use App\Application\Identity\RepresentativeContext;
use Psr\Http\Message\ResponseInterface;
use Psr\Http\Message\ServerRequestInterface;
use Psr\Http\Server\MiddlewareInterface;
use Psr\Http\Server\RequestHandlerInterface;

final readonly class DemoRepresentativeMiddleware implements MiddlewareInterface
{
    public function __construct(private RepresentativeContext $context)
    {
    }

    public function process(ServerRequestInterface $request, RequestHandlerInterface $handler): ResponseInterface
    {
        return $handler->handle($request->withAttribute('demoActor', $this->context->current()));
    }
}
