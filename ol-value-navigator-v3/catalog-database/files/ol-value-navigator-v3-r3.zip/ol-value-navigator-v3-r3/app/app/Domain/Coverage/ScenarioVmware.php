<?php

declare(strict_types=1);

namespace App\Domain\Coverage;

/** Qualified VCF/VVF core policy and replacement gates; never grants bundle equivalence. */
final class ScenarioVmware
{
    public const FEATURES = ['storage', 'networking', 'backup', 'operations', 'kubernetes', 'vdi', 'integrations', 'guest_support'];

    /** @param array<string,mixed> $line
     * @param array<string,mixed> $period
     * @param list<array<string,mixed>> $otherCosts
     * @return array{quantity:?int,requiredCores:?int,retained:bool,issues:list<array{code:string,message:string}>,advisories:list<array{code:string,message:string}>}
     */
    public function evaluate(array $line, array $period, string $mode, array $otherCosts): array
    {
        $vmware = ScenarioFacts::record($line['vmware'] ?? []);
        $quantity = is_int($line['quantity'] ?? null) ? $line['quantity'] : null;
        $retained = ($vmware['intent'] ?? '') === 'RETAIN_VMWARE';
        $issues = [];
        $advisories = [];
        $cores = 0;
        $hosts = ScenarioFacts::records($vmware['sourceHosts'] ?? []);
        $hostIds = [];
        if ($hosts === []) {
            $cores = null;
        }
        foreach ($hosts as $host) {
            $id = ScenarioFacts::text($host['id'] ?? '');
            $processors = $host['cpus'] ?? [];
            if ($id === '' || isset($hostIds[$id]) || !is_array($processors) || $processors === []) {
                $issues[] = ScenarioFacts::issue('VMWARE_QUANTITY_REVIEW', 'Every source host needs one unique identifier and its physical processors.');
                $cores = null;
            }
            $hostIds[$id] = true;
            foreach (is_array($processors) ? $processors : [] as $processor) {
                if (!is_int($processor) || $processor < 1) {
                    $cores = null;
                } elseif ($cores !== null) {
                    $cores += max(16, $processor);
                }
            }
        }
        if (($vmware['metric'] ?? '') !== 'CORE' || ScenarioFacts::text($vmware['productVersion'] ?? '') === '') {
            $issues[] = ScenarioFacts::issue('VMWARE_METRIC_REVIEW', 'Verify the exact VCF/VVF product version and annual physical-core commercial model.');
        }
        $major = ($line['sku'] ?? '') === 'VCF-VSP-FND-8' ? '8' : '5';
        if (preg_match('/^' . $major . '(?:\.\d+)*$/D', ScenarioFacts::text($vmware['productVersion'] ?? '')) !== 1) {
            $issues[] = ScenarioFacts::issue('SKU_IDENTITY_CONFLICT', 'VMware product version conflicts with the exact maintained VCF/VVF identifier.');
        }
        if (($vmware['quantityMode'] ?? '') === 'HARDWARE_DERIVED_ESTIMATE') {
            $policy = ScenarioFacts::record($vmware['commercialPolicy'] ?? []);
            $minimum = $policy['minimum'] ?? null;
            $step = $policy['step'] ?? null;
            if ($cores === null) {
                $issues[] = ScenarioFacts::issue('VMWARE_QUANTITY_REVIEW', 'Actual physical cores are unknown; the 16-core floor is not a hardware default.');
                $quantity = null;
            } elseif (($policy['state'] ?? '') !== 'CONFIRMED' || !ScenarioFacts::evidence($policy['evidence'] ?? null)
                || ScenarioFacts::text($policy['version'] ?? '') === '' || ($policy['scope'] ?? '') !== 'ORDER'
                || !is_int($minimum) || $minimum < 0 || !is_int($step) || $step < 1) {
                $issues[] = ScenarioFacts::issue('COMMERCIAL_TERMS_REVIEW_REQUIRED', 'Establish the applicable order minimum and pack/rounding policy; no universal order floor is assumed.');
                $quantity = null;
            } else {
                $quantity = intdiv(max($minimum, $cores) + $step - 1, $step) * $step;
                $advisories[] = ScenarioFacts::issue('HARDWARE_DERIVED_ESTIMATE', 'Billable cores are a hardware/order-policy estimate, not an observed customer purchase.');
            }
        } elseif (($vmware['quantityMode'] ?? '') !== 'CUSTOMER_PRICED_UNITS') {
            $issues[] = ScenarioFacts::issue('VMWARE_QUANTITY_REVIEW', 'Choose customer-priced core units or a qualified hardware estimate.');
        } elseif ($cores !== null && $quantity !== null && $quantity < $cores) {
            $issues[] = ScenarioFacts::issue('VMWARE_QUANTITY_REVIEW', 'The preserved customer core quantity is below hardware requirements; review without silently repricing the purchase.');
        }
        if ($retained) {
            $advisories[] = ScenarioFacts::issue('VMWARE_RETAINED', 'VMware continues on both financial sides; no VMware avoided cost is claimed.');
        } elseif (($vmware['intent'] ?? '') !== 'REPLACE_VIRTUALIZATION') {
            $issues[] = ScenarioFacts::issue('VMWARE_BUNDLE_REVIEW', 'Resolve VMware retention or replacement intent before claiming avoided costs.');
        } else {
            if (!ScenarioFacts::accepted($vmware['sizing'] ?? null, $mode)) {
                $issues[] = ScenarioFacts::issue('VMWARE_TARGET_REVIEW', 'Record the source-to-target host sizing or explicit illustrative sizing assumption.');
            }
            $retirement = ScenarioFacts::record($vmware['retirement'] ?? []);
            $locale = ScenarioFacts::text($period['dateLocale'] ?? 'ISO');
            $date = ScenarioDates::parse(ScenarioFacts::text($retirement['date'] ?? ''), $locale);
            $rawCommitment = ScenarioFacts::text($retirement['commitmentEnd'] ?? '');
            $commitmentEnd = ScenarioDates::parse($rawCommitment, $locale);
            $rawStart = ScenarioFacts::text($period['startDate'] ?? '') ?: ScenarioFacts::text($period['asOfDate'] ?? '');
            $start = ScenarioDates::parse($rawStart, $locale);
            if (!ScenarioFacts::accepted($retirement, $mode) || $date === null
                || ($rawCommitment !== '' && ($commitmentEnd === null || $date <= $commitmentEnd))
                || ($rawStart !== '' && ($start === null || $date > $start))) {
                $issues[] = ScenarioFacts::issue('VMWARE_BUNDLE_REVIEW', 'Establish a feasible retirement date and remaining commitments for the selected comparison period.');
            }
            $features = [];
            foreach (ScenarioFacts::records($vmware['features'] ?? []) as $feature) {
                $name = ScenarioFacts::text($feature['name'] ?? '');
                if ($name === '') {
                    $issues[] = ScenarioFacts::issue('VMWARE_BUNDLE_REVIEW', 'Name each declared VMware capability so its requirements can be reviewed.');
                    continue;
                }
                if (isset($features[$name])) {
                    $issues[] = ScenarioFacts::issue('VMWARE_BUNDLE_REVIEW', 'Review duplicate feature inventory entries.');
                }
                $features[$name] = $feature;
            }
            $costs = [];
            foreach ($otherCosts as $cost) {
                $costs[ScenarioFacts::text($cost['id'] ?? '')] = $cost;
            }
            foreach (array_unique([...self::FEATURES, ...array_keys($features)]) as $name) {
                $feature = $features[$name] ?? [];
                $status = $feature['status'] ?? 'UNRESOLVED';
                if (!in_array($status, ['COVERED', 'OUT_OF_SCOPE', 'RETAINED', 'REPLACED'], true) || !ScenarioFacts::evidence($feature['evidence'] ?? null)) {
                    $issues[] = ScenarioFacts::issue('VMWARE_BUNDLE_REVIEW', 'Review required VMware ' . $name . ' capability and evidence.');
                    continue;
                }
                if (in_array($status, ['RETAINED', 'REPLACED'], true)) {
                    $references = ScenarioFacts::strings($feature['costIds'] ?? []);
                    if ($references === []) {
                        $issues[] = ScenarioFacts::issue('VMWARE_BUNDLE_REVIEW', 'Account for required ' . $name . ' retained/replacement costs.');
                    }
                    foreach ($references as $reference) {
                        $cost = $costs[$reference] ?? [];
                        if (!in_array($cost['side'] ?? '', $status === 'RETAINED' ? ['BOTH'] : ['TARGET'], true)
                            || array_diff(ScenarioFacts::strings($line['groupIds'] ?? []), ScenarioFacts::strings($cost['groupIds'] ?? [])) !== []) {
                            $issues[] = ScenarioFacts::issue('VMWARE_BUNDLE_REVIEW', 'Required cost ' . $reference . ' must cover this scope on the appropriate financial sides.');
                        }
                    }
                }
            }
        }
        return ['quantity' => $quantity, 'requiredCores' => $cores, 'retained' => $retained, 'issues' => $issues, 'advisories' => $advisories];
    }
}
