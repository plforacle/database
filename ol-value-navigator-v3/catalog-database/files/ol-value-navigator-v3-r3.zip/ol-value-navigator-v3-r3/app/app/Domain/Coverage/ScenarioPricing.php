<?php

declare(strict_types=1);

namespace App\Domain\Coverage;

use App\Domain\Package\CatalogSnapshot;
use App\Domain\Shared\DomainViolation;
use Brick\Math\BigDecimal;
use Brick\Math\RoundingMode;

/**
 * Prices one source purchase; identity, population and duplicate checks belong to the evaluator.
 * @phpstan-import-type Entry from CoverageCatalog
 * @phpstan-import-type Issue from ScenarioTerm
 * @phpstan-type Price array{id:string,amount:?string,currency:string,metric:string,periodBasis:string,termMonths:int,basis:string,verification:string,evidence:string,reason:string,approvedBy:string,approvedAt:string,effectiveOn:string,observedOn:string,originalAmount:?string,installments:list<string|null>}
 * @phpstan-type Result array{annual:?string,term:?string,annualKind:string,price:?Price,variance:?string,issues:list<Issue>,advisories:list<Issue>}
 */
final class ScenarioPricing
{
    /** @param array<string,mixed> $line
     * @param Entry|null $entry
     * @param array<string,mixed> $period
     * @return Result
     */
    public static function evaluate(array $line, ?array $entry, array $period, string $mode, CatalogSnapshot $snapshot): array
    {
        $term = ScenarioTerm::evaluate($period);
        $result = ['annual' => null, 'term' => null, 'annualKind' => '', 'price' => null, 'variance' => null, 'issues' => $term['issues'], 'advisories' => []];
        $price = self::select($line, $entry, $result['issues'], $snapshot);
        $result['price'] = $price;
        if ($price === null) {
            return $result;
        }
        self::validate($price, $entry, $period, $mode, $result['issues']);
        $quantity = $line['quantity'] ?? null;
        if (!is_int($quantity) || $quantity < 0 || $quantity > 1000000000) {
            $result['issues'][] = self::issue('PRICE_QUANTITY_REVIEW', 'A nonnegative, bounded integer quantity is required for pricing.');
        }
        if ($result['issues'] !== [] || !is_int($quantity)) {
            return $result;
        }
        /** @var string $amount Validation above admits decimal strings only. */
        $amount = $price['amount'];
        $years = $term['multiplier'];
        $basis = $price['periodBasis'];
        if ($basis === 'ANNUAL_UNIT_RATE') {
            $annual = self::extension($amount, $quantity);
            $total = $annual->multipliedBy($years);
            $result['annualKind'] = 'ANNUAL_RATE';
        } elseif ($basis === 'ANNUAL_INSTALLMENT') {
            $schedule = $price['installments'];
            $result['advisories'][] = self::issue('INSTALLMENT_COMMITMENT', 'Annual installments remain subject to their full commitment; they are not freely purchasable one-year quotes.');
            if ($schedule !== []) {
                if (count($schedule) !== $years) {
                    $result['issues'][] = self::issue('INSTALLMENT_SCHEDULE_REVIEW', 'Provide one valid per-unit annual installment for each year of the selected term.');
                    return $result;
                }
                $total = BigDecimal::zero()->toScale(2);
                foreach ($schedule as $installment) {
                    if (!is_string($installment) || !self::decimal($installment)) {
                        $result['issues'][] = self::issue('INSTALLMENT_SCHEDULE_REVIEW', 'Every annual installment amount must be known and use a nonnegative decimal value.');
                        return $result;
                    }
                    $total = $total->plus(self::extension($installment, $quantity));
                }
                $annual = $total->dividedBy($years, 2, RoundingMode::HALF_UP);
                $result['annualKind'] = 'DISPLAY_ANNUALIZED_EQUIVALENT';
            } else {
                if ($years > 1 && ($period['constantRateConfirmed'] ?? false) !== true) {
                    $result['issues'][] = self::issue('INSTALLMENT_SCHEDULE_REVIEW', 'An installment schedule or explicit constant-installment assumption is required.');
                    return $result;
                }
                $annual = self::extension($amount, $quantity);
                $total = $annual->multipliedBy($years);
                $result['annualKind'] = 'ANNUAL_INSTALLMENT';
            }
        } else {
            $total = self::extension($amount, $basis === 'FULL_TERM_LINE_TOTAL' ? 1 : $quantity);
            $annual = $total->dividedBy($years, 2, RoundingMode::HALF_UP);
            $result['annualKind'] = 'DISPLAY_ANNUALIZED_EQUIVALENT';
        }
        $result['annual'] = (string) $annual;
        $result['term'] = (string) $total;
        if (($period['model'] ?? 'CONSTANT_RATE') === 'CONSTANT_RATE') {
            $result['advisories'][] = self::issue('CONSTANT_RATE_MODEL', 'Modeled costs use the adopted prices over the selected period. They do not establish historical invoices, refundable payments or recoverable contract savings.');
        }
        self::reconcile($line, $period, $result);
        return $result;
    }

    /** @param array<string,mixed> $line
     * @param Entry|null $entry
     * @param list<Issue> $issues
     * @return Price|null
     */
    private static function select(array $line, ?array $entry, array &$issues, CatalogSnapshot $snapshot): ?array
    {
        $recordId = (string) ($line['priceRecordId'] ?? '');
        $supplied = $line['price'] ?? null;
        if ($recordId !== '') {
            if ($supplied !== null || !isset($snapshot->scenarioPrices()[$recordId])) {
                $issues[] = self::issue('PRICE_SELECTION_REVIEW', 'Select one known versioned record or one explicit scenario price; no fallback replaces an invalid selection.');
                return null;
            }
            try {
                return $snapshot->scenarioPrice($recordId, ScenarioFacts::text($line['sku'] ?? ''));
            } catch (DomainViolation) {
                $issues[] = self::issue('PRICE_APPLICABILITY_REVIEW', 'The selected catalog price does not apply to this SKU.');
                return null;
            }
        }
        if (is_array($supplied)) {
            if (($supplied['verification'] ?? '') === 'INDEPENDENTLY_VERIFIED_PUBLIC') {
                $issues[] = self::issue('PRICE_AUTHORITY_REVIEW', 'A submitted price cannot establish independent public verification. Select an admitted server catalog record, or explicitly adopt a user-verified scenario price.');
            }
            // Input normalization supplies these fields; retaining defaults also makes independent valuation fail closed.
            $defaults = ['id' => '', 'amount' => null, 'currency' => '', 'metric' => '', 'periodBasis' => '', 'termMonths' => 0, 'basis' => '', 'verification' => '', 'evidence' => '', 'reason' => '', 'approvedBy' => '', 'approvedAt' => '', 'effectiveOn' => '', 'observedOn' => '', 'originalAmount' => null, 'installments' => []];
            /** @var Price $price */
            $price = array_replace($defaults, $supplied);
            return $price;
        }
        if ($supplied !== null) {
            $issues[] = self::issue('PRICE_SELECTION_REVIEW', 'The supplied price record is invalid; no catalog value is substituted.');
            return null;
        }
        if ($entry !== null && $entry['scenarioPrice'] !== null && $entry['readiness'] === 'READY'
            && $entry['term'] === 'ANNUAL' && in_array($entry['priceBasis'], ['CURRENT_PUBLIC_STORE', 'SYNTHETIC'], true)) {
            $synthetic = $entry['priceBasis'] === 'SYNTHETIC';
            return [
                'id' => 'catalog:' . $snapshot->priceVersion() . ':' . ($line['sku'] ?? ''),
                'amount' => $entry['scenarioPrice'], 'currency' => $entry['currency'], 'metric' => $entry['unit'],
                'periodBasis' => 'ANNUAL_UNIT_RATE', 'termMonths' => 12,
                'basis' => $synthetic ? 'SCENARIO_SUPPLIED' : 'MANUFACTURER_LIST',
                'verification' => $synthetic ? 'USER_VERIFIED' : 'INDEPENDENTLY_VERIFIED_PUBLIC',
                'evidence' => $entry['provenance'], 'reason' => '',
                'approvedBy' => $synthetic ? 'Synthetic fixture' : '', 'approvedAt' => $synthetic ? $entry['verifiedOn'] : '',
                'effectiveOn' => $entry['effectiveOn'], 'observedOn' => $entry['verifiedOn'], 'originalAmount' => null, 'installments' => [],
            ];
        }
        $issues[] = self::issue('PRICE_REQUIRED', 'Select an evidenced numerical price and its billing basis; historical references are not automatically adopted.');
        return null;
    }

    /** @param Price $price
     * @param Entry|null $entry
     * @param array<string,mixed> $period
     * @param list<Issue> $issues
     */
    private static function validate(array $price, ?array $entry, array $period, string $mode, array &$issues): void
    {
        if (!self::decimal($price['amount'])) {
            $issues[] = self::issue('PRICE_REQUIRED', 'A nonnegative decimal amount with retained precision is required.');
        }
        if ($price['currency'] !== 'USD' || $price['currency'] !== ($period['currency'] ?? 'USD')) {
            $issues[] = self::issue('PRICE_CURRENCY_REVIEW', 'Source and comparison currencies must both be USD; no FX conversion is applied.');
        }
        if ($price['metric'] === '' || ($entry !== null && !self::metricMatches($price['metric'], $entry))) {
            $issues[] = self::issue('PRICE_METRIC_REVIEW', 'The price metric must match the identified source subscription or physical-core billing unit.');
        }
        if (!in_array($price['periodBasis'], ['ANNUAL_UNIT_RATE', 'ANNUAL_INSTALLMENT', 'FULL_TERM_UNIT_PRICE', 'FULL_TERM_LINE_TOTAL'], true)) {
            $issues[] = self::issue('PRICE_PERIOD_BASIS_REVIEW', 'Confirm whether the amount is an annual rate, annual installment, full-term unit price or full-term line total.');
        }
        if (!in_array($price['termMonths'], [12, 36], true)
            || ($price['periodBasis'] === 'ANNUAL_UNIT_RATE' ? $price['termMonths'] !== 12 : $price['termMonths'] !== ($period['months'] ?? 12))) {
            $issues[] = self::issue('PRICE_TERM_REVIEW', 'The selected price term does not match this comparison; prepaid amounts and commitments are not silently prorated.');
        }
        if (!in_array($price['basis'], ['MANUFACTURER_LIST', 'RESELLER_ADVERTISED', 'HISTORICAL_PUBLIC', 'SCENARIO_SUPPLIED'], true)
            || !in_array($price['verification'], ['USER_VERIFIED', 'INDEPENDENTLY_VERIFIED_PUBLIC'], true)
            || trim($price['evidence']) === '') {
            $issues[] = self::issue('PRICE_PROVENANCE_REVIEW', 'Retain the price basis, verification authority and supporting evidence before using the amount.');
        }
        if ($price['verification'] === 'USER_VERIFIED' && (trim($price['approvedBy']) === '' || trim($price['approvedAt']) === '')) {
            $issues[] = self::issue('PRICE_APPROVAL_REVIEW', 'A user-verified price must retain the approving actor and date.');
        }
        if ($price['verification'] === 'INDEPENDENTLY_VERIFIED_PUBLIC' && trim($price['observedOn']) === '') {
            $issues[] = self::issue('PRICE_PROVENANCE_REVIEW', 'An independently verified public price must retain its observation date.');
        }
        if ($mode === 'VALIDATED_PUBLIC' && ($price['verification'] !== 'INDEPENDENTLY_VERIFIED_PUBLIC'
            || !in_array($price['basis'], ['MANUFACTURER_LIST', 'RESELLER_ADVERTISED'], true))) {
            $issues[] = self::issue('PUBLIC_PRICE_REVIEW', 'Validated public comparisons require independently verified manufacturer-list or labeled reseller prices.');
        }
        if (!in_array($mode, ['ILLUSTRATIVE', 'VALIDATED_PUBLIC'], true)) {
            $issues[] = self::issue('PRICE_MODE_REVIEW', 'Select illustrative or validated-public comparison mode.');
        }
        if ($price['originalAmount'] !== null && (!self::decimal($price['originalAmount'])
            || (is_string($price['amount']) && self::decimal($price['amount']) && BigDecimal::of($price['originalAmount'])->compareTo($price['amount']) !== 0
                && (trim($price['reason']) === '' || trim($price['approvedBy']) === '' || trim($price['approvedAt']) === '')))) {
            $issues[] = self::issue('PRICE_OVERRIDE_REVIEW', 'Retain the original amount, adopted amount, override reason and approval.');
        }
        if (($period['model'] ?? 'CONSTANT_RATE') === 'HISTORICAL_ACTUAL'
            && ($price['basis'] !== 'SCENARIO_SUPPLIED' || trim((string) ($period['startDate'] ?? '')) === '' || trim((string) ($period['evidence'] ?? '')) === '')) {
            $issues[] = self::issue('HISTORICAL_PRICE_REVIEW', 'Historical actual costs require dated source transaction evidence; public or current rates are not historical invoices.');
        }
    }

    /** @param array<string,mixed> $line
     * @param array<string,mixed> $period
     * @param Result $result
     */
    private static function reconcile(array $line, array $period, array &$result): void
    {
        $supplied = $line['suppliedTotal'] ?? null;
        if ($supplied === null) {
            return;
        }
        $basis = $line['suppliedTotalBasis'] ?? 'UNKNOWN';
        if (!self::decimal($supplied) || ($line['suppliedTotalCurrency'] ?? '') !== ($period['currency'] ?? 'USD')) {
            $result['issues'][] = self::issue('SUPPLIED_TOTAL_REVIEW', 'The supplied total requires a valid decimal amount and matching currency before reconciliation.');
            return;
        }
        if (!in_array($basis, ['ANNUAL', 'FULL_TERM'], true)
            || ($basis === 'ANNUAL' && $result['annualKind'] === 'DISPLAY_ANNUALIZED_EQUIVALENT')) {
            $result['issues'][] = self::issue('SUPPLIED_TOTAL_BASIS_REVIEW', 'Confirm the supplied total uses the same annual or full-term basis; annualized display equivalents are not actual annual charges.');
            return;
        }
        $computed = $basis === 'ANNUAL' ? $result['annual'] : $result['term'];
        if ($computed !== null) {
            $result['variance'] = (string) BigDecimal::of($computed)->minus($supplied)->toScale(2, RoundingMode::HALF_UP);
            if ($result['variance'] !== '0.00') {
                $result['advisories'][] = self::issue('SOURCE_TOTAL_VARIANCE', 'The adopted calculation differs from the supplied total; the difference is not automatically attributed to rounding.');
            }
        }
    }

    private static function decimal(mixed $value): bool
    {
        return is_string($value) && strlen($value) <= 64 && preg_match('/^\d{1,18}(?:\.\d{1,18})?$/D', $value) === 1;
    }

    /** Display wording stays in the catalog; canonical units are admitted only for the exact reviewed family.
     * @param Entry $entry
     */
    private static function metricMatches(string $metric, array $entry): bool
    {
        if ($metric === $entry['unit']) {
            return true;
        }
        if (($entry['vendor'] ?? '') !== 'Red Hat') {
            return false;
        }
        $canonical = ($entry['nodePackSize'] ?? 0) > 0 ? 'NODE_PACK' : 'SUBSCRIPTION';
        return $metric === $canonical;
    }

    private static function extension(string $amount, int $quantity): BigDecimal
    {
        return BigDecimal::of($amount)->multipliedBy($quantity)->toScale(2, RoundingMode::HALF_UP);
    }

    /** @return Issue */
    private static function issue(string $code, string $message): array
    {
        return ['code' => $code, 'message' => $message];
    }
}
