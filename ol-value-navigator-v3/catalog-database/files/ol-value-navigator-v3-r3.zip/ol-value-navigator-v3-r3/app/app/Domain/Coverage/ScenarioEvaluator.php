<?php

declare(strict_types=1);

namespace App\Domain\Coverage;

use App\Domain\Package\CatalogSnapshot;
use App\Domain\Shared\DomainViolation;
use Brick\Math\BigDecimal;
use Brick\Math\RoundingMode;

/** Deterministic v1.3.1 connected-scope calculation; stored facts never inherit old assumptions. */
final class ScenarioEvaluator
{
    /** @var list<array{groupId:string,code:string,message:string}> */
    private array $reviews = [];
    /** @var list<array{groupId:string,code:string,message:string}> */
    private array $advisories = [];
    /** @var array<string,string> */
    private array $parents = [];

    /** @param array<string,mixed> $input
     * @return array<string,mixed>
     */
    public function evaluate(array $input, CatalogSnapshot $snapshot): array
    {
        if ($snapshot->profileId() !== 'scenario-1.3.1' || ($input['schemaVersion'] ?? null) !== '1.3.1') {
            throw DomainViolation::because('Scenario input requires its matching catalog snapshot profile.');
        }
        $this->reviews = $this->advisories = $this->parents = [];
        $mode = ScenarioFacts::text($input['mode'] ?? '');
        $period = ScenarioFacts::record($input['period'] ?? []);
        $term = ScenarioTerm::evaluate($period);
        $months = $term['months'];
        $this->issues([], $term['issues']);
        if (($period['model'] ?? '') === 'HISTORICAL_ACTUAL') {
            $this->review('', 'HISTORICAL_TARGET_PRICE_REVIEW', 'Current Oracle support prices cannot establish actual historical spend. Select a constant-rate illustration or supply an approved historical target-price policy.');
        }
        if (!ScenarioFacts::accepted($input['scope'] ?? null, $mode)) {
            $this->review('', 'COVERAGE_REVIEW_REQUIRED', 'Confirm the comparison scope and disjoint physical targets, or explicitly adopt an illustrative assumption.');
        }
        $catalog = $snapshot->entries();
        $offerings = $snapshot->offerings();
        $rawGroups = [];
        foreach (ScenarioFacts::records($input['groups'] ?? []) as $group) {
            $id = ScenarioFacts::text($group['id'] ?? '');
            if ($id === '' || isset($rawGroups[$id])) {
                $this->review('', 'DUPLICATE_TARGET_REVIEW', 'Physical group identifiers must be present and unique.');
            }
            $rawGroups[$id] = $group;
            $this->parents[$id] = $id;
        }
        $rows = [];
        $assigned = [];
        $seenLineIds = [];
        $seenSourceRows = [];
        $seenPurchases = [];
        $bucketRows = ['included' => [], 'excluded' => [], 'held' => [], 'outOfPeriod' => []];
        $facts = new ScenarioFacts();
        $otherRaw = ScenarioFacts::records($input['otherCosts'] ?? []);
        foreach (ScenarioFacts::records($input['lines'] ?? []) as $line) {
            $id = ScenarioFacts::text($line['id'] ?? '');
            $sku = ScenarioFacts::text($line['sku'] ?? '');
            $groupIds = ScenarioFacts::strings($line['groupIds'] ?? []);
            $entry = $catalog[$sku] ?? null;
            $row = [...$line, 'catalogMetadata' => $entry, 'annual' => null, 'term' => null, 'variance' => null, 'issues' => [], 'bucket' => 'nonproduct'];
            if (($line['rowType'] ?? '') !== 'PRODUCT') {
                $rows[] = $row;
                continue;
            }
            $sourceRow = ScenarioFacts::text($line['sourceId'] ?? '');
            if ($id === '' || isset($seenLineIds[$id]) || ($sourceRow !== '' && isset($seenSourceRows[$sourceRow]))) {
                $this->review('', 'DUPLICATE_PURCHASE_REVIEW', 'A product row identifier/source row is repeated; reconcile the preserved inventory before claiming complete totals.');
            }
            $seenLineIds[$id] = true;
            if ($sourceRow !== '') {
                $seenSourceRows[$sourceRow] = true;
            }
            $issues = $facts->identity($line, $entry);
            $vm = null;
            $pricingLine = $line;
            $vendor = in_array($sku, ['VCF-CLD-FND-5', 'VCF-VSP-FND-8'], true) ? 'VMware' : 'Red Hat';
            $selected = ($line['selected'] ?? false) === true && ($line['quantity'] ?? null) !== 0;
            $outOfPeriod = $this->outsidePeriod($line, $period);
            $excluded = $issues === [] && ($entry['treatment'] ?? '') === 'EXCLUDED';
            if ($selected && !$outOfPeriod && !$excluded && $vendor === 'VMware' && $issues === []) {
                $vm = (new ScenarioVmware())->evaluate($line, $period, $mode, $otherRaw);
                $pricingLine['quantity'] = $vm['quantity'];
                $issues = [...$issues, ...$vm['issues']];
                $this->issues($groupIds, $vm['advisories'], true);
            }
            $pricing = ScenarioPricing::evaluate($pricingLine, $entry, $period, $mode, $snapshot);
            if (($line['quantity'] ?? null) === 0) {
                $pricing['annual'] = $pricing['term'] = '0.00';
            }
            $row = [...$row, 'vendor' => $vendor, 'annual' => $pricing['annual'], 'term' => $pricing['term'], 'price' => $pricing['price'],
                'annualKind' => $pricing['annualKind'], 'variance' => $pricing['variance'], 'vmwareEvaluation' => $vm,
                'pricedQuantity' => $pricingLine['quantity'] ?? null];
            if (!$selected || $outOfPeriod) {
                $row['bucket'] = 'outOfPeriod';
            } elseif ($excluded) {
                $row['bucket'] = 'excluded';
                $row['exclusionCode'] = $entry['exclusionCode'] ?? 'EXCLUDED';
                $row['exclusionReason'] = $entry['exclusionReason'] ?? 'Excluded from comparable costs.';
            } else {
                $this->connect($groupIds);
                foreach (['subscriptionId', 'poolId'] as $field) {
                    $key = ScenarioFacts::text($line[$field] ?? '');
                    if ($key !== '') {
                        $key = $field . ':' . ScenarioFacts::text($line['organization'] ?? '') . ':' . $key;
                        if (isset($seenPurchases[$key])) {
                            $issues[] = ScenarioFacts::issue('DUPLICATE_PURCHASE_REVIEW', 'Repeated source/pool record requires purchase and period reconciliation; do not sum host-expanded rows.');
                            $this->issues($seenPurchases[$key], [ScenarioFacts::issue('DUPLICATE_PURCHASE_REVIEW', 'A source purchase or subscription pool is repeated.')]);
                            $this->connect([...$seenPurchases[$key], ...$groupIds]);
                        }
                        $seenPurchases[$key] = $groupIds;
                    }
                }
                if ($groupIds === [] || count(array_unique($groupIds)) !== count($groupIds) || array_diff($groupIds, array_keys($rawGroups)) !== []) {
                    $issues[] = ScenarioFacts::issue('COVERAGE_REVIEW_REQUIRED', 'Assign this selected source line to its actual target groups exactly once.');
                }
                if (!ScenarioFacts::accepted($line['coverage'] ?? null, $mode)) {
                    $issues[] = ScenarioFacts::issue('COVERAGE_REVIEW_REQUIRED', 'Record confirmed or explicitly assumed source-to-target coverage. Equal quantities do not establish overlap.');
                }
                if (!is_int($pricingLine['quantity'] ?? null) || $pricingLine['quantity'] < 1) {
                    $issues[] = ScenarioFacts::issue('SOURCE_QUANTITY_REVIEW', 'Selected source units must be positive whole numbers.');
                }
                if ($entry !== null && $facts->identity($line, $entry) === []) {
                    $issues = [...$issues, ...$facts->source($pricingLine, $entry, $mode)];
                    foreach ($groupIds as $gid) {
                        $assigned[$gid][] = [...$line, 'catalogMetadata' => $entry, 'retained' => $vm['retained'] ?? false];
                    }
                    if ($entry['eligible'] === []) {
                        $issues[] = ScenarioFacts::issue('CAPABILITY_REVIEW_REQUIRED', 'The verified product has no approved capability mapping.');
                    }
                    if ($entry['embeddedLifecycle'] ?? false) {
                        $this->issues($groupIds, [ScenarioFacts::issue('EMBEDDED_LIFECYCLE_BENEFIT_NOT_COMPARED', $sku . ': full bundle price retained; embedded EUS is outside feature comparison.')], true);
                    }
                }
                $issues = [...$issues, ...$pricing['issues'], ...$this->lineDates($line, $period)];
                $this->issues($groupIds, $pricing['advisories'], true);
                $row['bucket'] = $issues === [] ? 'included' : 'held';
                $row['issues'] = $issues;
                $this->issues($groupIds, $issues);
            }
            $bucketRows[$row['bucket']][] = $row;
            $rows[] = $row;
        }
        $groups = $this->groups($rawGroups, $assigned, $offerings, $mode, $months);
        $requiredGroups = [];
        foreach ($groups as $gid => $group) {
            if ($group['olamRequired']) {
                $requiredGroups[] = $gid;
            }
        }
        $rawPools = ScenarioFacts::records($input['pools'] ?? []);
        foreach ($rawPools as $pool) {
            $this->connect(ScenarioFacts::strings($pool['groupIds'] ?? []));
        }
        $poolResult = (new ScenarioPools())->evaluate($rawPools, $groups, $requiredGroups, $mode, $months, $snapshot);
        foreach ($poolResult['issues'] as $issue) {
            $this->review($issue['groupId'], $issue['code'], $issue['message']);
        }
        foreach ($poolResult['advisories'] as $issue) {
            $this->advisories[] = $issue;
        }
        $otherCosts = $this->otherCosts($otherRaw, $catalog, $period, $mode, $snapshot);
        $scope = ScenarioFacts::record($input['scope'] ?? []);
        $reduced = ($scope['reduced'] ?? false) === true;
        $scopes = $this->scopes($groups, $rows, $poolResult['pools'], $otherCosts);
        $ready = $this->reviews === [] && $scopes !== [] && !$reduced;
        $includedCount = count($bucketRows['included']);
        if ($includedCount === 0) {
            $this->review('', 'COMPARISON_SCOPE_REVIEW', 'Select at least one resolved source purchase for a comparison.');
            $ready = false;
        }
        $completeScopes = array_values(array_filter($scopes, static fn (array $scope): bool => $scope['complete']));
        $totals = $this->sumScopes($ready ? array_values($scopes) : []);
        $partial = $this->sumScopes($completeScopes);
        $partial['scopeIds'] = array_column($completeScopes, 'id');
        $partial['label'] = $reduced ? 'CONDITIONAL_REDUCED_SCOPE' : 'PARTIAL_RESOLVED';
        $label = $ready ? ($mode === 'ILLUSTRATIVE' ? 'ILLUSTRATIVE' : 'VALIDATED_INPUTS')
            : ($reduced ? 'CONDITIONAL_REDUCED_SCOPE' : ($completeScopes !== [] ? 'PARTIAL_RESOLVED' : 'INCOMPLETE'));
        foreach ($groups as &$group) {
            $group['complete'] = ($scopes[$this->root($group['id'])]['complete'] ?? false) === true;
        }
        unset($group);
        $reconciliation = [];
        foreach ($bucketRows as $bucket => $items) {
            $reconciliation[$bucket] = $this->bucket($items);
        }
        $reconciliation['gross'] = $this->bucket(array_merge(...array_values($bucketRows)));
        $reconciliation['sourceVariance'] = null;
        $exclusions = [];
        $exclusionDetails = [];
        foreach ($bucketRows['excluded'] as $row) {
            $exclusions[] = $row['sku'] . ': ' . $row['exclusionReason'];
            $exclusionDetails[] = ['sku' => $row['sku'], 'code' => $row['exclusionCode'], 'reason' => $row['exclusionReason'], 'annual' => $row['annual'], 'term' => $row['term']];
        }
        return [
            'schemaVersion' => '1.3.1', 'mode' => $mode, 'ready' => $ready, 'completeness' => $ready ? 'COMPLETE' : $label, 'resultLabel' => $label,
            'termMonths' => $months, 'period' => $term, 'temporalModel' => $period['model'] ?? '',
            'catalogContext' => $snapshot->context(), 'mappingVersion' => $snapshot->mappingVersion(), 'priceVersion' => $snapshot->priceVersion(),
            'versions' => ['mapping' => $snapshot->mappingVersion(), 'catalog' => $snapshot->releaseId(), 'prices' => $snapshot->priceVersion(),
                'olam' => CatalogSnapshot::OLAM_RULE, 'vmware' => CatalogSnapshot::VMWARE_RULE, 'parser' => 'scenario-import-1.3.1'],
            'blockers' => array_values(array_unique(array_column($this->reviews, 'message'))), 'reviews' => $this->reviews, 'advisories' => $this->advisories,
            'groups' => array_values($groups), 'lines' => $rows, 'pools' => $poolResult['pools'], 'otherCosts' => $otherCosts, 'scopes' => array_values($scopes),
            'exclusions' => $exclusions, 'exclusionDetails' => $exclusionDetails, 'reconciliation' => $reconciliation,
            'assumptions' => $this->assumptions($input), 'partial' => $partial,
            ...($ready ? $totals : array_fill_keys(array_keys($totals), null)),
        ];
    }

    /** @param array<string,array<string,mixed>> $rawGroups
     * @param array<string,list<array<string,mixed>>> $assigned
     * @param array<string,array<string,mixed>> $offerings
     * @return array<string,array<string,mixed>>
     */
    private function groups(array $rawGroups, array $assigned, array $offerings, string $mode, int $months): array
    {
        $groups = [];
        $keys = [];
        $physicalIds = [];
        foreach ($rawGroups as $id => $group) {
            $groupIssues = [];
            $systems = $group['systems'] ?? null;
            $cpus = $group['cpusPerSystem'] ?? null;
            $systemIds = ScenarioFacts::strings($group['systemIds'] ?? []);
            $key = ScenarioFacts::text($group['populationKey'] ?? '');
            if (!is_int($systems) || $systems < 1 || !is_int($cpus) || $cpus < 1 || $cpus > 1024 || ($group['deployment'] ?? '') !== 'PHYSICAL') {
                $groupIssues[] = ScenarioFacts::issue('QUANTITY_REVIEW_REQUIRED', 'A supported physical Oracle target needs distinct systems and physical CPUs per system; vCPUs or guests are not sockets.');
            }
            if (!ScenarioFacts::accepted($group['coverage'] ?? null, $mode)) {
                $groupIssues[] = ScenarioFacts::issue('COVERAGE_REVIEW_REQUIRED', 'Review the physical target count and CPU configuration, including any illustrative assumptions.');
            }
            if (($systemIds !== [] && count($systemIds) !== $systems) || ($systemIds === [] && $key === '')) {
                $groupIssues[] = ScenarioFacts::issue('QUANTITY_REVIEW_REQUIRED', 'System identifiers must reconcile to the target count, or provide an explicitly disjoint population key.');
            }
            foreach ($systemIds as $physicalId) {
                if (isset($physicalIds[$physicalId])) {
                    $previous = $physicalIds[$physicalId];
                    $this->connect([$previous, $id]);
                    $this->review($previous, 'DUPLICATE_TARGET_REVIEW', 'A physical system appears in multiple target groups.');
                    $groupIssues[] = ScenarioFacts::issue('DUPLICATE_TARGET_REVIEW', 'A physical system is repeated; support must be charged once.');
                }
                $physicalIds[$physicalId] = $id;
            }
            if ($key !== '' && isset($keys[$key])) {
                $previous = $keys[$key];
                $this->connect([$previous, $id]);
                $this->review($previous, 'DUPLICATE_TARGET_REVIEW', 'A population key appears in multiple target groups.');
                $groupIssues[] = ScenarioFacts::issue('DUPLICATE_TARGET_REVIEW', 'Repeated population keys cannot establish disjoint targets.');
            }
            $keys[$key] = $id;
            $eligible = null;
            $olam = ($group['olamRequired'] ?? false) === true;
            $sourceLines = $assigned[$id] ?? [];
            $entitlements = [];
            $hasBase = false;
            $hasUnlimitedBase = false;
            foreach ($sourceLines as $line) {
                $entry = ScenarioFacts::record($line['catalogMetadata']);
                if ($line['retained'] ?? false) {
                    continue;
                }
                $candidate = ScenarioFacts::strings($entry['eligible'] ?? []);
                $eligible = $eligible === null ? $candidate : array_values(array_intersect($eligible, $candidate));
                $olam = $olam || ($entry['olam'] ?? false);
                if ($entry['baseEntitlement'] ?? false) {
                    $hasBase = true;
                    $hasUnlimitedBase = $hasUnlimitedBase || ($entry['unlimitedGuests'] ?? false);
                    $entitlements['BASE_OS'][] = $line;
                }
                foreach (array_intersect(['OSMH', 'HA_COROSYNC_PACEMAKER', 'OLAM'], ScenarioFacts::strings($entry['features'] ?? [])) as $feature) {
                    $entitlements[$feature][] = $line;
                }
                if (($entry['workstation'] ?? false) && ($group['workstationScope'] ?? '') !== 'OS_ONLY_GUEST_EXCLUDED') {
                    $groupIssues[] = ScenarioFacts::issue('WORKSTATION_SCOPE_REVIEW', 'Declare OS-only workstation scope, compatibility review and excluded guest scope.');
                }
            }
            if ($olam) {
                $eligible = array_values(array_intersect($eligible ?? ['OL-PREMIER', 'OL-PREMIER-PLUS'], ['OL-PREMIER', 'OL-PREMIER-PLUS']));
            }
            foreach ($entitlements as $feature => $purchases) {
                if (count($purchases) > 1) {
                    foreach ($purchases as $purchase) {
                        if (!ScenarioFacts::evidence(ScenarioFacts::record($purchase['sourceEstate'] ?? [])['duplicateEvidence'] ?? null)) {
                            $groupIssues[] = ScenarioFacts::issue('DUPLICATE_ENTITLEMENT_REVIEW', 'Overlapping ' . $feature . ' entitlements need evidence of actual separate purchases or a scope correction.');
                            break;
                        }
                    }
                }
            }
            foreach ($sourceLines as $line) {
                $entry = ScenarioFacts::record($line['catalogMetadata']);
                if (($entry['requiresBase'] ?? false) && (($entry['unlimitedGuests'] ?? false) ? !$hasUnlimitedBase : !$hasBase)
                    && !ScenarioFacts::evidence(ScenarioFacts::record($line['sourceEstate'] ?? [])['prerequisiteEvidence'] ?? null)) {
                    $groupIssues[] = ScenarioFacts::issue('SOURCE_PREREQUISITE_REVIEW', ScenarioFacts::text($line['sku']) . ': establish the qualifying base and its matching guest scope.');
                }
            }
            $selected = ScenarioFacts::text($group['offering'] ?? '');
            $minimum = $eligible[0] ?? '';
            $selected = $selected === '' ? $minimum : $selected;
            if ($eligible === null || $eligible === [] || !in_array($selected, $eligible, true) || !isset($offerings[$selected])) {
                $groupIssues[] = ScenarioFacts::issue('CAPABILITY_REVIEW_REQUIRED', 'Resolve the qualifying Oracle support tier for all included source features in this population.');
            }
            $validUnits = is_int($systems) && $systems > 0 && is_int($cpus) && $cpus > 0 && $cpus <= 1024 && ($group['deployment'] ?? '') === 'PHYSICAL';
            $pairs = $validUnits ? $systems * intdiv($cpus + 1, 2) : null;
            $units = $selected === 'OL-PUBLIC-YUM' ? 0 : $pairs;
            $rate = $offerings[$selected]['price'] ?? null;
            $annual = $validUnits && $units !== null && is_string($rate) && in_array($selected, $eligible ?? [], true) ? self::money(BigDecimal::of($rate)->multipliedBy($units)) : null;
            $this->issues([$id], $groupIssues);
            $groups[$id] = [...$group, 'id' => $id, 'systems' => $systems, 'cpusPerSystem' => $cpus, 'units' => $units, 'pairs' => $pairs,
                'offering' => $selected, 'offeringDescription' => $offerings[$selected]['description'] ?? '', 'minimumOffering' => $minimum, 'minimumTier' => $minimum,
                'olamRequired' => $olam, 'annual' => $annual, 'term' => $annual === null ? null : self::multiply($annual, intdiv($months, 12)),
                'complete' => $groupIssues === [], 'issues' => $groupIssues];
        }
        return $groups;
    }

    /** @param list<array<string,mixed>> $raw
     * @param array<string,array<string,mixed>> $catalog
     * @param array<string,mixed> $period
     * @return list<array<string,mixed>>
     */
    private function otherCosts(array $raw, array $catalog, array $period, string $mode, CatalogSnapshot $snapshot): array
    {
        $results = [];
        $ids = [];
        foreach ($raw as $cost) {
            $id = ScenarioFacts::text($cost['id'] ?? '');
            $groups = ScenarioFacts::strings($cost['groupIds'] ?? []);
            $this->connect($groups);
            $issues = [];
            if ($id === '' || isset($ids[$id]) || $groups === [] || array_diff($groups, array_keys($this->parents)) !== []) {
                $issues[] = ScenarioFacts::issue('OTHER_COST_REVIEW', 'Other costs require unique identifiers and an explicit comparison scope.');
            }
            if (isset($ids[$id])) {
                $this->connect([...$ids[$id], ...$groups]);
                $this->issues($ids[$id], [ScenarioFacts::issue('OTHER_COST_REVIEW', 'A required cost identifier is repeated across comparison scopes.')]);
            }
            $ids[$id] = $groups;
            $sku = ScenarioFacts::text($cost['sku'] ?? '');
            if (($catalog[$sku]['treatment'] ?? '') === 'EXCLUDED') {
                $issues[] = ScenarioFacts::issue('POLICY_EXCLUSION_REVIEW', 'Excluded products cannot be reintroduced through the other-cost ledger.');
            }
            $pricing = ScenarioPricing::evaluate(['quantity' => 1, 'price' => $cost['price'] ?? null], null, $period, $mode, $snapshot);
            $issues = [...$issues, ...$pricing['issues']];
            $this->issues($groups, $issues);
            $results[] = [...$cost, 'annual' => $pricing['annual'], 'term' => $pricing['term'], 'issues' => $issues];
        }
        return $results;
    }

    /** @param array<string,array<string,mixed>> $groups
     * @param list<array<string,mixed>> $lines
     * @param list<array<string,mixed>> $pools
     * @param list<array<string,mixed>> $costs
     * @return array<string,array<string,mixed>>
     */
    private function scopes(array $groups, array $lines, array $pools, array $costs): array
    {
        $scopes = [];
        foreach ($groups as $id => $group) {
            $root = $this->root($id);
            $scopes[$root] ??= ['id' => $root, 'groupIds' => [], 'lineIds' => [], 'poolIds' => [], 'complete' => true,
                'sourceVendorAnnual' => ['Red Hat' => '0.00', 'VMware' => '0.00'], 'sourceVendorTerm' => ['Red Hat' => '0.00', 'VMware' => '0.00'],
                'sourceOtherAnnual' => '0.00', 'sourceOtherTerm' => '0.00', 'oracleSupportAnnual' => '0.00', 'oracleSupportTerm' => '0.00', 'targetOtherAnnual' => '0.00', 'targetOtherTerm' => '0.00'];
            $scopes[$root]['groupIds'][] = $id;
            $scopes[$root]['oracleSupportAnnual'] = self::add($scopes[$root]['oracleSupportAnnual'], $group['annual']);
            $scopes[$root]['oracleSupportTerm'] = self::add($scopes[$root]['oracleSupportTerm'], $group['term']);
        }
        foreach ($this->reviews as $review) {
            if ($review['groupId'] === '') {
                foreach ($scopes as &$scope) {
                    $scope['complete'] = false;
                }
                unset($scope);
            } elseif (isset($scopes[$this->root($review['groupId'])])) {
                $scopes[$this->root($review['groupId'])]['complete'] = false;
            }
        }
        foreach ($lines as $line) {
            if (!in_array($line['bucket'], ['included', 'held'], true)) {
                continue;
            }
            $groupIds = ScenarioFacts::strings($line['groupIds'] ?? []);
            $root = $this->root($groupIds[0] ?? '');
            if (!isset($scopes[$root])) {
                continue;
            }
            $scopes[$root]['lineIds'][] = $line['id'];
            $vendor = ScenarioFacts::text($line['vendor']);
            foreach (['Annual' => 'annual', 'Term' => 'term'] as $suffix => $field) {
                $scopes[$root]['sourceVendor' . $suffix][$vendor] = self::add($scopes[$root]['sourceVendor' . $suffix][$vendor], $line[$field]);
                if (ScenarioFacts::record($line['vmwareEvaluation'] ?? [])['retained'] ?? false) {
                    $scopes[$root]['targetOther' . $suffix] = self::add($scopes[$root]['targetOther' . $suffix], $line[$field]);
                }
            }
        }
        foreach ($pools as $pool) {
            $ids = ScenarioFacts::strings($pool['groupIds'] ?? []);
            $root = $this->root($ids[0] ?? '');
            if (!isset($scopes[$root])) {
                continue;
            }
            $scopes[$root]['poolIds'][] = $pool['id'];
            $scopes[$root]['oracleSupportAnnual'] = self::add($scopes[$root]['oracleSupportAnnual'], $pool['extraAnnual']);
            $scopes[$root]['oracleSupportTerm'] = self::add($scopes[$root]['oracleSupportTerm'], $pool['extraTerm']);
        }
        foreach ($costs as $cost) {
            $ids = ScenarioFacts::strings($cost['groupIds'] ?? []);
            $root = $this->root($ids[0] ?? '');
            if (!isset($scopes[$root])) {
                continue;
            }
            foreach (['Annual' => 'annual', 'Term' => 'term'] as $suffix => $field) {
                if (in_array($cost['side'], ['SOURCE', 'BOTH'], true)) {
                    $scopes[$root]['sourceOther' . $suffix] = self::add($scopes[$root]['sourceOther' . $suffix], $cost[$field]);
                }
                if (in_array($cost['side'], ['TARGET', 'BOTH'], true)) {
                    $scopes[$root]['targetOther' . $suffix] = self::add($scopes[$root]['targetOther' . $suffix], $cost[$field]);
                }
            }
        }
        foreach ($scopes as &$scope) {
            $scope = [...$scope, ...$this->financial($scope)];
            $scope['complete'] = $scope['complete'] && $scope['sourceAnnual'] !== null && $scope['oracleAnnual'] !== null && $scope['sourceTerm'] !== null && $scope['oracleTerm'] !== null;
            if (!$scope['complete']) {
                foreach (['savingsAnnual', 'savingsTerm', 'savingsPercent', 'termPercent'] as $key) {
                    $scope[$key] = null;
                }
            }
        }
        unset($scope);
        return $scopes;
    }

    /** @param list<array<string,mixed>> $scopes
     * @return array<string,mixed>
     */
    private function sumScopes(array $scopes): array
    {
        $total = ['sourceVendorAnnual' => ['Red Hat' => '0.00', 'VMware' => '0.00'], 'sourceVendorTerm' => ['Red Hat' => '0.00', 'VMware' => '0.00'],
            'sourceOtherAnnual' => '0.00', 'sourceOtherTerm' => '0.00', 'oracleSupportAnnual' => '0.00', 'oracleSupportTerm' => '0.00', 'targetOtherAnnual' => '0.00', 'targetOtherTerm' => '0.00'];
        foreach ($scopes as $scope) {
            foreach (array_keys($total) as $key) {
                if (is_array($total[$key])) {
                    foreach (array_keys($total[$key]) as $vendor) {
                        $total[$key][$vendor] = self::add($total[$key][$vendor], $scope[$key][$vendor]);
                    }
                } else {
                    $total[$key] = self::add($total[$key], $scope[$key]);
                }
            }
        }
        return [...$total, ...$this->financial($total)];
    }

    /** @param array<string,mixed> $scope
     * @return array<string,?string>
     */
    private function financial(array $scope): array
    {
        $result = [];
        foreach (['Annual', 'Term'] as $suffix) {
            $vendors = ScenarioFacts::record($scope['sourceVendor' . $suffix]);
            $source = self::add(self::add($vendors['Red Hat'], $vendors['VMware']), $scope['sourceOther' . $suffix]);
            $target = self::add($scope['oracleSupport' . $suffix], $scope['targetOther' . $suffix]);
            $difference = $source === null || $target === null ? null : self::money(BigDecimal::of($source)->minus($target));
            $percent = $source === null || $difference === null || BigDecimal::of($source)->isLessThanOrEqualTo(0) ? null
                : (string) BigDecimal::of($difference)->multipliedBy(100)->dividedBy($source, 2, RoundingMode::HALF_UP);
            $result['source' . $suffix] = $source;
            $result['oracle' . $suffix] = $target;
            $result['savings' . $suffix] = $difference;
            $result[$suffix === 'Annual' ? 'savingsPercent' : 'termPercent'] = $percent;
        }
        return $result;
    }

    /** @param list<array<string,mixed>> $rows
     * @return array<string,mixed>
     */
    private function bucket(array $rows): array
    {
        $annual = $term = $valuedAnnual = $valuedTerm = '0.00';
        $unvalued = [];
        foreach ($rows as $row) {
            $annual = self::add($annual, $row['annual']);
            $term = self::add($term, $row['term']);
            $valuedAnnual = self::add($valuedAnnual, $row['annual'] ?? '0.00');
            $valuedTerm = self::add($valuedTerm, $row['term'] ?? '0.00');
            if ($row['annual'] === null || $row['term'] === null) {
                $unvalued[] = $row['id'];
            }
        }
        return ['annual' => $annual, 'term' => $term, 'valuedAnnual' => $valuedAnnual, 'valuedTerm' => $valuedTerm, 'count' => count($rows), 'unvaluedIds' => $unvalued];
    }

    /** @param array<string,mixed> $line
     * @param array<string,mixed> $period
     */
    private function outsidePeriod(array $line, array $period): bool
    {
        $locale = ScenarioFacts::text($period['dateLocale'] ?? 'ISO');
        $start = ScenarioDates::parse(ScenarioFacts::text($line['startDate'] ?? ''), $locale);
        $end = ScenarioDates::parse(ScenarioFacts::text($line['endDate'] ?? ''), $locale);
        $comparisonStart = ScenarioDates::parse(ScenarioFacts::text($period['startDate'] ?? ''), $locale);
        $comparisonEnd = ScenarioDates::parse(ScenarioFacts::text($period['endDate'] ?? ''), $locale);
        return $start !== null && $end !== null && $start <= $end && $comparisonStart !== null && $comparisonEnd !== null
            && ($end < $comparisonStart || $start > $comparisonEnd);
    }

    /** @param array<string,mixed> $line
     * @param array<string,mixed> $period
     * @return list<array{code:string,message:string}>
     */
    private function lineDates(array $line, array $period): array
    {
        $start = ScenarioFacts::text($line['startDate'] ?? '');
        $end = ScenarioFacts::text($line['endDate'] ?? '');
        if ($start === '' && $end === '') {
            return [];
        }
        $locale = ScenarioFacts::text($period['dateLocale'] ?? 'ISO');
        $parsedStart = ScenarioDates::parse($start, $locale);
        $parsedEnd = ScenarioDates::parse($end, $locale);
        $compareStart = ScenarioDates::parse(ScenarioFacts::text($period['startDate'] ?? ''), $locale);
        $compareEnd = ScenarioDates::parse(ScenarioFacts::text($period['endDate'] ?? ''), $locale);
        if ($parsedStart === null || $parsedEnd === null || $parsedStart > $parsedEnd || $compareStart === null || $compareEnd === null || $parsedStart > $compareStart || $parsedEnd < $compareEnd) {
            return [ScenarioFacts::issue('SOURCE_PERIOD_REVIEW', 'Resolve source coverage dates and the selected comparison period; no implicit partial-term proration.')];
        }
        return [];
    }

    /** @param array<string,mixed> $input
     * @return list<string>
     */
    private function assumptions(array $input): array
    {
        $values = [];
        $walk = function (array $record) use (&$walk, &$values): void {
            if (($record['state'] ?? '') === 'ASSUMED' && is_string($record['evidence'] ?? null)) {
                $values[] = $record['evidence'];
            }
            foreach ($record as $value) {
                if (is_array($value)) {
                    $walk($value);
                }
            }
        };
        $walk($input);
        return array_values(array_unique($values));
    }

    /** @param list<string> $ids */
    private function connect(array $ids): void
    {
        $known = array_values(array_filter($ids, fn (string $id): bool => isset($this->parents[$id])));
        if ($known === []) {
            return;
        }
        $root = $this->root($known[0]);
        foreach ($known as $id) {
            $this->parents[$this->root($id)] = $root;
        }
    }

    private function root(string $id): string
    {
        while (isset($this->parents[$id]) && $this->parents[$id] !== $id) {
            $id = $this->parents[$id];
        }
        return $id;
    }

    /** @param list<string> $groups
     * @param list<array<string,mixed>> $issues
     */
    private function issues(array $groups, array $issues, bool $advisory = false): void
    {
        foreach ($issues as $issue) {
            foreach ($groups === [] ? [''] : array_unique($groups) as $id) {
                if ($advisory) {
                    $this->advisories[] = ['groupId' => $id, 'code' => ScenarioFacts::text($issue['code'] ?? ''), 'message' => ScenarioFacts::text($issue['message'] ?? '')];
                } else {
                    $this->review($id, ScenarioFacts::text($issue['code'] ?? ''), ScenarioFacts::text($issue['message'] ?? ''));
                }
            }
        }
    }

    private function review(string $id, string $code, string $message): void
    {
        $this->reviews[] = ['groupId' => $id, 'code' => $code, 'message' => $message];
    }

    private static function add(mixed $a, mixed $b): ?string
    {
        return is_string($a) && is_string($b) ? self::money(BigDecimal::of($a)->plus($b)) : null;
    }

    private static function multiply(string $amount, int $multiple): string
    {
        return self::money(BigDecimal::of($amount)->multipliedBy($multiple));
    }

    private static function money(BigDecimal $amount): string
    {
        return (string) $amount->toScale(2, RoundingMode::HALF_UP);
    }
}
