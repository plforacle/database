<?php

declare(strict_types=1);

namespace App\Domain\Coverage;

/** Input has no authority to supply prices, catalog mappings, rule versions or calculated totals. */
final class CoverageScenario
{
    /** @return array{customer:array{name:string,objective:string,scope:string,nextStep:string},populationEvidence:string,groups:list<array<string,mixed>>,lines:list<array{sourceId:string,originalQuantity:int,sku:string,quantity:int,groupId:string,exclusionReason:string}>} */
    public static function example(): array
    {
        return [
            'customer' => ['name' => 'Synthetic customer', 'objective' => 'Compare annual subscription spend', 'scope' => 'Ten homogeneous physical systems in one support population', 'nextStep' => 'Validate inventory and obtain an approved commercial quote.'],
            'populationEvidence' => 'Synthetic inventory reviewed: populations are homogeneous and disjoint; each source row covers one complete population.',
            'groups' => [[
                'id' => 'group-1', 'label' => 'Core systems', 'populationKey' => 'synthetic-core', 'systems' => 10, 'cpusPerSystem' => 2,
                'populationEvidence' => 'Synthetic inventory: ten distinct two-CPU physical systems.', 'offering' => 'SYN-PREMIER',
                'olamRequired' => true, 'demand' => 200, 'allocatedUnits' => 10,
                'allocationEvidence' => 'Synthetic unique direct and indirect targets reviewed; allocation is exclusive to this population and support scope.',
                'additionalOffering' => 'SYN-PREMIER', 'additionalUnits' => 0,
                'deployment' => 'PHYSICAL', 'sourceEntitlementsConfirmed' => false,
                'sourceDeployment' => '', 'sourceSystems' => null, 'sourceCpusPerSystem' => 2,
                'sourceGuests' => null, 'sourceManagedNodes' => null,
                'sourceQuantityEvidence' => '', 'prerequisiteEvidence' => '',
                'workstationScopeAcknowledged' => false, 'workstationGuestScope' => '',
                'duplicateEntitlementEvidence' => '',
            ]],
            'lines' => [['sourceId' => 'source-1', 'originalQuantity' => 10, 'sku' => 'SYN-OS', 'quantity' => 10, 'groupId' => 'group-1', 'exclusionReason' => '']],
        ];
    }
}
