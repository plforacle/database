<?php

declare(strict_types=1);

namespace App\Domain\Shared;

final readonly class RedactedSourceText
{
    private const MAX_BYTES = 32_768;

    private function __construct(private string $value)
    {
    }

    public static function fromString(string $value): self
    {
        if (preg_match('//u', $value) !== 1) {
            throw DomainViolation::because('Redacted source text must be valid UTF-8.');
        }

        if (strlen($value) > self::MAX_BYTES) {
            throw DomainViolation::because('Redacted source text exceeds the permitted byte limit.');
        }

        return new self($value);
    }

    public function value(): string
    {
        return $this->value;
    }
}
