<?php

declare(strict_types=1);

namespace App\Domain\Catalog;

use App\Domain\Shared\CatalogVersionId;

interface CatalogRepository
{
    /**
     * @return array{sku: string, description: string, unit: string, annualUsdPrice: string|null}|null
     */
    public function findSku(CatalogVersionId $catalogVersionId, string $governedSku): ?array;

    /**
     * @return list<array{alias: string, governedSku: string}>
     */
    public function aliasesForVersion(CatalogVersionId $catalogVersionId): array;

    /**
     * @return list<array{sku: string, description: string, unit: string, annualUsdPrice: string, rationale: string}>
     */
    public function eligibleOptions(CatalogVersionId $catalogVersionId, string $sourceSku): array;
}
