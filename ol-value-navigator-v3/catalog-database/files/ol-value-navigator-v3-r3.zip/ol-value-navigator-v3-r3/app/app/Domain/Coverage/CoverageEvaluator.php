<?php

declare(strict_types=1);

namespace App\Domain\Coverage;

use App\Domain\Package\CatalogSnapshot;
use App\Domain\Shared\DomainViolation;

/** Shared deterministic evaluation for review and locked confirmation. Money uses exact cents. */
final class CoverageEvaluator
{
    /** @param array<string,mixed> $input
     * @return array<string,mixed>
     */
    public function evaluate(array $input, CatalogSnapshot $snapshot): array
    {
        $schema = $input['schemaVersion'] ?? 'legacy-coverage';
        if ($schema !== $snapshot->context()['inputSchema']) {
            throw DomainViolation::because('Input schema does not match the selected catalog snapshot profile.');
        }
        if ($schema === '1.3.1') {
            return (new ScenarioEvaluator())->evaluate(ScenarioInput::normalize($input), $snapshot);
        }
        $reviews = [];
        $advisories = [];
        $exclusions = [];
        $exclusionDetails = [];
        $lines = [];
        $groups = [];
        $rawGroups = $input['groups'] ?? null;
        $rawLines = $input['lines'] ?? null;
        if (!is_array($rawGroups) || !array_is_list($rawGroups) || count($rawGroups) < 1 || count($rawGroups) > 5
            || !is_array($rawLines) || !array_is_list($rawLines) || count($rawLines) < 1 || count($rawLines) > 10) {
            return $this->result([], [], [], [], [$this->issue('', 'INPUT_REVIEW_REQUIRED', 'Use one to five populations and one to ten source subscriptions.')], [], null, null, $snapshot);
        }
        if (!$this->evidence($input['populationEvidence'] ?? null)) {
            $reviews[] = $this->issue('', 'QUANTITY_REVIEW_REQUIRED', 'Confirm disjoint homogeneous populations and complete source assignments; split subscriptions spanning populations.');
        }
        $catalog = $snapshot->entries();
        $offerings = $snapshot->offerings();
        $byId = [];
        $keys = [];
        foreach ($rawGroups as $group) {
            if (!is_array($group) || !$this->identifier($group['id'] ?? null)) {
                $reviews[] = $this->issue('', 'QUANTITY_REVIEW_REQUIRED', 'Every population requires a unique identifier.');
                continue;
            }
            $id = $group['id'];
            if (isset($byId[$id])) {
                $reviews[] = $this->issue('', 'QUANTITY_REVIEW_REQUIRED', 'Duplicate population identifier: ' . $id);
            }
            $byId[$id] = $group;
        }
        $origins = [];
        $assigned = [];
        $reference = 0;
        $addons = 0;
        foreach ($rawLines as $index => $line) {
            if (!is_array($line)) {
                $reviews[] = $this->issue('', 'INPUT_REVIEW_REQUIRED', 'Invalid source subscription.');
                continue;
            }
            $sku = is_string($line['sku'] ?? null) ? strtoupper(trim($line['sku'])) : '';
            $entry = $catalog[$sku] ?? null;
            $reason = $line['exclusionReason'] ?? '';
            // Excluded products never contribute quantities, capabilities, price or capacity.
            if (($entry['treatment'] ?? '') === 'EXCLUDED' || (is_string($reason) && trim($reason) !== '' && mb_strlen($reason) <= 500)) {
                $automatic = ($entry['treatment'] ?? '') === 'EXCLUDED';
                $reason = $automatic ? ($entry['exclusionReason'] ?? 'Excluded from comparison.') : trim($reason);
                $exclusions[] = $sku . ': ' . $reason;
                $exclusionDetails[] = ['sku' => $sku, 'code' => $automatic ? ($entry['exclusionCode'] ?? 'EXCLUDED') : 'SELLER_EXCLUDED', 'reason' => $reason];
                continue;
            }
            $gid = is_string($line['groupId'] ?? null) ? $line['groupId'] : '';
            if (!isset($byId[$gid])) {
                $reviews[] = $this->issue('', 'QUANTITY_REVIEW_REQUIRED', 'Source row ' . ($index + 1) . ' requires an explicit population assignment.');
            }
            $quantity = $this->count($line['quantity'] ?? null, 1);
            $original = $this->count($line['originalQuantity'] ?? null, 1);
            $origin = $line['sourceId'] ?? null;
            if (!$this->identifier($origin) || $original === null || $quantity === null) {
                $reviews[] = $this->issue($gid, 'QUANTITY_REVIEW_REQUIRED', $sku . ': original source identifier and positive whole quantities are required to reconcile assignments.');
            } else {
                $previous = $origins[$origin] ?? ['sku' => $sku, 'original' => $original, 'sum' => 0, 'groups' => []];
                if ($previous['sku'] !== $sku || $previous['original'] !== $original || in_array($gid, $previous['groups'], true)) {
                    foreach (array_unique([...$previous['groups'], $gid]) as $affected) {
                        $reviews[] = $this->issue($affected, 'QUANTITY_REVIEW_REQUIRED', 'Source ' . $origin . ': inconsistent split or repeated population assignment.');
                    }
                }
                $previous['sum'] += $quantity;
                $previous['groups'][] = $gid;
                $origins[$origin] = $previous;
            }
            $refCents = $entry !== null && $entry['term'] === 'ANNUAL' && $entry['currency'] === 'USD' ? $this->cents($entry['referencePrice']) : null;
            $reference = $reference === null || $refCents === null || $quantity === null ? null : $reference + $quantity * $refCents;
            if (($entry['treatment'] ?? '') === 'ADD_TO_RHEL') {
                $addons = $addons === null || $refCents === null || $quantity === null ? null : $addons + $quantity * $refCents;
            }
            $price = $this->cents($entry['scenarioPrice'] ?? null);
            $cost = null;
            if ($entry === null || $entry['readiness'] !== 'READY' || $price === null || $quantity === null) {
                $reviews[] = $this->issue($gid, $entry === null ? 'MISSING_FROM_CATALOG' : 'PRICE_REVIEW_REQUIRED', $sku . ': ' . ($entry['readiness'] ?? 'MISSING_FROM_CATALOG') . '; confirmed current price and subscription term, metric, USD amount, public source and review date plus a typed quantity are required.');
            } else {
                $cost = $quantity * $price;
            }
            if (($entry['mappingStatus'] ?? '') === 'UNRESOLVED_CAPABILITY') {
                $reviews[] = $this->issue($gid, 'CAPABILITY_REVIEW_REQUIRED', $sku . ': ' . $entry['capabilityRule']);
            }
            if ($entry['embeddedLifecycle'] ?? false) {
                $advisories[] = $this->issue($gid, 'EMBEDDED_LIFECYCLE_BENEFIT_NOT_COMPARED', $sku . ': full published bundle price retained; embedded EUS is outside feature comparison. No lifecycle parity, RH deduction or Oracle ELS charge is assumed.');
            }
            $evaluated = ['sku' => $sku, 'groupId' => $gid, 'sourceId' => $origin, 'description' => $entry['description'] ?? 'Unresolved subscription', 'quantity' => $quantity, 'unit' => $entry['unit'] ?? 'UNKNOWN', 'annualCost' => $cost === null ? null : $this->money($cost), 'priceBasis' => $entry['priceBasis'] ?? 'UNKNOWN', 'provenance' => $entry['provenance'] ?? 'Missing evidence', 'catalogMetadata' => $entry, 'eligibleOfferingDescriptions' => array_map(static fn (string $id): string => $offerings[$id]['description'] ?? $id, $entry['eligible'] ?? [])];
            $lines[] = $evaluated;
            if (isset($byId[$gid])) {
                $assigned[$gid][] = $evaluated;
            }
        }
        foreach ($origins as $origin => $reconciliation) {
            if ($reconciliation['sum'] !== $reconciliation['original']) {
                foreach ($reconciliation['groups'] as $gid) {
                    $reviews[] = $this->issue($gid, 'QUANTITY_REVIEW_REQUIRED', 'Source ' . $origin . ': included assignments must sum to the original included subscription quantity.');
                }
            }
        }
        if ($lines === []) {
            $reviews[] = $this->issue('', 'SCOPE_REVIEW_REQUIRED', 'At least one included source subscription is required.');
        }
        // Mark both sides of overlapping inventories before deciding which groups may enter partial totals.
        foreach ($assigned as $id => $_lines) {
            $key = is_string($byId[$id]['populationKey'] ?? null) ? strtolower(trim($byId[$id]['populationKey'])) : '';
            if ($key === '') {
                $reviews[] = $this->issue($id, 'QUANTITY_REVIEW_REQUIRED', 'Population identity is unresolved.');
            } elseif (isset($keys[$key])) {
                $reviews[] = $this->issue($id, 'QUANTITY_REVIEW_REQUIRED', 'Population overlaps another included group.');
                $reviews[] = $this->issue($keys[$key], 'QUANTITY_REVIEW_REQUIRED', 'Population overlaps another included group.');
            }
            $keys[$key] = $id;
        }
        foreach ($assigned as $id => $groupLines) {
            $group = $byId[$id];
            if (($group['deployment'] ?? '') !== 'PHYSICAL') {
                $reviews[] = $this->issue($id, 'QUANTITY_REVIEW_REQUIRED', 'Select a confirmed PHYSICAL Oracle target; virtual, cloud and unspecified targets require separate quantity review.');
            }
            if (!$this->evidence($group['populationEvidence'] ?? null)) {
                $reviews[] = $this->issue($id, 'QUANTITY_REVIEW_REQUIRED', 'Confirm unique physical systems, homogeneous CPU counts and inventory evidence.');
            }
            $systems = $this->count($group['systems'] ?? null, 1);
            $cpus = $this->count($group['cpusPerSystem'] ?? null, 1, 1024);
            $physicalUnits = $systems === null || $cpus === null || ($group['deployment'] ?? '') !== 'PHYSICAL' ? null : $systems * intdiv($cpus + 1, 2);
            if ($physicalUnits === null) {
                $reviews[] = $this->issue($id, 'QUANTITY_REVIEW_REQUIRED', 'Positive whole physical systems and CPUs per system are required; vCPUs cannot be used.');
            }
            foreach ((new SourceEntitlementReview())->review($group, $groupLines) as $review) {
                $reviews[] = $this->issue($id, $review['code'], $review['message']);
            }
            $eligible = array_keys($offerings);
            $features = [];
            $source = 0;
            $required = $group['olamRequired'] ?? null;
            if (!is_bool($required)) {
                $reviews[] = $this->issue($id, 'CAPABILITY_REVIEW_REQUIRED', 'Confirm whether OLAM is required.');
            }
            foreach ($groupLines as $line) {
                $entry = $line['catalogMetadata'];
                $eligible = array_values(array_intersect($eligible, $entry['eligible'] ?? []));
                $features = array_values(array_unique([...$features, ...($entry['features'] ?? [])]));
                if (($entry['olam'] ?? false) && $required !== true) {
                    $reviews[] = $this->issue($id, 'OLAM_DEMAND_REVIEW_REQUIRED', 'Automation subscription requires reviewed OLAM demand.');
                    $required = true;
                }
                $cents = $this->cents($line['annualCost']);
                $source = $source === null || $cents === null ? null : $source + $cents;
            }
            if ($required === true) {
                $eligible = array_values(array_filter($eligible, static fn (string $key): bool => $offerings[$key]['olam']));
                $features = array_values(array_unique([...$features, 'OLAM']));
            }
            $minimum = $eligible[0] ?? '';
            $offeringId = is_string($group['offering'] ?? null) && $group['offering'] !== '' ? $group['offering'] : $minimum;
            $offering = $offerings[$offeringId] ?? null;
            if (!in_array($offeringId, $eligible, true)) {
                $reviews[] = $this->issue($id, 'UNMET_CAPABILITY_REVIEW', 'Selected offering does not satisfy every included subscription capability (' . implode(', ', $features) . '). Minimum: ' . ($minimum === '' ? 'unresolved' : $minimum) . '.');
            }
            $units = !in_array($offeringId, $eligible, true) ? null
                : ($offeringId === 'OL-PUBLIC-YUM' && $physicalUnits !== null ? 0 : $physicalUnits);
            $baseRate = $this->cents($offering['price'] ?? null);
            if ($baseRate === null) {
                $reviews[] = $this->issue($id, 'PRICE_REVIEW_REQUIRED', 'Confirmed annual Oracle support price is required.');
            }
            $baseCost = $units === null || $baseRate === null ? null : $units * $baseRate;
            $demand = null;
            $capacity = 0;
            $shortfall = 0;
            $additional = $this->count($group['additionalUnits'] ?? 0, 0);
            $additionalCost = 0;
            $extraId = is_string($group['additionalOffering'] ?? null) && $group['additionalOffering'] !== '' ? $group['additionalOffering'] : (str_starts_with($offeringId, 'SYN-') ? 'SYN-PREMIER' : 'OL-PREMIER');
            $status = 'NOT_APPLICABLE';
            if ($additional === null) {
                $reviews[] = $this->issue($id, 'QUANTITY_REVIEW_REQUIRED', 'Additional OLAM pairs must be a whole nonnegative seller-entered count.');
                $additionalCost = null;
            }
            if ($required === true) {
                $demand = $this->count($group['demand'] ?? null, 0);
                $allocated = $this->count($group['allocatedUnits'] ?? null, 0, 512000000);
                $capacityReady = true;
                if ($demand === null) {
                    $reviews[] = $this->issue($id, 'OLAM_DEMAND_REVIEW_REQUIRED', 'Confirmed unique managed-instance demand is required (zero differs from unknown).');
                    $capacityReady = false;
                }
                if ($offering === null || !$offering['olam'] || $units === null) {
                    $reviews[] = $this->issue($id, 'OLAM_ENTITLEMENT_REVIEW_REQUIRED', 'OLAM requires verified Premier or Premier Plus support on the declared systems.');
                    $capacityReady = false;
                }
                if ($allocated !== $units || !$this->evidence($group['allocationEvidence'] ?? null)) {
                    $reviews[] = $this->issue($id, 'OLAM_ALLOCATION_REVIEW_REQUIRED', 'Allocate every eligible baseline pair exclusively to this population and review unique direct/indirect nodes; pairs and nodes cannot be reused across groups.');
                    $capacityReady = false;
                }
                if ($additional !== null && $additional > 0) {
                    $extra = $offerings[$extraId] ?? null;
                    $extraRate = $this->cents($extra['price'] ?? null);
                    if ($extra === null || !$extra['olam'] || $extraRate === null || str_starts_with($extraId, 'SYN-') !== str_starts_with($offeringId, 'SYN-')) {
                        $reviews[] = $this->issue($id, 'PRICE_REVIEW_REQUIRED', 'Select a priced Premier or Premier Plus offering for explicit extra OLAM pairs in the same catalog and support scope.');
                        $additionalCost = null;
                        $capacityReady = false;
                    } else {
                        $additionalCost = $additional * $extraRate;
                    }
                }
                $capacity = (($offering['olam'] ?? false) ? ($units ?? 0) : 0) * 20 + ($additionalCost !== null ? ($additional ?? 0) * 20 : 0);
                $shortfall = $demand === null ? 0 : max(0, $demand - $capacity);
                $status = !$capacityReady ? 'REVIEW_REQUIRED' : ($shortfall > 0 ? 'GAP_REQUIRES_REVIEW' : 'SUFFICIENT_FOR_DECLARED_NODES');
                if ($status === 'GAP_REQUIRES_REVIEW') {
                    $advisories[] = $this->issue($id, 'OLAM_SUPPORT_CAPACITY_REVIEW', 'OLAM capacity ' . $capacity . ' does not cover all ' . $demand . ' declared nodes: ' . $shortfall . ' excess nodes, ' . intdiv($shortfall + 19, 20) . ' further support pairs indicated. Cost includes only explicitly entered purchases. This scenario is not fully supported for all declared nodes.');
                }
            } elseif ($additional !== 0) {
                $reviews[] = $this->issue($id, 'OLAM_DEMAND_REVIEW_REQUIRED', 'Additional OLAM support cannot be charged without a reviewed OLAM requirement.');
            }
            $oracle = $baseCost === null || $additionalCost === null ? null : $baseCost + $additionalCost;
            $groupReviews = array_values(array_filter($reviews, static fn (array $review): bool => $review['groupId'] === $id || $review['groupId'] === ''));
            $complete = $groupReviews === [] && $source !== null && $oracle !== null;
            $groups[] = ['id' => (string) $id, 'label' => is_string($group['label'] ?? null) && trim($group['label']) !== '' ? mb_substr($group['label'], 0, 80) : (string) $id,
                'deployment' => $group['deployment'] ?? '', 'systems' => $systems, 'cpusPerSystem' => $cpus, 'supportUnits' => $units,
                'minimumOffering' => $minimum, 'offering' => $offeringId, 'selectedOffering' => $offeringId, 'features' => $features,
                'annualCost' => $baseCost === null ? null : $this->money($baseCost), 'sourceAnnual' => $source === null ? null : $this->money($source), 'oracleAnnual' => $oracle === null ? null : $this->money($oracle),
                'savingsAnnual' => $complete ? $this->money($source - $oracle) : null, 'savingsPercent' => $complete && $source > 0 ? $this->percent($source - $oracle, $source) : null,
                'unit' => $offering['unit'] ?? 'CPU_PAIR', 'olamStatus' => $status, 'supportCapacityStatus' => $status, 'demand' => $demand, 'capacity' => $capacity, 'shortfall' => $shortfall,
                'additionalUnits' => $additional, 'additionalOffering' => $extraId, 'additionalCost' => $additionalCost === null ? null : $this->money($additionalCost), 'additionalPairsIndicated' => $demand === null ? null : intdiv($shortfall + 19, 20),
                'eligibleOfferings' => $eligible, 'offeringMetadata' => $offering, 'complete' => $complete, 'reviewCodes' => array_values(array_unique(array_column($groupReviews, 'code')))];
        }
        return $this->result($groups, $lines, $exclusions, $exclusionDetails, $reviews, $advisories, $reference, $addons, $snapshot);
    }

    /** @param list<array<string,mixed>> $groups
     * @param list<array<string,mixed>> $lines
     * @param list<string> $exclusions
     * @param list<array<string,string>> $exclusionDetails
     * @param list<array{code:string,groupId:string,message:string}> $reviews
     * @param list<array{code:string,groupId:string,message:string}> $advisories
     * @return array<string,mixed>
     */
    private function result(array $groups, array $lines, array $exclusions, array $exclusionDetails, array $reviews, array $advisories, ?int $reference, ?int $addons, CatalogSnapshot $snapshot): array
    {
        $ready = $reviews === [] && $groups !== [];
        $source = 0;
        $oracle = 0;
        $included = [];
        foreach ($groups as $group) {
            if ($group['complete']) {
                $source += $this->cents($group['sourceAnnual']) ?? 0;
                $oracle += $this->cents($group['oracleAnnual']) ?? 0;
                $included[] = $group['id'];
            }
        }
        return ['ready' => $ready, 'completeness' => $ready ? 'COMPLETE' : ($included === [] ? 'INCOMPLETE' : 'PARTIAL'),
            'catalogContext' => $snapshot->context(), 'mappingVersion' => $snapshot->mappingVersion(), 'priceVersion' => $snapshot->priceVersion(),
            'blockers' => array_values(array_unique(array_map(static fn (array $review): string => ($review['groupId'] === '' ? '' : $review['groupId'] . ': ') . $review['message'], $reviews))),
            'reviews' => $reviews, 'advisories' => $advisories, 'sourceAnnual' => $ready ? $this->money($source) : null, 'oracleAnnual' => $ready ? $this->money($oracle) : null,
            'savingsAnnual' => $ready ? $this->money($source - $oracle) : null, 'savingsPercent' => $ready && $source > 0 ? $this->percent($source - $oracle, $source) : null,
            'sourceThreeYear' => $ready ? $this->money(3 * $source) : null, 'oracleThreeYear' => $ready ? $this->money(3 * $oracle) : null,
            'sourceFiveYear' => $ready ? $this->money(5 * $source) : null, 'oracleFiveYear' => $ready ? $this->money(5 * $oracle) : null,
            'partial' => ['groupIds' => $included, 'sourceAnnual' => $included === [] ? null : $this->money($source), 'oracleAnnual' => $included === [] ? null : $this->money($oracle), 'savingsAnnual' => $included === [] ? null : $this->money($source - $oracle), 'savingsPercent' => $included !== [] && $source > 0 ? $this->percent($source - $oracle, $source) : null],
            'rhelAddOnReferenceAnnual' => $addons === null ? null : $this->money($addons), 'sourceReferenceAnnual' => $reference === null ? null : $this->money($reference),
            'groups' => $groups, 'lines' => $lines, 'exclusions' => $exclusions, 'exclusionDetails' => $exclusionDetails];
    }

    /** @return array{code:string,groupId:string,message:string} */
    private function issue(string $groupId, string $code, string $message): array
    {
        return ['code' => $code, 'groupId' => $groupId, 'message' => $message];
    }

    private function count(mixed $value, int $min, int $max = 1000000): ?int
    {
        return is_int($value) && $value >= $min && $value <= $max ? $value : null;
    }

    private function identifier(mixed $value): bool
    {
        return is_string($value) && preg_match('/^[a-zA-Z0-9_-]{1,40}$/D', $value) === 1;
    }

    private function evidence(mixed $value): bool
    {
        return is_string($value) && mb_strlen(trim($value)) >= 10 && mb_strlen($value) <= 1000;
    }

    private function cents(mixed $value): ?int
    {
        return is_string($value) && preg_match('/^\d{1,15}\.\d{2}$/D', $value) === 1 ? (int) str_replace('.', '', $value) : null;
    }

    private function money(int $cents): string
    {
        return ($cents < 0 ? '-' : '') . intdiv(abs($cents), 100) . '.' . str_pad((string) (abs($cents) % 100), 2, '0', STR_PAD_LEFT);
    }

    private function percent(int $savings, int $source): string
    {
        return number_format($savings * 100 / $source, 2, '.', '');
    }
}
