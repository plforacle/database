<?php

declare(strict_types=1);

namespace App\Domain\Coverage;

use Brick\Math\BigDecimal;
use DateTimeImmutable;
use RuntimeException;

/** @phpstan-import-type Entry from CoverageCatalog */
final class WorkbookCoverageCatalog
{
    private const TIERS = ['OL-PUBLIC-YUM', 'OL-BASIC', 'OL-PREMIER', 'OL-PREMIER-PLUS'];
    public const SUPPORT_SOURCE = 'https://www.oracle.com/a/ocom/docs/linux/oracle-linux-ds.pdf';

    /** Exact, reviewed entitlement attributes; workbook mapping/action annotations are evidence only.
     * @var array<string, array{rank:int,features:list<string>,base?:bool,workstation?:bool,physicalOnly?:bool,requiresBase?:bool,nodePackSize?:int,embeddedLifecycle?:bool,bundle?:list<string>}>
     */
    private const CANDIDATES = [
        'RH00005' => ['rank' => 0, 'features' => [], 'base' => true, 'physicalOnly' => true],
        'RH00004' => ['rank' => 1, 'features' => ['CORE_OS_SUPPORT'], 'base' => true],
        'RH00003' => ['rank' => 1, 'features' => ['CORE_OS_SUPPORT'], 'base' => true],
        'RH00010' => ['rank' => 1, 'features' => ['OSMH'], 'base' => true, 'physicalOnly' => true, 'bundle' => ['RHEL', 'SATELLITE']],
        'RH00009' => ['rank' => 1, 'features' => ['CORE_OS_SUPPORT', 'OSMH'], 'base' => true, 'bundle' => ['RHEL', 'SATELLITE']],
        'RH00008' => ['rank' => 1, 'features' => ['CORE_OS_SUPPORT', 'OSMH'], 'base' => true, 'bundle' => ['RHEL', 'SATELLITE']],
        'RH00002' => ['rank' => 3, 'features' => ['CORE_OS_SUPPORT', 'UNLIMITED_VM_HOST'], 'base' => true],
        'RH00001' => ['rank' => 3, 'features' => ['CORE_OS_SUPPORT', 'UNLIMITED_VM_HOST'], 'base' => true, 'embeddedLifecycle' => true],
        'RH00007' => ['rank' => 3, 'features' => ['CORE_OS_SUPPORT', 'UNLIMITED_VM_HOST', 'OSMH'], 'base' => true, 'bundle' => ['RHEL', 'SATELLITE']],
        'RH00006' => ['rank' => 3, 'features' => ['CORE_OS_SUPPORT', 'UNLIMITED_VM_HOST', 'OSMH'], 'base' => true, 'bundle' => ['RHEL', 'SATELLITE'], 'embeddedLifecycle' => true],
        'RH0986300' => ['rank' => 0, 'features' => [], 'base' => true, 'workstation' => true],
        'RH0958488' => ['rank' => 1, 'features' => ['CORE_OS_SUPPORT'], 'base' => true, 'workstation' => true],
        'RH00025' => ['rank' => 2, 'features' => ['HA_COROSYNC_PACEMAKER'], 'requiresBase' => true],
        'RH00059' => ['rank' => 3, 'features' => ['HA_COROSYNC_PACEMAKER', 'UNLIMITED_VM_HOST'], 'requiresBase' => true],
        'RH00031' => ['rank' => 1, 'features' => ['OSMH'], 'requiresBase' => true],
        'RH00032' => ['rank' => 3, 'features' => ['OSMH', 'UNLIMITED_VM_HOST'], 'requiresBase' => true],
        'MCT3691' => ['rank' => 2, 'features' => ['OLAM'], 'nodePackSize' => 100],
        'MCT3692' => ['rank' => 2, 'features' => ['OLAM'], 'nodePackSize' => 5000],
        'MCT3693' => ['rank' => 2, 'features' => ['OLAM'], 'nodePackSize' => 10000],
        'MCT3694' => ['rank' => 2, 'features' => ['OLAM'], 'nodePackSize' => 100],
        'MCT3695' => ['rank' => 2, 'features' => ['OLAM'], 'nodePackSize' => 5000],
        'MCT3696' => ['rank' => 2, 'features' => ['OLAM'], 'nodePackSize' => 10000],
    ];

    /** @return array<string, Entry> */
    public static function entries(): array
    {
        $path = dirname(__DIR__, 3) . '/resources/catalog/reference-workbook-v3.json';
        $json = file_get_contents($path);
        if ($json === false) {
            throw new RuntimeException('The reference workbook catalog is unavailable.');
        }
        /** @var array{filename:string,sha256:string,sheet:string,rows:list<array<string,string|int>>} $source */
        $source = json_decode($json, true, 32, JSON_THROW_ON_ERROR);
        $entries = [];
        foreach ($source['rows'] as $row) {
            $sku = strtoupper(trim((string) $row['sku']));
            if ($sku === '' || isset($entries[$sku])) {
                throw new RuntimeException('Workbook SKU identifiers must be present and unique.');
            }
            $attributes = self::CANDIDATES[$sku] ?? null;
            $family = (string) $row['family'];
            $excluded = $attributes === null;
            $exclusionCode = $excluded ? self::exclusionCode($sku, $family) : '';
            $features = $attributes['features'] ?? [];
            $eligible = $attributes === null ? [] : array_slice(self::TIERS, $attributes['rank']);
            $base = $attributes['base'] ?? false;
            $treatment = $excluded ? 'EXCLUDED' : ($base ? 'BASE' : 'ADD_TO_RHEL');
            $unlimited = in_array('UNLIMITED_VM_HOST', $features, true);
            $price = (string) $row['price'];
            $price = preg_match('/^\d+(?:\.\d{1,2})?$/D', $price) === 1 ? (string) BigDecimal::of($price)->toScale(2) : null;
            $annual = in_array($row['term'], ['1 Year', '1 Year extension'], true);
            $priceReady = !$excluded && $price !== null && self::currentPriceEligible($sku, $row);
            $reason = self::exclusionReason($exclusionCode);
            $capability = $excluded ? $reason : self::capabilityDescription($features);
            $entries[$sku] = [
                'description' => (string) $row['description'], 'unit' => (string) $row['metric'],
                'referencePrice' => $price, 'scenarioPrice' => $priceReady ? $price : null,
                'priceBasis' => $priceReady ? 'CURRENT_PUBLIC_STORE' : ($price !== null && $row['status'] !== 'CURRENT' ? 'HISTORICAL_PUBLIC_MSRP' : 'WORKBOOK_REFERENCE'),
                'readiness' => $excluded ? 'EXCLUDED' : ($priceReady ? 'READY' : 'PRICE_REVIEW_REQUIRED'),
                'provenance' => $source['filename'] . ' / ' . $source['sheet'] . '!A' . $row['row'] . ':Q' . $row['row'] . '; original annotations P' . $row['row'] . ':Q' . $row['row'] . ' Oracle Linux=' . $row['oracleLinux'] . ', Action Note=' . $row['actionNote'] . '; source status: ' . $row['status'] . '; ' . $row['sourceUrl'] . '; workbook SHA-256 ' . $source['sha256'],
                'effectiveOn' => (string) $row['effectivePeriod'], 'verifiedOn' => (string) $row['verifiedOn'],
                'currency' => (string) $row['currency'], 'term' => $annual ? 'ANNUAL' : 'UNKNOWN',
                'exclusionReason' => $reason, 'eligible' => $eligible,
                'olam' => in_array('OLAM', $features, true),
                'capabilityRule' => 'Value Navigator ' . CoverageCatalog::MAPPING_VERSION . ': ' . $capability . '; support matrix: ' . self::SUPPORT_SOURCE . '#page=4',
                'approval' => null, 'vendor' => 'Red Hat', 'treatment' => $treatment,
                'mappingStatus' => $excluded ? 'EXCLUDED' : 'MAPPED',
                'unlimitedGuests' => $unlimited,
                'features' => $features, 'baseEntitlement' => $base,
                'workstation' => $attributes['workstation'] ?? false,
                'selfSupportPhysicalOnly' => $attributes['physicalOnly'] ?? false,
                'requiresBase' => $attributes['requiresBase'] ?? false,
                'nodePackSize' => $attributes['nodePackSize'] ?? null,
                'embeddedLifecycle' => $attributes['embeddedLifecycle'] ?? false,
                'bundleComponents' => $attributes['bundle'] ?? [],
                'minimumOffering' => $eligible[0] ?? '', 'exclusionCode' => $exclusionCode,
                'catalogStatus' => isset($attributes['nodePackSize']) ? 'CATALOG_ONLY_AUTOMATION' : ($excluded ? 'WORKBOOK_REFERENCE' : 'STORE_LISTED'),
                'sourceUrl' => (string) $row['sourceUrl'], 'supportLevel' => (string) $row['supportLevel'],
            ];
        }
        return $entries;
    }

    /** @param array<string,string|int> $row */
    private static function currentPriceEligible(string $sku, array $row): bool
    {
        if (!isset(self::CANDIDATES[$sku]) || $row['term'] !== '1 Year' || trim((string) $row['metric']) === ''
            || $row['currency'] !== 'USD' || $row['status'] !== 'CURRENT'
            || !in_array($row['sourceType'], ['Official Red Hat Store', 'Official Red Hat Store - bundle price'], true)) {
            return false;
        }
        $reviewedOn = DateTimeImmutable::createFromFormat('!Y-m-d\TH:i:s', (string) $row['verifiedOn']);
        if ($reviewedOn === false || $reviewedOn->format('Y-m-d\TH:i:s') !== $row['verifiedOn']) {
            return false;
        }
        $urls = explode(';', (string) $row['sourceUrl']);
        foreach ($urls as $url) {
            $url = trim($url);
            if (filter_var($url, FILTER_VALIDATE_URL) === false || parse_url($url, PHP_URL_SCHEME) !== 'https'
                || parse_url($url, PHP_URL_HOST) !== 'www.redhat.com') {
                return false;
            }
        }
        return true;
    }

    private static function exclusionCode(string $sku, string $family): string
    {
        if (in_array($sku, ['RH00026', 'RH00060'], true)) {
            return 'RESILIENT_STORAGE';
        }
        return match ($family) {
            'RHEL Lifecycle', 'Satellite Lifecycle', 'OpenShift Lifecycle', 'JBoss EAP Lifecycle', 'JBoss Web Server Lifecycle' => 'LIFECYCLE_SUPPORT',
            'RHEL for SAP' => 'SAP',
            'RHEL IBM Power' => 'POWER',
            'OpenShift Container Platform', 'OpenShift Kubernetes Engine', 'OpenShift Platform Plus', 'OpenShift + Runtimes', 'OpenShift Platform Plus + Runtimes', 'OpenShift + Application Foundations', 'OpenShift Platform Plus + Application Foundations', 'OpenShift Data Foundation' => 'OPENSHIFT',
            'JBoss EAP', 'JBoss Web Server', 'JBoss EAP for OpenShift' => 'JBOSS',
            'Red Hat Runtimes' => 'RUNTIMES',
            default => 'NO_APPROVED_MAPPING',
        };
    }

    private static function exclusionReason(string $code): string
    {
        return match ($code) {
            '' => '',
            'RESILIENT_STORAGE' => 'Resilient Storage is excluded as a whole SKU, including bundled HA; no supported storage equivalence or price allocation is included.',
            'LIFECYCLE_SUPPORT' => 'Extended/enhanced lifecycle support is deferred to the next version; excluded from current comparison.',
            'SAP' => 'SAP-specific subscriptions have no approved mapping in this release; excluded from both comparison sides.',
            'POWER' => 'IBM Power subscriptions are excluded from both comparison sides.',
            'OPENSHIFT' => 'OpenShift subscriptions and bundles are excluded from both comparison sides.',
            'JBOSS' => 'JBoss subscriptions are excluded from both comparison sides.',
            'RUNTIMES' => 'Red Hat Runtimes subscriptions are excluded from both comparison sides.',
            default => 'No approved Oracle mapping in this release; excluded from both comparison sides.',
        };
    }

    /** @param list<string> $features */
    private static function capabilityDescription(array $features): string
    {
        if ($features === []) {
            return 'Oracle Linux Public Yum self-support; no paid support entitlement';
        }
        return implode('; ', array_map(static fn (string $feature): string => match ($feature) {
            'CORE_OS_SUPPORT' => 'Supported core Oracle Linux OS',
            'OSMH' => 'Oracle OS Management Hub management-function mapping; provisioning, content and integration parity require review',
            'HA_COROSYNC_PACEMAKER' => 'HA with Corosync and Pacemaker',
            'OLAM' => 'Oracle Linux Automation Manager function mapping; automation content and endpoint OS support are not inferred',
            'UNLIMITED_VM_HOST' => 'Unlimited VM host scope requires Premier Plus and reviewed target topology',
            default => $feature,
        }, $features));
    }
}
