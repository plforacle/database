<?php

declare(strict_types=1);

namespace App\Domain\Analysis;

use App\Domain\Shared\DomainViolation;
use Brick\Math\BigDecimal;
use Brick\Money\Context\CustomContext;
use Brick\Money\Money;

final readonly class ConfirmedLine
{
    private const MAX_INTEGER_DIGITS = 15;

    private const MAX_SCALE = 4;

    private function __construct(
        public string $sku,
        public BigDecimal $quantity,
        public Money $annualUnitPrice,
    ) {
    }

    public static function annualUsd(
        string $sku,
        string $quantity,
        string $price,
        string $currency = 'USD',
        string $term = 'ANNUAL',
        bool $unitBasisPresent = true,
    ): self {
        if (trim($sku) === '') {
            throw DomainViolation::because('A confirmed line requires a SKU.');
        }

        if ($currency !== 'USD') {
            throw DomainViolation::because('Confirmed line prices must use USD.');
        }

        if ($term !== 'ANNUAL') {
            throw DomainViolation::because('Confirmed line prices must use an annual term.');
        }

        if (!$unitBasisPresent) {
            throw DomainViolation::because('A confirmed unit basis is required.');
        }

        $quantityValue = self::decimal($quantity, 'quantity');
        if (!$quantityValue->isPositive()) {
            throw DomainViolation::because('Confirmed line quantity must be positive.');
        }

        $priceValue = self::decimal($price, 'price');
        if ($priceValue->isNegative()) {
            throw DomainViolation::because('Confirmed line price cannot be negative.');
        }

        return new self(
            trim($sku),
            $quantityValue,
            Money::of($priceValue, 'USD', new CustomContext(self::MAX_SCALE)),
        );
    }

    private static function decimal(string $value, string $field): BigDecimal
    {
        if (preg_match('/^-?\d+(?:\.\d{1,4})?$/D', $value) !== 1) {
            throw DomainViolation::because(sprintf('Confirmed line %s must be a decimal with at most four places.', $field));
        }

        $unsigned = ltrim($value, '-');
        $integer = explode('.', $unsigned, 2)[0];
        $significantInteger = ltrim($integer, '0');

        if (strlen($significantInteger) > self::MAX_INTEGER_DIGITS) {
            throw DomainViolation::because(sprintf('Confirmed line %s exceeds DECIMAL(19,4).', $field));
        }

        return BigDecimal::of($value);
    }
}
