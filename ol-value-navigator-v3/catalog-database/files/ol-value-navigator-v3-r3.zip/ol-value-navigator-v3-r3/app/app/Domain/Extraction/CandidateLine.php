<?php

declare(strict_types=1);

namespace App\Domain\Extraction;

final readonly class CandidateLine
{
    public function __construct(
        private string $lineId,
        private int $sourceStart,
        private int $sourceEnd,
        private string $sourceExcerpt,
        private ?string $sku,
        private ?string $quantity,
    ) {
    }

    public function lineId(): string
    {
        return $this->lineId;
    }
    public function sourceStart(): int
    {
        return $this->sourceStart;
    }
    public function sourceEnd(): int
    {
        return $this->sourceEnd;
    }
    public function sourceExcerpt(): string
    {
        return $this->sourceExcerpt;
    }
    public function sku(): ?string
    {
        return $this->sku;
    }
    public function quantity(): ?string
    {
        return $this->quantity;
    }
}
