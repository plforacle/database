<?php

declare(strict_types=1);

namespace App\Domain\Coverage;

/** Identity and source-entitlement facts are checked independently of prices and target sizing. */
final class ScenarioFacts
{
    public static function accepted(mixed $assertion, string $mode): bool
    {
        return is_array($assertion) && self::evidence($assertion['evidence'] ?? null)
            && (($assertion['state'] ?? '') === 'CONFIRMED' || ($mode === 'ILLUSTRATIVE' && ($assertion['state'] ?? '') === 'ASSUMED'));
    }

    public static function evidence(mixed $value): bool
    {
        return is_string($value) && mb_strlen(trim($value)) >= 10;
    }

    /** @param array<string,mixed> $line
     * @param array<string,mixed>|null $entry
     * @return list<array{code:string,message:string}>
     */
    public function identity(array $line, ?array $entry): array
    {
        $sku = self::text($line['sku'] ?? '');
        if ($entry === null || $sku === '') {
            return [self::issue('MISSING_FROM_CATALOG', ($sku === '' ? 'Blank SKU product' : $sku) . ': verify the exact identity before mapping.')];
        }
        $rawSku = strtoupper(trim(self::text($line['rawSku'] ?? $sku)));
        $description = self::text($line['adoptedDescription'] ?? '') ?: self::text($line['description'] ?? '');
        $state = $line['identityState'] ?? 'CATALOG';
        if (in_array($state, ['CONFLICT', 'UNRESOLVED'], true)) {
            return [self::issue('SKU_IDENTITY_CONFLICT', $sku . ': identity remains unresolved.')];
        }
        if ($rawSku !== '' && $rawSku !== $sku && !$this->corrected($line, 'sku', $rawSku, $sku)) {
            return [self::issue('SKU_IDENTITY_CONFLICT', $sku . ': record the original-to-corrected SKU with actor, date, reason and evidence.')];
        }
        $rawDescription = self::text($line['description'] ?? '');
        if (self::text($line['adoptedDescription'] ?? '') !== '' && $rawDescription !== $description
            && !$this->corrected($line, 'description', $rawDescription, $description)) {
            return [self::issue('SKU_IDENTITY_CONFLICT', $sku . ': a changed description requires an explicit correction record.')];
        }
        $conflict = false;
        $features = self::strings($entry['features'] ?? []);
        $name = strtolower(self::text($entry['description'] ?? ''));
        $text = strtolower($description);
        if ($text !== '' && trim($text) === trim($name)) {
            return [];
        }
        if ($text !== '') {
            $lifecycle = preg_match('/\b(eus|els|extended (?:life|update|support)|enhanced (?:eus|support|extended))\b/i', $text) === 1;
            $conflict = ($lifecycle && ($entry['exclusionCode'] ?? '') !== 'LIFECYCLE_SUPPORT' && !($entry['embeddedLifecycle'] ?? false))
                || (preg_match('/\bsap\b/i', $text) === 1 && ($entry['exclusionCode'] ?? '') !== 'SAP')
                || (str_contains($text, '3scale') && in_array('OLAM', $features, true))
                || (str_contains($text, 'ansible') && !in_array('OLAM', $features, true))
                || (str_contains($text, 'workstation') && !($entry['workstation'] ?? false))
                || (str_contains($text, 'unlimited') && !str_contains($name, 'unlimited') && !($entry['unlimitedGuests'] ?? false) && ($entry['vendor'] ?? '') === 'Red Hat')
                || (str_contains($text, 'satellite') && !in_array('OSMH', $features, true) && ($entry['exclusionCode'] ?? '') !== 'LIFECYCLE_SUPPORT')
                || (str_contains($text, 'resilient storage') && ($entry['exclusionCode'] ?? '') !== 'RESILIENT_STORAGE');
            foreach (['openshift' => 'OPENSHIFT', 'jboss' => 'JBOSS', 'ibm power' => 'POWER', 'red hat runtimes' => 'RUNTIMES', 'quay' => 'NO_APPROVED_MAPPING'] as $family => $code) {
                if (str_contains($text, $family) && !str_contains($name, $family) && ($entry['exclusionCode'] ?? '') !== $code) {
                    $conflict = true;
                }
            }
            if ($sku === 'VCF-CLD-FND-5' && preg_match('/vsphere\s+foundation/i', $text) === 1) {
                $conflict = true;
            }
            if ($sku === 'VCF-VSP-FND-8' && preg_match('/(?:cloud\s+foundation|\bvcf\s*5)/i', $text) === 1) {
                $conflict = true;
            }
            foreach (['premium', 'standard', 'self-support'] as $support) {
                if (str_contains($text, $support) && !str_contains($name, $support)
                    && !str_contains(strtolower(self::text($entry['supportLevel'] ?? '')), $support)) {
                    $conflict = true;
                }
            }
        }
        return $conflict ? [self::issue('SKU_IDENTITY_CONFLICT', $sku . ': material source description conflicts with the maintained identity; correct the source observation explicitly.')] : [];
    }

    /** @param array<string,mixed> $line
     * @param array<string,mixed> $entry
     * @return list<array{code:string,message:string}>
     */
    public function source(array $line, array $entry, string $mode): array
    {
        $issues = [];
        $sku = self::text($line['sku']);
        if (!self::accepted($line['quantityState'] ?? null, $mode)
            || !in_array($line['quantityBasis'] ?? '', $mode === 'ILLUSTRATIVE' ? ['PURCHASED', 'ASSUMED'] : ['PURCHASED'], true)) {
            $issues[] = self::issue('SOURCE_QUANTITY_REVIEW', $sku . ': establish purchased units or an explicit illustrative quantity assumption. Manifest/host rows do not prove purchases.');
        }
        if (($entry['vendor'] ?? '') !== 'Red Hat') {
            return $issues;
        }
        $estate = self::record($line['sourceEstate'] ?? []);
        $quantity = $line['quantity'] ?? null;
        if (!is_int($quantity) || $quantity < 1) {
            return [...$issues, self::issue('SOURCE_QUANTITY_REVIEW', $sku . ': select positive whole subscription units.')];
        }
        $assumed = $mode === 'ILLUSTRATIVE' && self::accepted($line['quantityState'] ?? null, $mode)
            && (self::record($line['quantityState'] ?? [])['state'] ?? '') === 'ASSUMED';
        $pack = $entry['nodePackSize'] ?? null;
        if (is_int($pack) && $pack > 0) {
            $nodes = $estate['managedNodes'] ?? null;
            if ((!is_int($nodes) && !$assumed) || (is_int($nodes) && $nodes > $quantity * $pack)) {
                $issues[] = self::issue('SOURCE_QUANTITY_REVIEW', $sku . ': review this purchase\'s RH managed-node entitlement independently of unique Oracle managed demand.');
            }
            return $issues;
        }
        $deployment = $estate['deployment'] ?? 'UNKNOWN';
        $systems = $estate['systems'] ?? null;
        $cpus = $estate['cpusPerSystem'] ?? null;
        $guests = $estate['guests'] ?? null;
        $known = is_int($systems) && is_int($guests) && ($deployment !== 'PHYSICAL' || is_int($cpus));
        if (!$known || !in_array($deployment, ['PHYSICAL', 'VIRTUAL_GUEST'], true)) {
            if (!$assumed) {
                $issues[] = self::issue('SOURCE_QUANTITY_REVIEW', $sku . ': verify source systems, sockets and guests independently of the Oracle target.');
            }
            return $issues;
        }
        if (($deployment === 'PHYSICAL' && ($systems < 1 || $cpus < 1))
            || ($deployment === 'VIRTUAL_GUEST' && ($systems !== 0 || $guests < 1))
            || (($entry['unlimitedGuests'] ?? false) && $deployment !== 'PHYSICAL')) {
            $issues[] = self::issue('SOURCE_QUANTITY_REVIEW', $sku . ': source deployment and physical/guest counts contradict the entitlement.');
        }
        if (($entry['selfSupportPhysicalOnly'] ?? false) && ($deployment !== 'PHYSICAL' || $guests > 0 || $cpus > 2)) {
            $issues[] = self::issue('SOURCE_QUANTITY_REVIEW', $sku . ': self-support Server is physical and nonstackable, with at most two sockets and no guest entitlement.');
        }
        if ($entry['workstation'] ?? false) {
            if ($deployment !== 'PHYSICAL' || $quantity < $systems || $guests > $quantity) {
                $issues[] = self::issue('SOURCE_QUANTITY_REVIEW', $sku . ': one workstation purchase covers one physical workstation and one guest.');
            }
        } else {
            $required = ($deployment === 'PHYSICAL' && is_int($cpus) ? $systems * intdiv($cpus + 1, 2) : 0)
                + (($entry['unlimitedGuests'] ?? false) ? 0 : intdiv($guests + 1, 2));
            if ($quantity < $required) {
                $issues[] = self::issue('SOURCE_QUANTITY_REVIEW', $sku . ': selected units are below the confirmed source socket/guest requirement of ' . $required . '.');
            }
        }
        return $issues;
    }

    /** @param array<string,mixed> $line */
    private function corrected(array $line, string $field, string $old, string $new): bool
    {
        foreach (self::records($line['corrections'] ?? []) as $correction) {
            if (($correction['field'] ?? '') === $field && ($correction['oldValue'] ?? '') === $old && ($correction['newValue'] ?? '') === $new
                && self::evidence($correction['reason'] ?? null) && self::evidence($correction['evidence'] ?? null)
                && self::text($correction['actor'] ?? '') !== '' && self::text($correction['at'] ?? '') !== '') {
                return true;
            }
        }
        return false;
    }

    /** @return array{code:string,message:string} */
    public static function issue(string $code, string $message): array
    {
        return ['code' => $code, 'message' => $message];
    }

    public static function text(mixed $value): string
    {
        return is_string($value) ? $value : '';
    }

    /** @return array<string,mixed> */
    public static function record(mixed $value): array
    {
        if (!is_array($value)) {
            return [];
        }
        return array_filter($value, is_string(...), ARRAY_FILTER_USE_KEY);
    }

    /** @return list<array<string,mixed>> */
    public static function records(mixed $value): array
    {
        return is_array($value) ? array_values(array_map(self::record(...), array_filter($value, is_array(...)))) : [];
    }

    /** @return list<string> */
    public static function strings(mixed $value): array
    {
        return is_array($value) ? array_values(array_filter($value, is_string(...))) : [];
    }
}
