<?php

declare(strict_types=1);

namespace App\Domain\Analysis;

use App\Domain\Shared\DomainViolation;

final class StateTransition
{
    public static function assertAllowed(AnalysisState $from, AnalysisState $to): void
    {
        $allowed = match ($from) {
            AnalysisState::DRAFT => $to === AnalysisState::NEEDS_REVIEW,
            AnalysisState::NEEDS_REVIEW => in_array(
                $to,
                [AnalysisState::INCOMPLETE, AnalysisState::READY_TO_CALCULATE],
                true,
            ),
            AnalysisState::INCOMPLETE => $to === AnalysisState::READY_TO_CALCULATE,
            AnalysisState::READY_TO_CALCULATE => $to === AnalysisState::CONFIRMED,
            AnalysisState::CONFIRMED => $to === AnalysisState::SUPERSEDED,
            AnalysisState::SUPERSEDED => false,
        };

        if (!$allowed) {
            throw DomainViolation::because(sprintf(
                'Analysis transition from %s to %s is not allowed.',
                $from->name,
                $to->name,
            ));
        }
    }
}
