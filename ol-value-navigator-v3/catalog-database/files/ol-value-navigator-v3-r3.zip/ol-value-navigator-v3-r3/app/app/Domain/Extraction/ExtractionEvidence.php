<?php

declare(strict_types=1);

namespace App\Domain\Extraction;

use App\Domain\Shared\DomainViolation;

final readonly class ExtractionEvidence
{
    private function __construct(
        private ExtractionMode $mode,
        private ?string $modelIdentifier,
        private ?string $contractVersion,
        private ?string $promptTemplateVersion,
        private ?string $responseDigest,
    ) {
    }

    public static function ai(
        string $modelIdentifier,
        string $contractVersion,
        string $promptTemplateVersion,
        string $responseDigest,
    ): self {
        if (trim($modelIdentifier) === '' || strlen($modelIdentifier) > 255) {
            throw DomainViolation::because('AI extraction evidence must use a bounded nonblank model identifier.');
        }
        foreach ([$contractVersion, $promptTemplateVersion] as $value) {
            if (trim($value) === '' || strlen($value) > 64) {
                throw DomainViolation::because('AI extraction evidence must use bounded nonblank version identifiers.');
            }
        }
        if (preg_match('/^[0-9a-f]{64}$/', $responseDigest) !== 1) {
            throw DomainViolation::because('AI extraction response digest must be 64 lowercase hexadecimal characters.');
        }

        return new self(ExtractionMode::AI, $modelIdentifier, $contractVersion, $promptTemplateVersion, $responseDigest);
    }

    public static function manual(): self
    {
        return new self(ExtractionMode::MANUAL, null, null, null, null);
    }

    public function mode(): ExtractionMode
    {
        return $this->mode;
    }

    public function modelIdentifier(): ?string
    {
        return $this->modelIdentifier;
    }

    public function contractVersion(): ?string
    {
        return $this->contractVersion;
    }

    public function promptTemplateVersion(): ?string
    {
        return $this->promptTemplateVersion;
    }

    public function responseDigest(): ?string
    {
        return $this->responseDigest;
    }
}
