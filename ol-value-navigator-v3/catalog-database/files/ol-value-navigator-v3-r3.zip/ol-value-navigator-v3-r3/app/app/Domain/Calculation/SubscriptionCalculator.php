<?php

declare(strict_types=1);

namespace App\Domain\Calculation;

use App\Domain\Analysis\ConfirmedLine;
use App\Domain\Shared\DomainViolation;
use Brick\Math\Exception\RoundingNecessaryException;
use Brick\Math\RoundingMode;
use Brick\Money\Context\DefaultContext;
use Brick\Money\Money;

final class SubscriptionCalculator
{
    /**
     * @param list<ConfirmedLine> $lines
     */
    public function calculate(array $lines): ComparisonTotals
    {
        if ($lines === []) {
            throw DomainViolation::because('At least one confirmed included line is required.');
        }

        $annual = Money::of('0.00', 'USD');

        foreach ($lines as $line) {
            try {
                $lineTotal = $line->annualUnitPrice
                    ->multipliedBy($line->quantity)
                    ->to(new DefaultContext(), RoundingMode::Unnecessary);
            } catch (RoundingNecessaryException) {
                throw DomainViolation::because('A confirmed line total must resolve exactly to USD cents.');
            }

            $annual = $annual->plus($lineTotal);
        }

        return ComparisonTotals::fromAnnual($annual);
    }
}
