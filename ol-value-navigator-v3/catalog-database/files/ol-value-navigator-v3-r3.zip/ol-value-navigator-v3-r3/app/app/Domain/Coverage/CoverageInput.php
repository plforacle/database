<?php

declare(strict_types=1);

namespace App\Domain\Coverage;

use App\Domain\Shared\DomainViolation;

final class CoverageInput
{
    /** @param array<string,mixed> $input
     * @return array<string,mixed>
     */
    public static function normalize(array $input): array
    {
        if (($input['schemaVersion'] ?? null) === ScenarioInput::VERSION) {
            return ScenarioInput::normalize($input);
        }
        $example = CoverageScenario::example();
        self::keys($input, array_keys($example));
        $customer = self::record($input['customer']);
        self::keys($customer, array_keys($example['customer']));
        foreach ($customer as $key => $value) {
            $customer[$key] = self::text($value, $key === 'name' ? 80 : 300);
        }
        $groups = self::rows($input['groups'], 5);
        foreach ($groups as &$group) {
            // New revisions of legacy inputs must explicitly resolve the new scope checks.
            $group += self::reviewDefaults();
            self::keys($group, array_keys($example['groups'][0]));
            foreach (['systems', 'cpusPerSystem', 'demand', 'allocatedUnits', 'additionalUnits', 'sourceSystems', 'sourceCpusPerSystem', 'sourceGuests', 'sourceManagedNodes'] as $key) {
                $group[$key] = self::count($group[$key], $key === 'allocatedUnits' ? 512000000 : 1000000);
            }
            $group['additionalUnits'] ??= 0;
            foreach (['olamRequired', 'sourceEntitlementsConfirmed', 'workstationScopeAcknowledged'] as $key) {
                if (!is_bool($group[$key])) {
                    throw DomainViolation::because('Review confirmations must be explicit yes or no values.');
                }
            }
            foreach (['id', 'label', 'populationKey', 'offering', 'additionalOffering', 'populationEvidence', 'allocationEvidence', 'deployment', 'sourceDeployment', 'sourceQuantityEvidence', 'prerequisiteEvidence', 'workstationGuestScope', 'duplicateEntitlementEvidence'] as $key) {
                $group[$key] = self::text($group[$key], str_ends_with($key, 'Evidence') ? 1000 : 80, true);
            }
            foreach (['deployment', 'sourceDeployment'] as $key) {
                if (!in_array($group[$key], ['', 'PHYSICAL', 'VIRTUAL_GUEST', 'CLOUD'], true)) {
                    throw DomainViolation::because('Select a recognized target and source deployment.');
                }
            }
            if (!in_array($group['workstationGuestScope'], ['', 'EXCLUDED', 'REQUIRED'], true)) {
                throw DomainViolation::because('Review the workstation guest scope.');
            }
        }
        unset($group);
        $lines = self::rows($input['lines'], 10);
        foreach ($lines as &$line) {
            self::keys($line, array_keys($example['lines'][0]));
            $line['quantity'] = self::count($line['quantity']);
            $line['originalQuantity'] = self::count($line['originalQuantity']);
            foreach (['sourceId', 'sku', 'groupId', 'exclusionReason'] as $key) {
                $line[$key] = self::text($line[$key], $key === 'exclusionReason' ? 500 : 80, true);
            }
            $line['sku'] = strtoupper($line['sku']);
        }
        unset($line);
        return ['customer' => $customer, 'populationEvidence' => self::text($input['populationEvidence'], 1000, true), 'groups' => $groups, 'lines' => $lines];
    }

    /** @return array<string,mixed> */
    private static function reviewDefaults(): array
    {
        return ['deployment' => '', 'sourceEntitlementsConfirmed' => false,
            'sourceDeployment' => '', 'sourceSystems' => null, 'sourceCpusPerSystem' => 2,
            'sourceGuests' => null, 'sourceManagedNodes' => null,
            'sourceQuantityEvidence' => '', 'prerequisiteEvidence' => '',
            'workstationScopeAcknowledged' => false, 'workstationGuestScope' => '',
            'duplicateEntitlementEvidence' => ''];
    }

    /** @param array<string,mixed> $record
     * @param list<string> $expected
     */
    private static function keys(array $record, array $expected): void
    {
        if (count($record) !== count($expected) || array_diff(array_keys($record), $expected) !== []) {
            throw DomainViolation::because('The comparison contains unsupported or missing fields. Prices and rules are server-owned.');
        }
    }

    /** @return array<string,mixed> */
    private static function record(mixed $value): array
    {
        if (!is_array($value) || array_is_list($value)) {
            throw DomainViolation::because('A structured comparison record is required.');
        }
        foreach (array_keys($value) as $key) {
            if (!is_string($key)) {
                throw DomainViolation::because('Comparison field names must be text.');
            }
        }
        return $value;
    }

    /** @return list<array<string,mixed>> */
    private static function rows(mixed $value, int $maximum): array
    {
        if (!is_array($value) || !array_is_list($value) || count($value) < 1 || count($value) > $maximum) {
            throw DomainViolation::because('The number of comparison rows is outside the supported limit.');
        }
        return array_map(self::record(...), $value);
    }

    private static function text(mixed $value, int $maximum, bool $allowEmpty = false): string
    {
        if (!is_string($value) || !mb_check_encoding($value, 'UTF-8') || preg_match('/[\x00-\x08\x0B\x0C\x0E-\x1F\x{FFFE}\x{FFFF}]/u', $value) === 1 || mb_strlen($value) > $maximum || (!$allowEmpty && trim($value) === '')) {
            throw DomainViolation::because('Comparison text is missing, too long or invalid.');
        }
        return trim($value);
    }

    private static function count(mixed $value, int $maximum = 1000000): ?int
    {
        if ($value === null || $value === '') {
            return null;
        }
        if (is_string($value) && preg_match('/^\d{1,9}$/D', $value) === 1) {
            $value = (int) $value;
        }
        if (!is_int($value) || $value < 0 || $value > $maximum) {
            throw DomainViolation::because('Quantities must be whole nonnegative counts, or blank when unknown.');
        }
        return $value;
    }
}
