<?php

declare(strict_types=1);

namespace App\Domain\Shared;

final readonly class Actor
{
    private function __construct(
        private string $identifier,
        private bool $mayImportCatalog,
        private bool $mayOwnCatalog,
        private bool $mayConfirmAnalysis,
        private bool $mayAudit,
    ) {
        if (trim($identifier) === '') {
            throw DomainViolation::because('An actor identifier is required.');
        }
    }

    public static function catalogImporter(string $identifier): self
    {
        return new self($identifier, true, false, false, false);
    }

    public static function catalogOwner(string $identifier): self
    {
        return new self($identifier, false, true, false, false);
    }

    public static function representative(string $identifier): self
    {
        return new self($identifier, false, false, true, false);
    }

    public static function auditor(string $identifier): self
    {
        return new self($identifier, false, false, false, true);
    }

    public function identifier(): string
    {
        return $this->identifier;
    }

    public function canManageCatalog(): bool
    {
        return $this->mayImportCatalog || $this->mayOwnCatalog;
    }

    public function canImportCatalog(): bool
    {
        return $this->mayImportCatalog;
    }

    public function canOwnCatalog(): bool
    {
        return $this->mayOwnCatalog;
    }

    public function canConfirmAnalysis(): bool
    {
        return $this->mayConfirmAnalysis;
    }

    public function canAudit(): bool
    {
        return $this->mayAudit;
    }
}
