<?php

declare(strict_types=1);

namespace App\Domain\Matching;

use App\Domain\Shared\DomainViolation;

final readonly class EligibleOption
{
    public function __construct(
        private string $sku,
        private string $description,
        private string $unit,
        private string $annualUsdPrice,
        private string $rationale,
    ) {
        if (trim($sku) === ''
            || trim($description) === ''
            || trim($unit) === ''
            || trim($annualUsdPrice) === ''
            || trim($rationale) === ''
        ) {
            throw DomainViolation::because('An eligible option requires complete governed facts.');
        }
    }

    public function sku(): string
    {
        return $this->sku;
    }

    public function description(): string
    {
        return $this->description;
    }

    public function unit(): string
    {
        return $this->unit;
    }

    public function annualUsdPrice(): string
    {
        return $this->annualUsdPrice;
    }

    public function rationale(): string
    {
        return $this->rationale;
    }
}
