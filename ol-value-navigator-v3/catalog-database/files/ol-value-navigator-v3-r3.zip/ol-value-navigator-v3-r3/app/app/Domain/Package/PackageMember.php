<?php

declare(strict_types=1);

namespace App\Domain\Package;

use App\Domain\Shared\DomainViolation;

final readonly class PackageMember
{
    /** @param list<string> $profileIds */
    private function __construct(
        private string $id,
        private string $schemaVersion,
        private string $json,
        private array $profileIds,
    ) {
    }

    /** Structural validation only; compatibility is checked by the envelope. */
    public static function fromJson(string $json): self
    {
        $root = StrictJsonObjectDecoder::decode($json, 8 * 1024 * 1024);
        StrictJsonObjectDecoder::keys($root, ['schemaVersion', 'memberId', 'profiles']);
        $profiles = StrictJsonObjectDecoder::object($root->profiles);
        $ids = [];
        foreach (get_object_vars($profiles) as $id => $payload) {
            $ids[] = StrictJsonObjectDecoder::identifier((string) $id);
            StrictJsonObjectDecoder::object($payload);
        }
        if ($ids === []) {
            throw DomainViolation::because('Package member profiles must not be empty.');
        }

        return new self(
            StrictJsonObjectDecoder::identifier($root->memberId),
            StrictJsonObjectDecoder::identifier($root->schemaVersion),
            $json,
            $ids,
        );
    }

    public function id(): string
    {
        return $this->id;
    }

    public function schemaVersion(): string
    {
        return $this->schemaVersion;
    }

    public function digest(): string
    {
        return hash('sha256', $this->json);
    }

    public function json(): string
    {
        return $this->json;
    }

    /** @return list<string> */
    public function profileIds(): array
    {
        return $this->profileIds;
    }
}
