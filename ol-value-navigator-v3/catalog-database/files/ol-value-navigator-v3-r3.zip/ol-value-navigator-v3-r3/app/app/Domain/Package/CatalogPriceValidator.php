<?php

declare(strict_types=1);

namespace App\Domain\Package;

use Brick\Math\BigDecimal;
use DateTimeImmutable;
use DateTimeZone;
use App\Domain\Coverage\CoverageCatalog;
use App\Domain\Coverage\ScenarioPricing;

/** @internal Price claims are validated as data, never authenticated as commercial approval.
 * @phpstan-import-type Entry from CoverageCatalog
 * @phpstan-import-type Offering from CoverageCatalog
 * @phpstan-import-type Price from ScenarioPricing
 */
final class CatalogPriceValidator
{
    /** @param array<string,mixed> $mapping
     * @return Entry
     */
    public static function entry(mixed $value, array $mapping, string $scope): array
    {
        $r = CatalogRecordShape::record($value, ['priceReadiness', 'metric', 'periodBasis', 'catalogFields', 'evidence'], location: 'entry price');
        $f = CatalogRecordShape::record($r['catalogFields'], CatalogPackageContract::ENTRY_PRICE_FIELDS, location: 'entry price fields');
        $state = CatalogRecordShape::choice($r['priceReadiness'], ['READY', 'MISSING_CURRENT_PRICE', 'EXCEPTION_APPROVAL_REQUIRED', 'MISSING_CURRENT_PRICE_AND_TERM', 'PRICE_REVIEW_REQUIRED', 'NOT_ADOPTED'], 'price readiness');
        CatalogRecordShape::check(($scope === 'IN_SCOPE') === ($state !== 'NOT_ADOPTED'), 'price readiness', 'scope and price state conflict');
        CatalogRecordShape::check($r['metric'] === $mapping['unit'], 'entry metric', 'mapping and price units differ');
        CatalogRecordShape::choice($f['currency'], ['USD'], 'entry currency');
        $term = CatalogRecordShape::choice($f['term'], ['ANNUAL', 'UNKNOWN'], 'entry term');
        CatalogRecordShape::check($r['periodBasis'] === ($term === 'ANNUAL' ? 'ANNUAL_UNIT_RATE' : 'UNKNOWN'), 'entry period', 'period and term differ');
        CatalogRecordShape::amount($f['referencePrice'], 15, 2, true);
        $amount = CatalogRecordShape::amount($f['scenarioPrice'], 15, 2, true);
        CatalogRecordShape::choice($f['priceBasis'], ['SYNTHETIC', 'RESELLER', 'REFERENCE_ONLY', 'CURRENT_PUBLIC_STORE', 'WORKBOOK_REFERENCE', 'HISTORICAL_PUBLIC_MSRP'], 'entry price basis');
        if ($state === 'READY') {
            CatalogRecordShape::check($amount !== null && $term === 'ANNUAL' && in_array($f['priceBasis'], ['SYNTHETIC', 'CURRENT_PUBLIC_STORE'], true), 'ready price', 'usable annual current price required');
        }
        foreach (['effectiveOn', 'verifiedOn', 'approval'] as $key) {
            if ($key !== 'approval' || $f[$key] !== null) {
                CatalogRecordShape::text($f[$key], 'entry ' . $key);
            }
        }
        $evidence = CatalogRecordShape::evidence($r['evidence'], 'PRICE');
        if ($state === 'READY') {
            CatalogRecordShape::check(trim($evidence['text']) !== '', 'ready price', 'supporting evidence required');
            if ($f['priceBasis'] === 'CURRENT_PUBLIC_STORE') {
                CatalogRecordShape::check($f['verifiedOn'] !== '', 'ready public price', 'observation date required');
                self::date((string) $f['verifiedOn']);
            }
        }
        /** @var Entry $entry Mapping validation and all price field checks above establish this consumer contract. */
        $entry = [...$mapping, ...$f, 'readiness' => $scope === 'IN_SCOPE' ? $state : $scope, 'provenance' => $evidence['text']];
        return $entry;
    }

    /** @param array<string,mixed> $mapping
     * @return Offering
     */
    public static function offering(mixed $value, array $mapping): array
    {
        $r = CatalogRecordShape::record($value, ['metric', 'periodBasis', 'catalogFields', 'evidence'], location: 'offering price');
        $f = CatalogRecordShape::record($r['catalogFields'], CatalogPackageContract::OFFERING_PRICE_REQUIRED, CatalogPackageContract::OFFERING_PRICE_OPTIONAL, 'offering price fields');
        CatalogRecordShape::check($r['metric'] === $mapping['unit'], 'offering metric', 'mapping and price units differ');
        CatalogRecordShape::choice($r['periodBasis'], ['ANNUAL_UNIT_RATE'], 'offering period');
        $amount = CatalogRecordShape::amount($f['price'], 8, 2, false);
        CatalogRecordShape::choice($f['priceBasis'], ['SYNTHETIC', 'FREE_SELF_SUPPORT', 'PUBLIC_LIST_PRICE'], 'offering basis');
        foreach (CatalogPackageContract::OFFERING_PRICE_OPTIONAL as $key) {
            if (array_key_exists($key, $f)) {
                CatalogRecordShape::text($f[$key], 'offering ' . $key);
            }
        }
        if (array_key_exists('currency', $f)) {
            CatalogRecordShape::choice($f['currency'], ['USD'], 'offering currency');
        }
        if (array_key_exists('term', $f)) {
            CatalogRecordShape::choice($f['term'], ['ANNUAL'], 'offering term');
        }
        CatalogRecordShape::check($mapping['unit'] !== 'NONE' || BigDecimal::of((string) $amount)->isZero(), 'zero target unit', 'zero price required');
        $evidence = CatalogRecordShape::evidence($r['evidence'], 'PRICE');
        /** @var Offering $offering Mapping validation and all price field checks above establish this consumer contract. */
        $offering = [...$mapping, ...$f, 'provenance' => $evidence['text']];
        return $offering;
    }

    /** @param array<string,Entry> $entries
     * @return array{record:Price,applicableSkus:list<string>}
     */
    public static function reusable(mixed $value, string $id, array $entries): array
    {
        $r = CatalogRecordShape::record($value, ['applicableSkus', 'record'], location: 'reusable price');
        $skus = CatalogRecordShape::selection($r['applicableSkus'], array_map(strval(...), array_keys($entries)), 'price applicability', true);
        $f = CatalogRecordShape::record($r['record'], CatalogPackageContract::PRICE_FIELDS, location: 'reusable price fields');
        CatalogRecordShape::check(StrictJsonObjectDecoder::identifier($f['id']) === $id, 'price identity', 'key and record ID differ');
        $amount = CatalogRecordShape::amount($f['amount'], 18, 18, false, false);
        $original = CatalogRecordShape::amount($f['originalAmount'], 18, 18, true, false);
        CatalogRecordShape::choice($f['currency'], ['USD'], 'reusable currency');
        $metric = CatalogRecordShape::choice($f['metric'], CatalogPackageContract::SOURCE_UNITS, 'reusable metric');
        foreach ($skus as $sku) {
            $entry = $entries[$sku];
            $canonical = ($entry['nodePackSize'] ?? 0) > 0 ? 'NODE_PACK' : 'SUBSCRIPTION';
            CatalogRecordShape::check($metric === $entry['unit'] || (($entry['vendor'] ?? '') === 'Red Hat' && $metric === $canonical), 'reusable metric', 'metric incompatible with applicable entry');
        }
        $period = CatalogRecordShape::choice($f['periodBasis'], ['ANNUAL_UNIT_RATE', 'ANNUAL_INSTALLMENT', 'FULL_TERM_UNIT_PRICE', 'FULL_TERM_LINE_TOTAL'], 'reusable period');
        CatalogRecordShape::check(in_array($f['termMonths'], [12, 36], true), 'reusable term', '12 or 36 months required');
        CatalogRecordShape::check($period !== 'ANNUAL_UNIT_RATE' || $f['termMonths'] === 12, 'annual rate', '12-month rate required');
        CatalogRecordShape::choice($f['basis'], ['MANUFACTURER_LIST', 'RESELLER_ADVERTISED', 'HISTORICAL_PUBLIC', 'SCENARIO_SUPPLIED'], 'reusable basis');
        $verification = CatalogRecordShape::choice($f['verification'], ['USER_VERIFIED', 'INDEPENDENTLY_VERIFIED_PUBLIC'], 'verification');
        CatalogRecordShape::text($f['evidence'], 'reusable evidence', CatalogPackageContract::EVIDENCE_BYTES, true);
        foreach (['reason', 'approvedBy', 'approvedAt', 'effectiveOn', 'observedOn'] as $key) {
            CatalogRecordShape::text($f[$key], 'reusable ' . $key);
        }
        foreach (['approvedAt', 'effectiveOn', 'observedOn'] as $key) {
            self::date((string) $f[$key]);
        }
        if ($verification === 'USER_VERIFIED') {
            CatalogRecordShape::check(trim((string) $f['approvedBy']) !== '' && $f['approvedAt'] !== '', 'user verification', 'actor and approval date required');
        } else {
            CatalogRecordShape::check($f['observedOn'] !== '', 'public verification', 'observation date required');
        }
        if ($original !== null && BigDecimal::of($original)->compareTo((string) $amount) !== 0) {
            CatalogRecordShape::check(trim((string) $f['reason']) !== '' && trim((string) $f['approvedBy']) !== '' && $f['approvedAt'] !== '', 'adopted amount', 'change reason and approval required');
        }
        $schedule = $f['installments'];
        CatalogRecordShape::check(is_array($schedule) && array_is_list($schedule), 'installments', 'list required');
        /** @var list<mixed> $schedule */
        CatalogRecordShape::check($schedule === [] || ($period === 'ANNUAL_INSTALLMENT' && count($schedule) === $f['termMonths'] / 12), 'installments', 'one installment per commitment year required');
        foreach ($schedule as $installment) {
            CatalogRecordShape::amount($installment, 18, 18, false, false);
        }
        /** @var Price $f Every field and nested list has passed the exact reusable contract above. */
        return ['record' => $f, 'applicableSkus' => $skus];
    }

    private static function date(string $value): void
    {
        if ($value === '') {
            return;
        }
        CatalogRecordShape::check(preg_match('/\A[0-9]{4}-[0-9]{2}-[0-9]{2}(?:T[0-9]{2}:[0-9]{2}:[0-9]{2})?\z/D', $value) === 1, 'structured date', 'ISO calendar format required');
        $format = strlen($value) === 10 ? 'Y-m-d' : 'Y-m-d\TH:i:s';
        // Validate calendar text independently of host timezone or daylight-saving gaps.
        $date = DateTimeImmutable::createFromFormat('!' . $format, $value, new DateTimeZone('UTC'));
        CatalogRecordShape::check($date !== false && $date->format($format) === $value && substr($value, 0, 4) !== '0000', 'structured date', 'exact valid calendar date or datetime required');
    }
}
