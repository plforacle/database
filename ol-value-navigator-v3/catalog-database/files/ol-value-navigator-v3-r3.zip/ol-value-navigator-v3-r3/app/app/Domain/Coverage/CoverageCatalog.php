<?php

declare(strict_types=1);

namespace App\Domain\Coverage;

use RuntimeException;

/**
 * Demonstration catalog with reference mappings; never an activated commercial catalog.
 * @phpstan-type Entry array{description:string,unit:string,referencePrice:?string,scenarioPrice:?string,priceBasis:string,readiness:string,provenance:string,effectiveOn:string,verifiedOn:string,currency:string,term:string,exclusionReason:string,eligible:list<string>,olam:bool,capabilityRule:string,approval:?string,vendor?:string,treatment?:string,mappingStatus?:string,unlimitedGuests?:bool,features?:list<string>,baseEntitlement?:bool,workstation?:bool,selfSupportPhysicalOnly?:bool,requiresBase?:bool,nodePackSize?:?int,embeddedLifecycle?:bool,bundleComponents?:list<string>,minimumOffering?:string,exclusionCode?:string,catalogStatus?:string,sourceUrl?:string,supportLevel?:string}
 * @phpstan-type Offering array{description:string,unit:string,price:?string,olam:bool,priceBasis:string,provenance:string,priceVersion?:string,currency?:string,term?:string,effectiveOn?:string,verifiedOn?:string,sourceUrl?:string}
 */
final class CoverageCatalog
{
    public const VERSION = 'coverage-v7-rules-1.2.0-2026-09-09';
    public const MAPPING_VERSION = '1.2.0';
    public const PRICE_VERSION = 'oracle-usd-2026-09-01-rh-v3-2026-08-25';
    public const RULE = 'OLAM-2026-06-15';

    /** @return array<string, Entry> */
    public static function entries(): array
    {
        $base = ['description' => '', 'unit' => 'SYSTEM', 'referencePrice' => '150.00', 'scenarioPrice' => '150.00', 'priceBasis' => 'SYNTHETIC', 'readiness' => 'READY', 'provenance' => 'Synthetic coverage fixture v2; invented test prices, not Oracle or Red Hat pricing.', 'effectiveOn' => '2026-09-09', 'verifiedOn' => '2026-09-09', 'currency' => 'USD', 'term' => 'ANNUAL', 'exclusionReason' => '', 'eligible' => ['SYN-BASIC', 'SYN-PREMIER', 'SYN-PLUS'], 'olam' => false, 'capabilityRule' => 'Explicit synthetic mapping; no inferred tier hierarchy.', 'approval' => null];
        return [
            'SYN-OS' => [...$base, 'description' => 'Synthetic OS subscription'],
            'SYN-AUTOMATION' => [...$base, 'description' => 'Synthetic automation node pack', 'unit' => 'NODE_PACK', 'referencePrice' => '500.00', 'scenarioPrice' => '500.00', 'eligible' => ['SYN-PREMIER', 'SYN-PLUS'], 'olam' => true],
            'SYN-MISSING' => [...$base, 'description' => 'Synthetic missing current price', 'referencePrice' => null, 'scenarioPrice' => null, 'readiness' => 'MISSING_CURRENT_PRICE'],
            'SYN-RESELLER' => [...$base, 'description' => 'Synthetic reseller evidence requiring approval', 'referencePrice' => null, 'scenarioPrice' => '90.00', 'priceBasis' => 'RESELLER', 'readiness' => 'EXCEPTION_APPROVAL_REQUIRED', 'provenance' => 'Synthetic reseller quote retained as evidence; not MSRP.'],
            'SYN-LIFECYCLE' => [...$base, 'description' => 'Synthetic lifecycle exclusion', 'referencePrice' => '0.00', 'scenarioPrice' => null, 'readiness' => 'EXCLUDED', 'eligible' => [], 'exclusionReason' => 'Historical zero placeholder; retired product is not a free subscription.'],
            'SYN-NO-EQUIVALENT' => [...$base, 'description' => 'Synthetic unsupported capability', 'referencePrice' => null, 'scenarioPrice' => null, 'readiness' => 'NO_EQUIVALENT', 'eligible' => [], 'exclusionReason' => 'No supported equivalent for this capability.'],
            'SYN-ZERO' => [...$base, 'description' => 'Synthetic evidenced zero-cost subscription', 'referencePrice' => '0.00', 'scenarioPrice' => '0.00'],
            'VCF-CLD-FND-5' => [
                ...$base,
                'description' => 'VMware Cloud Foundation (VCF)',
                'unit' => 'CORE',
                'referencePrice' => '350.00',
                'scenarioPrice' => null,
                'priceBasis' => 'REFERENCE_ONLY',
                'readiness' => 'MISSING_CURRENT_PRICE_AND_TERM',
                'provenance' => 'red_hat_sku_price_catalogv3.xlsx / vmware!A2:E2: supplied 2025 MSRP of USD 350 per core, with a stated 16-core minimum per CPU. Source URL and subscription term are absent; current price and quantity rules require verification.',
                'effectiveOn' => '',
                'verifiedOn' => '',
                'term' => 'UNKNOWN',
                'eligible' => ['OL-PREMIER-PLUS'],
                'capabilityRule' => 'Shawn confirmed VCF-CLD-FND-5 maps directly to Oracle Linux Premier Plus on 2026-09-09. Comparison mapping only; no blanket VCF feature equivalence.',
            ],
        ] + WorkbookCoverageCatalog::entries();
    }

    /** @return array<string, Offering> */
    public static function offerings(): array
    {
        $base = ['unit' => 'CPU_PAIR', 'priceBasis' => 'SYNTHETIC', 'provenance' => 'Synthetic coverage fixture v2; not an approved commercial offering.'];
        return [
            'SYN-BASIC' => [...$base, 'description' => 'Synthetic Basic', 'price' => '60.00', 'olam' => false],
            'SYN-PREMIER' => [...$base, 'description' => 'Synthetic Premier', 'price' => '100.00', 'olam' => true],
            'SYN-PLUS' => [...$base, 'description' => 'Synthetic Premier Plus', 'price' => '180.00', 'olam' => true],
        ] + self::oracleOfferings();
    }

    /** @return array<string, Offering> */
    private static function oracleOfferings(): array
    {
        $json = file_get_contents(dirname(__DIR__, 3) . '/resources/catalog/oracle-support-prices-v1.json');
        if ($json === false) {
            throw new RuntimeException('The Oracle support price catalog is unavailable.');
        }
        /** @var array{priceVersion:string,currency:string,term:string,verifiedOn:string,offerings:array<string,array{description:string,unit:string,price:string,olam:bool,priceBasis:string,effectiveOn:string,sourceUrl:string,provenance:string}>} $data */
        $data = json_decode($json, true, 16, JSON_THROW_ON_ERROR);
        if ($data['priceVersion'] !== self::PRICE_VERSION || $data['currency'] !== 'USD' || $data['term'] !== 'ANNUAL'
            || array_keys($data['offerings']) !== ['OL-PUBLIC-YUM', 'OL-BASIC', 'OL-PREMIER', 'OL-PREMIER-PLUS']) {
            throw new RuntimeException('The Oracle support price catalog version or scope is invalid.');
        }
        $offerings = [];
        foreach ($data['offerings'] as $id => $offering) {
            if (preg_match('/^\d{1,8}\.\d{2}$/D', $offering['price']) !== 1
                || $offering['unit'] !== ($id === 'OL-PUBLIC-YUM' ? 'NONE' : 'CPU_PAIR')
                || filter_var($offering['sourceUrl'], FILTER_VALIDATE_URL) === false
                || preg_match('/^\d{4}-\d{2}-\d{2}$/D', $data['verifiedOn']) !== 1
                || preg_match('/^\d{4}-\d{2}-\d{2}$/D', $offering['effectiveOn']) !== 1) {
                throw new RuntimeException('The Oracle support price evidence is invalid for ' . $id);
            }
            $offerings[$id] = [
                ...$offering, 'priceVersion' => $data['priceVersion'], 'currency' => $data['currency'],
                'term' => $data['term'], 'verifiedOn' => $data['verifiedOn'],
                'provenance' => $offering['provenance'] . ' ' . $offering['sourceUrl'] . '; support matrix: ' . WorkbookCoverageCatalog::SUPPORT_SOURCE . '#page=4',
            ];
        }
        return $offerings;
    }
}
