<?php

declare(strict_types=1);

namespace App\Domain\Extraction;

final readonly class ExtractionResult
{
    /** @param list<CandidateLine> $candidates */
    public function __construct(private ExtractionEvidence $evidence, private array $candidates)
    {
    }

    public function mode(): ExtractionMode
    {
        return $this->evidence->mode();
    }
    public function evidence(): ExtractionEvidence
    {
        return $this->evidence;
    }

    /** @return list<CandidateLine> */
    public function candidates(): array
    {
        return $this->candidates;
    }
}
