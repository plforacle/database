<?php

declare(strict_types=1);

namespace App\Domain\Shared;

use RuntimeException;

final class ResourceNotFound extends RuntimeException
{
    public static function because(string $reason): self
    {
        return new self($reason);
    }
}
