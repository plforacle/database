<?php

declare(strict_types=1);

namespace App\Domain\Coverage;

use App\Domain\Package\CatalogSnapshot;
use Brick\Math\BigDecimal;
use Brick\Math\RoundingMode;

/**
 * Concurrent OLAM capacity is independent of recurring charges and actual managed-node demand.
 * @phpstan-type Issue array{groupId:string,code:string,message:string}
 * @phpstan-type Pool array{id:string,groupIds:list<string>,capacity:?int,excess:?int,additionalPairsIndicated:?int,status:string,extraAnnual:?string,extraTerm:?string,additionalUnits:int,uniqueNodes:?int,allocatedPairs:?int}
 * @phpstan-type Result array{pools:list<Pool>,issues:list<Issue>,advisories:list<Issue>,extraAnnual:string,extraTerm:string}
 */
final class ScenarioPools
{
    /** @param list<array<string,mixed>> $pools
     * @param array<string,array<string,mixed>> $groups
     * @param list<string> $requiredGroupIds
     * @return Result
     */
    public static function evaluate(array $pools, array $groups, array $requiredGroupIds, string $mode, int $months, CatalogSnapshot $snapshot): array
    {
        $result = ['pools' => [], 'issues' => [], 'advisories' => [], 'extraAnnual' => '0.00', 'extraTerm' => '0.00'];
        [$poolCounts, $purchaseCounts, $allocations] = self::inventory($pools);
        $covered = [];
        foreach ($pools as $pool) {
            $id = ScenarioFacts::text($pool['id'] ?? '');
            $groupIds = ScenarioFacts::strings($pool['groupIds'] ?? []);
            $scopeIds = $groupIds === [] ? [''] : array_values(array_unique($groupIds));
            $required = array_intersect($groupIds, $requiredGroupIds) !== [];
            $coverage = ScenarioFacts::accepted($pool['coverage'] ?? null, $mode);
            $material = false;
            if ($id === '' || ($poolCounts[$id] ?? 0) > 1) {
                self::add($result['issues'], $scopeIds, 'OLAM_POOL_DUPLICATE_REVIEW', 'Pool IDs must be present and unique; repeated pools do not create additional capacity.');
                $material = true;
            }
            if ($groupIds === [] || count($groupIds) !== count(array_unique($groupIds)) || array_diff($groupIds, array_keys($groups)) !== []) {
                self::add($result['issues'], $scopeIds, 'OLAM_POOL_MEMBERSHIP_REVIEW', 'A pool must reference each existing member group once.');
                $material = true;
            }
            foreach ($groupIds as $groupId) {
                $covered[$groupId] = true;
            }
            $allocated = self::allocation($pool, $groups, $allocations, $scopeIds, $result['issues'], $material);
            [$extraAnnual, $extraUnits] = self::purchases($pool, $purchaseCounts, $scopeIds, $result['issues'], $snapshot);
            if ($extraAnnual === null) {
                $material = true;
            }
            if (!$required && $extraUnits > 0) {
                self::add($result['issues'], $scopeIds, 'OLAM_ORPHAN_PURCHASE_REVIEW', 'Additional OLAM purchases remain without a selected automation scope; review their purpose rather than silently removing their cost.');
            }
            $unique = $pool['uniqueNodes'] ?? null;
            if ($unique !== null && (!is_int($unique) || $unique < 0 || $unique > 1000000000)) {
                self::add($result['issues'], $scopeIds, 'OLAM_NODES_REVIEW', 'Unique managed-node demand must be a nonnegative integer or explicitly unknown.');
                $unique = null;
                $material = true;
            }
            if (!$coverage || $material) {
                $allocated = null;
            }
            $capacity = $required && $allocated !== null ? ($allocated + $extraUnits) * 20 : null;
            $excess = $required && $capacity !== null && is_int($unique) ? max(0, $unique - $capacity) : null;
            $status = !$required ? 'NOT_APPLICABLE' : ($excess === null ? 'REVIEW_REQUIRED' : ($excess > 0 ? 'GAP_REQUIRES_REVIEW' : 'SUFFICIENT_FOR_DECLARED_NODES'));
            if ($required && ($excess === null || !$coverage)) {
                $message = 'OLAM coverage is unverified: establish unique managed nodes, exclusive allocation and applicable pool terms. ' . CatalogSnapshot::OLAM_RULE . ' allows 20 nodes per eligible paid CPU pair; unknown inputs are not zero.';
                if ($mode === 'ILLUSTRATIVE') {
                    self::add($result['advisories'], $scopeIds, 'OLAM_COVERAGE_UNVERIFIED', $message);
                } else {
                    self::add($result['issues'], $scopeIds, 'OLAM_COVERAGE_UNVERIFIED', $message);
                }
            } elseif ($required && $excess > 0) {
                self::add($result['advisories'], $scopeIds, 'OLAM_SUPPORT_CAPACITY_REVIEW', 'Declared OLAM demand exceeds allocated support capacity. Additional pairs are advisory only; no purchase or support-condition waiver is inferred.');
            }
            $extraTerm = $extraAnnual !== null && in_array($months, [12, 36], true)
                ? (string) BigDecimal::of($extraAnnual)->multipliedBy(intdiv($months, 12)) : null;
            if ($extraTerm === null && !in_array($months, [12, 36], true)) {
                self::add($result['issues'], $scopeIds, 'OLAM_TERM_REVIEW', 'Additional support purchases require the same supported 12- or 36-month comparison period.');
            }
            $result['pools'][] = [
                'id' => $id, 'groupIds' => $groupIds, 'capacity' => $capacity, 'excess' => $excess,
                'additionalPairsIndicated' => $excess !== null ? intdiv($excess + 19, 20) : null,
                'status' => $status, 'extraAnnual' => $extraAnnual, 'extraTerm' => $extraTerm,
                'additionalUnits' => $extraUnits, 'uniqueNodes' => is_int($unique) ? $unique : null,
                'allocatedPairs' => $required ? $allocated : null,
            ];
            if ($extraAnnual !== null) {
                $result['extraAnnual'] = (string) BigDecimal::of($result['extraAnnual'])->plus($extraAnnual);
            }
            if ($extraTerm !== null) {
                $result['extraTerm'] = (string) BigDecimal::of($result['extraTerm'])->plus($extraTerm);
            }
        }
        foreach (array_unique($requiredGroupIds) as $groupId) {
            if (isset($covered[$groupId])) {
                continue;
            }
            $result['pools'][] = ['id' => 'unassigned:' . $groupId, 'groupIds' => [$groupId], 'capacity' => null, 'excess' => null, 'additionalPairsIndicated' => null, 'status' => 'REVIEW_REQUIRED', 'extraAnnual' => '0.00', 'extraTerm' => '0.00', 'additionalUnits' => 0, 'uniqueNodes' => null, 'allocatedPairs' => null];
            $message = 'Define an OLAM pool with explicit unique managed nodes and eligible pair allocations; no group capacity is inferred automatically.';
            if ($mode === 'ILLUSTRATIVE') {
                self::add($result['advisories'], [$groupId], 'OLAM_COVERAGE_UNVERIFIED', $message);
            } else {
                self::add($result['issues'], [$groupId], 'OLAM_COVERAGE_UNVERIFIED', $message);
            }
        }
        return $result;
    }

    /** @param list<array<string,mixed>> $pools
     * @return array{array<string,int>,array<string,int>,array<string,int>}
     */
    private static function inventory(array $pools): array
    {
        $poolCounts = $purchaseCounts = $allocations = [];
        foreach ($pools as $pool) {
            $id = ScenarioFacts::text($pool['id'] ?? '');
            $poolCounts[$id] = ($poolCounts[$id] ?? 0) + 1;
            foreach (ScenarioFacts::records($pool['extraPurchases'] ?? []) as $purchase) {
                $purchaseId = ScenarioFacts::text($purchase['id'] ?? '');
                $purchaseCounts[$purchaseId] = ($purchaseCounts[$purchaseId] ?? 0) + 1;
            }
            foreach (ScenarioFacts::records($pool['allocations'] ?? []) as $allocation) {
                $groupId = ScenarioFacts::text($allocation['groupId'] ?? '');
                $pairs = $allocation['pairs'] ?? null;
                if (is_int($pairs) && $pairs >= 0 && $pairs <= 512000000) {
                    $allocations[$groupId] = ($allocations[$groupId] ?? 0) + $pairs;
                }
            }
        }
        return [$poolCounts, $purchaseCounts, $allocations];
    }

    /** @param array<string,mixed> $pool
     * @param array<string,array<string,mixed>> $groups
     * @param array<string,int> $totals
     * @param list<string> $scopeIds
     * @param list<Issue> $issues
     */
    private static function allocation(array $pool, array $groups, array $totals, array $scopeIds, array &$issues, bool &$material): ?int
    {
        $known = true;
        $sum = 0;
        $seen = [];
        $members = ScenarioFacts::strings($pool['groupIds'] ?? []);
        foreach (ScenarioFacts::records($pool['allocations'] ?? []) as $allocation) {
            $id = ScenarioFacts::text($allocation['groupId'] ?? '');
            $group = $groups[$id] ?? [];
            $pairs = $allocation['pairs'] ?? null;
            $units = array_key_exists('units', $group) ? $group['units'] : ($group['pairs'] ?? null);
            if (!in_array($id, $members, true) || isset($seen[$id]) || !isset($groups[$id])) {
                self::add($issues, $scopeIds, 'OLAM_ALLOCATION_REVIEW', 'Allocate each member group at most once within the pool.');
                $material = true;
            }
            $seen[$id] = true;
            if ($pairs === null || $units === null) {
                $known = false;
                continue;
            }
            if (!is_int($pairs) || $pairs < 0 || $pairs > 512000000 || !is_int($units) || $units < 0
                || ($pairs > 0 && !in_array($group['offering'] ?? '', ['OL-PREMIER', 'OL-PREMIER-PLUS'], true))
                || ($totals[$id] ?? 0) > $units) {
                self::add($issues, $scopeIds, 'OLAM_ALLOCATION_REVIEW', 'Allocated OLAM pairs must be eligible paid pairs and cannot exceed the group total across all pools.');
                $material = true;
                continue;
            }
            $sum += $pairs;
        }
        foreach ($members as $id) {
            $group = $groups[$id] ?? [];
            if (!isset($seen[$id]) && (in_array($group['offering'] ?? '', ['OL-PREMIER', 'OL-PREMIER-PLUS', ''], true)
                || !is_int($group['units'] ?? $group['pairs'] ?? null))) {
                $known = false;
            }
        }
        return $known && !$material ? $sum : null;
    }

    /** @param array<string,mixed> $pool
     * @param array<string,int> $counts
     * @param list<string> $scopeIds
     * @param list<Issue> $issues
     * @return array{?string,int}
     */
    private static function purchases(array $pool, array $counts, array $scopeIds, array &$issues, CatalogSnapshot $snapshot): array
    {
        $annual = BigDecimal::zero()->toScale(2);
        $units = 0;
        $known = true;
        $offerings = $snapshot->offerings();
        foreach (ScenarioFacts::records($pool['extraPurchases'] ?? []) as $purchase) {
            $id = ScenarioFacts::text($purchase['id'] ?? '');
            $offering = ScenarioFacts::text($purchase['offering'] ?? '');
            $quantity = $purchase['units'] ?? null;
            if ($id === '' || ($counts[$id] ?? 0) > 1) {
                self::add($issues, $scopeIds, 'OLAM_PURCHASE_DUPLICATE_REVIEW', 'Each additional purchase requires one unique ID and may be charged in one pool only.');
                $known = false;
                continue;
            }
            if (!is_int($quantity) || $quantity < 0 || $quantity > 1000000 || !in_array($offering, ['OL-PREMIER', 'OL-PREMIER-PLUS'], true)) {
                self::add($issues, $scopeIds, 'OLAM_PURCHASE_REVIEW', 'Additional purchases require explicit nonnegative whole units and a Premier or Premier Plus offering.');
                $known = false;
                continue;
            }
            $price = ($offerings[$offering]['olam'] ?? false) ? ($offerings[$offering]['price'] ?? null) : null;
            if ($price === null) {
                self::add($issues, $scopeIds, 'OLAM_PURCHASE_REVIEW', 'The additional support price is unknown.');
                $known = false;
                continue;
            }
            $annual = $annual->plus(BigDecimal::of($price)->multipliedBy($quantity)->toScale(2, RoundingMode::HALF_UP));
            $units += $quantity;
        }
        return [$known ? (string) $annual : null, $units];
    }

    /** @param list<Issue> $items
     * @param list<string> $groupIds
     */
    private static function add(array &$items, array $groupIds, string $code, string $message): void
    {
        foreach ($groupIds as $id) {
            $items[] = ['groupId' => $id, 'code' => $code, 'message' => $message];
        }
    }
}
