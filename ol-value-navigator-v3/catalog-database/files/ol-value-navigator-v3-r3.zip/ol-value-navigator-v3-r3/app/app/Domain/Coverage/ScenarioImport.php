<?php

declare(strict_types=1);

namespace App\Domain\Coverage;

use App\Domain\Shared\DomainViolation;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use PhpOffice\PhpSpreadsheet\Reader\Xlsx;

/** Local-only preview. It never calculates formulas, follows links, deduplicates rows or adopts facts. */
final class ScenarioImport
{
    public const VERSION = 'scenario-intake-1.3.1';
    public const MAX_BYTES = 8388608;
    public const MAX_ROWS = 2000;
    public const MAX_COLUMNS = 64;
    private const FIELDS = ['sku', 'description', 'quantity', 'startDate', 'endDate', 'unitPrice', 'lineTotal', 'rowType'];
    private const ROW_TYPES = ['PRODUCT', 'HEADER', 'TOTAL', 'NOTE', 'EMPTY'];

    /** @param array<string,mixed> $profile
     * @return array<string,mixed>
     */
    public static function preview(string $path, string $filename, array $profile = []): array
    {
        if (!is_file($path) || !is_readable($path) || is_link($path) || filesize($path) > self::MAX_BYTES || filesize($path) === 0) {
            throw DomainViolation::because('Supply a readable, nonempty local file no larger than 8 MB.');
        }
        $filename = ScenarioInput::safeText($filename, 255);
        if ($filename === '' || basename($filename) !== $filename || str_contains($filename, '\\')) {
            throw DomainViolation::because('The import filename must be a simple filename.');
        }
        $profile = self::normalizeProfile($profile);
        $extension = strtolower(pathinfo($filename, PATHINFO_EXTENSION));
        $mediaTypes = ['csv' => 'text/csv', 'tsv' => 'text/tab-separated-values', 'xlsx' => 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet', 'png' => 'image/png', 'jpg' => 'image/jpeg', 'jpeg' => 'image/jpeg'];
        if (!isset($mediaTypes[$extension])) {
            throw DomainViolation::because('Supported imports are CSV, TSV, XLSX, PNG and JPEG.');
        }
        $hash = hash_file('sha256', $path);
        if ($hash === false) {
            throw DomainViolation::because('The source file could not be fingerprinted.');
        }
        $issues = [];
        if (in_array($hash, $profile['existingHashes'], true)) {
            $issues[] = self::issue('DUPLICATE_FILE', 'This exact file was already reviewed. Review its purpose before appending; no rows were removed.');
        }
        if ($profile['columnMap'] === [] && $profile['sheetProfiles'] === []) {
            $issues[] = self::issue('COLUMN_MAPPING_REQUIRED', 'Map source columns explicitly before adopting product values.');
        }
        if ($profile['quantityBasis'] === 'UNKNOWN') {
            $issues[] = self::issue('QUANTITY_BASIS_UNKNOWN', 'Source quantities are not confirmed purchased entitlements; select their meaning or record a separate illustrative assumption.');
        }
        if (in_array($extension, ['png', 'jpg', 'jpeg'], true)) {
            $image = @getimagesize($path);
            if ($image === false || $image['mime'] !== $mediaTypes[$extension] || $image[0] * $image[1] > 40000000) {
                throw DomainViolation::because('The image format or dimensions are unsupported.');
            }
            $profile['sourceType'] = 'IMAGE_TRANSCRIPTION';
            if ($profile['manualRows'] === []) {
                $issues[] = self::issue('IMAGE_TRANSCRIPTION_REQUIRED', 'Transcribe the visible image manually. No OCR or native source-report validation has occurred.');
            }
            if (in_array('', $profile['visualReview'], true)) {
                $issues[] = self::issue('IMAGE_VISUAL_REVIEW_REQUIRED', 'Record the reviewer, review time and visual-check evidence for the manual transcription.');
            }
            $sheets = ['Image transcription' => $profile['manualRows']];
        } elseif ($extension === 'xlsx') {
            $sheets = self::workbook($path);
        } else {
            $sheets = ['Sheet 1' => self::delimited($path, $extension === 'tsv' ? "\t" : ',')];
        }
        $rows = [];
        foreach ($sheets as $sheet => $rawRows) {
            $sheetProfile = $profile['sheetProfiles'][$sheet] ?? ['columnMap' => $profile['columnMap'], 'headerRow' => $profile['headerRow']];
            if ($sheetProfile['columnMap'] === []) {
                $issues[] = self::issue('SHEET_MAPPING_REQUIRED', 'Column mapping is unresolved for sheet ' . $sheet . '.');
            }
            foreach ($rawRows as $index => $raw) {
                if (count($rows) >= self::MAX_ROWS) {
                    throw DomainViolation::because('Import exceeds 2,000 total worksheet rows.');
                }
                $rows[] = self::row($sheet, $index + 1, $raw, $sheetProfile, $profile['locale'], $profile['dateLocale']);
            }
        }
        return ['id' => 'sha256:' . $hash, 'filename' => $filename, 'sha256' => $hash, 'mediaType' => $mediaTypes[$extension], 'parserVersion' => self::VERSION, 'importedAt' => gmdate('Y-m-d\TH:i:s\Z'), 'sourceType' => $profile['sourceType'], 'sourceOrigin' => $profile['sourceOrigin'], 'quantityBasis' => $profile['quantityBasis'], 'profile' => $profile, 'rows' => $rows, 'issues' => $issues];
    }

    /** Revalidate posted evidence shape; persistence must resolve fingerprints to private originals.
     * @return array<string,mixed>
     */
    public static function normalizeSnapshot(mixed $snapshot): array
    {
        $snapshot = self::record($snapshot, ['id', 'filename', 'sha256', 'mediaType', 'parserVersion', 'importedAt', 'sourceType', 'sourceOrigin', 'quantityBasis', 'profile', 'rows', 'issues']);
        foreach (['id', 'filename', 'sha256', 'mediaType', 'parserVersion', 'importedAt', 'sourceType', 'sourceOrigin', 'quantityBasis'] as $key) {
            $snapshot[$key] = ScenarioInput::safeText($snapshot[$key] ?? '', 255);
        }
        if (preg_match('/^[a-f0-9]{64}$/D', $snapshot['sha256']) !== 1) {
            throw DomainViolation::because('A valid source fingerprint is required.');
        }
        $snapshot['profile'] = self::normalizeProfile($snapshot['profile'] ?? []);
        $snapshot['issues'] = self::issues($snapshot['issues'] ?? []);
        $rows = self::list($snapshot['rows'] ?? [], self::MAX_ROWS);
        foreach ($rows as &$row) {
            $row = self::record($row, ['sheet', 'row', 'rawValues', 'rowType', 'sku', 'description', 'quantity', 'startDate', 'endDate', 'unitPrice', 'lineTotal', 'issues']);
            if (count($row) !== 12) {
                throw DomainViolation::because('Every source row must preserve all preview fields, including unknown values.');
            }
            foreach (['sheet', 'sku', 'description', 'startDate', 'endDate', 'rowType'] as $field) {
                $row[$field] = ScenarioInput::safeText($row[$field] ?? '', 4000, true);
            }
            if (!in_array($row['rowType'], self::ROW_TYPES, true) || !is_int($row['row']) || $row['row'] < 1 || $row['row'] > self::MAX_ROWS) {
                throw DomainViolation::because('Invalid source row type or number.');
            }
            $row['rawValues'] = self::rawRow($row['rawValues'] ?? []);
            $row['issues'] = self::issues($row['issues'] ?? []);
            if ($row['quantity'] !== null && (!is_int($row['quantity']) || $row['quantity'] < 0 || $row['quantity'] > 1000000)) {
                throw DomainViolation::because('Invalid reviewed source quantity.');
            }
            foreach (['unitPrice', 'lineTotal'] as $field) {
                if ($row[$field] !== null && (!is_string($row[$field]) || preg_match('/^\d{1,15}(?:\.\d{1,6})?$/D', $row[$field]) !== 1)) {
                    throw DomainViolation::because('Invalid reviewed source price.');
                }
            }
        }
        unset($row);
        $snapshot['rows'] = $rows;
        return $snapshot;
    }

    /** @return array<string,mixed> */
    public static function normalizeProfile(mixed $input): array
    {
        $input = self::record($input, ['columnMap', 'headerRow', 'locale', 'dateLocale', 'sourceType', 'sourceOrigin', 'quantityBasis', 'sheetProfiles', 'existingHashes', 'manualRows', 'visualReview']);
        $result = $input + ['columnMap' => [], 'headerRow' => 1, 'locale' => 'UNKNOWN', 'dateLocale' => 'ISO', 'sourceType' => 'WORKSHEET', 'sourceOrigin' => 'UNVERIFIED', 'quantityBasis' => 'UNKNOWN', 'sheetProfiles' => [], 'existingHashes' => [], 'manualRows' => [], 'visualReview' => []];
        $result['columnMap'] = self::columnMap($result['columnMap']);
        $result['headerRow'] = self::headerRow($result['headerRow']);
        $enums = ['locale' => ['UNKNOWN', 'en_US', 'de_DE', 'fr_FR'], 'dateLocale' => ['ISO', 'MDY', 'DMY'], 'sourceType' => ['WORKSHEET', 'SATELLITE_EXPORT', 'IMAGE_TRANSCRIPTION'], 'sourceOrigin' => ['UNVERIFIED', 'CUSTOMER_DECLARED'], 'quantityBasis' => ScenarioInput::QUANTITY_BASES];
        foreach ($enums as $field => $values) {
            if (!in_array($result[$field], $values, true)) {
                throw DomainViolation::because('Unsupported import profile option.');
            }
        }
        $profiles = self::record($result['sheetProfiles'], null);
        if (count($profiles) > 30) {
            throw DomainViolation::because('At most 30 worksheet profiles are supported.');
        }
        foreach ($profiles as $name => &$profile) {
            ScenarioInput::safeText($name, 255);
            $profile = self::record($profile, ['columnMap', 'headerRow']);
            $profile = ['columnMap' => self::columnMap($profile['columnMap'] ?? []), 'headerRow' => self::headerRow($profile['headerRow'] ?? 1)];
        }
        unset($profile);
        $result['sheetProfiles'] = $profiles;
        $result['existingHashes'] = self::list($result['existingHashes'], 100);
        foreach ($result['existingHashes'] as $hash) {
            if (!is_string($hash) || preg_match('/^[a-f0-9]{64}$/D', $hash) !== 1) {
                throw DomainViolation::because('Existing file fingerprints must be SHA-256 strings.');
            }
        }
        $result['manualRows'] = array_map(self::rawRow(...), self::list($result['manualRows'], self::MAX_ROWS));
        $visual = self::record($result['visualReview'], ['reviewer', 'at', 'evidence']) + ['reviewer' => '', 'at' => '', 'evidence' => ''];
        foreach ($visual as &$value) {
            $value = ScenarioInput::safeText($value, 2000);
        }
        unset($value);
        $result['visualReview'] = $visual;
        return $result;
    }

    /** @return list<array<string,string>> */
    private static function delimited(string $path, string $delimiter): array
    {
        $handle = fopen($path, 'rb');
        if ($handle === false) {
            throw DomainViolation::because('The source file could not be opened.');
        }
        $rows = [];
        try {
            while (($values = fgetcsv($handle, 0, $delimiter, '"', '')) !== false) {
                if (count($values) > self::MAX_COLUMNS || count($rows) >= self::MAX_ROWS) {
                    throw DomainViolation::because('Import exceeds the 2,000 row or 64 column limit.');
                }
                $row = [];
                foreach ($values as $index => $value) {
                    $value ??= '';
                    if ($rows === [] && $index === 0) {
                        $value = preg_replace('/^\xEF\xBB\xBF/', '', $value) ?? $value;
                    }
                    $row[Coordinate::stringFromColumnIndex($index + 1)] = ScenarioInput::safeText($value, 4000, true);
                }
                $rows[] = $row;
            }
        } finally {
            fclose($handle);
        }
        return $rows;
    }

    /** @return array<string,list<array<string,string|int|float>>> */
    private static function workbook(string $path): array
    {
        self::inspectArchive($path);
        $reader = new Xlsx();
        $reader->setReadDataOnly(true);
        $reader->setReadEmptyCells(false);
        $reader->setIncludeCharts(false);
        try {
            $info = $reader->listWorksheetInfo($path);
            if (count($info) > 30 || array_sum(array_column($info, 'totalRows')) > self::MAX_ROWS) {
                throw DomainViolation::because('Workbook exceeds 30 sheets or 2,000 total rows.');
            }
            foreach ($info as $sheet) {
                if ($sheet['totalColumns'] > self::MAX_COLUMNS) {
                    throw DomainViolation::because('Workbook exceeds 64 columns.');
                }
            }
            $book = $reader->load($path);
            try {
                $sheets = [];
                foreach ($book->getAllSheets() as $sheet) {
                    $rows = [];
                    $maxColumn = Coordinate::columnIndexFromString($sheet->getHighestDataColumn());
                    for ($row = 1; $row <= $sheet->getHighestDataRow(); ++$row) {
                        $values = [];
                        for ($column = 1; $column <= $maxColumn; ++$column) {
                            $value = $sheet->getCell([$column, $row])->getValue();
                            if ($value instanceof \PhpOffice\PhpSpreadsheet\RichText\RichText) {
                                $value = $value->getPlainText();
                            }
                            if ($value === null) {
                                $value = '';
                            } elseif (is_bool($value)) {
                                $value = (string) $value;
                            }
                            $values[Coordinate::stringFromColumnIndex($column)] = self::rawValue($value);
                        }
                        $rows[] = $values;
                    }
                    $sheets[ScenarioInput::safeText($sheet->getTitle(), 255)] = $rows;
                }
                return $sheets;
            } finally {
                $book->disconnectWorksheets();
            }
        } catch (DomainViolation $error) {
            throw $error;
        } catch (\Throwable) {
            throw DomainViolation::because('The workbook could not be safely parsed. Supply a plain XLSX workbook without active content.');
        }
    }

    private static function inspectArchive(string $path): void
    {
        $zip = new \ZipArchive();
        if ($zip->open($path, \ZipArchive::RDONLY) !== true) {
            throw DomainViolation::because('The XLSX file is not a valid archive.');
        }
        try {
            if ($zip->numFiles > 512) {
                throw DomainViolation::because('Workbook archive has too many entries.');
            }
            $bytes = 0;
            for ($index = 0; $index < $zip->numFiles; ++$index) {
                $entry = $zip->statIndex($index);
                if ($entry === false) {
                    throw DomainViolation::because('Unreadable workbook archive entry.');
                }
                $name = $entry['name'];
                $bytes += $entry['size'];
                if ($bytes > 33554432 || $entry['size'] > self::MAX_BYTES || str_contains($name, '..') || str_starts_with($name, '/') || str_contains($name, '\\') || preg_match('~(?:vbaProject|embeddings/|activeX/|externalLinks/)~i', $name) === 1 || $entry['encryption_method'] !== 0) {
                    throw DomainViolation::because('Workbook archive contains unsafe content or exceeds decompression limits.');
                }
                if (str_ends_with(strtolower($name), '.xml') || str_ends_with(strtolower($name), '.rels')) {
                    $xml = $zip->getFromIndex($index);
                    if ($xml === false || str_contains($xml, "\0") || preg_match('/<!\s*(?:DOCTYPE|ENTITY)|TargetMode\s*=\s*[\'"]External[\'"]|<\s*ddeLink\b/i', $xml) === 1) {
                        throw DomainViolation::because('Workbook XML contains unsupported external references or active content.');
                    }
                    self::inspectXml($xml);
                }
            }
        } finally {
            $zip->close();
        }
    }

    /** Decode attribute character references without expanding entities or accessing a network. */
    private static function inspectXml(string $xml): void
    {
        $reader = new \XMLReader();
        $previous = libxml_use_internal_errors(true);
        try {
            if (!$reader->XML($xml, null, LIBXML_NONET | LIBXML_COMPACT)) {
                throw DomainViolation::because('Workbook XML is malformed.');
            }
            $reader->setParserProperty(\XMLReader::LOADDTD, false);
            $reader->setParserProperty(\XMLReader::SUBST_ENTITIES, false);
            $nodes = 0;
            while ($reader->read()) {
                if (++$nodes > 200000 || $reader->depth > 128 || $reader->nodeType === \XMLReader::DOC_TYPE || strcasecmp($reader->localName, 'ddeLink') === 0 || strcasecmp($reader->getAttribute('TargetMode') ?? '', 'External') === 0) {
                    throw DomainViolation::because('Workbook XML contains unsafe references or exceeds parsing limits.');
                }
            }
            if (libxml_get_last_error() !== false) {
                throw DomainViolation::because('Workbook XML is malformed.');
            }
        } finally {
            $reader->close();
            libxml_clear_errors();
            libxml_use_internal_errors($previous);
        }
    }

    /** @param array<string,string|int|float> $raw
     * @param array<string,mixed> $profile
     * @return array<string,mixed>
     */
    private static function row(string $sheet, int $number, array $raw, array $profile, string $locale, string $dateLocale): array
    {
        $values = [];
        foreach (self::FIELDS as $field) {
            $values[$field] = isset($profile['columnMap'][$field]) ? trim((string) ($raw[$profile['columnMap'][$field]] ?? '')) : '';
        }
        $issues = [];
        $rowType = self::classify($raw, $values, $number, $profile['headerRow']);
        $result = ['sheet' => $sheet, 'row' => $number, 'rawValues' => $raw, 'rowType' => $rowType, 'sku' => strtoupper($values['sku']), 'description' => $values['description'], 'quantity' => null, 'startDate' => $values['startDate'], 'endDate' => $values['endDate'], 'unitPrice' => null, 'lineTotal' => null, 'issues' => []];
        if ($rowType === 'PRODUCT' && $profile['columnMap'] !== []) {
            if ($result['sku'] === '') {
                $issues[] = self::issue('SKU_MISSING', 'Product identity is unresolved; a blank SKU is not a free or excluded product.');
            }
            foreach (['quantity', 'unitPrice', 'lineTotal'] as $field) {
                $text = $values[$field];
                if ($text === '') {
                    continue;
                }
                if (preg_match('/^[=+@]/', $text) === 1) {
                    $issues[] = self::issue('FORMULA_REQUIRES_REVIEW', 'Formula in ' . $field . ' was preserved without execution. Supply a separately reviewed value.');
                    continue;
                }
                $original = $raw[$profile['columnMap'][$field] ?? ''] ?? '';
                $numeric = self::number($text, is_int($original) || is_float($original) ? 'en_US' : $locale, $field === 'quantity');
                if ($numeric === null) {
                    $issues[] = self::issue('NUMBER_REQUIRES_REVIEW', 'The ' . $field . ' value is missing a usable numeric interpretation for the selected locale.');
                } else {
                    $result[$field] = $numeric;
                }
            }
            foreach (['startDate', 'endDate'] as $field) {
                if ($values[$field] !== '' && (($dateLocale === 'ISO' && preg_match('/^\d{4}-\d{2}-\d{2}$/D', $values[$field]) !== 1) || preg_match('/^[=+@]/', $values[$field]) === 1)) {
                    $issues[] = self::issue('DATE_REQUIRES_REVIEW', 'Original ' . $field . ' was retained. Confirm the source date format before adopting it.');
                }
            }
            if ($result['quantity'] === 0) {
                $issues[] = self::issue('ZERO_QUANTITY_NOT_SELECTED', 'Zero quantity is not selected for comparison.');
            }
        }
        $result['issues'] = $issues;
        return $result;
    }

    /** @param array<string,string|int|float> $raw
     * @param array<string,string> $values
     */
    private static function classify(array $raw, array $values, int $number, int $headerRow): string
    {
        if (implode('', array_map(static fn (string|int|float $value): string => trim((string) $value), $raw)) === '') {
            return 'EMPTY';
        }
        if ($headerRow > 0 && $number <= $headerRow) {
            return 'HEADER';
        }
        if (in_array(strtoupper($values['rowType']), self::ROW_TYPES, true)) {
            return strtoupper($values['rowType']);
        }
        $label = trim($values['sku'] . ' ' . $values['description']);
        if (preg_match('/^(?:(?:grand\s+)?total|subtotal|tax)(?:\b|\s*[:.])/i', $label) === 1) {
            return 'TOTAL';
        }
        if (preg_match('/^(?:hardware|software|notes?|red hat beta access)$/i', $label) === 1) {
            return 'NOTE';
        }
        return 'PRODUCT';
    }

    private static function number(string $text, string $locale, bool $count): string|int|null
    {
        $text = trim($text);
        if ($locale !== 'UNKNOWN') {
            $text = preg_replace('/^(?:USD\s*|\$\s*)/', '', $text) ?? $text;
        }
        $pattern = match ($locale) {
            'en_US' => '/^(?:\d+|\d{1,3}(?:,\d{3})+)(?:\.\d{1,6})?$/D',
            'de_DE' => '/^(?:\d+|\d{1,3}(?:\.\d{3})+)(?:,\d{1,6})?$/D',
            'fr_FR' => '/^(?:\d+|\d{1,3}(?:[ \x{00A0}\x{202F}]\d{3})+)(?:,\d{1,6})?$/uD',
            default => '/^\d+$/D',
        };
        if (preg_match($pattern, $text) !== 1) {
            return null;
        }
        $normalized = match ($locale) {
            'en_US' => str_replace(',', '', $text),
            'de_DE' => str_replace(',', '.', str_replace('.', '', $text)),
            'fr_FR' => str_replace(',', '.', str_replace([' ', "\u{00A0}", "\u{202F}"], '', $text)),
            default => $text,
        };
        if (preg_match('/^\d{1,15}(?:\.\d{1,6})?$/D', $normalized) !== 1) {
            return null;
        }
        if (!$count) {
            return $normalized;
        }
        if (str_contains($normalized, '.') || strlen($normalized) > 7 || (int) $normalized > 1000000) {
            return null;
        }
        return (int) $normalized;
    }

    /** @return array<string,string|int|float> */
    private static function rawRow(mixed $input): array
    {
        $input = self::record($input, null);
        if (count($input) > self::MAX_COLUMNS) {
            throw DomainViolation::because('Source rows cannot exceed 64 columns.');
        }
        $result = [];
        foreach ($input as $column => $value) {
            self::column($column);
            $result[$column] = self::rawValue($value);
        }
        return $result;
    }

    /** Raw numeric cells are source evidence, never floating-point calculation inputs. */
    private static function rawValue(mixed $value): string|int|float
    {
        if (is_int($value) || (is_float($value) && is_finite($value))) {
            return $value;
        }
        return ScenarioInput::safeText($value, 4000, true);
    }

    /** @return array<string,string> */
    private static function columnMap(mixed $input): array
    {
        $input = self::record($input, self::FIELDS);
        $result = [];
        foreach ($input as $field => $column) {
            if (!is_string($column)) {
                throw DomainViolation::because('Column maps use Excel column letters such as A or B.');
            }
            self::column($column);
            $result[$field] = $column;
        }
        if (count(array_unique($result)) !== count($result)) {
            throw DomainViolation::because('Each mapped field must use a distinct source column.');
        }
        return $result;
    }

    private static function column(string $column): void
    {
        if (preg_match('/^[A-Z]{1,2}$/D', $column) !== 1 || Coordinate::columnIndexFromString($column) > self::MAX_COLUMNS) {
            throw DomainViolation::because('Column letters must be between A and BL.');
        }
    }

    private static function headerRow(mixed $value): int
    {
        if (!is_int($value) || $value < 0 || $value > 100) {
            throw DomainViolation::because('The explicit header row must be 0 through 100.');
        }
        return $value;
    }

    /** @param list<string>|null $allowed
     * @return array<string,mixed>
     */
    private static function record(mixed $input, ?array $allowed): array
    {
        if (!is_array($input) || ($input !== [] && array_is_list($input))) {
            throw DomainViolation::because('An import profile or evidence record must be a structured object.');
        }
        foreach (array_keys($input) as $key) {
            if (!is_string($key) || ($allowed !== null && !in_array($key, $allowed, true))) {
                throw DomainViolation::because('The import contains an unsupported field.');
            }
        }
        return $input;
    }

    /** @return list<mixed> */
    private static function list(mixed $input, int $max): array
    {
        if (!is_array($input) || !array_is_list($input) || count($input) > $max) {
            throw DomainViolation::because('Import evidence exceeds list limits or has an invalid list shape.');
        }
        return $input;
    }

    /** @return list<array{code:string,message:string}> */
    private static function issues(mixed $input): array
    {
        $result = [];
        foreach (self::list($input, 100) as $issue) {
            $issue = self::record($issue, ['code', 'message']);
            $result[] = self::issue(ScenarioInput::safeText($issue['code'] ?? '', 100), ScenarioInput::safeText($issue['message'] ?? '', 2000));
        }
        return $result;
    }

    /** @return array{code:string,message:string} */
    private static function issue(string $code, string $message): array
    {
        return ['code' => $code, 'message' => $message];
    }
}
