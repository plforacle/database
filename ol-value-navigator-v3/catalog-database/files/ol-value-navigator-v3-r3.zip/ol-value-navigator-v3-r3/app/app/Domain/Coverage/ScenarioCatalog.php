<?php

declare(strict_types=1);

namespace App\Domain\Coverage;

use RuntimeException;

/**
 * Versioned scenario overlays; the original workbook and v1.2 catalog stay immutable.
 * @phpstan-import-type Entry from CoverageCatalog
 * @phpstan-import-type Price from ScenarioPricing
 */
final class ScenarioCatalog
{
    public const VERSION = 'coverage-v8-rules-1.3.1-2026-09-10';
    public const MAPPING_VERSION = '1.3.1';
    public const PRICE_VERSION = 'scenario-prices-1.3.1-2026-09-10';
    public const VCF_PRICE_ID = 'VCF-USD-CORE-ANNUAL-USER-20260910';

    /** @return array<string, Entry> */
    public static function entries(): array
    {
        $entries = CoverageCatalog::entries();
        foreach ([
            'RH00150' => ['Red Hat Enterprise Linux for SAP Applications, Premium', 'https://www.cdw.com/product/red-hat-enterprise-linux-for-sap-applications-premium-subscription-1-ph/6905983'],
            'RH00151' => ['Red Hat Enterprise Linux Server for SAP Applications, Non-production, Standard', 'https://www.cdw.com/product/red-hat-enterprise-linux-server-for-sap-applications-non-production-sta/6905985'],
        ] as $sku => [$description, $url]) {
            $entries[$sku] = [
                ...$entries['RH00764'], 'description' => $description, 'referencePrice' => null,
                'scenarioPrice' => null, 'priceBasis' => 'REFERENCE_ONLY', 'readiness' => 'EXCLUDED',
                'provenance' => 'v1.3.1 verified SAP identity overlay; reseller evidence establishes identity only. ' . $url,
                'effectiveOn' => '', 'verifiedOn' => '2026-09-09', 'sourceUrl' => $url,
                'catalogStatus' => 'VERIFIED_IDENTITY_OVERLAY', 'exclusionCode' => 'SAP',
            ];
        }
        $vcf = $entries['VCF-CLD-FND-5'];
        $entries['VCF-CLD-FND-5'] = [
            ...$vcf, 'vendor' => 'VMware', 'treatment' => 'BASE', 'mappingStatus' => 'MAPPED',
            'minimumOffering' => 'OL-PREMIER-PLUS', 'baseEntitlement' => true,
            'features' => ['UNLIMITED_VM_HOST', 'VIRTUALIZATION'], 'unlimitedGuests' => true,
            'catalogStatus' => 'VERIFIED_IDENTITY_OVERLAY',
        ];
        $entries['VCF-VSP-FND-8'] = [
            ...$entries['VCF-CLD-FND-5'], 'description' => 'VMware vSphere Foundation 8 (VVF)',
            'referencePrice' => null, 'scenarioPrice' => null,
            'provenance' => 'v1.3.1 HPE service-description identity overlay, page 11. Product-version suffix 8 does not establish a subscription term. No numerical price supplied.',
            'sourceUrl' => 'https://www.hpe.com/psnow/doc/a50012921enw',
            'verifiedOn' => '2026-09-09',
            'capabilityRule' => 'Approved KVM/OLVM replacement requires Premier Plus; full bundle fit, retirement and continuing costs require separate review.',
        ];
        return $entries;
    }

    /** Reusable prices require an explicit selection; they never become catalog defaults.
     * @return array<string, Price>
     */
    public static function prices(): array
    {
        $json = file_get_contents(dirname(__DIR__, 3) . '/resources/catalog/scenario-prices-v1.3.1.json');
        if ($json === false) {
            throw new RuntimeException('The versioned scenario price records are unavailable.');
        }
        /** @var array{version:string,prices:array<string,Price>} $records */
        $records = json_decode($json, true, 32, JSON_THROW_ON_ERROR);
        if ($records['version'] !== self::PRICE_VERSION) {
            throw new RuntimeException('The scenario price-record version does not match the evaluator.');
        }
        return $records['prices'];
    }
}
