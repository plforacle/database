<?php

declare(strict_types=1);

namespace App\Domain\Matching;

enum MatchState
{
    case EXACT;
    case UNRESOLVED;
}
