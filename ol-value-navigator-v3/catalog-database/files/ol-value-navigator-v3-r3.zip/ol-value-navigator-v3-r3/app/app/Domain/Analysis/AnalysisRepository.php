<?php

declare(strict_types=1);

namespace App\Domain\Analysis;

use App\Domain\Shared\Actor;
use App\Domain\Shared\AnalysisId;
use App\Domain\Shared\CatalogVersionId;
use App\Domain\Shared\RedactedSourceText;
use App\Domain\Shared\RevisionId;
use App\Domain\Extraction\ExtractionResult;
use App\Domain\Matching\MatchResult;
use App\Domain\Calculation\ComparisonTotals;

interface AnalysisRepository
{
    public function createDraft(
        AnalysisId $analysisId,
        RevisionId $revisionId,
        Actor $actor,
        RedactedSourceText $source,
        CatalogVersionId $catalogVersionId,
    ): void;

    /**
     * @return array{id: string, currentRevisionId: string|null, creatorSubject: string, accessScope: string}|null
     */
    public function findForSubject(AnalysisId $analysisId, Actor $subject): ?array;

    /**
     * @return array{id: string, analysisId: string, state: AnalysisState, catalogVersionId: string}|null
     */
    public function findRevisionForSubject(RevisionId $revisionId, Actor $subject): ?array;

    /** @return array{source: RedactedSourceText}|null */
    public function findDraftForSubject(RevisionId $revisionId, Actor $subject): ?array;

    public function recordExtraction(
        RevisionId $revisionId,
        Actor $subject,
        ExtractionResult $result,
        AnalysisState $state,
    ): void;

    /**
     * @return array{state: AnalysisState, catalogVersionId: string, decision: LineDecision, extractedIdentifier: string|null, resolvedSku: string|null, quantity: string|null}|null
     */
    public function lockLineForReview(RevisionId $revisionId, string $lineId, Actor $actor): ?array;

    public function confirmLine(
        RevisionId $revisionId,
        string $lineId,
        Actor $actor,
        MatchResult $match,
        ConfirmedLine $line,
        LineDecision $decision,
        ?string $correctedIdentifier,
    ): void;

    public function excludeLine(
        RevisionId $revisionId,
        string $lineId,
        Actor $actor,
        string $reason,
    ): void;

    public function selectOption(
        RevisionId $revisionId,
        string $lineId,
        CatalogVersionId $catalogVersionId,
        string $optionSku,
        Actor $actor,
    ): void;

    /**
     * @return array{state: AnalysisState, catalogVersionId: string, lines: list<array{lineId: string, matchState: string, decision: LineDecision, resolvedSku: string|null, resolvedDescription: string|null, quantity: string|null, annualUsdPrice: string|null, currency: string|null, annualTerm: string|null, unitBasis: string|null, exclusionReason: string|null, selectedOptionSku: string|null}>}|null
     */
    public function lockReadinessSnapshot(RevisionId $revisionId): ?array;

    public function updateRevisionState(
        RevisionId $revisionId,
        AnalysisState $from,
        AnalysisState $to,
    ): void;

    /**
     * @return array{state: AnalysisState, catalogVersionId: string, extractionMode: string|null, modelIdentifier: string|null, extractionContractVersion: string|null, promptTemplateVersion: string|null, responseDigest: string|null, lines: list<array{lineId: string, extractedIdentifier: string|null, matchState: string, decision: LineDecision, resolvedSku: string|null, resolvedDescription: string|null, quantity: string|null, annualUsdPrice: string|null, currency: string|null, annualTerm: string|null, unitBasis: string|null, exclusionReason: string|null, selectedOptionSku: string|null}>}|null
     */
    public function lockConfirmationSnapshot(RevisionId $revisionId, Actor $actor): ?array;

    /**
     * @param list<string> $assumptions
     * @param list<array{lineId: string, reason: string}> $exclusions
     * @return array{sourceAnnualTotal: string, sourceThreeYearTotal: string, sourceFiveYearTotal: string, optionAnnualTotal: string, optionThreeYearTotal: string, optionFiveYearTotal: string, currency: string, annualTerm: string}
     */
    public function insertCalculationResult(
        RevisionId $revisionId,
        ComparisonTotals $source,
        ComparisonTotals $option,
        array $assumptions,
        array $exclusions,
    ): array;

    /** @return array{confirmedBySubject: string, confirmedAt: string} */
    public function confirmRevision(RevisionId $revisionId, Actor $actor): array;

    /** @return array<string, mixed>|null */
    public function findConfirmedComparisonForSubject(RevisionId $revisionId, Actor $actor): ?array;
}
