<?php

declare(strict_types=1);

namespace App\Domain\Package;

/** @internal Mapping ownership, capabilities and selection prerequisites. */
final class CatalogMappingValidator
{
    /** @param list<string> $offeringIds
     * @return array{scope:string,fields:array<string,mixed>,evidence:array{kind:string,text:string}}
     */
    public static function entry(mixed $value, string $profileId, array $offeringIds): array
    {
        $r = CatalogRecordShape::record($value, ['scopeState', 'catalogFields', 'evidence'], location: 'mapping entry');
        $scope = CatalogRecordShape::choice($r['scopeState'], ['IN_SCOPE', 'EXCLUDED', 'NO_EQUIVALENT'], 'scope');
        $f = CatalogRecordShape::record($r['catalogFields'], CatalogPackageContract::ENTRY_MAPPING_REQUIRED, CatalogPackageContract::ENTRY_MAPPING_OPTIONAL, 'entry mapping fields');
        foreach (['description', 'exclusionReason', 'capabilityRule', 'minimumOffering', 'sourceUrl', 'supportLevel'] as $key) {
            if (array_key_exists($key, $f)) {
                CatalogRecordShape::text($f[$key], 'mapping ' . $key, $key === 'capabilityRule' ? CatalogPackageContract::EVIDENCE_BYTES : CatalogPackageContract::TEXT_BYTES);
            }
        }
        CatalogRecordShape::choice($f['unit'], CatalogPackageContract::SOURCE_UNITS, 'source unit');
        foreach (['olam', 'unlimitedGuests', 'baseEntitlement', 'workstation', 'selfSupportPhysicalOnly', 'requiresBase', 'embeddedLifecycle'] as $key) {
            if (array_key_exists($key, $f)) {
                CatalogRecordShape::check(is_bool($f[$key]), 'mapping ' . $key, 'boolean required');
            }
        }
        foreach ([
            'vendor' => ['Red Hat', 'VMware'], 'treatment' => ['BASE', 'ADD_TO_RHEL', 'EXCLUDED'],
            'mappingStatus' => ['MAPPED', 'EXCLUDED', 'UNRESOLVED_CAPABILITY'],
            'exclusionCode' => ['', 'POWER', 'RESILIENT_STORAGE', 'LIFECYCLE_SUPPORT', 'SAP', 'OPENSHIFT', 'NO_APPROVED_MAPPING', 'JBOSS', 'RUNTIMES'],
            'catalogStatus' => ['STORE_LISTED', 'WORKBOOK_REFERENCE', 'CATALOG_ONLY_AUTOMATION', 'VERIFIED_IDENTITY_OVERLAY'],
        ] as $key => $allowed) {
            if (array_key_exists($key, $f)) {
                CatalogRecordShape::choice($f[$key], $allowed, 'mapping ' . $key);
            }
        }
        $eligible = CatalogRecordShape::selection($f['eligible'], $offeringIds, 'eligible offerings');
        $features = array_key_exists('features', $f) ? CatalogRecordShape::selection($f['features'], [...CatalogPackageContract::FEATURES, ...($profileId === 'scenario-1.3.1' ? ['VIRTUALIZATION'] : [])], 'features') : [];
        if (array_key_exists('features', $f)) {
            CatalogRecordShape::check($f['olam'] === in_array('OLAM', $features, true), 'OLAM capability', 'feature and flag must agree');
        }
        if (array_key_exists('bundleComponents', $f)) {
            CatalogRecordShape::selection($f['bundleComponents'], ['RHEL', 'SATELLITE'], 'bundle components');
        }
        if ($scope !== 'IN_SCOPE') {
            CatalogRecordShape::check($eligible === [] && trim((string) $f['exclusionReason']) !== '', 'scope', 'excluded or unavailable mappings require no eligibility and an explanation');
        }
        foreach (['treatment', 'mappingStatus'] as $key) {
            if (array_key_exists($key, $f)) {
                CatalogRecordShape::check(($f[$key] === 'EXCLUDED') === ($scope === 'EXCLUDED'), 'scope classification', 'excluded classifications must agree');
            }
        }
        $treatment = $f['treatment'] ?? null;
        if ($treatment === 'BASE' || $treatment === 'ADD_TO_RHEL') {
            CatalogRecordShape::check(($f['baseEntitlement'] ?? null) === ($treatment === 'BASE'), 'base entitlement', 'treatment prerequisite missing');
        }
        CatalogRecordShape::check(!($f['baseEntitlement'] ?? false) || !($f['requiresBase'] ?? false), 'base entitlement', 'base cannot require another base');
        $pack = $f['nodePackSize'] ?? null;
        if ($pack !== null) {
            CatalogRecordShape::check(is_int($pack) && $pack > 0 && $pack <= 1000000, 'node pack', 'positive bounded integer required');
            CatalogRecordShape::check($f['olam'] === true && in_array('OLAM', $features, true), 'node pack', 'OLAM capability required');
        }
        if (array_key_exists('unlimitedGuests', $f)) {
            CatalogRecordShape::check($f['unlimitedGuests'] === in_array('UNLIMITED_VM_HOST', $features, true), 'unlimited guests', 'feature and flag must agree');
        }
        if (($f['minimumOffering'] ?? '') !== '') {
            CatalogRecordShape::check(($eligible[0] ?? null) === $f['minimumOffering'], 'minimum offering', 'first eligibility must match');
        }
        return ['scope' => $scope, 'fields' => $f, 'evidence' => CatalogRecordShape::evidence($r['evidence'], 'MAPPING')];
    }

    /** @return array{fields:array<string,mixed>,evidence:array{kind:string,text:string}} */
    public static function offering(mixed $value): array
    {
        $r = CatalogRecordShape::record($value, ['catalogFields', 'evidence'], location: 'mapping offering');
        $f = CatalogRecordShape::record($r['catalogFields'], CatalogPackageContract::OFFERING_MAPPING_FIELDS, location: 'offering mapping fields');
        CatalogRecordShape::text($f['description'], 'offering description');
        CatalogRecordShape::choice($f['unit'], ['CPU_PAIR', 'NONE'], 'target unit');
        CatalogRecordShape::check(is_bool($f['olam']), 'offering OLAM', 'boolean required');
        CatalogRecordShape::check($f['unit'] !== 'NONE' || $f['olam'] === false, 'zero target unit', 'OLAM capacity is unsupported');
        return ['fields' => $f, 'evidence' => CatalogRecordShape::evidence($r['evidence'], 'MAPPING')];
    }
}
