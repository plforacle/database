<?php

declare(strict_types=1);

namespace App\Domain\Extraction;

enum ExtractionMode
{
    case AI;
    case MANUAL;
}
