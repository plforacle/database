<?php

declare(strict_types=1);

namespace App\Domain\Analysis;

enum LineDecision
{
    case PENDING;
    case CONFIRMED;
    case CORRECTED_CONFIRMED;
    case EXCLUDED;
}
