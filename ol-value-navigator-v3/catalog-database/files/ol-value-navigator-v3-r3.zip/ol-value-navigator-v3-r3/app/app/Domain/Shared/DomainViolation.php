<?php

declare(strict_types=1);

namespace App\Domain\Shared;

use DomainException;

final class DomainViolation extends DomainException
{
    public static function because(string $reason): self
    {
        return new self($reason);
    }
}
