<?php

declare(strict_types=1);

namespace App\Domain\Coverage;

/** Source subscription quantities are checked against the source estate, never the Oracle target. */
final class SourceEntitlementReview
{
    /** @param array<string,mixed> $group
     * @param list<array<string,mixed>> $lines
     * @return list<array{code:string,message:string}>
     */
    public function review(array $group, array $lines): array
    {
        $reviews = [];
        $rh = array_values(array_filter($lines, static fn (array $line): bool => ($line['catalogMetadata']['vendor'] ?? '') === 'Red Hat'));
        if ($rh === []) {
            return [];
        }
        if (($group['sourceEntitlementsConfirmed'] ?? false) !== true || !$this->evidence($group['sourceQuantityEvidence'] ?? null)) {
            $reviews[] = $this->issue('Confirm RH source estate, socket/guest/node-pack quantities and subscription entitlements with review evidence.');
        }
        $hasBase = false;
        $hasUnlimitedBase = false;
        $entitlements = [];
        foreach ($rh as $line) {
            $entry = $line['catalogMetadata'];
            if ($entry['baseEntitlement'] ?? false) {
                $hasBase = true;
                $hasUnlimitedBase = $hasUnlimitedBase || ($entry['unlimitedGuests'] ?? false);
                $entitlements['BASE_OS'] = ($entitlements['BASE_OS'] ?? 0) + 1;
            }
            foreach (['OSMH', 'HA_COROSYNC_PACEMAKER', 'OLAM'] as $feature) {
                if (in_array($feature, $entry['features'] ?? [], true)) {
                    $entitlements[$feature] = ($entitlements[$feature] ?? 0) + 1;
                }
            }
        }
        if (max($entitlements === [] ? [0] : $entitlements) > 1 && !$this->evidence($group['duplicateEntitlementEvidence'] ?? null)) {
            $reviews[] = ['code' => 'DUPLICATE_ENTITLEMENT_REVIEW', 'message' => 'Bundle/base or repeated capability entitlements overlap. Identify actual separately purchased subscriptions, or remove the duplicate component/split distinct populations.'];
        }
        foreach ($rh as $line) {
            $entry = $line['catalogMetadata'];
            $sku = $line['sku'];
            $quantity = $line['quantity'];
            if (!is_int($quantity) || $quantity < 1) {
                continue; // The main evaluator reports invalid quantities.
            }
            if (($entry['requiresBase'] ?? false) && (!($entry['unlimitedGuests'] ?? false) ? !$hasBase : !$hasUnlimitedBase)
                && !$this->evidence($group['prerequisiteEvidence'] ?? null)) {
                $reviews[] = $this->issue($sku . ': verify the prerequisite RHEL subscription and matching limited/unlimited guest entitlement, including any base held outside this comparison.');
            }
            $pack = $entry['nodePackSize'] ?? null;
            if (is_int($pack) && $pack > 0) {
                $nodes = $this->count($group['sourceManagedNodes'] ?? null, 0);
                if ($nodes === null || $nodes > $quantity * $pack) {
                    $reviews[] = $this->issue($sku . ': confirm RH managed-node count within the selected node-pack quantity; Oracle demand is a separate input.');
                }
                continue;
            }
            $deployment = $group['sourceDeployment'] ?? '';
            $systems = $this->count($group['sourceSystems'] ?? null, $deployment === 'VIRTUAL_GUEST' ? 0 : 1);
            $cpus = $this->count($group['sourceCpusPerSystem'] ?? null, 1, 1024);
            $guests = $this->count($group['sourceGuests'] ?? null, 0);
            $unlimited = $entry['unlimitedGuests'] ?? false;
            if (!in_array($deployment, ['PHYSICAL', 'VIRTUAL_GUEST'], true) || $systems === null || $guests === null
                || ($deployment === 'PHYSICAL' && $cpus === null)
                || ($deployment === 'VIRTUAL_GUEST' && ($systems !== 0 || $guests === 0))
                || ($unlimited && $deployment !== 'PHYSICAL')) {
                $reviews[] = $this->issue($sku . ': resolve the RH source physical systems, sockets, guest counts and deployment independently of Oracle targets.');
                continue;
            }
            if (($entry['selfSupportPhysicalOnly'] ?? false) && ($deployment !== 'PHYSICAL' || $guests > 0 || $cpus > 2)) {
                $reviews[] = $this->issue($sku . ': Server self-support is physical and nonstackable; it cannot cover guests or hosts with more than two sockets.');
            }
            if ($entry['workstation'] ?? false) {
                if ($deployment !== 'PHYSICAL' || $quantity < $systems || $guests > $quantity) {
                    $reviews[] = $this->issue($sku . ': each RH workstation subscription covers one physical workstation and one guest.');
                }
                if (($group['workstationScopeAcknowledged'] ?? false) !== true || ($group['workstationGuestScope'] ?? '') !== 'EXCLUDED') {
                    $reviews[] = ['code' => 'WORKSTATION_SCOPE_REVIEW', 'message' => $sku . ': acknowledge OS-only scope and hardware/application compatibility; Oracle has no workstation-specific offering. Any required guest coverage must be resolved separately.'];
                }
                continue;
            }
            $required = ($deployment === 'PHYSICAL' ? $systems * intdiv($cpus + 1, 2) : 0)
                + ($unlimited ? 0 : intdiv($guests + 1, 2));
            if ($quantity < $required) {
                $reviews[] = $this->issue($sku . ': RH quantity ' . $quantity . ' is below ' . $required . ' subscriptions required by the confirmed source socket/guest estate.');
            }
        }
        return $reviews;
    }

    /** @return array{code:string,message:string} */
    private function issue(string $message): array
    {
        return ['code' => 'QUANTITY_REVIEW_REQUIRED', 'message' => $message];
    }

    private function count(mixed $value, int $min, int $max = 1000000): ?int
    {
        return is_int($value) && $value >= $min && $value <= $max ? $value : null;
    }

    private function evidence(mixed $value): bool
    {
        return is_string($value) && mb_strlen(trim($value)) >= 10 && mb_strlen($value) <= 1000;
    }
}
