<?php

declare(strict_types=1);

namespace App\Domain\Calculation;

use App\Domain\Shared\DomainViolation;
use Brick\Money\Context\DefaultContext;
use Brick\Money\Money;

final readonly class ComparisonTotals
{
    private function __construct(
        public Money $annual,
        public Money $threeYear,
        public Money $fiveYear,
    ) {
    }

    public static function fromAnnual(Money $annual): self
    {
        if ($annual->getCurrency()->getCurrencyCode() !== 'USD') {
            throw DomainViolation::because('Comparison totals must use USD.');
        }

        if (!$annual->getContext() instanceof DefaultContext) {
            throw DomainViolation::because('Comparison totals must use normal USD cent precision.');
        }

        if ($annual->isNegative()) {
            throw DomainViolation::because('Comparison totals cannot be negative.');
        }

        return new self(
            $annual,
            $annual->multipliedBy(3),
            $annual->multipliedBy(5),
        );
    }
}
