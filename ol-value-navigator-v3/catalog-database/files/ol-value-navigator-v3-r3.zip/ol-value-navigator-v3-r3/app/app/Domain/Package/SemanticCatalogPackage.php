<?php

declare(strict_types=1);

namespace App\Domain\Package;

use App\Domain\Shared\DomainViolation;
use App\Domain\Coverage\CoverageCatalog;
use App\Domain\Coverage\ScenarioPricing;

/** Validated local data only; no publisher, activation, or approval capability.
 * @phpstan-import-type Entry from CoverageCatalog
 * @phpstan-import-type Offering from CoverageCatalog
 * @phpstan-import-type Price from ScenarioPricing
 * @phpstan-type Evidence array{entries:array<string,array{kind:string,text:string}>,offerings:array<string,array{kind:string,text:string}>}
 * @phpstan-type Profile array{entries:array<string,Entry>,offerings:array<string,Offering>,scenarioPrices:array<string,Price>,applicability:array<string,list<string>>,evidence:Evidence}
 */
final readonly class SemanticCatalogPackage
{
    /** @param array<string,Profile> $profiles */
    private function __construct(private PackageEnvelope $envelope, private array $profiles)
    {
    }

    public static function fromEnvelope(PackageEnvelope $envelope): self
    {
        // Recheck against this engine's contracts even if the envelope caller admitted others.
        PackageEnvelope::fromJson($envelope->manifestJson(), $envelope->member('mappings')->json(), $envelope->member('prices')->json(), CatalogPackageContract::PROFILES, CatalogPackageContract::MEMBER_SCHEMAS);
        $mappingRoot = StrictJsonObjectDecoder::decode($envelope->member('mappings')->json(), 8 * 1024 * 1024);
        $priceRoot = StrictJsonObjectDecoder::decode($envelope->member('prices')->json(), 8 * 1024 * 1024);
        $mappingProfiles = StrictJsonObjectDecoder::object($mappingRoot->profiles);
        $priceProfiles = StrictJsonObjectDecoder::object($priceRoot->profiles);
        $profiles = [];
        foreach (array_keys(CatalogPackageContract::PROFILES) as $profileId) {
            $m = CatalogRecordShape::record($mappingProfiles->{$profileId}, ['entries', 'offerings'], location: 'mapping profile');
            $p = CatalogRecordShape::record($priceProfiles->{$profileId}, ['entries', 'offerings', 'scenarioPrices'], location: 'price profile');
            $entries = CatalogRecordShape::records($m['entries'], CatalogPackageContract::MAX_ENTRIES, 'mapping entries');
            $offerings = CatalogRecordShape::records($m['offerings'], CatalogPackageContract::MAX_OFFERINGS, 'mapping offerings');
            $entryPrices = CatalogRecordShape::records($p['entries'], CatalogPackageContract::MAX_ENTRIES, 'entry prices');
            $offeringPrices = CatalogRecordShape::records($p['offerings'], CatalogPackageContract::MAX_OFFERINGS, 'offering prices');
            self::matchingKeys($entries, $entryPrices);
            self::matchingKeys($offerings, $offeringPrices);
            $profile = ['entries' => [], 'offerings' => [], 'scenarioPrices' => [], 'applicability' => [], 'evidence' => ['entries' => [], 'offerings' => []]];
            foreach ($offerings as $id => $record) {
                $mapping = CatalogMappingValidator::offering($record);
                $profile['offerings'][$id] = CatalogPriceValidator::offering($offeringPrices[$id], $mapping['fields']);
                $profile['evidence']['offerings'][$id] = $mapping['evidence'];
            }
            foreach ($entries as $id => $record) {
                $mapping = CatalogMappingValidator::entry($record, $profileId, array_map(strval(...), array_keys($offerings)));
                $profile['entries'][$id] = CatalogPriceValidator::entry($entryPrices[$id], $mapping['fields'], $mapping['scope']);
                $profile['evidence']['entries'][$id] = $mapping['evidence'];
            }
            foreach (CatalogRecordShape::records($p['scenarioPrices'], CatalogPackageContract::MAX_PRICES, 'reusable prices') as $id => $record) {
                $price = CatalogPriceValidator::reusable($record, (string) $id, $profile['entries']);
                $profile['scenarioPrices'][$id] = $price['record'];
                $profile['applicability'][$id] = $price['applicableSkus'];
            }
            $profiles[$profileId] = $profile;
        }
        return new self($envelope, $profiles);
    }

    public function envelope(): PackageEnvelope
    {
        return $this->envelope;
    }

    /** @return array<string,Entry> */
    public function entries(string $profileId): array
    {
        return $this->profile($profileId)['entries'];
    }

    /** @return array<string,Offering> */
    public function offerings(string $profileId): array
    {
        return $this->profile($profileId)['offerings'];
    }

    /** @return array<string,Price> */
    public function scenarioPrices(string $profileId): array
    {
        return $this->profile($profileId)['scenarioPrices'];
    }

    /** @return list<string> */
    public function applicableSkus(string $profileId, string $priceId): array
    {
        return $this->profile($profileId)['applicability'][$priceId] ?? throw DomainViolation::because('Unknown catalog scenario price.');
    }

    /** @return Price */
    public function scenarioPrice(string $profileId, string $priceId, string $sku): array
    {
        if (!in_array($sku, $this->applicableSkus($profileId, $priceId), true)) {
            throw DomainViolation::because('Catalog scenario price does not apply to the selected SKU.');
        }
        return $this->scenarioPrices($profileId)[$priceId];
    }

    /** @return Evidence */
    public function mappingEvidence(string $profileId): array
    {
        return $this->profile($profileId)['evidence'];
    }

    /** @return Profile */
    private function profile(string $profileId): array
    {
        return $this->profiles[$profileId] ?? throw DomainViolation::because('Unknown semantic catalog profile.');
    }

    /** @param array<string,mixed> $mapping
     * @param array<string,mixed> $prices
     */
    private static function matchingKeys(array $mapping, array $prices): void
    {
        CatalogRecordShape::check(array_diff_key($mapping, $prices) === [] && array_diff_key($prices, $mapping) === [], 'paired prices', 'mapping and price keys differ');
    }
}
