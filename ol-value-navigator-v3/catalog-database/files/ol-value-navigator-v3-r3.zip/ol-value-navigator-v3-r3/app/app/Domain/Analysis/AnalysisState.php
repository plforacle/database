<?php

declare(strict_types=1);

namespace App\Domain\Analysis;

enum AnalysisState
{
    case DRAFT;
    case NEEDS_REVIEW;
    case INCOMPLETE;
    case READY_TO_CALCULATE;
    case CONFIRMED;
    case SUPERSEDED;
}
