<?php

declare(strict_types=1);

namespace App\Domain\Package;

use App\Domain\Coverage\CoverageInput;
use App\Domain\Shared\DomainViolation;
use stdClass;

/**
 * Strict, inert acceptance bytes bound to one semantic package.
 *
 * @phpstan-type AcceptanceCase array{id:string,profileId:string,input:array<string,mixed>}
 */
final readonly class PackageAcceptanceDocument
{
    private const MAX_BYTES = 4 * 1024 * 1024;
    private const MIN_CASES = 2;
    private const MAX_CASES = 16;

    /**
     * @param list<AcceptanceCase> $cases
     * @param list<stdClass> $expected
     */
    private function __construct(private array $cases, private array $expected)
    {
    }

    public static function fromJson(SemanticCatalogPackage $package, string $json): self
    {
        $root = StrictJsonObjectDecoder::decode($json, self::MAX_BYTES);
        StrictJsonObjectDecoder::keys($root, ['schemaVersion', 'manifestSha256', 'synthetic', 'cases']);
        if ($root->schemaVersion !== 'package-acceptance-1') {
            throw DomainViolation::because('Unsupported package acceptance schema.');
        }
        if (!is_string($root->manifestSha256)
            || preg_match('/\A[0-9a-f]{64}\z/D', $root->manifestSha256) !== 1
            || !hash_equals($package->envelope()->manifestDigest(), $root->manifestSha256)) {
            throw DomainViolation::because('Package acceptance manifest digest does not match.');
        }
        if ($root->synthetic !== true) {
            throw DomainViolation::because('Package acceptance cases require an explicit synthetic declaration.');
        }
        if (!is_array($root->cases) || !array_is_list($root->cases)
            || count($root->cases) < self::MIN_CASES || count($root->cases) > self::MAX_CASES) {
            throw DomainViolation::because('Package acceptance requires two to sixteen ordered cases.');
        }

        $cases = [];
        $expected = [];
        $seenIds = [];
        $seenProfiles = [];
        foreach ($root->cases as $case) {
            $case = StrictJsonObjectDecoder::object($case);
            StrictJsonObjectDecoder::keys($case, ['id', 'profileId', 'input', 'expected']);
            $id = StrictJsonObjectDecoder::identifier($case->id);
            if (isset($seenIds[':' . $id])) {
                throw DomainViolation::because('Package acceptance case identifiers must be unique.');
            }
            $seenIds[':' . $id] = true;
            $profileId = StrictJsonObjectDecoder::identifier($case->profileId);
            if (!isset(CatalogPackageContract::PROFILES[$profileId])) {
                throw DomainViolation::because('Package acceptance profile is unsupported.');
            }
            $seenProfiles[$profileId] = true;
            $inputObject = StrictJsonObjectDecoder::object($case->input);
            $input = self::toNative($inputObject);
            if (!is_array($input) || array_is_list($input)) {
                throw DomainViolation::because('Package acceptance input must be an object.');
            }
            $normalized = CoverageInput::normalize($input);
            if (!self::sameStructure($inputObject, $normalized)) {
                throw DomainViolation::because('Package acceptance input is not already normalized without fact loss.');
            }
            $expected[] = StrictJsonObjectDecoder::object($case->expected);
            $cases[] = ['id' => $id, 'profileId' => $profileId, 'input' => $normalized];
        }
        if (array_diff_key(CatalogPackageContract::PROFILES, $seenProfiles) !== []) {
            throw DomainViolation::because('Package acceptance must exercise every supported profile.');
        }

        return new self($cases, $expected);
    }

    /** @return list<AcceptanceCase> */
    public function cases(): array
    {
        return $this->cases;
    }

    public function expectedMatches(int $caseIndex, mixed $actual): bool
    {
        return isset($this->expected[$caseIndex])
            && self::sameStructure($this->expected[$caseIndex], $actual);
    }

    private static function sameStructure(mixed $left, mixed $right): bool
    {
        return self::structure($left) === self::structure($right);
    }

    /** @return array{string,mixed} */
    private static function structure(mixed $value): array
    {
        if ($value instanceof stdClass) {
            $properties = get_object_vars($value);
            ksort($properties, SORT_STRING);
            $entries = [];
            foreach ($properties as $key => $item) {
                $entries[] = [(string) $key, self::structure($item)];
            }

            return ['object', $entries];
        }
        if (is_array($value)) {
            if (array_is_list($value)) {
                return ['list', array_map(self::structure(...), $value)];
            }
            ksort($value, SORT_STRING);
            $entries = [];
            foreach ($value as $key => $item) {
                $entries[] = [(string) $key, self::structure($item)];
            }

            return ['object', $entries];
        }

        return [get_debug_type($value), $value];
    }

    private static function toNative(mixed $value): mixed
    {
        if ($value instanceof stdClass) {
            $result = [];
            foreach (get_object_vars($value) as $key => $item) {
                $result[$key] = self::toNative($item);
            }

            return $result;
        }
        if (is_array($value)) {
            return array_map(self::toNative(...), $value);
        }

        return $value;
    }
}
