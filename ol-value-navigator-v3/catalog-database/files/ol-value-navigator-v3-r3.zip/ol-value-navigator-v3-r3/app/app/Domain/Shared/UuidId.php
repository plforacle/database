<?php

declare(strict_types=1);

namespace App\Domain\Shared;

use Ramsey\Uuid\Uuid;

abstract readonly class UuidId
{
    final protected function __construct(private string $value)
    {
    }

    final public static function fromString(string $value): static
    {
        if (!Uuid::isValid($value)) {
            throw DomainViolation::because('A valid UUID is required.');
        }

        return new static(Uuid::fromString($value)->toString());
    }

    final public static function new(): static
    {
        return new static(Uuid::uuid4()->toString());
    }

    final public function __toString(): string
    {
        return $this->value;
    }
}
