<?php

declare(strict_types=1);

namespace App\Domain\Package;

/** Closed engine vocabulary; independent of installed catalogs and package claims. */
final class CatalogPackageContract
{
    public const PROFILES = [
        'legacy-coverage' => ['inputSchema' => 'legacy-coverage', 'resultSchema' => 'legacy-coverage', 'ruleModel' => 'coverage-1.2.0'],
        'scenario-1.3.1' => ['inputSchema' => '1.3.1', 'resultSchema' => '1.3.1', 'ruleModel' => 'coverage-1.3.1'],
    ];
    public const MEMBER_SCHEMAS = ['mappings' => ['olvn-mappings-1'], 'prices' => ['olvn-prices-1']];
    public const MAX_ENTRIES = 10000;
    public const MAX_OFFERINGS = 100;
    public const MAX_PRICES = 10000;
    public const TEXT_BYTES = 2048;
    public const EVIDENCE_BYTES = 16384;
    public const ENTRY_MAPPING_REQUIRED = ['description', 'unit', 'exclusionReason', 'eligible', 'olam', 'capabilityRule'];
    public const ENTRY_MAPPING_OPTIONAL = ['vendor', 'treatment', 'mappingStatus', 'unlimitedGuests', 'features', 'baseEntitlement', 'workstation', 'selfSupportPhysicalOnly', 'requiresBase', 'nodePackSize', 'embeddedLifecycle', 'bundleComponents', 'minimumOffering', 'exclusionCode', 'catalogStatus', 'sourceUrl', 'supportLevel'];
    public const ENTRY_PRICE_FIELDS = ['referencePrice', 'scenarioPrice', 'priceBasis', 'effectiveOn', 'verifiedOn', 'currency', 'term', 'approval'];
    public const OFFERING_MAPPING_FIELDS = ['description', 'unit', 'olam'];
    public const OFFERING_PRICE_REQUIRED = ['price', 'priceBasis'];
    public const OFFERING_PRICE_OPTIONAL = ['priceVersion', 'currency', 'term', 'effectiveOn', 'verifiedOn', 'sourceUrl'];
    public const PRICE_FIELDS = ['id', 'amount', 'currency', 'metric', 'periodBasis', 'termMonths', 'basis', 'verification', 'evidence', 'reason', 'approvedBy', 'approvedAt', 'effectiveOn', 'observedOn', 'originalAmount', 'installments'];
    public const FEATURES = ['CORE_OS_SUPPORT', 'OSMH', 'HA_COROSYNC_PACEMAKER', 'OLAM', 'UNLIMITED_VM_HOST'];
    public const SOURCE_UNITS = [
        'SYSTEM', 'NODE_PACK', 'CORE', 'SUBSCRIPTION', 'Physical server', 'Physical/virtual nodes',
        'Hypervisor; unlimited RHEL guests', 'Hypervisor; unlimited guests', '1 physical workstation + 1 VM guest',
        'Power entitlement', 'Limited guests / underlying RHEL entitlement', 'Unlimited guests', 'Limited guests',
        'Limited guests / physical or virtual nodes', 'Physical/virtual-node entitlement',
        '1 physical 2-socket server or 2 VMs', 'Unlimited VMs on 2-socket virtualization host', 'Enterprise footprint',
        'Physical or virtual node', 'Physical server or virtual nodes', '2-socket virtualization host; unlimited guests',
        'Virtual datacenter', '100 managed nodes', '5,000 managed nodes', '10,000 managed nodes', '2 cores / 4 vCPU',
        '1-2 sockets, up to 64 cores', '1-2 sockets', '1 deployment', '16 cores', '64 cores',
        '16 cores / 32 vCPU', '64 cores / 128 vCPU', '2 cores',
    ];
}
