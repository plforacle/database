<?php

declare(strict_types=1);

namespace App\Domain\Package;

use App\Domain\Coverage\CoverageCatalog;
use App\Domain\Coverage\ScenarioPricing;
use App\Domain\Shared\DomainViolation;

/**
 * One immutable admitted package selection for a complete comparison operation.
 * @phpstan-import-type Entry from CoverageCatalog
 * @phpstan-import-type Offering from CoverageCatalog
 * @phpstan-import-type Price from ScenarioPricing
 * @phpstan-type Context array{format:string,channel:string,generation:int,releaseId:string,manifestSha256:string,mappingId:string,mappingSha256:string,priceId:string,priceSha256:string,profileId:string,inputSchema:string,resultSchema:string,ruleModel:string,olamRule:string,vmwareRule:string}
 */
final readonly class CatalogSnapshot
{
    public const OLAM_RULE = 'OLAM-2026-06-15';
    public const VMWARE_RULE = 'VCF-CORE-PER-PROCESSOR-16-v1';

    public function __construct(
        private SemanticCatalogPackage $package,
        private string $profileId,
        private string $channel = 'coverage',
        private int $generation = 0,
    ) {
        StrictJsonObjectDecoder::identifier($channel);
        if (!isset($package->envelope()->profiles()[$profileId])) {
            throw DomainViolation::because('Unknown catalog snapshot profile.');
        }
        if ($generation < 0) {
            throw DomainViolation::because('Catalog snapshot generation must be nonnegative.');
        }
    }

    public function package(): SemanticCatalogPackage
    {
        return $this->package;
    }

    public function profileId(): string
    {
        return $this->profileId;
    }

    /** @return Context */
    public function context(): array
    {
        $envelope = $this->package->envelope();
        return [
            'format' => 'catalog-snapshot-1', 'channel' => $this->channel, 'generation' => $this->generation,
            'releaseId' => $this->releaseId(), 'manifestSha256' => $this->manifestDigest(),
            'mappingId' => $this->mappingVersion(), 'mappingSha256' => $envelope->member('mappings')->digest(),
            'priceId' => $this->priceVersion(), 'priceSha256' => $envelope->member('prices')->digest(),
            'profileId' => $this->profileId, ...$envelope->profiles()[$this->profileId],
            'olamRule' => self::OLAM_RULE, 'vmwareRule' => self::VMWARE_RULE,
        ];
    }

    /** @return array<string,Entry> */
    public function entries(): array
    {
        return $this->package->entries($this->profileId);
    }

    /** @return array<string,Offering> */
    public function offerings(): array
    {
        return $this->package->offerings($this->profileId);
    }

    /** @return array<string,Price> */
    public function scenarioPrices(): array
    {
        return $this->package->scenarioPrices($this->profileId);
    }

    /** @return Price */
    public function scenarioPrice(string $priceId, string $sku): array
    {
        return $this->package->scenarioPrice($this->profileId, $priceId, $sku);
    }

    public function priceVersion(): string
    {
        return $this->package->envelope()->member('prices')->id();
    }

    public function mappingVersion(): string
    {
        return $this->package->envelope()->member('mappings')->id();
    }

    public function releaseId(): string
    {
        return $this->package->envelope()->releaseId();
    }

    public function manifestDigest(): string
    {
        return $this->package->envelope()->manifestDigest();
    }
}
