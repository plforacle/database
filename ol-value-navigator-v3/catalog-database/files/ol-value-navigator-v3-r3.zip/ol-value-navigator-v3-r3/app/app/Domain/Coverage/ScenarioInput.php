<?php

declare(strict_types=1);

namespace App\Domain\Coverage;

use App\Domain\Shared\DomainViolation;

/** Strict transport boundary for reviewed v1.3.1 inputs; no inferred business confirmations. */
final class ScenarioInput
{
    public const VERSION = '1.3.1';
    public const QUANTITY_BASES = ['PURCHASED', 'MANIFEST_ALLOCATED', 'HOST_ASSOCIATED', 'HOST_INVENTORY', 'CONSUMPTION', 'ASSUMED', 'UNKNOWN'];

    /** @param array<string,mixed> $input
     * @return array<string,mixed>
     */
    public static function normalize(array $input): array
    {
        $encoded = json_encode($input);
        if ($encoded === false || strlen($encoded) > 4 * 1024 * 1024) {
            throw DomainViolation::because('The scenario is invalid or exceeds the 4 MB input limit.');
        }
        $result = self::record($input, self::schema());
        foreach ($result['lines'] as &$line) {
            $line['sku'] = strtoupper($line['sku']);
        }
        unset($line);
        return $result;
    }

    /** @return array<string,mixed> */
    public static function example(): array
    {
        return self::normalize([
            'customer' => ['name' => 'Synthetic v1.3.1 review', 'objective' => 'Compare subscription costs', 'scope' => 'One synthetic physical system'],
            'period' => ['months' => 12, 'constantRateConfirmed' => true, 'evidence' => 'Synthetic annual constant-rate example'],
            'scope' => ['label' => 'Synthetic server', 'state' => 'ASSUMED', 'evidence' => 'One distinct physical target for this illustration'],
            'groups' => [['id' => 'g1', 'label' => 'Synthetic server', 'populationKey' => 'synthetic-server-1', 'systems' => 1, 'deployment' => 'PHYSICAL', 'coverage' => ['state' => 'ASSUMED', 'evidence' => 'One dedicated two-CPU physical target']]],
            'lines' => [['id' => 'l1', 'sourceId' => 'synthetic-source-1', 'rawSku' => 'RH00005', 'sku' => 'RH00005', 'identityState' => 'CATALOG', 'quantity' => 1, 'quantityBasis' => 'ASSUMED', 'quantityState' => ['state' => 'ASSUMED', 'evidence' => 'One synthetic purchased subscription'], 'groupIds' => ['g1'], 'coverage' => ['state' => 'ASSUMED', 'evidence' => 'One purchased base for one physical target'], 'sourceEstate' => ['deployment' => 'PHYSICAL', 'systems' => 1, 'cpusPerSystem' => 2]]],
        ]);
    }

    /** @return array<string,mixed> */
    private static function schema(): array
    {
        $state = self::state();
        $price = self::price();
        $period = ['months' => self::enum([12, 36], 12), 'currency' => self::enum(['USD']), 'startDate' => self::text(40), 'endDate' => self::text(40), 'dateLocale' => self::enum(['ISO', 'MDY', 'DMY']), 'inclusiveEnd' => ['type' => 'nullableBool', 'default' => null], 'model' => self::enum(['CONSTANT_RATE', 'HISTORICAL_ACTUAL', 'FUTURE_RENEWAL']), 'constantRateConfirmed' => self::bool(), 'evidence' => self::text(2000), 'asOfDate' => self::text(40)];
        $source = ['deployment' => self::enum(['UNKNOWN', 'PHYSICAL', 'VIRTUAL_GUEST']), 'systems' => self::count(), 'cpusPerSystem' => self::count(1024), 'guests' => self::count(), 'managedNodes' => self::count(), 'prerequisiteEvidence' => self::text(2000), 'duplicateEvidence' => self::text(2000)];
        $vmware = ['intent' => self::enum(['UNRESOLVED', 'RETAIN_VMWARE', 'REPLACE_VIRTUALIZATION']), 'quantityMode' => self::enum(['CUSTOMER_PRICED_UNITS', 'HARDWARE_DERIVED_ESTIMATE']), 'productVersion' => self::text(160), 'metric' => self::enum(['CORE']), 'sourceHosts' => self::rows(['id' => self::text(80), 'cpus' => self::list(self::count(8192), 1024)], 500), 'commercialPolicy' => self::object($state + ['version' => self::text(160), 'minimum' => self::count(), 'step' => self::count(), 'scope' => self::enum(['ORDER'])]), 'sizing' => self::object($state), 'retirement' => self::object($state + ['date' => self::text(40), 'commitmentEnd' => self::text(40)]), 'features' => self::rows(['name' => self::text(160), 'status' => self::enum(['UNRESOLVED', 'COVERED', 'OUT_OF_SCOPE', 'RETAINED', 'REPLACED']), 'evidence' => self::text(2000), 'costIds' => self::list(self::text(80), 100)], 100)];
        return [
            'schemaVersion' => self::enum([self::VERSION]),
            'customer' => self::object(['name' => self::text(80), 'objective' => self::text(1000), 'scope' => self::text(1000), 'nextStep' => self::text(1000)]),
            'mode' => self::enum(['ILLUSTRATIVE', 'VALIDATED_PUBLIC']),
            'period' => self::object($period),
            'scope' => self::object(['label' => self::text(160)] + $state + ['reduced' => self::bool()]),
            'groups' => self::rows(['id' => self::text(80), 'label' => self::text(160), 'populationKey' => self::text(160), 'systemIds' => self::list(self::text(160), 2000), 'systems' => self::count(), 'cpusPerSystem' => self::count(1024, 2), 'deployment' => self::enum(['UNKNOWN', 'PHYSICAL', 'VIRTUAL_GUEST', 'CLOUD']), 'offering' => self::text(80), 'coverage' => self::object($state), 'olamRequired' => self::bool(), 'workstationScope' => self::enum(['UNRESOLVED', 'OS_ONLY_GUEST_EXCLUDED'])], 100),
            'lines' => self::rows(['id' => self::text(80), 'sourceId' => self::text(160), 'rawSku' => self::text(160, true), 'sku' => self::text(160), 'description' => self::text(2000), 'adoptedDescription' => self::text(2000), 'identityState' => self::enum(['UNRESOLVED', 'CATALOG', 'VERIFIED', 'CONFLICT']), 'identityEvidence' => self::text(2000), 'rowType' => self::enum(['PRODUCT', 'HEADER', 'TOTAL', 'NOTE', 'EMPTY']), 'selected' => self::bool(true), 'quantity' => self::count(), 'quantityBasis' => self::enum(self::QUANTITY_BASES, 'UNKNOWN'), 'quantityState' => self::object($state), 'groupIds' => self::list(self::text(80), 100), 'coverage' => self::object($state), 'subscriptionId' => self::text(160), 'poolId' => self::text(160), 'organization' => self::text(160), 'startDate' => self::text(40), 'endDate' => self::text(40), 'selectionReason' => self::text(2000), 'sourceEstate' => self::object($source), 'price' => self::object($price, true), 'priceRecordId' => self::text(160), 'suppliedTotal' => self::money(), 'suppliedTotalBasis' => self::enum(['UNKNOWN', 'ANNUAL', 'FULL_TERM']), 'suppliedTotalCurrency' => self::enum(['USD']), 'corrections' => self::rows(['field' => self::text(160), 'oldValue' => self::rawScalar(), 'newValue' => self::rawScalar(), 'actor' => self::text(160), 'at' => self::text(40), 'reason' => self::text(2000), 'evidence' => self::text(2000)], 50), 'vmware' => self::object($vmware, true)], 500),
            'pools' => self::rows(['id' => self::text(80), 'groupIds' => self::list(self::text(80), 100), 'allocations' => self::rows(['groupId' => self::text(80), 'pairs' => self::count(512000000)], 100), 'uniqueNodes' => self::count(1000000000), 'coverage' => self::object($state), 'extraPurchases' => self::rows(['id' => self::text(80), 'offering' => self::enum(['OL-PREMIER', 'OL-PREMIER-PLUS']), 'units' => self::count(1000000, 0)], 100)], 100),
            'otherCosts' => self::rows(['id' => self::text(80), 'label' => self::text(160), 'sku' => self::text(160), 'groupIds' => self::list(self::text(80), 100), 'side' => self::enum(['BOTH', 'SOURCE', 'TARGET']), 'required' => self::bool(true), 'price' => self::object($price)], 100),
            'snapshots' => ['type' => 'snapshots', 'default' => []],
        ];
    }

    /** @return array<string,mixed> */
    private static function price(): array
    {
        return ['id' => self::text(160), 'amount' => self::money(), 'currency' => self::enum(['USD']), 'metric' => self::text(160), 'periodBasis' => self::enum(['UNKNOWN', 'ANNUAL_UNIT_RATE', 'ANNUAL_INSTALLMENT', 'FULL_TERM_UNIT_PRICE', 'FULL_TERM_LINE_TOTAL']), 'termMonths' => self::enum([12, 36], 12), 'basis' => self::enum(['SCENARIO_SUPPLIED', 'MANUFACTURER_LIST', 'RESELLER_ADVERTISED', 'HISTORICAL_PUBLIC']), 'verification' => self::enum(['UNVERIFIED', 'USER_VERIFIED', 'INDEPENDENTLY_VERIFIED_PUBLIC']), 'evidence' => self::text(2000), 'reason' => self::text(2000), 'approvedBy' => self::text(160), 'approvedAt' => self::text(40), 'effectiveOn' => self::text(40), 'observedOn' => self::text(40), 'originalAmount' => self::money(), 'installments' => self::list(self::money(), 3)];
    }

    /** @return array<string,mixed> */
    private static function state(): array
    {
        return ['state' => self::enum(['UNRESOLVED', 'ASSUMED', 'CONFIRMED']), 'evidence' => self::text(2000), 'actor' => self::text(160), 'at' => self::text(40)];
    }

    /** @param array<string,mixed> $schema
     * @return array<string,mixed>
     */
    private static function record(mixed $input, array $schema): array
    {
        if (!is_array($input) || ($input !== [] && array_is_list($input)) || array_diff(array_keys($input), array_keys($schema)) !== []) {
            throw DomainViolation::because('The scenario contains an unsupported field or invalid structured record.');
        }
        $result = [];
        foreach ($schema as $key => $descriptor) {
            $result[$key] = self::value(array_key_exists($key, $input) ? $input[$key] : $descriptor['default'], $descriptor);
        }
        return $result;
    }

    /** @param array<string,mixed> $descriptor */
    private static function value(mixed $value, array $descriptor): mixed
    {
        switch ($descriptor['type']) {
            case 'text':
                return self::safeText($value, $descriptor['max'], $descriptor['raw']);
            case 'count':
                if ($value === null || $value === '') {
                    return null;
                }
                if (is_string($value) && preg_match('/^\d{1,10}$/D', $value) === 1) {
                    $value = (int) $value;
                }
                if (!is_int($value) || $value < 0 || $value > $descriptor['max']) {
                    throw DomainViolation::because('Counts must be bounded whole numbers or blank when unknown.');
                }
                return $value;
            case 'money':
                if ($value === null || $value === '') {
                    return null;
                }
                if (!is_string($value) || preg_match('/^\d{1,15}(?:\.\d{1,6})?$/D', $value) !== 1) {
                    throw DomainViolation::because('Money must be a nonnegative exact decimal string, or blank when unknown.');
                }
                return $value;
            case 'enum':
                if (!in_array($value, $descriptor['values'], true)) {
                    throw DomainViolation::because('Select a supported scenario option.');
                }
                return $value;
            case 'bool':
            case 'nullableBool':
                if (!is_bool($value) && !($descriptor['type'] === 'nullableBool' && $value === null)) {
                    throw DomainViolation::because('Confirmations must be explicit boolean values.');
                }
                return $value;
            case 'object':
                if ($value === null && $descriptor['nullable']) {
                    return null;
                }
                return self::record($value, $descriptor['schema']);
            case 'list':
                if (!is_array($value) || !array_is_list($value) || count($value) > $descriptor['max']) {
                    throw DomainViolation::because('Scenario lists exceed their supported bounds or are malformed.');
                }
                return array_map(static fn (mixed $item): mixed => self::value($item, $descriptor['item']), $value);
            case 'raw':
                if ($value === null || is_bool($value) || is_int($value)) {
                    return $value;
                }
                return self::safeText($value, 4000, true);
            case 'snapshots':
                if (!is_array($value) || !array_is_list($value) || count($value) > 20) {
                    throw DomainViolation::because('At most 20 source snapshots are supported.');
                }
                return array_map(static fn (mixed $snapshot): array => ScenarioImport::normalizeSnapshot($snapshot), $value);
        }
        throw new \LogicException('Unknown scenario field descriptor.');
    }

    /** Shared text validation for private, non-executing evidence. Raw strings retain whitespace. */
    public static function safeText(mixed $value, int $maximum = 2000, bool $raw = false): string
    {
        if (!is_string($value) || !mb_check_encoding($value, 'UTF-8') || mb_strlen($value) > $maximum || preg_match('/[\x00-\x08\x0B\x0C\x0E-\x1F\x{FFFE}\x{FFFF}]/u', $value) === 1) {
            throw DomainViolation::because('Scenario text is too long or contains invalid characters.');
        }
        if (!$raw && preg_match('~\b(?:javascript|vbscript)\s*:|\bdata:[^,\s]*,|\b(?:file|ftp|gopher|php)\s*://~i', $value) === 1) {
            throw DomainViolation::because('Evidence links must use safe HTTP or HTTPS addresses.');
        }
        return $raw ? $value : trim($value);
    }

    /** @return array<string,mixed> */
    private static function text(int $max, bool $raw = false): array
    {
        return ['type' => 'text', 'default' => '', 'max' => $max, 'raw' => $raw];
    }
    /** @return array<string,mixed> */
    private static function count(int $max = 1000000, ?int $default = null): array
    {
        return ['type' => 'count', 'default' => $default, 'max' => $max];
    }
    /** @param list<string|int> $values
     * @return array<string,mixed>
     */
    private static function enum(array $values, string|int|null $default = null): array
    {
        return ['type' => 'enum', 'default' => $default ?? $values[0], 'values' => $values];
    }
    /** @return array<string,mixed> */
    private static function bool(bool $default = false): array
    {
        return ['type' => 'bool', 'default' => $default];
    }
    /** @return array<string,mixed> */
    private static function money(): array
    {
        return ['type' => 'money', 'default' => null];
    }
    /** @return array<string,mixed> */
    private static function rawScalar(): array
    {
        return ['type' => 'raw', 'default' => ''];
    }
    /** @param array<string,mixed> $schema
     * @return array<string,mixed>
     */
    private static function object(array $schema, bool $nullable = false): array
    {
        return ['type' => 'object', 'default' => $nullable ? null : [], 'nullable' => $nullable, 'schema' => $schema];
    }
    /** @param array<string,mixed> $item
     * @return array<string,mixed>
     */
    private static function list(array $item, int $max): array
    {
        return ['type' => 'list', 'default' => [], 'item' => $item, 'max' => $max];
    }
    /** @param array<string,mixed> $schema
     * @return array<string,mixed>
     */
    private static function rows(array $schema, int $max): array
    {
        return self::list(self::object($schema), $max);
    }
}
