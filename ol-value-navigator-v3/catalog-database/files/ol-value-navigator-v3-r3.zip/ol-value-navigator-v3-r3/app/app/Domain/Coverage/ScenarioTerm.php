<?php

declare(strict_types=1);

namespace App\Domain\Coverage;

/** @phpstan-type Issue array{code:string,message:string}
 * @phpstan-type Result array{ready:bool,months:int,multiplier:int,startDate:string,endDate:string,coveredDays:?int,issues:list<Issue>}
 */
final class ScenarioTerm
{
    /** @param array<string,mixed> $period
     * @return Result
     */
    public static function evaluate(array $period): array
    {
        $months = $period['months'] ?? 12;
        $issues = [];
        if (!in_array($months, [12, 36], true)) {
            $issues[] = self::issue('TERM_REVIEW', 'Only explicitly selected 12- or 36-month comparisons are supported.');
        }
        if (($period['currency'] ?? 'USD') !== 'USD') {
            $issues[] = self::issue('TERM_CURRENCY_REVIEW', 'This comparison supports USD only; no currency conversion is inferred.');
        }
        if (!in_array($period['model'] ?? 'CONSTANT_RATE', ['CONSTANT_RATE', 'HISTORICAL_ACTUAL', 'FUTURE_RENEWAL'], true)) {
            $issues[] = self::issue('TERM_MODEL_REVIEW', 'Select a constant-rate, historical-actual or future-renewal model.');
        }
        if ($months === 36 && in_array($period['model'] ?? 'CONSTANT_RATE', ['CONSTANT_RATE', 'FUTURE_RENEWAL'], true)
            && (($period['constantRateConfirmed'] ?? false) !== true || trim((string) ($period['evidence'] ?? '')) === '')) {
            $issues[] = self::issue('CONSTANT_RATE_REVIEW', 'Record approval and evidence for the 36-month constant-rate assumption.');
        }
        $rawStart = (string) ($period['startDate'] ?? '');
        $rawEnd = (string) ($period['endDate'] ?? '');
        $start = $end = null;
        $days = null;
        if ($rawStart !== '' || $rawEnd !== '') {
            $locale = (string) ($period['dateLocale'] ?? 'ISO');
            $start = ScenarioDates::parse($rawStart, $locale);
            $end = ScenarioDates::parse($rawEnd, $locale);
            $inclusive = $period['inclusiveEnd'] ?? null;
            if ($start === null || $end === null) {
                $issues[] = self::issue('TERM_DATE_REVIEW', 'Provide both valid calendar dates with an explicit matching locale.');
            } elseif (!is_bool($inclusive)) {
                $issues[] = self::issue('TERM_END_CONVENTION_REVIEW', 'Confirm whether the ending date is inclusive; no day-count convention is inferred.');
            } elseif (in_array($months, [12, 36], true)) {
                $anniversary = $start->modify('+' . $months . ' months');
                if ($anniversary->format('m-d') !== $start->format('m-d')) {
                    $issues[] = self::issue('TERM_ANNIVERSARY_REVIEW', 'The leap-day anniversary is ambiguous; no automatic date repair is applied.');
                } else {
                    $boundary = $inclusive ? $end->modify('+1 day') : $end;
                    if ($boundary != $anniversary || $boundary <= $start) {
                        $issues[] = self::issue('TERM_ANNIVERSARY_REVIEW', 'The supplied dates do not match the selected calendar anniversary term.');
                    } else {
                        $days = (int) $start->diff($boundary)->format('%a');
                    }
                }
            }
        }
        return [
            'ready' => $issues === [], 'months' => is_int($months) ? $months : 0,
            'multiplier' => $months === 36 ? 3 : ($months === 12 ? 1 : 0),
            'startDate' => $start?->format('Y-m-d') ?? $rawStart,
            'endDate' => $end?->format('Y-m-d') ?? $rawEnd, 'coveredDays' => $days, 'issues' => $issues,
        ];
    }

    /** @return Issue */
    private static function issue(string $code, string $message): array
    {
        return ['code' => $code, 'message' => $message];
    }
}
