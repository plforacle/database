<?php

declare(strict_types=1);

namespace App\Domain\Package;

use App\Domain\Shared\DomainViolation;
use JsonException;
use stdClass;

/** @internal Shared parsing rules for the package value factories. */
final class StrictJsonObjectDecoder
{
    public static function decode(string $json, int $maxBytes): stdClass
    {
        if (strlen($json) > $maxBytes) {
            throw DomainViolation::because('Package JSON exceeds its byte limit.');
        }
        try {
            // PHP counts one extra level: this permits at most 32 nested containers.
            $value = json_decode($json, false, 33, JSON_THROW_ON_ERROR);
        } catch (JsonException) {
            throw DomainViolation::because('Package JSON is invalid or exceeds depth 32.');
        }
        if (!$value instanceof stdClass) {
            throw DomainViolation::because('Package JSON must be an object.');
        }
        $offset = 0;
        self::scanValue($json, $offset);

        return $value;
    }

    /** @param list<string> $keys */
    public static function keys(stdClass $object, array $keys): void
    {
        $actual = array_map(strval(...), array_keys(get_object_vars($object)));
        sort($actual, SORT_STRING);
        sort($keys, SORT_STRING);
        if ($actual !== $keys) {
            throw DomainViolation::because('Package object fields do not match the contract.');
        }
    }

    public static function identifier(mixed $value): string
    {
        if (!is_string($value) || preg_match('/\A[A-Za-z0-9][A-Za-z0-9._-]{0,99}\z/D', $value) !== 1) {
            throw DomainViolation::because('Package identifier is invalid.');
        }

        return $value;
    }

    public static function object(mixed $value): stdClass
    {
        if (!$value instanceof stdClass) {
            throw DomainViolation::because('Package field must be an object.');
        }

        return $value;
    }

    /**
     * Walk syntax already accepted by PHP. Decode only object keys, comparing their
     * Unicode values; strings in values cannot be confused with structural tokens.
     * Each object's key set is discarded when that object ends.
     */
    private static function scanValue(string $json, int &$offset): void
    {
        self::whitespace($json, $offset);
        $start = $json[$offset];
        if ($start === '"') {
            self::scanString($json, $offset);
            return;
        }
        if ($start !== '{' && $start !== '[') {
            $offset += strcspn($json, ",]} \n\r\t", $offset);
            return;
        }
        $object = $start === '{';
        $end = $object ? '}' : ']';
        ++$offset;
        self::whitespace($json, $offset);
        $seen = [];
        if ($json[$offset] === $end) {
            ++$offset;
            return;
        }
        while (true) {
            if ($object) {
                self::whitespace($json, $offset);
                $keyStart = $offset;
                self::scanString($json, $offset);
                $key = json_decode(substr($json, $keyStart, $offset - $keyStart), false, 33, JSON_THROW_ON_ERROR);
                // Prefix prevents PHP's numeric-string array-key coercion.
                $key = ':' . $key;
                if (isset($seen[$key])) {
                    throw DomainViolation::because('Package JSON contains a duplicate object key.');
                }
                $seen[$key] = true;
                self::whitespace($json, $offset);
                ++$offset; // colon, already validated by PHP
            }
            self::scanValue($json, $offset);
            self::whitespace($json, $offset);
            if ($json[$offset++] === $end) {
                return;
            }
        }
    }

    private static function scanString(string $json, int &$offset): void
    {
        ++$offset;
        while (true) {
            $offset += strcspn($json, "\"\\", $offset);
            if ($json[$offset++] === '"') {
                return;
            }
            ++$offset; // skip the escaped byte; PHP has validated escape syntax
        }
    }

    private static function whitespace(string $json, int &$offset): void
    {
        $offset += strspn($json, " \n\r\t", $offset);
    }
}
