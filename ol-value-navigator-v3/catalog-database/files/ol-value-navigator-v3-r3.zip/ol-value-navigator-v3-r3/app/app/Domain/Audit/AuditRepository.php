<?php

declare(strict_types=1);

namespace App\Domain\Audit;

use App\Domain\Analysis\AnalysisState;
use App\Domain\Shared\Actor;
use App\Domain\Shared\RequestId;
use App\Domain\Shared\RevisionId;

interface AuditRepository
{
    /**
     * Appends an immutable event; callers cannot supply SQL, role, or sort fragments.
     */
    public function append(
        RevisionId $revisionId,
        Actor $actor,
        AuditAction $action,
        ?AnalysisState $previousState,
        ?AnalysisState $resultingState,
        RequestId $requestId,
    ): void;
}
