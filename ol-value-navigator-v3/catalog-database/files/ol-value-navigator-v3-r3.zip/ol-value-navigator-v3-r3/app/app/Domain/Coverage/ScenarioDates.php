<?php

declare(strict_types=1);

namespace App\Domain\Coverage;

use DateTimeImmutable;
use DateTimeZone;

/** Strict calendar parsing shared by term, source coverage and retirement checks. */
final class ScenarioDates
{
    public static function parse(string $value, string $locale = 'ISO'): ?DateTimeImmutable
    {
        $formats = preg_match('/^\d{4}-\d{2}-\d{2}$/D', $value) === 1 ? ['Y-m-d'] : match ($locale) {
            'MDY' => ['n/j/Y', 'n/j/y', 'm/d/Y', 'm/d/y'],
            'DMY' => ['j/n/Y', 'j/n/y', 'd/m/Y', 'd/m/y'], default => [],
        };
        foreach ($formats as $format) {
            $date = DateTimeImmutable::createFromFormat('!' . $format, $value, new DateTimeZone('UTC'));
            $errors = DateTimeImmutable::getLastErrors();
            if ($date !== false && ($errors === false || ($errors['warning_count'] === 0 && $errors['error_count'] === 0)) && $date->format($format) === $value) {
                return $date;
            }
        }
        return null;
    }
}
