<?php

declare(strict_types=1);

namespace App\Domain\Package;

use App\Domain\Shared\DomainViolation;
use stdClass;

/**
 * Integrity and compatibility only. Never a runtime snapshot or approval.
 * @phpstan-type Profiles array<array-key, array{inputSchema:string, resultSchema:string, ruleModel:string}>
 * @phpstan-type MemberSchemas array{mappings:list<string>, prices:list<string>}
 */
final readonly class PackageEnvelope
{
    /**
     * @param Profiles $profiles
     * @param non-empty-list<string> $evidenceReferences
     */
    private function __construct(
        private string $releaseId,
        private string $manifestJson,
        private array $profiles,
        private array $evidenceReferences,
        private PackageMember $mappings,
        private PackageMember $prices,
    ) {
    }

    /**
     * Every public construction path applies the same invariants.
     * @param Profiles $supportedProfiles
     * @param MemberSchemas $supportedMemberSchemas
     */
    public static function fromJson(
        string $manifestJson,
        string $mappingJson,
        string $priceJson,
        array $supportedProfiles,
        array $supportedMemberSchemas,
    ): self {
        $root = StrictJsonObjectDecoder::decode($manifestJson, 64 * 1024);
        StrictJsonObjectDecoder::keys($root, ['schemaVersion', 'releaseId', 'profiles', 'members', 'evidenceReferences']);
        if ($root->schemaVersion !== 'olvn-release-envelope-1') {
            throw DomainViolation::because('Unsupported package envelope schema.');
        }
        $releaseId = StrictJsonObjectDecoder::identifier($root->releaseId);
        $profiles = self::validateProfiles(StrictJsonObjectDecoder::object($root->profiles), $supportedProfiles);
        $evidence = $root->evidenceReferences;
        if (!is_array($evidence) || !array_is_list($evidence) || $evidence === []) {
            throw DomainViolation::because('Package evidence references must be a nonempty list.');
        }
        foreach ($evidence as $reference) {
            if (!is_string($reference) || trim($reference) === '' || strlen($reference) > 1024) {
                throw DomainViolation::because('Package evidence reference is invalid.');
            }
        }
        $descriptors = StrictJsonObjectDecoder::object($root->members);
        StrictJsonObjectDecoder::keys($descriptors, ['mappings', 'prices']);
        $mappings = PackageMember::fromJson($mappingJson);
        $prices = PackageMember::fromJson($priceJson);
        foreach (['mappings' => $mappings, 'prices' => $prices] as $kind => $member) {
            $descriptor = StrictJsonObjectDecoder::object($descriptors->{$kind});
            StrictJsonObjectDecoder::keys($descriptor, ['memberId', 'schemaVersion', 'sha256']);
            $digest = $descriptor->sha256;
            if (!is_string($digest) || preg_match('/\A[0-9a-f]{64}\z/D', $digest) !== 1
                || !hash_equals($member->digest(), $digest)) {
                throw DomainViolation::because('Package member digest is invalid or does not match.');
            }
            if ($descriptor->memberId !== $member->id() || $descriptor->schemaVersion !== $member->schemaVersion()) {
                throw DomainViolation::because('Package member identity does not match its descriptor.');
            }
            if (!in_array($member->schemaVersion(), $supportedMemberSchemas[$kind], true)) {
                throw DomainViolation::because('Unsupported package member schema.');
            }
            $expected = array_map(strval(...), array_keys($profiles));
            $actual = $member->profileIds();
            sort($expected, SORT_STRING);
            sort($actual, SORT_STRING);
            if ($actual !== $expected) {
                throw DomainViolation::because('Package member profile set does not match.');
            }
        }

        return new self($releaseId, $manifestJson, $profiles, $evidence, $mappings, $prices);
    }

    /**
     * @param Profiles $supported
     * @return Profiles
     */
    private static function validateProfiles(stdClass $profiles, array $supported): array
    {
        if ($supported === []) {
            throw DomainViolation::because('Supported package profiles must not be empty.');
        }
        StrictJsonObjectDecoder::keys($profiles, array_map(strval(...), array_keys($supported)));
        $result = [];
        foreach ($supported as $id => $tuple) {
            StrictJsonObjectDecoder::identifier((string) $id);
            $actual = StrictJsonObjectDecoder::object($profiles->{$id});
            StrictJsonObjectDecoder::keys($actual, ['inputSchema', 'resultSchema', 'ruleModel']);
            foreach (['inputSchema', 'resultSchema', 'ruleModel'] as $field) {
                StrictJsonObjectDecoder::identifier($actual->{$field});
                if ($actual->{$field} !== $tuple[$field]) {
                    throw DomainViolation::because('Unsupported package compatibility tuple.');
                }
            }
            $result[$id] = [
                'inputSchema' => $actual->inputSchema,
                'resultSchema' => $actual->resultSchema,
                'ruleModel' => $actual->ruleModel,
            ];
        }

        return $result;
    }

    public function releaseId(): string
    {
        return $this->releaseId;
    }

    public function manifestDigest(): string
    {
        return hash('sha256', $this->manifestJson);
    }

    public function manifestJson(): string
    {
        return $this->manifestJson;
    }

    /** @return Profiles */
    public function profiles(): array
    {
        return $this->profiles;
    }

    /** @return non-empty-list<string> */
    public function evidenceReferences(): array
    {
        return $this->evidenceReferences;
    }

    public function member(string $kind): PackageMember
    {
        return match ($kind) {
            'mappings' => $this->mappings,
            'prices' => $this->prices,
            default => throw DomainViolation::because('Unknown package member kind.'),
        };
    }
}
