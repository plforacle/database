<?php

declare(strict_types=1);

namespace App\Domain\Audit;

enum AuditAction
{
    case ANALYSIS_CREATED;
    case EXTRACTION_COMPLETED;
    case EXTRACTION_FAILED;
    case LINE_CONFIRMED;
    case LINE_CORRECTED;
    case LINE_EXCLUDED;
    case ANALYSIS_CONFIRMED;
    case CALCULATION_PRODUCED;
    case CALCULATION_WITHHELD;
}
