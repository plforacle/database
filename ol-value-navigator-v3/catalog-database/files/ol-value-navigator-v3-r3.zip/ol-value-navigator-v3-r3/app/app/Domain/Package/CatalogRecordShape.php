<?php

declare(strict_types=1);

namespace App\Domain\Package;

use App\Domain\Shared\DomainViolation;
use stdClass;

/** @internal Typed wire primitives. Reasons contain only developer-owned locations. */
final class CatalogRecordShape
{
    /** @param list<string> $required
     * @param list<string> $optional
     * @return array<string,mixed>
     */
    public static function record(mixed $value, array $required, array $optional = [], string $location = 'record'): array
    {
        self::check($value instanceof stdClass, $location, 'object required');
        /** @var stdClass $value */
        $fields = get_object_vars($value);
        self::check(array_diff($required, array_keys($fields)) === [] && array_diff(array_keys($fields), [...$required, ...$optional]) === [], $location, 'fields do not match contract');
        return $fields;
    }

    /** @return array<string,mixed> */
    public static function records(mixed $value, int $limit, string $location): array
    {
        self::check($value instanceof stdClass, $location, 'record map required');
        /** @var stdClass $value */
        $records = get_object_vars($value);
        self::check(count($records) <= $limit, $location, 'record count exceeded');
        foreach ($records as $id => $record) {
            StrictJsonObjectDecoder::identifier((string) $id);
            self::check($record instanceof stdClass, $location, 'record object required');
        }
        return $records;
    }

    public static function text(mixed $value, string $location, int $limit = CatalogPackageContract::TEXT_BYTES, bool $nonblank = false): string
    {
        self::check(is_string($value), $location, 'text required');
        /** @var string $value */
        self::check(strlen($value) <= $limit && (!$nonblank || trim($value) !== ''), $location, 'text length or content invalid');
        return $value;
    }

    /** @param list<string> $allowed */
    public static function choice(mixed $value, array $allowed, string $location): string
    {
        self::check(is_string($value) && in_array($value, $allowed, true), $location, 'unsupported value');
        /** @var string $value */
        return $value;
    }

    /** @param list<string> $allowed
     * @return list<string>
     */
    public static function selection(mixed $value, array $allowed, string $location, bool $nonempty = false): array
    {
        self::check(is_array($value) && array_is_list($value), $location, 'list required');
        /** @var list<mixed> $value */
        self::check(count($value) <= count($allowed) && (!$nonempty || $value !== []), $location, 'list count invalid');
        $allowedSet = [];
        foreach ($allowed as $item) {
            $allowedSet[':' . $item] = true;
        }
        $result = $seen = [];
        foreach ($value as $item) {
            self::check(is_string($item) && isset($allowedSet[':' . $item]), $location, 'unsupported selection');
            /** @var string $item */
            self::check(!isset($seen[':' . $item]), $location, 'duplicate selection');
            $seen[':' . $item] = true;
            $result[] = $item;
        }
        return $result;
    }

    /** @return array{kind:string,text:string} */
    public static function evidence(mixed $value, string $kind): array
    {
        $fields = self::record($value, ['kind', 'text'], location: 'evidence');
        return ['kind' => self::choice($fields['kind'], [$kind, 'LEGACY_MIXED'], 'evidence kind'), 'text' => self::text($fields['text'], 'evidence text', CatalogPackageContract::EVIDENCE_BYTES)];
    }

    public static function amount(mixed $value, int $integerDigits, int $fractionDigits, bool $nullable, bool $fixed = true): ?string
    {
        if ($value === null && $nullable) {
            return null;
        }
        $pattern = $fixed ? '/\A[0-9]{1,' . $integerDigits . '}\.[0-9]{' . $fractionDigits . '}\z/D' : '/\A[0-9]{1,' . $integerDigits . '}(?:\.[0-9]{1,' . $fractionDigits . '})?\z/D';
        self::check(is_string($value) && preg_match($pattern, $value) === 1, 'amount', 'nonnegative bounded decimal string required');
        /** @var string $value */
        return $value;
    }

    public static function check(bool $condition, string $location, string $reason): void
    {
        if (!$condition) {
            throw DomainViolation::because('Catalog ' . $location . ': ' . $reason . '.');
        }
    }
}
