<?php

declare(strict_types=1);

namespace App\Domain\Matching;

final readonly class MatchResult
{
    /**
     * @param list<EligibleOption> $eligibleOptions
     */
    private function __construct(
        private MatchState $state,
        private ?string $governedSku,
        private ?string $description,
        private ?string $unit,
        private ?string $annualUsdPrice,
        private array $eligibleOptions,
    ) {
    }

    /** @param list<EligibleOption> $eligibleOptions */
    public static function exact(
        string $governedSku,
        string $description,
        string $unit,
        ?string $annualUsdPrice,
        array $eligibleOptions,
    ): self {
        return new self(
            MatchState::EXACT,
            $governedSku,
            $description,
            $unit,
            $annualUsdPrice,
            $eligibleOptions,
        );
    }

    public static function unresolved(): self
    {
        return new self(MatchState::UNRESOLVED, null, null, null, null, []);
    }

    public function state(): MatchState
    {
        return $this->state;
    }

    public function governedSku(): ?string
    {
        return $this->governedSku;
    }

    public function description(): ?string
    {
        return $this->description;
    }

    public function unit(): ?string
    {
        return $this->unit;
    }

    public function annualUsdPrice(): ?string
    {
        return $this->annualUsdPrice;
    }

    /** @return list<EligibleOption> */
    public function eligibleOptions(): array
    {
        return $this->eligibleOptions;
    }
}
