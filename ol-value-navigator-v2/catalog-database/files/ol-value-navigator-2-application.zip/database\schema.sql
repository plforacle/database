-- Workbook-style persistence for source inputs, AI suggestions, human decisions,
-- deterministic result snapshots, workflow events, and retained deletion audits.
CREATE DATABASE IF NOT EXISTS ol_value_navigator_2
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_0900_ai_ci;

USE ol_value_navigator_2;

-- Stores application-managed identities. Passwords are created and verified by
-- PHP using password_hash and password_verify; plaintext credentials are never
-- stored. The active flag lets an administrator disable access without deleting
-- the identity or its future comparison ownership history.
CREATE TABLE IF NOT EXISTS user_account (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(64) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  active TINYINT(1) NOT NULL DEFAULT 1,
  last_login_at DATETIME NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY unique_user_account_username (username),
  CHECK (CHAR_LENGTH(username) BETWEEN 3 AND 64),
  CHECK (active IN (0, 1))
);

-- Identifies the deterministic calculation policy attached to each comparison.
-- The prototype seeds a demonstration rule and does not claim production approval.
CREATE TABLE IF NOT EXISTS calculation_rule_version (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  version_label VARCHAR(64) NOT NULL UNIQUE,
  description VARCHAR(500) NOT NULL,
  source_reference VARCHAR(255) NOT NULL,
  governance_status ENUM('DEMONSTRATION','APPROVED','RETIRED')
    NOT NULL DEFAULT 'DEMONSTRATION',
  approved_by VARCHAR(255) NULL,
  approved_at DATETIME NULL,
  active TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Parent workbook record. source_comparison_id records duplication lineage without
-- preventing deletion of the source, owner_user_id enforces durable ownership,
-- and rule_version_id makes results traceable.
CREATE TABLE IF NOT EXISTS comparison (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  owner_user_id BIGINT UNSIGNED NOT NULL,
  source_comparison_id BIGINT UNSIGNED NULL,
  name VARCHAR(255) NOT NULL,
  status ENUM('DRAFT','NEEDS_REVIEW','CONFIRMED','CALCULATED')
    NOT NULL DEFAULT 'DRAFT',
  rule_version_id BIGINT UNSIGNED NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_comparison_owner
    FOREIGN KEY (owner_user_id) REFERENCES user_account(id),
  CONSTRAINT fk_comparison_source
    FOREIGN KEY (source_comparison_id) REFERENCES comparison(id)
    ON DELETE SET NULL,
  CONSTRAINT fk_comparison_rule_version
    FOREIGN KEY (rule_version_id) REFERENCES calculation_rule_version(id),
  INDEX idx_comparison_owner_updated (owner_user_id, updated_at)
);

-- Preserves exactly one complete RHEL input and one complete Oracle Linux input per
-- comparison. Deleting the parent comparison cascades to all input-owned children.
CREATE TABLE IF NOT EXISTS comparison_input (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  comparison_id BIGINT UNSIGNED NOT NULL,
  input_side ENUM('RHEL','ORACLE_LINUX') NOT NULL,
  raw_text MEDIUMTEXT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_input_comparison
    FOREIGN KEY (comparison_id) REFERENCES comparison(id)
    ON DELETE CASCADE,
  UNIQUE KEY unique_comparison_input (comparison_id, input_side)
);

-- Records each successful or failed ML_GENERATE attempt independently for one input.
-- response_text contains generated output only and is never treated as approved data.
CREATE TABLE IF NOT EXISTS ai_formatting_run (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  comparison_input_id BIGINT UNSIGNED NOT NULL,
  model_id VARCHAR(128) NOT NULL,
  run_status ENUM('COMPLETED','FAILED') NOT NULL,
  response_text MEDIUMTEXT NULL,
  error_code VARCHAR(64) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_ai_run_input
    FOREIGN KEY (comparison_input_id) REFERENCES comparison_input(id)
    ON DELETE CASCADE,
  INDEX idx_ai_run_input (comparison_input_id, created_at)
);

-- Stores immutable AI suggestions beside editable representative-reviewed values.
-- Group numbers express user-selected alignment, not vendor product equivalence.
CREATE TABLE IF NOT EXISTS comparison_line (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  comparison_input_id BIGINT UNSIGNED NOT NULL,
  ai_formatting_run_id BIGINT UNSIGNED NULL,
  line_number INT UNSIGNED NOT NULL,
  comparison_group INT UNSIGNED NULL,
  entry_method ENUM('AI','MANUAL') NOT NULL,
  suggested_sku VARCHAR(128) NULL,
  suggested_description VARCHAR(500) NULL,
  suggested_quantity DECIMAL(12,2) NULL,
  suggested_annual_unit_price DECIMAL(14,2) NULL,
  ai_confidence ENUM('high','medium','low','unknown') NULL,
  ai_warnings JSON NULL,
  sku VARCHAR(128) NULL,
  description VARCHAR(500) NULL,
  quantity DECIMAL(12,2) NULL,
  annual_unit_price DECIMAL(14,2) NULL,
  review_status ENUM('AI_SUGGESTED','CONFIRMED','EXCLUDED','UNRESOLVED')
    NOT NULL DEFAULT 'AI_SUGGESTED',
  representative_note VARCHAR(500) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
    ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_line_input
    FOREIGN KEY (comparison_input_id) REFERENCES comparison_input(id)
    ON DELETE CASCADE,
  CONSTRAINT fk_line_ai_run
    FOREIGN KEY (ai_formatting_run_id) REFERENCES ai_formatting_run(id)
    ON DELETE SET NULL,
  UNIQUE KEY unique_input_line (comparison_input_id, line_number),
  CHECK (quantity IS NULL OR quantity > 0),
  CHECK (annual_unit_price IS NULL OR annual_unit_price >= 0)
);

-- Stores one deterministic annual, three-year, and five-year snapshot per comparison.
-- Recalculation replaces the snapshot, while source and reviewed lines remain traceable.
CREATE TABLE IF NOT EXISTS comparison_result (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  comparison_id BIGINT UNSIGNED NOT NULL UNIQUE,
  rhel_annual_total DECIMAL(16,2) NOT NULL,
  oracle_linux_annual_total DECIMAL(16,2) NOT NULL,
  annual_difference DECIMAL(16,2) NOT NULL,
  rhel_three_year_total DECIMAL(16,2) NOT NULL,
  oracle_linux_three_year_total DECIMAL(16,2) NOT NULL,
  three_year_difference DECIMAL(16,2) NOT NULL,
  rhel_five_year_total DECIMAL(16,2) NOT NULL,
  oracle_linux_five_year_total DECIMAL(16,2) NOT NULL,
  five_year_difference DECIMAL(16,2) NOT NULL,
  calculated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_result_comparison
    FOREIGN KEY (comparison_id) REFERENCES comparison(id)
    ON DELETE CASCADE,
  CHECK (rhel_annual_total >= 0),
  CHECK (oracle_linux_annual_total >= 0)
);

-- Captures workflow actions without storing credentials or duplicating source text.
-- Events belong to the workbook and are removed when that workbook is deleted.
CREATE TABLE IF NOT EXISTS application_event (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  comparison_id BIGINT UNSIGNED NOT NULL,
  event_type VARCHAR(64) NOT NULL,
  actor_type ENUM('AI','REPRESENTATIVE','APPLICATION') NOT NULL,
  outcome ENUM('COMPLETED','CONFIRMED','REJECTED','FAILED') NOT NULL,
  details JSON NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_event_comparison
    FOREIGN KEY (comparison_id) REFERENCES comparison(id)
    ON DELETE CASCADE,
  INDEX idx_event_comparison (comparison_id, created_at)
);

-- Retains only the minimum deletion evidence after the workbook and its children are gone.
CREATE TABLE IF NOT EXISTS comparison_deletion_audit (
  -- No foreign key points to comparison, so the audit survives workbook deletion.
  -- The owner foreign key preserves which durable user account owned the workbook.
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  deleted_comparison_id BIGINT UNSIGNED NOT NULL,
  owner_user_id BIGINT UNSIGNED NOT NULL,
  comparison_name VARCHAR(255) NOT NULL,
  deleted_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  UNIQUE KEY unique_deleted_comparison (deleted_comparison_id),
  CONSTRAINT fk_deletion_audit_owner
    FOREIGN KEY (owner_user_id) REFERENCES user_account(id),
  INDEX idx_deletion_audit_owner (owner_user_id, deleted_at)
);

-- Idempotent seed keeps repeat workshop runs aligned to the same demonstration policy.
INSERT INTO calculation_rule_version
  (version_label, description, source_reference, governance_status)
VALUES
  ('workshop-v2',
   'Annual line cost equals quantity multiplied by annual unit price. Three-year and five-year costs equal the confirmed annual amount multiplied by three and five.',
   'Oracle Linux Value Navigator Version 2 workshop demonstration rules',
   'DEMONSTRATION')
ON DUPLICATE KEY UPDATE description = VALUES(description);
